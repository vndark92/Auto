@echo off
setlocal
cd /d "%~dp0"
set "AUTOBANG_PY=.venv-bangthien-build\Scripts\python.exe"
if not exist "%AUTOBANG_PY%" set "AUTOBANG_PY=.venv-onefile\Scripts\python.exe"
if not exist "%AUTOBANG_PY%" (echo Run TAO_1_FILE_EXE.bat first. & pause & exit /b 1)
"%AUTOBANG_PY%" tools\package_inventory.py "%~dp0dist\AutoBangThien.exe"
if errorlevel 1 (echo Could not inspect EXE. & pause & exit /b 1)
echo Report: dist\AutoBangThien.size-report.json
pause
