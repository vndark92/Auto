"""Windows entry point exposing only boss use, filtering and stop/status."""
from pathlib import Path
import ctypes
import sys
import threading
import webview
import AutoProByEric_Stage17_Backend_v1_8 as core
from AutoProByEric_AutoBoss_v1 import AutoBossSessionController
from AutoProByEric_LicenseGuard_v1 import LICENSE_GUARD
from AutoProByEric_ClientOwnership_v1716 import ClientOwnership
from boss_only_flow import BossOnlyFlow

ROOT = Path(__file__).resolve().parent
class Controller(BossOnlyFlow, AutoBossSessionController):
    pass

class BossOnlyApi:
    def __init__(self):
        self._core = core.Api()
        self._core._cfg['input_mode'] = 'Foreground'
        self._core._cfg.setdefault('runtime', {})['module_running'] = {}
        self._boss = Controller(self._core, core, ROOT)
        self._boss.config['mode'] = 'KEEP'
        self._boss.config['filter_profile_ids'] = [1]
        self._owner = ClientOwnership(core.LOGDIR, shared=True)
        self._lock = threading.RLock()

    def setup(self):
        return {'windows': self._core.refresh_windows(), 'filter': self._core.get_option_filter_setup()}

    def start(self, hwnd, hotkey, seconds, confirmed, config, once=True):
        with self._lock:
            if self._boss.running: return {'ok':False,'reason':'ALREADY_RUNNING'}
            if not LICENSE_GUARD.status().get('active'): return {'ok':False,'reason':'LICENSE_NOT_ACTIVE'}
            if not confirmed: return {'ok':False,'reason':'ENABLE_INGAME_COMBAT_AND_LOOT_FIRST'}
            hwnd = int(hwnd or 0)
            if not core.window_exists(hwnd): return {'ok':False,'reason':'GAME_CLIENT_NOT_FOUND'}
            if hotkey not in ('Q','F4'): return {'ok':False,'reason':'INVALID_BAG_HOTKEY'}
            seconds = float(seconds)
            if not 10 <= seconds <= 120: return {'ok':False,'reason':'WAIT_MUST_BE_10_TO_120_SECONDS'}
            saved = self._core.save_option_filter(config)
            if not saved.get('ok'): return saved
            gate = self._core.filter_runtime_guard('AUTO_BOSS',selected_profile_ids=[1],require_enabled_rules=True)
            if not gate.get('ok'): return gate
            claim = self._owner.claim_client(hwnd, core._window_pid(hwnd))
            if not claim.get('ok'): return claim
            claim = self._owner.claim_physical_input()
            if not claim.get('ok'): return claim
            self._core._cfg['shortcut_mode'] = 'Kết hợp' if hotkey=='Q' else 'Mặc định'
            selected=self._core.set_selection(hwnd,'__all__')
            if not selected.get('ok'): return selected
            self._boss.update_config({'mode':'KEEP','boss_wait_sec':seconds,'ingame_auto_setup_confirmed':True,'filter_profile_ids':[1]})
            return self._boss.start(hwnd, bool(once))

    def stop(self):
        return self._boss.stop('USER_UI_STOP')

    def status(self):
        status = self._boss.status()
        return {k:status.get(k) for k in ('running','state','cycle','counters','last_error','loot_queue','bag_free')}

    def logs(self):
        import os
        os.startfile(str(core.LOGDIR))
        return {'ok':True}


def main():
    if sys.platform != 'win32': raise SystemExit('Windows required')
    if not ctypes.windll.shell32.IsUserAnAdmin():
        import subprocess
        args = '' if getattr(sys,'frozen',False) else subprocess.list2cmdline([str(Path(__file__).resolve())])
        rc=ctypes.windll.shell32.ShellExecuteW(None,'runas',sys.executable,args,str(ROOT),1)
        if int(rc)<=32: raise SystemExit('Administrator permission required')
        return
    license_result=LICENSE_GUARD.startup_validate_with_setup()
    if not license_result.get('active'): raise SystemExit('License is not active')
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('BangThien.Auto')
    api=BossOnlyApi()
    LICENSE_GUARD.start_monitor(on_invalid=lambda reason:api._boss.stop('LICENSE_INVALID'))
    window=webview.create_window('Auto Bang Thiên',str(ROOT/'boss_only.html'),js_api=api,width=1080,height=800,min_size=(800,600))
    def closing():
        if api._boss.running:
            api.stop()
            return False
        api._owner.close()
    from bangthien_window_icon import apply_window_icon
    window.events.shown += apply_window_icon
    window.events.closing += closing
    webview.start(debug=False)

if __name__=='__main__': main()
