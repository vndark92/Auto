"""Inspect compressed contents of an existing PyInstaller EXE without executing it."""
import json
from pathlib import Path
from collections import defaultdict

def report(executable, output):
    from PyInstaller.archive.readers import CArchiveReader
    exe=Path(executable)
    groups=defaultdict(int); rows=[]
    for name,entry in CArchiveReader(str(exe)).toc.items():
        _,compressed,uncompressed,_,kind=entry
        normalized=name.replace('\\','/')
        group=normalized.split('/')[0] if '/' in normalized else '[root binaries/code]'
        groups[group]+=compressed
        rows.append({'path':name,'compressed_bytes':compressed,'uncompressed_bytes':uncompressed,'type':kind})
    result={'exe':exe.name,'exe_bytes':exe.stat().st_size,'groups_compressed_bytes':dict(sorted(groups.items(),key=lambda x:-x[1])), 'largest_entries':sorted(rows,key=lambda r:-r['compressed_bytes'])[:80]}
    Path(output).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
if __name__=='__main__':
    import sys
    target=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'dist'/'AutoBangThien.exe'
    result=report(target,target.with_suffix('.size-report.json'))
    print('EXE:',round(result['exe_bytes']/1024/1024,2),'MiB')
    for name,size in list(result['groups_compressed_bytes'].items())[:15]: print(f'{size/1024/1024:8.2f} MiB  {name}')
