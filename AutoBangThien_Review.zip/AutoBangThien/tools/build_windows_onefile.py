"""Generate ONE standalone AutoProByEric_V1.7.16.exe on Windows 64-bit.

No feature changes. PyInstaller extraction to _MEIPASS is transient, persistent
settings/logs are staged per EXE installation under %LOCALAPPDATA%.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import shutil
import ast

ROOT = Path(__file__).resolve().parent.parent
NAME = "AutoBangThien"
VERSION = "1.7.16-boss-only"
MUTABLE_NAMES = {
    "AutoProByEric_UserOptionFilter.json", "AutoProByEric_AutoRollRecordCoord_v1.json",
    "AutoProByEric_AutoBoss_v1.json", "input_tool.json", "license_client.json",
    "AutoProByEric_Stage16_FilterSample_v1.6.json",
    "autopro_runtime_config.json", "ocr_path.json", "shop_open_guard_v8_8.json",
    "shop_open_reference_v8_8.png",
}
INCLUDE_SUFFIX = {".py", ".html", ".css", ".js", ".json", ".png", ".ico"}


def local_modules():
    """Follow local Python imports, including lazy imports, without running modules."""
    pending = ['boss_only_app']
    found = set()
    while pending:
        name = pending.pop()
        if name in found: continue
        path = ROOT / (name + '.py')
        if not path.is_file(): continue
        found.add(name)
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8-sig'))):
            if isinstance(node, ast.Import):
                pending.extend(alias.name.split('.')[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                pending.append(node.module.split('.')[0])
    return sorted(found)


def payload_files():
    files = [ROOT / (name + '.py') for name in local_modules()]
    files += [ROOT / name for name in ('boss_only.html','boss_only.js','AutoBangThien.ico','AutoBangThien.png')]
    # Retain runtime configurations and recognition dictionaries; omit build reports.
    excluded = {'onefile_payload_manifest.json','BUILD_VERSION.json','LEAN_PACKAGE_MANIFEST.json',
                'MANIFEST_V1716.json','VERSION_V1715.json','VERSION_V1716.json',
                'ENV_STATUS.json','PADDLEOCR_ENGINE_STATUS.json','build-payload-report.json','build-size-report.json'}
    files += [p for p in ROOT.glob('*.json') if p.name not in excluded]
    for folder_name in ('Data',):
        files += [p for p in (ROOT / folder_name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    for name in ('eng.traineddata','vie.traineddata','NOTICE.txt'):
        p=ROOT/'runtime'/'tessdata'/name
        if p.exists(): files.append(p)
    # All native DLL dependencies retained; exclude OCR training tools, docs,
    # duplicate language models and unrelated language packs.
    tess=ROOT/'runtime'/'tesseract'
    if tess.exists():
        files += [p for p in tess.rglob('*') if p.is_file() and
                  (p.suffix.lower()=='.dll' or p.name.lower()=='tesseract.exe' or
                   p.name.lower().startswith(('license','copying','notice')) or
                   any(part in ('configs','tessconfigs') for part in p.relative_to(tess).parts))]
    return sorted(set(p for p in files if p.is_file()))


def make_manifest(paths):
    records = []
    for file in paths:
        rel = file.relative_to(ROOT).as_posix()
        records.append({
            "path": rel,
            "sha256": hashlib.sha256(file.read_bytes()).hexdigest(),
            # Never overwrite user configs or the taught data registry on update.
            "mutable": file.name in MUTABLE_NAMES or rel.startswith("Data/"),
        })
    manifest = {"version": VERSION, "files": records}
    target = ROOT / "onefile_payload_manifest.json"
    target.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return target


def write_spec(paths, manifest):
    """Store data arguments in a spec file; never grow the Windows command line."""
    data = [(str(file), str(file.relative_to(ROOT).parent)) for file in [*paths, manifest]]
    spec = ROOT / f"{NAME}.spec"
    source = "from PyInstaller.utils.hooks import collect_all\n"
    source += f"datas = {data!r}\nbinaries = []\n"
    source += "hiddenimports = ['pytesseract', 'mss', 'PIL', 'clr', 'webview.platforms.winforms']\n"
    source += "def include_ocr_module(name):\n    return name != 'paddle.jit.sot' and not name.startswith('paddle.jit.sot.')\n"
    source += f"hiddenimports += {local_modules()!r}\n"
    source += "for package in ['paddleocr', 'paddle']:\n"
    source += "    d, b, h = collect_all(package, filter_submodules=include_ocr_module)\n    datas += d\n    binaries += b\n    hiddenimports += h\n"
    source += f"a = Analysis([{str(ROOT / 'tools' / 'onefile_launcher.py')!r}], pathex=[{str(ROOT)!r}], binaries=binaries, datas=datas, hiddenimports=hiddenimports, hookspath=[], hooksconfig={{}}, runtime_hooks=[], excludes=['webview.platforms.qt','webview.platforms.gtk','webview.platforms.cocoa','webview.platforms.cef'], noarchive=False)\n"
    source += "pyz = PYZ(a.pure)\n"
    source += f"exe = EXE(pyz, a.scripts, a.binaries, a.datas, [], name={NAME!r}, debug=False, bootloader_ignore_signals=False, strip=False, upx=False, console=False, icon={str(ROOT / 'AutoBangThien.ico')!r})\n"
    spec.write_text(source, encoding="utf-8")
    return spec


def build():
    if os.name != "nt" or platform.machine().lower() not in ("amd64", "x86_64"):
        raise SystemExit("ERROR: Build requires Windows x64. This machine cannot cross-compile PyInstaller Windows packages.")
    # Vendor an existing local Windows Tesseract distribution before writing
    # the manifest. This is required because _MEIPASS is temporary and the
    # application needs a stable executable in its profile after extraction.
    bundled_tesseract = ROOT / "runtime" / "tesseract"
    machine_tesseract = Path(os.environ.get("PROGRAMFILES", "C:/Program Files")) / "Tesseract-OCR"
    vendor_tesseract = ROOT / "vendor" / "Tesseract-OCR"
    if not (bundled_tesseract / "tesseract.exe").is_file():
        for source in (vendor_tesseract, machine_tesseract):
            if (source / "tesseract.exe").is_file():
                shutil.copytree(source, bundled_tesseract, dirs_exist_ok=True)
                print("Bundled Windows Tesseract from", source, flush=True)
                break
    if not (bundled_tesseract / "tesseract.exe").is_file():
        raise SystemExit("BUILD BLOCKED: Tesseract.exe not found. Install Tesseract-OCR x64 on this Windows builder or copy its complete directory into vendor\\Tesseract-OCR. This prevents distributing a one-file build with broken Tesseract OCR.")
    # Test the native runtime separately before PyInstaller starts its scanner.
    # A native crash cannot be caught by Python try/except in the same process.
    print("Checking Paddle/PaddleOCR imports...", flush=True)
    probe = subprocess.run([sys.executable, "-X", "faulthandler", "-c",
                            "import paddle; print('Paddle', paddle.__version__, flush=True); from paddleocr import PaddleOCR; print('PaddleOCR import OK', flush=True)"],
                           cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ROOT / 'build-preflight.log').write_text(probe.stdout or '', encoding='utf-8')
    print(probe.stdout or '', flush=True)
    if probe.returncode:
        raise SystemExit(f"Paddle import failed before packaging (exit {probe.returncode}). See build-preflight.log; this is a runtime installation problem.")
    paths = payload_files()
    if not (ROOT / "boss_only_app.py") in paths:
        raise SystemExit("Missing application source")
    total=sum(p.stat().st_size for p in paths)
    (ROOT/'build-payload-report.json').write_text(json.dumps({'payload_bytes':total,'files':[
        {'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size} for p in paths]},indent=2),encoding='utf-8')
    print(f"Application payload: {len(paths)} files, {total/1024/1024:.2f} MiB before compression",flush=True)
    manifest = make_manifest(paths)
    spec = write_spec(paths, manifest)
    cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean",
           "--distpath", str(ROOT / "dist"), "--workpath", str(ROOT / "build"), str(spec)]
    print("Building one-file Windows EXE (this can be large)...", flush=True)
    with (ROOT / 'build-onefile.log').open('w', encoding='utf-8') as log:
        with subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True, encoding='utf-8', errors='replace',
                              env={**os.environ, 'PYTHONUTF8': '1'}) as process:
            for line in process.stdout:
                print(line, end='', flush=True)
                log.write(line)
                log.flush()
            code = process.wait()
    if code:
        raise SystemExit(f"PyInstaller failed (exit {code}). See build-onefile.log for the full error.")
    out = ROOT / "dist" / f"{NAME}.exe"
    if not out.is_file() or out.open("rb").read(2) != b"MZ":
        raise SystemExit("EXE was not generated or is not PE executable")
    print("BUILD OK:", out, "bytes:", out.stat().st_size, flush=True)
    from package_inventory import report
    report(out, ROOT/'build-size-report.json')
    print('Size breakdown saved to build-size-report.json', flush=True)
    print("One EXE is the only required distribution artifact (Windows runtimes such as WebView2 may still be required).")


if __name__ == "__main__":
    build()
