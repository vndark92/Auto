"""Runtime entry point for the V1.7.16 one-file Windows distribution.

PyInstaller supplies the Python runtime and extracts dependencies to _MEIPASS.
Application data is staged into a stable writable per-exe profile. Never write
runtime configuration into _MEIPASS; it is temporary and removed on exit.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import tempfile
import traceback

VERSION = "1.7.16-boss-only"
MAIN = "boss_only_app.py"
MANIFEST = "onefile_payload_manifest.json"


def app_dir(executable: Path, localappdata: Path) -> Path:
    """One install location => one durable profile; copies can run separate accs."""
    absolute = str(executable.resolve()).casefold()
    unique = hashlib.sha256(absolute.encode("utf-8")).hexdigest()[:12]
    friendly = "".join(c if c.isalnum() or c in "-_" else "_" for c in executable.stem)[:30]
    return localappdata / "AutoProByEric" / ("V" + VERSION) / "instances" / f"{friendly}_{unique}"


def _atomic_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix="." + dst.name + ".", suffix=".tmp", dir=dst.parent)
    os.close(fd)
    try:
        shutil.copyfile(src, temp)
        os.replace(temp, dst)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


@contextlib.contextmanager
def _profile_lock(profile: Path):
    """Serialize staging when the same EXE is started twice on Windows."""
    profile.mkdir(parents=True, exist_ok=True)
    with (profile / ".onefile_setup.lock").open("a+b") as f:
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            if f.read(1) != b"X":
                f.seek(0)
                f.write(b"X")
                f.flush()
            f.seek(0)
            # Blocking lock waits for the other launch to finish extraction.
            msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if os.name == "nt":
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def stage_payload(bundle: Path, profile: Path):
    """Copy only application resources from extracted bundle into writable profile.

    Static resources refresh on version/hash changes; user-editable data never
    gets overwritten after its first initialization.
    """
    plan = json.loads((bundle / MANIFEST).read_text(encoding="utf-8"))
    if plan.get("version") != VERSION:
        raise RuntimeError("Wrong embedded application version")
    entries = plan.get("files")
    if not isinstance(entries, list) or not entries:
        raise RuntimeError("Empty onefile payload")
    with _profile_lock(profile):
        for record in entries:
            rel = record["path"]
            path = Path(rel)
            if path.is_absolute() or ".." in path.parts or ":" in rel or "\\" in rel:
                raise RuntimeError("Unsafe embedded resource path: " + rel)
            source, dest = bundle / path, profile / path
            if not source.is_file():
                raise RuntimeError("Missing resource in EXE: " + rel)
            expected = record["sha256"]
            if hashlib.sha256(source.read_bytes()).hexdigest() != expected:
                raise RuntimeError("Embedded resource checksum mismatch: " + rel)
            if dest.is_file():
                if record.get("mutable", False):
                    continue
                if hashlib.sha256(dest.read_bytes()).hexdigest() == expected:
                    continue
            _atomic_copy(source, dest)
        (profile / ".onefile_version").write_text(VERSION + "\n", encoding="ascii")
    return plan


def _init_ocr_paths(profile: Path):
    """Use bundled Tesseract when present; OS-installed OCR is a fallback."""
    tess = profile / "runtime" / "tesseract" / "tesseract.exe"
    if tess.is_file():
        os.environ["PATH"] = str(tess.parent) + os.pathsep + os.environ.get("PATH", "")
        os.environ["TESSDATA_PREFIX"] = str(profile / "runtime" / "tessdata")
        # pytesseract defaults to 'tesseract' and can find the bundled exe in PATH.


def _show_error(title: str, body: str):
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, body[:3000], title, 0x10)
    except Exception:
        if sys.stderr is not None:
            print(title + "\n" + body, file=sys.stderr)


def main():
    frozen = bool(getattr(sys, "frozen", False))
    if frozen and os.name != "nt":
        raise RuntimeError("V1.7.16 Windows build only")
    bundled = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent)).resolve()
    exe = Path(sys.executable if frozen else __file__)
    local = Path(os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share"))
    profile = app_dir(exe, local)
    try:
        stage_payload(bundled, profile)
        _init_ocr_paths(profile)
        os.chdir(profile)
        sys.path.insert(0, str(profile))
        # Do not import application modules in this launcher: they must resolve
        # from the persistent profile, not PyInstaller's ephemeral _MEIPASS.
        runpy.run_path(str(profile / MAIN), run_name="__main__")
    except Exception as err:
        profile.mkdir(parents=True, exist_ok=True)
        trace = "".join(traceback.format_exception(type(err), err, err.__traceback__))
        try:
            (profile / "STARTUP_ERROR.log").write_text(trace, encoding="utf-8")
        except Exception:
            pass
        _show_error("Auto Bang Thiên", "Không thể khởi động ứng dụng.\n\n"
                    + str(err)[:700] + "\n\nNhật ký lỗi:\n" + str(profile / "STARTUP_ERROR.log"))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
