"""Assign the application ICO to this process's Windows title/taskbar icons."""
from pathlib import Path
import os
import ctypes
from ctypes import wintypes

_handles = []  # Keep icon resources alive for the lifetime of the window.

def apply_window_icon():
    if os.name != 'nt':
        return
    user = ctypes.WinDLL('user32', use_last_error=True)
    user.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT,
                               ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user.LoadImageW.restype = wintypes.HANDLE
    user.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user.SendMessageW.restype = ctypes.c_ssize_t
    user.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    user.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
    path = str(Path(__file__).resolve().parent / 'AutoBangThien.ico')
    @callback_type
    def visit(hwnd, _):
        pid = wintypes.DWORD()
        user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value != os.getpid():
            return True
        title = ctypes.create_unicode_buffer(256)
        user.GetWindowTextW(hwnd, title, len(title))
        if title.value != 'Auto Bang Thiên':
            return True
        for kind, size in ((0, 32), (1, 256)):
            handle = user.LoadImageW(None, path, 1, size, size, 0x10)
            if handle:
                _handles.append(handle)
                user.SendMessageW(hwnd, 0x80, kind, handle)
        return True
    user.EnumWindows(visit, 0)
