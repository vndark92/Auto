import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from tools import build_windows_onefile as build

class PayloadTests(unittest.TestCase):
    def test_local_dependency_closure_and_runtime_resources(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            entries={'boss_only_app.py':'import needed\n','needed.py':'def lazy():\n import nested\n','nested.py':'','old_ui.py':'',
                'boss_only.html':'','boss_only.js':'','AutoBangThien.ico':'','AutoBangThien.png':'',
                'assets/old-background.png':'','AutoProByEric_icon.png':'','Data/recognition.png':'',
                'AutoProByEric_UserOptionFilter.json':'{}','build-size-report.json':'{}',
                'runtime/tessdata/eng.traineddata':'','runtime/tessdata/vie.traineddata':'',
                'runtime/tesseract/tesseract.exe':'','runtime/tesseract/lib/dependency.dll':'',
                'runtime/tesseract/tessdata/eng.traineddata':'','runtime/tesseract/tessdata/deu.traineddata':'',
                'runtime/tesseract/combine_tessdata.exe':'','runtime/tesseract/LICENSE':'',
                'runtime/tesseract/tessdata/configs/quiet':''}
            for name,content in entries.items():
                p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
            with patch.object(build,'ROOT',root):
                files={p.relative_to(root).as_posix() for p in build.payload_files()}
            for name in ('boss_only_app.py','needed.py','nested.py','Data/recognition.png','AutoProByEric_UserOptionFilter.json','runtime/tesseract/tesseract.exe','runtime/tesseract/lib/dependency.dll','runtime/tessdata/vie.traineddata','runtime/tesseract/LICENSE'):
                self.assertIn(name,files)
            for name in ('assets/old-background.png','old_ui.py','AutoProByEric_icon.png','runtime/tesseract/tessdata/eng.traineddata','runtime/tesseract/tessdata/deu.traineddata','runtime/tesseract/combine_tessdata.exe','build-size-report.json'):
                self.assertNotIn(name,files)
