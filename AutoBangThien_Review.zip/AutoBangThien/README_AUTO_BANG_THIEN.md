# Auto Bang Thiên — chỉ dùng lệnh bài và lọc đồ

Đây là bản nguồn thử nghiệm Windows, chưa phải EXE đã xác minh trong game.

## Phạm vi
- Sử dụng vật phẩm đã đặt ở ô phím 1 (không tìm vật phẩm bằng tên).
- Người dùng bật Auto đánh và nhặt có sẵn trong game trước khi bắt đầu.
- Ứng dụng ghi nhận hành trang Q/F4, gửi phím 1 một lần, chờ/quan sát đồ mới, đọc thuộc tính và lọc.
- Đạt mọi điều kiện đang chọn: giữ tại chỗ. Không đạt có kết quả chắc chắn: vứt. Chưa đọc chắc chắn: giữ và dừng báo lỗi.
- Không có màn hình Mở rương, Roll, NPC, cất kho, đường đi A/B hoặc phím buff.
- Không bật/tắt Ctrl+F. Các module đọc ảnh, bộ lọc và điều khiển dùng chung vẫn được giữ làm thư viện nội bộ.

## Build và chạy
Python 3.12 x64 và Tesseract Windows như bản trước. Giải nén vào thư mục mới, chạy TAO_1_FILE_EXE.bat. Mở dist\AutoBangThien.exe, không mở EXE cũ.
Cấu hình bản Boss-only nằm trong profile riêng; không sao chép thư mục .venv từ vị trí khác.
Các bản sửa build .spec và quét Paddle đã được giữ lại. Khi build lỗi, xem build-preflight.log và build-onefile.log.

## Kiểm tra lần đầu
Chọn cửa sổ game, chọn Q hoặc F4 đúng với game, đặt thời gian chờ đủ để game đánh/nhặt, cấu hình ít nhất một điều kiện, xác nhận Auto game và lệnh bài đã sẵn sàng. Chạy 1 lượt có tiêu hao lệnh bài và có thể vứt đồ không đạt; chỉ thử với đồ được phép loại bỏ.
Đồ mới chỉ được xử lý khi các ô của nó được xác nhận trống trước lượt; ô cũ hoặc không chắc chắn làm dừng phiên. Không di chuyển/sắp xếp đồ bằng tay khi đang chạy.

## Giới hạn cần kiểm chứng
- Chờ theo thời gian cấu hình, chưa nhận diện trực tiếp boss chết. Không thấy đồ mới sẽ dừng, không dùng tiếp lệnh bài.
- Bộ nhận diện hành trang và OCR vẫn cần kiểm tra trên ảnh/game thật của người dùng. Chưa chứng minh đã hết lỗi nhận diện trên Windows.
- Giữ hành trang mở để theo dõi trong lượt. Game phải hỗ trợ đánh và nhặt khi hành trang đang mở.
- 35 kiểm thử Python đạt, gồm 7 kiểm thử điều phối mới; kiểm thử Chromium dùng API giả lập, không thay cho kiểm thử game.
- Danh sách API giao diện mới chỉ có setup/start/stop/status/logs; các thao tác cũ không được đưa lên giao diện.

## Nhận diện ứng dụng
Tên hiển thị: Auto Bang Thiên. Tệp chạy: dist\AutoBangThien.exe. Icon vàng được nhúng vào EXE và dùng cho cửa sổ Windows. Chưa xác minh hiển thị taskbar trên Windows thực tế.

## Bản thu gọn gói build
- Không collect_all toàn bộ webview, cv2, pythonnet và win32com. Dùng phân tích phụ thuộc + hook chuẩn của PyInstaller; chỉ backend Windows của giao diện được yêu cầu.
- Giữ Paddle/PaddleOCR vì bộ đọc thuộc tính sử dụng nó làm bằng chứng bổ sung. Không loại bỏ OCR hoặc đổi kết luận lọc để giảm dung lượng.
- Payload chỉ chứa các module nội bộ cần từ entry point, giao diện hiện tại, cấu hình và bộ ảnh nhận diện. Không nhúng nền trang trí cũ, icon trùng hoặc báo cáo build.
- Tesseract chỉ nhúng tesseract.exe, các DLL, cấu hình và thông báo bản quyền; chỉ có một bản eng/vie.traineddata. Bỏ tiện ích huấn luyện và bộ ngôn ngữ khác.
- Build dùng .venv-bangthien-build riêng để không bị ảnh hưởng bởi thư viện thừa từ môi trường cũ.
- Sau build có build-payload-report.json và build-size-report.json. Có thể chạy KIEM_TRA_DUNG_LUONG.bat để đọc dung lượng từng thành phần trong EXE mà không chạy ứng dụng.
- Trên bộ nguồn Linux hiện tại, payload ứng dụng giảm từ 13,979,180 xuống 8,947,533 byte (chưa gồm DLL Windows/thư viện Python). Đây không phải dung lượng EXE. Chưa đo mức giảm EXE trên Windows.
