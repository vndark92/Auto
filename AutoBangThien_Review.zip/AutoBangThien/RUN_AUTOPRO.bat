@echo off
cd /d "%~dp0"
".venv-bangthien-build\Scripts\python.exe" boss_only_app.py
pause
