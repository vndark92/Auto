# Auto Pro V1.7.16 — UI Tabs review build

Bản nguồn để thử nghiệm giao diện trên Windows, chưa phải EXE đã build.

## Thay đổi
- Sáu tab: Tổng quan, Tự động, Bộ lọc, Túi & Kho, Nhật ký, Cài đặt.
- Mở rương / Roll / Boss là tab con của Tự động. Đường dẫn NPC cũ chuyển tới Roll.
- Bố cục cuộn, cỡ chữ lớn hơn, nền tối đơn giản; điều hướng bằng phím mũi tên, Home, End.
- Giữ các ID điều khiển và bộ điều khiển runtime; chuyển tab không tạo lại các ô cấu hình.
- Thanh chọn cửa sổ và nút Dừng tất cả luôn ở trên khi cuộn. Kéo tên ứng dụng để di chuyển.
- Dừng tất cả gửi yêu cầu tới các bộ điều khiển, hủy tự chạy lại của Mở rương và báo riêng các lệnh không xác nhận được. Thông báo đã gửi không có nghĩa mọi thao tác đã dừng ngay.
- PyInstaller dùng tệp .spec chứa danh sách tài nguyên để tránh lệnh quá dài (WinError 206).

## Thử trên Windows
1. Giải nén vào thư mục mới, ví dụ C:\AP-Tabs. Không chép đè cấu hình đang dùng.
2. Chạy TAO_1_FILE_EXE.bat với Python 3.12 x64 và Tesseract Windows đã cài.
3. Nếu thành công, mở dist\AutoProByEric_V1.7.16.exe.
4. Kiểm tra sáu tab, chọn cửa sổ game, lưu/đọc bộ lọc, phím tắt và dừng an toàn.
5. Kiểm tra Windows Scale 100%, 125%, 150%; thử các thao tác không gây mất vật phẩm trước.

## Kết quả ở Linux
- 28 bài Python đạt (27 regression hiện có + kiểm tra spec với 600 đường dẫn Unicode).
- Chromium: tám trang ở chiều rộng 1387 / 1109 / 925 CSS px; chuyển tab, bàn phím, giữ lựa chọn và báo lỗi từng lệnh dừng đạt.
- Kiểm tra trình duyệt dùng mock cho lệnh dừng; không phải kiểm thử kết nối game/Windows.
- Chưa build hoặc chạy EXE Windows; PaddleOCR, WebView2 và Windows Scale thực tế vẫn cần xác minh.

## Kiểm thử giao diện
Cài Playwright vào môi trường công cụ; phục vụ thư mục nguồn bằng HTTP cục bộ, cổng 8765.
Chạy node tests/ui_tabs.cjs (mặc định Chromium tại /usr/bin/chromium trên Linux).
Có thể đặt AUTOPRO_UI_URL để đổi URL. Kiểm tra Python: python -m unittest discover -s tests -v.
