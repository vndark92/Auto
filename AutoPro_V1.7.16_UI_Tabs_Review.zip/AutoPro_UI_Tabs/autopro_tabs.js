/* Presentation only: retain the existing runtime functions and DOM nodes. */
(function(){
  window.beginNativeDrag=function(){window.pywebview?.api?.begin_window_drag?.()};
  window.syncModernTabs=function(page){
    const automation=['chest','roll','boss'].includes(page);
    document.getElementById('automationTabs').hidden=!automation;
    document.querySelectorAll('.navbtn[data-module]').forEach(b=>{
      const selected=b.dataset.module===(automation?'chest':page);
      b.classList.toggle('active',selected);b.setAttribute('aria-selected',String(selected));b.tabIndex=selected?0:-1;
    });
    document.querySelectorAll('#automationTabs button').forEach(b=>{
      const selected=b.dataset.mode===page;b.setAttribute('aria-selected',String(selected));b.tabIndex=selected?0:-1;
    });
    document.querySelectorAll('.ice-page').forEach(p=>{p.setAttribute('role','tabpanel');p.setAttribute('aria-label',ICE_PAGE_LABELS[p.dataset.page]||p.dataset.page)});
  };
  document.addEventListener('DOMContentLoaded',()=>{
    const brand=document.querySelector('.v2-brand');
    brand.title='Kéo để di chuyển cửa sổ; nhấp đúp để phóng to';
    brand.addEventListener('pointerdown',e=>{if(e.button===0)window.beginNativeDrag()});
    brand.addEventListener('dblclick',()=>toggleMaximize());
    document.querySelectorAll('[role=tablist]').forEach(list=>list.addEventListener('keydown',e=>{
      const buttons=[...list.querySelectorAll('[role=tab]')];let i=buttons.indexOf(document.activeElement);
      if(i<0)return;
      if(e.key==='ArrowRight')i=(i+1)%buttons.length;else if(e.key==='ArrowLeft')i=(i+buttons.length-1)%buttons.length;
      else if(e.key==='Home')i=0;else if(e.key==='End')i=buttons.length-1;else return;
      e.preventDefault();buttons[i].focus();buttons[i].click();
    }));
    // Keep technical diagnostics available without filling the main workflow.
    for(const selector of ['.ProdContainerDebugRows','.ProdLogJson']){
      document.querySelectorAll(selector).forEach(node=>{
        const details=document.createElement('details'),summary=document.createElement('summary');
        summary.textContent='Chi tiết kỹ thuật';node.before(details);details.append(summary,node);
      });
    }
    document.querySelectorAll('input:not([type=hidden]),select').forEach(el=>{
      if(!el.labels?.length&&!el.getAttribute('aria-label'))el.setAttribute('aria-label',el.closest('label')?.textContent?.trim()||el.title||el.id||'Thiết lập');
    });
    document.querySelectorAll('.header-status strong,.header-status .tinyline').forEach(el=>el.style.fontSize='14px');
    const labels={'GENERAL':'CÀI ĐẶT CHUNG','INPUT':'ĐIỀU KHIỂN','AUTO RESUME':'TỰ CHẠY LẠI','CLIENT':'CỬA SỔ GAME','LOGGING':'NHẬT KÝ','PROFILE':'BỘ ĐIỀU KIỆN','PROFILE FILTER':'BỘ LỌC ÁP DỤNG','FLOW':'KẾT QUẢ XỬ LÝ','C. NEW ITEM QUEUE':'DANH SÁCH VẬT PHẨM MỚI','Inventory hotkey':'Phím mở túi đồ','Start with Windows':'Khởi động cùng Windows','Minimize to tray':'Thu nhỏ xuống khay','Selected client':'Cửa sổ đã chọn','Admin / elevation':'Quyền quản trị','Log level':'Mức ghi nhật ký','Enable':'Bật','Operator':'Điều kiện','Value':'Giá trị','Option':'Thuộc tính','Trong profile':'Trong một bộ lọc','Giữa 4 profile':'Giữa các bộ lọc','Không cross-profile merge':'Mỗi bộ lọc được xét riêng','UI scale':'Kích thước giao diện'};
    const walker=document.createTreeWalker(document.querySelector('.app'),NodeFilter.SHOW_TEXT);
    while(walker.nextNode()){
      const node=walker.currentNode,key=node.textContent.trim();
      if(labels[key]&&!node.parentElement.closest('script,style,option'))node.textContent=node.textContent.replace(key,labels[key]);
    }
    syncModernTabs(activeUiPage);
    document.getElementById('windowSelect').addEventListener('change',()=>{
      document.getElementById('connectionHint').textContent=document.getElementById('windowSelect').value?'Đã chọn cửa sổ game · Kiểm tra bộ lọc và vị trí trong chức năng trước khi bắt đầu.':'Chưa chọn cửa sổ game.';
    });
  });
  window.addEventListener('pywebviewready',()=>{
    document.getElementById('connectionHint').textContent='Đã kết nối ứng dụng · Chọn cửa sổ game và kiểm tra thiết lập trước khi bắt đầu.';
  });
})();
