from __future__ import annotations
from typing import Dict, Any, List, Tuple

GROUP_LABELS = {
    "ao": "Áo",
    "baotay": "Bao tay",
    "dailung": "Đai",
    "daychuyen": "Dây chuyền",
    "giay": "Giày",
    "ngocboi": "Ngọc bội",
    "nhan": "Nhẫn",
    "non": "Nón",
    "vukhi": "Vũ khí",
}


# v5.5 — USER-PROVIDED ITEM IDENTITY RULES
#
# Hard weapon anchors: if any of these is read confidently, the item is a weapon
# regardless of a noisy inventory footprint.
WEAPON_HARD_ANCHORS = {
    "Tăng độ chính xác đòn đánh cận chiến",
    "Hỏa sát – ngoại công",
    "Hỏa sát – nội công",
    "Sát thương vật lý – ngoại công",
    "Sát thương vật lý – nội công",
    "Tốc độ đánh – ngoại công",
    "Tốc độ đánh – nội công",
    "Độc sát – nội công",
    "Độc sát – ngoại công",
    "Lôi sát – nội công",
    "Lôi sát – ngoại công",
    "Băng sát – nội công",
    "Băng sát – ngoại công",
}

# User says these identify the jewelry family (Dây chuyền / Ngọc bội).
JEWELRY_FAMILY_HARD_ANCHORS = {
    "Kháng tất cả",
}

# User-confirmed exclusive anchors.
SHOES_HARD_ANCHORS = {
    "Tốc độ di chuyển",
}

ARMOR_HARD_ANCHORS = {
    "Thời gian phục hồi",
}

# V1.7.5 user-confirmed slot-exclusive teaching anchors.
GLOVES_HARD_ANCHORS = {
    "Tăng công kích kỹ năng",
}

NECKLACE_HARD_ANCHORS = {
    "Mức kháng tính tối đa",
}

# This option was explicitly supplied in BOTH the weapon list and the
# Dây chuyền/Ngọc bội list. It must never hard-force either side by itself.
SHARED_IDENTITY_OPTIONS = {
    "Kỹ năng Võ công vốn có": {"vukhi", "daychuyen", "ngocboi", "nhan"},
}


def _footprint_group_for_allowed(footprint, allowed):
    """Use geometry only as a tie-breaker inside an already allowed family."""
    if not footprint or len(footprint) != 2:
        return None
    w, h = int(footprint[0]), int(footprint[1])
    allowed = set(allowed)

    # Jewelry geometry is canonical in this project.
    if (w, h) == (2, 1) and "daychuyen" in allowed:
        return "daychuyen"
    if (w, h) == (1, 2) and "ngocboi" in allowed:
        return "ngocboi"

    # Weapon geometries that cannot be Dây chuyền/Ngọc bội.
    weapon_shapes = {
        (1, 1), (2, 2),
        (1, 3), (3, 1),
        (1, 4), (4, 1),
    }
    if (w, h) in weapon_shapes and "vukhi" in allowed:
        return "vukhi"

    return None


def classify_group_from_options(recognized_names, footprint, option_db):
    """
    v5.9 SEARCH-FIRST GROUP POLICY

    Group is secondary metadata only.
    ONLY user-confirmed hard anchors can classify an item.

    All other items are "Chung" and are still fully searchable by option.
    """
    names = [x for x in (recognized_names or []) if x]
    name_set = set(names)

    weapon_hits = sorted(name_set & WEAPON_HARD_ANCHORS)
    shoes_hits = sorted(name_set & SHOES_HARD_ANCHORS)
    armor_hits = sorted(name_set & ARMOR_HARD_ANCHORS)
    jewelry_hits = sorted(name_set & JEWELRY_FAMILY_HARD_ANCHORS)
    gloves_hits = sorted(name_set & GLOVES_HARD_ANCHORS)
    necklace_hits = sorted(name_set & NECKLACE_HARD_ANCHORS)
    shared_hits = sorted(name_set & set(SHARED_IDENTITY_OPTIONS.keys()))

    evidence = {
        "weapon_hard_hits": weapon_hits,
        "shoes_hard_hits": shoes_hits,
        "armor_hard_hits": armor_hits,
        "jewelry_hard_hits": jewelry_hits,
        "gloves_hard_hits": gloves_hits,
        "necklace_hard_hits": necklace_hits,
        "shared_hits": shared_hits,
        "footprint_observed_only": list(footprint) if footprint else None,
        "footprint_used_for_identity": False,
    }

    hard = []
    if weapon_hits: hard.append("vukhi")
    if shoes_hits: hard.append("giay")
    if armor_hits: hard.append("ao")
    if jewelry_hits: hard.append("jewelry")
    if gloves_hits: hard.append("baotay")
    if necklace_hits: hard.append("daychuyen")

    if len(hard) > 1:
        return {
            "group_id": None,
            "group_label": "Chung",
            "family": "CONFLICT",
            "confidence": 0.0,
            "ambiguous": True,
            "identity_known": False,
            "reason": "HARD_RULE_CONFLICT",
            "evidence": evidence,
            "ranking": [],
            "recognized_options": names,
        }

    if weapon_hits:
        return {
            "group_id": "vukhi",
            "group_label": GROUP_LABELS["vukhi"],
            "family": "VŨ KHÍ",
            "confidence": 1.0,
            "ambiguous": False,
            "identity_known": True,
            "reason": "USER_CONFIRMED_WEAPON_ANCHOR",
            "evidence": evidence,
            "ranking": [],
            "recognized_options": names,
        }

    if shoes_hits:
        return {
            "group_id": "giay",
            "group_label": GROUP_LABELS["giay"],
            "family": "GIÀY",
            "confidence": 1.0,
            "ambiguous": False,
            "identity_known": True,
            "reason": "USER_CONFIRMED_SHOES_ANCHOR",
            "evidence": evidence,
            "ranking": [],
            "recognized_options": names,
        }

    if armor_hits:
        return {
            "group_id": "ao",
            "group_label": GROUP_LABELS["ao"],
            "family": "ÁO",
            "confidence": 1.0,
            "ambiguous": False,
            "identity_known": True,
            "reason": "USER_CONFIRMED_ARMOR_ANCHOR",
            "evidence": evidence,
            "ranking": [],
            "recognized_options": names,
        }

    if gloves_hits:
        return {
            "group_id": "baotay",
            "group_label": GROUP_LABELS["baotay"],
            "family": "BAO TAY",
            "confidence": 1.0,
            "ambiguous": False,
            "identity_known": True,
            "reason": "USER_CONFIRMED_GLOVES_ANCHOR",
            "evidence": evidence,
            "ranking": [],
            "recognized_options": names,
        }

    if necklace_hits:
        return {
            "group_id": "daychuyen",
            "group_label": GROUP_LABELS["daychuyen"],
            "family": "DÂY CHUYỀN",
            "confidence": 1.0,
            "ambiguous": False,
            "identity_known": True,
            "reason": "USER_CONFIRMED_NECKLACE_ANCHOR",
            "evidence": evidence,
            "ranking": [],
            "recognized_options": names,
        }

    if jewelry_hits:
        return {
            "group_id": None,
            "group_label": "Dây chuyền / Ngọc bội",
            "family": "DÂY CHUYỀN / NGỌC BỘI",
            "confidence": 1.0,
            "ambiguous": True,
            "identity_known": True,
            "reason": "USER_CONFIRMED_JEWELRY_FAMILY_ANCHOR",
            "evidence": evidence,
            "ranking": [],
            "recognized_options": names,
        }

    # Shared option(s), generic options, unusual footprints: all treated alike.
    return {
        "group_id": None,
        "group_label": "Chung",
        "family": "CHUNG",
        "confidence": 0.0,
        "ambiguous": True,
        "identity_known": False,
        "reason": (
            "SHARED_OPTION_NOT_A_DISCRIMINATOR"
            if shared_hits
            else "NO_USER_CONFIRMED_GROUP_ANCHOR"
        ),
        "evidence": evidence,
        "ranking": [],
        "recognized_options": names,
    }


def possible_groups_for_footprint(footprint) -> List[str]:
    """
    Footprint is a PRIOR only, never a hard identity when geometry is abnormal.

    Real-client evidence showed a false 4x2 candidate caused by changed-cell
    spill across adjacent inventory cells. The old fallback forced such shapes
    to Vũ khí, which made the OCR dictionary reject valid accessory/armor options.
    """
    all_groups = list(GROUP_LABELS.keys())

    if not footprint or len(footprint) != 2:
        return all_groups

    w, h = int(footprint[0]), int(footprint[1])

    # Implausible equipment footprint in this project -> do not guess group.
    if w <= 0 or h <= 0 or (w * h) > 6 or w > 4 or h > 4:
        return all_groups

    if (w, h) == (2, 3):
        # Real JX1 evidence: both Áo and some weapons can occupy 2x3. This is
        # only a search/UI hint; actual unique tooltip anchors own identity.
        return ["ao", "vukhi"]
    if (w, h) in ((1, 3), (3, 1), (1, 4), (4, 1)):
        return ["vukhi"]
    if (w, h) == (1, 1):
        return ["nhan", "vukhi"]
    if (w, h) == (1, 2):
        return ["ngocboi", "baotay", "vukhi"]
    if (w, h) == (2, 1):
        return ["daychuyen", "dailung", "vukhi"]
    if (w, h) == (2, 2):
        return ["non", "giay", "vukhi"]

    # Unknown canonical shape -> use all groups instead of forcing Vũ khí.
    return all_groups

    w, h = int(footprint[0]), int(footprint[1])

    if (w, h) == (2, 3):
        return ["ao"]
    if (w, h) in ((1, 3), (3, 1), (1, 4), (4, 1)):
        return ["vukhi"]
    if (w, h) == (1, 1):
        return ["nhan", "vukhi"]
    if (w, h) == (1, 2):
        return ["ngocboi", "baotay", "vukhi"]
    if (w, h) == (2, 1):
        return ["daychuyen", "dailung", "vukhi"]
    if (w, h) == (2, 2):
        return ["non", "giay", "vukhi"]

    return ["vukhi"]

def hover_points_for_candidate(candidate: Dict[str, Any], grid: Dict[str, Any]) -> List[Tuple[int,int]]:
    """
    Build robust hover points from ACTUAL occupied cells.

    v5.6 bug:
      for an inferred 2x2 footprint with only three occupied cells, the old
      routine tried:
        1) footprint center (can land on a cell boundary),
        2) anchor cell,
        3) bounding-box bottom-right (which may be EMPTY).
      That is exactly what happened on the real Q01 test.

    v5.7:
      - use candidate["cells"] first;
      - every point stays strictly inside a detected occupied cell;
      - add small inset variants for transparent sprite pixels;
      - inferred footprint is fallback only when cells are unavailable.
    """
    xs = [int(x) for x in grid["x_lines"]]
    ys = [int(y) for y in grid["y_lines"]]

    if len(xs) < 7 or len(ys) < 11:
        return []

    def cell_points(r, c):
        if not (0 <= r < 10 and 0 <= c < 6):
            return []

        x0, x1 = xs[c], xs[c+1]
        y0, y1 = ys[r], ys[r+1]
        w = max(4, x1-x0)
        h = max(4, y1-y0)

        # All positions are comfortably inside the cell; never on a grid line.
        cx = (x0+x1)//2
        cy = (y0+y1)//2
        dx = max(3, int(round(w*0.18)))
        dy = max(3, int(round(h*0.18)))

        return [
            (cx, cy),
            (min(x1-3, cx+dx), cy),
            (max(x0+3, cx-dx), cy),
            (cx, min(y1-3, cy+dy)),
            (cx, max(y0+3, cy-dy)),
        ]

    actual_cells = []
    for raw in candidate.get("cells", []) or []:
        if not isinstance(raw, (list, tuple)) or len(raw) != 2:
            continue
        r, c = int(raw[0]), int(raw[1])
        if 0 <= r < 10 and 0 <= c < 6 and (r,c) not in actual_cells:
            actual_cells.append((r,c))

    # Anchor first if it is one of the actually detected occupied cells.
    anchor = candidate.get("anchor", [0,0])
    try:
        ar, ac = int(anchor[0]), int(anchor[1])
    except Exception:
        ar, ac = 0, 0

    ordered_cells = []
    if (ar,ac) in actual_cells:
        ordered_cells.append((ar,ac))
    for rc in actual_cells:
        if rc not in ordered_cells:
            ordered_cells.append(rc)

    # Normal path: actual occupancy is the source of truth.
    pts = []
    for r,c in ordered_cells:
        for p in cell_points(r,c):
            if p not in pts:
                pts.append(p)

    if pts:
        # Keep the search bounded. 3 cells × center/insets is already robust.
        return pts[:12]

    # Fallback for legacy candidates without explicit cell data:
    fw, fh = [int(x) for x in candidate.get("footprint", [1,1])]
    c1 = min(6, ac + max(1, fw))
    r1 = min(10, ar + max(1, fh))
    if not (0 <= ac < 6 and 0 <= ar < 10 and c1 > ac and r1 > ar):
        return []

    fallback_cells = []
    for r in range(ar, r1):
        for c in range(ac, c1):
            fallback_cells.append((r,c))

    for r,c in fallback_cells:
        for p in cell_points(r,c):
            if p not in pts:
                pts.append(p)
    return pts[:12]


def score_reader_result(result: Dict[str, Any]) -> float:
    lines = result.get("lines", []) or []
    if len(lines) != 6:
        return -100.0

    ready = sum(1 for x in lines if x.get("status") == "READY")
    names = [float(x.get("name_confidence") or 0.0) for x in lines]
    values = [float(x.get("value_confidence") or 0.0) for x in lines]
    units = sum(1 for x in lines if x.get("unit"))
    recognized_names = sum(1 for x in lines if x.get("name"))

    score = (
        ready * 10.0 +
        recognized_names * 2.0 +
        units * 1.5 +
        sum(names) * 2.2 +
        sum(values) * 1.6
    )
    if result.get("status") == "READY":
        score += 8.0
    return round(score, 4)

def choose_best_group(group_results: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    ranked = []
    for gid, result in group_results.items():
        ranked.append((score_reader_result(result), gid, result))
    ranked.sort(reverse=True, key=lambda x: x[0])

    if not ranked:
        return {
            "group_id": None,
            "group_label": None,
            "confidence": 0.0,
            "margin": 0.0,
            "ambiguous": True,
            "ranking": [],
        }

    best_score, best_gid, best_result = ranked[0]
    second_score = ranked[1][0] if len(ranked) > 1 else best_score - 20.0
    margin = best_score - second_score

    # Group confidence measures selection certainty, not OCR correctness.
    confidence = max(0.0, min(1.0, 0.55 + margin / 22.0))
    ambiguous = bool(len(ranked) > 1 and margin < 2.5)

    return {
        "group_id": best_gid,
        "group_label": GROUP_LABELS.get(best_gid, best_gid),
        "confidence": round(confidence, 3),
        "margin": round(margin, 3),
        "ambiguous": ambiguous,
        "best_reader_status": best_result.get("status"),
        "ranking": [
            {
                "group_id": gid,
                "group_label": GROUP_LABELS.get(gid, gid),
                "score": score,
                "reader_status": result.get("status"),
            }
            for score, gid, result in ranked
        ],
    }

def public_queue_item(item: Dict[str, Any]) -> Dict[str, Any]:
    allowed = (
        "queue_id", "logical_item_id", "session_generation", "originating_cycle_id",
        "open_index", "candidate_id", "anchor", "current_anchor", "original_anchor", "footprint",
        "cell_count", "visual_cell_count", "geometric_cell_count", "geometry_invariant_ok",
        "confidence", "status", "group_id", "group_label",
        "group_confidence", "decision", "reason", "hover_client",
        "source_item_visual_hash", "tooltip_option_signature",
    )
    return {k:item.get(k) for k in allowed if k in item}
