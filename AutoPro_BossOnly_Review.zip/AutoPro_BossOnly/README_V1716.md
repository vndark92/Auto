# Auto Pro By Eric V1.7.16-dev — mã nguồn Windows

**Tình trạng:** bản phát triển từ V1.7.15, **chưa biên dịch EXE** và **chưa test trực tiếp trong JX1 trên Windows**. Giữ bản cũ để có thể quay lại. Phiên bản trong `BUILD_VERSION.json` là metadata của nguồn trước; xem `VERSION_V1716.json` để nhận diện bản thay đổi này.

## Nâng cấp

1. **Giao diện tối giản:** tiếp tục giữ CSS v1.7.15 trung tính, bổ sung ô đặt tên hiển thị acc/log; không dùng màu neon, gradient trang trí. Các đường điều khiển chính vẫn giữ nguyên ID và giao diện hiện có.
2. **Một chủ điều khiển mỗi client:** OS byte-lock dùng PID game + HWND, chia sẻ trong `%LOCALAPPDATA%\AutoProByEric\owners`; trường hợp ứng dụng khác trong cùng bộ nguồn đã giữ client thì từ chối chọn hoặc Start. Khóa tự giải phóng khi tiến trình đóng, kể cả khi crash. Chỉ phối hợp được với các bản V1.7.16 trở lên cùng tuân thủ giao thức này, không khóa các chương trình bên ngoài.
3. **Không tranh chuột vật lý giữa các phiên:** tất cả Auto Chest/Roll/Boss chạy `Auto` hoặc `Foreground` cần khóa `global_physical_input`. Cast Bùa khi `Foreground/Auto` cũng vậy. **Khóa này chỉ giải phóng khi đóng ứng dụng** trong bản dev, nên không thể chạy hai Auto foreground độc lập đồng thời — đây là giới hạn bảo vệ, không phải chức năng hoàn thiện.
4. **Chế độ nền an toàn hơn:** đang chọn Background sẽ **không cho Start Auto Chest/Roll/Boss**; nhiều đường đọc tooltip, click/drag trong engine cũ vẫn có thể đụng chuột/focus. Chỉ Cast Bùa dùng PostMessage không lấy focus (không khẳng định game nhận phím). Không tự chuyển về Foreground. Không tắt rào an toàn nếu chưa có kiểm thử game và xác minh ACK cảm biến.
5. **Cast Bùa:** nút START và phím F10 cùng đi qua owner gate; không cho khởi chạy nếu có Chest/Roll/Boss đang chạy; Chest/Roll/Boss cũng không Start khi Cast đang chạy. Phím F11 gửi dừng. Các hotkey F10/F11 là hotkey toàn cục Windows: nếu mở nhiều instance, Windows có thể chỉ cho một instance đăng ký.
6. **Log nhiều acc:** bản ghi JSONL vẫn tách theo session/PID/HWND, có xoay vòng tối đa 3 file lưu trữ cho mỗi luồng; bộ lọc không bỏ sót acc ít hoạt động chỉ vì acc khác nhiều log. Người dùng tự đặt tên hiển thị cho từng HWND/PID; không lưu tên đăng nhập hay mật khẩu. Trạng thái phiên được cập nhật mỗi 12 giây (chỉ đọc trạng thái bộ nhớ + HWND), tự coi là cũ sau 90 giây. Log và báo trạng thái chung ở `%LOCALAPPDATA%\AutoProByEric\logs\accounts`.
7. **Tách dữ liệu per-account bằng thư mục riêng:** `CREATE_ACCOUNT_INSTANCE.bat` tạo bản nguồn riêng dưới `instances\Acc_XX` để mỗi acc có `autopro_runtime_config.json`, `input_tool.json`, filter/điểm riêng. Bản mới xóa `locked_client` và `runtime.module_running` cũ nếu có; không tự điều khiển cửa sổ cũ.

## Hướng dẫn Windows

**Một acc:** Chạy `RUN_AUTOPRO.bat`; nếu chưa có Python 3.12 / WebView2 / OCR, xem `SETUP_AUTOPRO/README_SETUP.txt` và kiểm tra scripts trước khi chạy. Trong giao diện chọn đúng cửa sổ JX1.

**Hai hoặc nhiều acc:**

1. Trong bản nguồn gốc, chạy `CREATE_ACCOUNT_INSTANCE.bat`, nhập `Acc01`, `Acc02`… (chỉ chữ/số/gạch dưới/gạch nối). Hoặc dòng lệnh: `py -3.12 tools\create_instance.py --name Acc02`.
2. Mở riêng `instances\Acc01\RUN_AUTOPRO.bat` và `instances\Acc02\RUN_AUTOPRO.bat`. Đừng khởi chạy cả hai bằng `RUN_AUTOPRO.bat` cùng một thư mục, để tránh chung cấu hình.
3. Chọn **hai HWND game khác nhau**; nếu có thông báo `OWNED_BY_ANOTHER_AUTOPRO_INSTANCE`, cửa sổ đang có một chủ khác — không nên cố vượt khóa.
4. Vào tab Logs, chọn PID:HWND, đặt tên hiển thị bằng **LƯU TÊN**, xem sự kiện/trạng thái từ nhiều instance chung. Tên này chỉ tồn tại cho định danh PID:HWND hiện tại; cần đặt lại sau khi game mở lại và HWND/PID thay đổi.
5. Nếu muốn hai acc cùng Cast Bùa không chiếm chuột: chọn **Background** riêng trên từng instance rồi chạy thử bằng phím không gây thao tác vật phẩm nguy hiểm. Phải tự xác thực game nhận đúng phím. **Không dùng Auto Chest/Roll/Boss Background**, bởi bản dev sẽ từ chối Start.

**Kiểm thử ngoại tuyến:** Chạy `CHECK_V1716.bat`, hoặc `py -3.12 -m unittest discover -s tests -p "test_v17*.py" -v`. Các bài liên quan OCR cần thêm OpenCV/Pillow/numpy. Để replay ảnh: `py -3.12 tests\benchmark_holdout.py` (không phải benchmark game).

## Giới hạn và an toàn

- Đây là **source ZIP**, không có `.exe` mới. Không thể xác nhận Win32/PostMessage, WebView2 và game DirectInput trong môi trường Linux. Giao diện còn cần QA DPI 100/125/150% và nhiều độ phân giải trên Windows.
- Khóa HWND và khóa chuột vật lý bảo vệ các entry point Auto chính; các lệnh chẩn đoán/thao tác thủ công kế thừa còn chưa được chuyển toàn bộ sang một `InputCoordinator` trung tâm. Vì vậy **không có bảo đảm bao phủ mọi lần dùng chuột hoặc phím**.
- Một máy Windows chỉ có một con trỏ chuột vật lý; không thể có hai Auto độc lập cùng dùng SendInput kéo/thả mà tuyệt đối không tranh nhau. Muốn hai acc chạy đồng thời thực sự cần cơ chế input nền được game chấp nhận và sensor/ACK riêng cho từng client.
- Engine Auto Chest/Roll/Boss vẫn có các đường `SetCursorPos`, `SendInput`, tooltip phụ thuộc con trỏ. Không suy diễn `PostMessageW` trả thành công thành thao tác đã được game thực hiện.
- Khi AutoPro đóng bất thường, file lock không bị xóa nhưng OS lock đã giải phóng. Presence cũ tự hết hạn; cấu hình an toàn của V1.7.15 và dữ liệu vật phẩm kế thừa không được sửa bằng những bộ test này.
- Chưa có tập ảnh OCR đã gán nhãn độc lập cho 7 loại thuộc tính thiếu dữ liệu. Corpus holdout cũ có dữ liệu trùng train, không chứng minh độ chính xác live.
- Installer cũ còn URL tải bên ngoài mà chưa có checksum SHA-256 được xác thực của bên cung cấp; **chưa đổi** cách tải/cài đặt trong bản này. Nếu chạy `INSTALL_ALL.bat`, cần tự xác minh installer trước khi cấp quyền Admin.
- Bản sao account có thể kế thừa tọa độ/đường đi từ bản nguồn; cần hiệu chỉnh từng tài khoản, không mặc nhiên dùng cho account khác hay vật phẩm quý.

## Quy trình tiếp nhận lỗi

Nếu gặp lỗi trên Windows, gửi `reason` từ UI, bản ghi log của đúng PID:HWND, phiên bản Windows/DPI, tình trạng game foreground/background/minimized, và video thao tác thử với vật phẩm không giá trị. **Không gửi mật khẩu, mã đăng nhập hoặc thông tin bí mật của tài khoản.**

Xem `BAO_CAO_PHAT_TRIEN_V1716.md` trong gói để biết tiêu chí nghiệm thu còn thiếu.
