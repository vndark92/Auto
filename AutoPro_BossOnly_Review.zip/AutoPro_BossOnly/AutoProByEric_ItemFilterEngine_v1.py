from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List
from AutoProByEric_OptionRegistry_v1 import FILTERABLE_OPTIONS, BY_NAME

CONFIG_SCHEMA_VERSION = 2
MAX_PROFILES = 4
MAX_CONDITIONS_PER_PROFILE = 12


def _normalize_rule(raw: Dict[str, Any]) -> Dict[str, Any] | None:
    name = str(raw.get("option_name") or raw.get("option") or "").strip()
    if name not in FILTERABLE_OPTIONS:
        return None
    op = str(raw.get("op", "EXISTS")).upper()
    if op not in ("EXISTS", ">=", "<=", ">", "<", "=="):
        op = "EXISTS"
    try:
        value = float(raw.get("value", raw.get("expected_value", 0)) or 0)
        if value.is_integer():
            value = int(value)
    except Exception:
        value = 0
    return {
        "option_id": BY_NAME[name]["id"],
        "option_name": name,
        "op": op,
        "value": value,
        "enabled": bool(raw.get("enabled", True)),
    }


def _empty_profile(pid: int, enabled: bool = False) -> Dict[str, Any]:
    return {
        "profile_id": pid,
        "enabled": bool(enabled),
        "rules": [],
    }


def migrate_config(cfg: Dict[str, Any] | None) -> Dict[str, Any]:
    cfg = dict(cfg or {})
    if int(cfg.get("schema_version") or 0) >= CONFIG_SCHEMA_VERSION and isinstance(cfg.get("profiles"), list):
        out = {
            "schema_version": CONFIG_SCHEMA_VERSION,
            "name": cfg.get("name") or "Auto Pro By Eric - Multi Filter Profiles",
            "scope": cfg.get("scope", "GLOBAL"),
            "scope_value": cfg.get("scope_value", "GLOBAL"),
            "group_id": cfg.get("group_id"),
            "family": cfg.get("family"),
            "mode": "PROFILES_OR",
            "profiles": [],
        }
        by_id = {int(p.get("profile_id", i + 1)): p for i, p in enumerate(cfg.get("profiles") or [])}
        for pid in range(1, MAX_PROFILES + 1):
            p = by_id.get(pid, {})
            rules = []
            for raw in list(p.get("rules") or [])[:MAX_CONDITIONS_PER_PROFILE]:
                nr = _normalize_rule(raw)
                if nr and nr["enabled"]:
                    rules.append(nr)
            out["profiles"].append({"profile_id": pid, "enabled": bool(p.get("enabled", pid == 1)), "rules": rules})
        return out

    # deterministic legacy migration: old single filter -> Profile 1; Profiles 2-4 disabled.
    rules = []
    for raw in list(cfg.get("rules") or [])[:MAX_CONDITIONS_PER_PROFILE]:
        nr = _normalize_rule(raw)
        if nr and nr["enabled"]:
            rules.append(nr)
    return {
        "schema_version": CONFIG_SCHEMA_VERSION,
        "name": "Auto Pro By Eric - Multi Filter Profiles",
        "scope": cfg.get("scope", "GLOBAL"),
        "scope_value": cfg.get("scope_value", "GLOBAL"),
        "group_id": cfg.get("group_id"),
        "family": cfg.get("family"),
        "mode": "PROFILES_OR",
        "profiles": [
            {"profile_id": 1, "enabled": True, "rules": rules},
            _empty_profile(2), _empty_profile(3), _empty_profile(4),
        ],
    }


def enabled_profiles(cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    c = migrate_config(cfg)
    return [p for p in c["profiles"] if p.get("enabled") and any(r.get("enabled", True) for r in p.get("rules") or [])]


def wanted_option_set(cfg: Dict[str, Any]) -> List[str]:
    seen = set(); out = []
    for p in enabled_profiles(cfg):
        for r in p.get("rules") or []:
            n = r.get("option_name")
            if n and n not in seen:
                seen.add(n); out.append(n)
    return out


def union_scan_rules(cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    # Keep one representative per option. Use the strictest threshold where compatible,
    # purely to make specialized rescue conservative; profile evaluation remains isolated.
    out: Dict[str, Dict[str, Any]] = {}
    for p in enabled_profiles(cfg):
        for r in p.get("rules") or []:
            name = r.get("option_name")
            if not name:
                continue
            if name not in out:
                out[name] = dict(r)
                continue
            old = out[name]
            if old.get("op") == r.get("op") == ">=":
                if float(r.get("value", 0)) > float(old.get("value", 0)):
                    out[name] = dict(r)
            elif old.get("op") == r.get("op") == "<=":
                if float(r.get("value", 0)) < float(old.get("value", 0)):
                    out[name] = dict(r)
    return list(out.values())


def flatten_profile_results(profile_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_name: Dict[str, Dict[str, Any]] = {}
    for pr in profile_results:
        for rr in pr.get("rule_results") or []:
            name = rr.get("option_name")
            if not name:
                continue
            cur = by_name.get(name)
            if cur is None or (rr.get("passed") and not cur.get("passed")):
                by_name[name] = rr
    return list(by_name.values())


def compose_profile_result(profile_results: List[Dict[str, Any]], frames=None, active_count=None) -> Dict[str, Any]:
    """Compose OR-across-profiles using V11.0 three-state evidence truth.

    PASS / FAIL / UNKNOWN are semantically distinct.  A profile may be treated
    as eliminated only when its evaluator supplies RejectAuthority ==
    AUTHORITATIVE_REJECT.  OCR uncertainty is never upgraded to rejection merely
    because the bounded second frame has already been consumed.
    """
    frames = frames or []
    active = int(active_count if active_count is not None else len(profile_results))
    matched = [x for x in profile_results if x.get("decision") == "PASS"]
    authoritative_failed = [
        x for x in profile_results
        if x.get("decision") == "FAIL"
        and str(x.get("reject_authority") or "").upper() == "AUTHORITATIVE_REJECT"
    ]
    unresolved = [
        x for x in profile_results
        if x.get("decision") in ("UNCERTAIN", "NO_FILTER")
        or (
            x.get("decision") == "FAIL"
            and str(x.get("reject_authority") or "").upper() != "AUTHORITATIVE_REJECT"
        )
    ]

    wanted_count = len({
        r.get("option_name")
        for p in profile_results
        for r in (p.get("rules") or [])
        if r.get("option_name")
    })

    if matched:
        m = matched[0]
        return {
            "decision": "PASS", "filter_result": "MATCH", "reason": "PROFILE_MATCHED_N_OF_N",
            "reject_authority": "NOT_APPLICABLE",
            "matched_profile_id": m.get("profile_id"), "active_profile_count": active,
            "profile_results": profile_results, "rule_results": flatten_profile_results(profile_results),
            "frames": frames, "disposition": "KEEP_NOW", "skip_review": False,
            "wanted_option_count": wanted_count,
            "pipeline": "MULTI_PROFILE_THREE_STATE_V11_0",
        }

    # A global REJECT exists only when EVERY active profile is authoritatively
    # eliminated.  Unknown evidence keeps the global result UNRESOLVED.
    if active > 0 and len(authoritative_failed) == active and not unresolved:
        return {
            "decision": "FAIL", "filter_result": "REJECT", "reason": "ALL_ENABLED_PROFILES_AUTHORITATIVELY_ELIMINATED",
            "reject_authority": "AUTHORITATIVE_REJECT",
            "matched_profile_id": None, "active_profile_count": active,
            "profile_results": profile_results, "rule_results": flatten_profile_results(profile_results),
            "frames": frames, "disposition": "REJECT_NOW", "skip_review": True,
            "fail_fast": True, "wanted_option_count": wanted_count,
            "pipeline": "MULTI_PROFILE_THREE_STATE_V11_0",
        }

    return {
        "decision": "UNCERTAIN", "filter_result": "UNRESOLVED",
        "reason": "PROFILE_EVIDENCE_UNRESOLVED",
        "reject_authority": "UNRESOLVED",
        "matched_profile_id": None, "active_profile_count": active,
        "profile_results": profile_results, "rule_results": flatten_profile_results(profile_results),
        "frames": frames,
        "disposition": ("RECHECK_PENDING" if len(frames) >= 2 else "RETRY_ONCE"),
        "skip_review": False, "wanted_option_count": wanted_count,
        "pipeline": "MULTI_PROFILE_THREE_STATE_V11_0",
    }
