from __future__ import annotations
from pathlib import Path
import json, hashlib, time

HARNESS_VERSION = 'STORAGE_TRUTH_HARNESS_V12_7_DUALROOT_DIAGNOSTIC_ONLY'
APPROVAL_FILENAME = 'STORAGE_TRUTH_APPROVAL.json'


def _safe_cell_lines(grid):
    try:
        xs=[int(x) for x in (grid or {}).get('x_lines',[])]
        ys=[int(y) for y in (grid or {}).get('y_lines',[])]
        if len(xs)==7 and len(ys)==11:
            return xs,ys
    except Exception:
        pass
    return [],[]


def _draw_grid(base, grid, *, states=None, selected_cells=None, click_point=None, title=None):
    from PIL import ImageDraw
    img=base.copy()
    draw=ImageDraw.Draw(img)
    xs,ys=_safe_cell_lines(grid)
    if not xs or not ys:
        return img
    # Do not rely on color semantics for machine truth; these overlays are for human review.
    for x in xs:
        draw.line((x,ys[0],x,ys[-1]),width=2)
    for y in ys:
        draw.line((xs[0],y,xs[-1],y),width=2)
    st=states or {}
    selected={tuple(x) for x in (selected_cells or [])}
    for r in range(10):
        for c in range(6):
            x0,x1=xs[c],xs[c+1]; y0,y1=ys[r],ys[r+1]
            state=str(st.get((r,c),'')).upper()
            label=f'{r},{c}' + (f' {state[0]}' if state else '')
            draw.text((x0+2,y0+2),label)
            if (r,c) in selected:
                draw.rectangle((x0+2,y0+2,x1-2,y1-2),width=3)
    if click_point:
        try:
            x,y=int(click_point[0]),int(click_point[1])
            d=7
            draw.ellipse((x-d,y-d,x+d,y+d),width=3)
            draw.line((x-d*2,y,x+d*2,y),width=2)
            draw.line((x,y-d*2,x,y+d*2),width=2)
        except Exception:
            pass
    if title:
        draw.text((6,6),str(title))
    return img


def _truth_id(payload):
    raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def write_pre_store_truth(output_dir, *, storage_image, storage_grid, occupancy_states,
                          source_image, source_grid, source_cells, item_id, footprint,
                          orientation, target, click_point, cycle_id, planner_reason=None):
    """Diagnostic-only writer. It never sends input and never changes destination policy."""
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    xs,ys=_safe_cell_lines(storage_grid)
    planned_cells=[list(x) for x in (target or {}).get('cells',[]) or []]
    planned_anchor=[int((target or {}).get('row',0)),int((target or {}).get('col',0))] if target else None
    payload={
        'harness_version':HARNESS_VERSION,
        'cycle_id':int(cycle_id or 0),
        'item_id':item_id,
        'grid':{
            'left':xs[0] if xs else None,'top':ys[0] if ys else None,
            'right':xs[-1] if xs else None,'bottom':ys[-1] if ys else None,
            'rows':10,'cols':6,
            'pitch_x':((xs[-1]-xs[0])/6.0) if xs else None,
            'pitch_y':((ys[-1]-ys[0])/10.0) if ys else None,
            'x_lines':xs,'y_lines':ys,
        },
        'occupancy':[
            {'row':r,'col':c,'state':str(occupancy_states.get((r,c),'UNKNOWN')).upper()}
            for r in range(10) for c in range(6)
        ],
        'footprint':{
            'width':int((footprint or [1,1])[0]),
            'height':int((footprint or [1,1])[1]),
            'orientation':orientation,
            'source_cells':[list(x) for x in (source_cells or [])],
        },
        'plan':{
            'selected_cell_col':planned_anchor[1] if planned_anchor else None,
            'selected_cell_row':planned_anchor[0] if planned_anchor else None,
            'planned_anchor':planned_anchor,
            'footprint_cells':planned_cells,
            'reason':planner_reason or (target or {}).get('placement_policy'),
        },
        'click':{
            'planned_cell':planned_anchor,
            'planned_anchor':planned_anchor,
            'client_x':int(click_point[0]) if click_point else None,
            'client_y':int(click_point[1]) if click_point else None,
        },
        'generated_at':time.strftime('%Y-%m-%dT%H:%M:%S'),
    }
    # Stable across a stop/restart when the reviewed physical truth is unchanged.
    # Deliberately exclude timestamp/cycle/item queue identifiers; any grid, occupancy,
    # footprint, selected plan or click-point change invalidates the approval.
    truth_basis={
        'grid':payload['grid'],
        'occupancy':payload['occupancy'],
        'footprint':payload['footprint'],
        'plan':payload['plan'],
        'click':payload['click'],
    }
    payload['truth_id']=_truth_id(truth_basis)
    payload['truth_id_basis']='GRID_OCCUPANCY_FOOTPRINT_PLAN_CLICK'

    storage_image.save(out/'STORAGE_RAW.png')
    grid_overlay=_draw_grid(storage_image,storage_grid,title='STORAGE GRID TRUTH')
    grid_overlay.save(out/'STORAGE_GRID_TRUTH.png'); grid_overlay.save(out/'STORAGE_GRID_OVERLAY.png')
    occ_overlay=_draw_grid(storage_image,storage_grid,states=occupancy_states,title='STORAGE OCCUPANCY TRUTH')
    occ_overlay.save(out/'STORAGE_OCCUPANCY_TRUTH.png'); occ_overlay.save(out/'STORAGE_OCCUPANCY_OVERLAY.png')
    if source_image is not None and source_grid is not None:
        _draw_grid(source_image,source_grid,selected_cells=source_cells,title='SOURCE FOOTPRINT TRUTH').save(out/'SOURCE_FOOTPRINT_TRUTH.png')
    _draw_grid(storage_image,storage_grid,states=occupancy_states,selected_cells=planned_cells,title='STORAGE PLAN DRYRUN').save(out/'STORAGE_PLAN_DRYRUN.png')
    click_overlay=_draw_grid(storage_image,storage_grid,states=occupancy_states,selected_cells=planned_cells,click_point=click_point,title='STORAGE CLICK POINT')
    click_overlay.save(out/'STORAGE_CLICK_POINT.png'); click_overlay.save(out/'STORAGE_DESTINATION_PRECLICK.png')
    (out/'STORAGE_TRUTH_PRE.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    return payload


def approval_status(root_dir, truth_payload):
    """Authorize exactly one physical Store only when a matching truth_id is explicitly approved."""
    p=Path(root_dir)/'Data'/APPROVAL_FILENAME
    if not p.exists():
        return {'ok':False,'reason':'STORAGE_TRUTH_REVIEW_REQUIRED','approval_path':str(p)}
    try:
        data=json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        return {'ok':False,'reason':'STORAGE_TRUTH_APPROVAL_INVALID','approval_path':str(p),'error':str(e)}
    if data.get('approve_one_store') is not True:
        return {'ok':False,'reason':'STORAGE_TRUTH_REVIEW_REQUIRED','approval_path':str(p)}
    if str(data.get('truth_id') or '') != str((truth_payload or {}).get('truth_id') or ''):
        return {'ok':False,'reason':'STORAGE_TRUTH_APPROVAL_MISMATCH','approval_path':str(p),
                'expected_truth_id':(truth_payload or {}).get('truth_id'),'actual_truth_id':data.get('truth_id')}
    # Consume before destructive input so the approval can never authorize a second item.
    consumed={**data,'approve_one_store':False,'consumed':True,'consumed_at':time.strftime('%Y-%m-%dT%H:%M:%S')}
    p.write_text(json.dumps(consumed,ensure_ascii=False,indent=2),encoding='utf-8')
    return {'ok':True,'reason':'ONE_STORE_APPROVED','approval_path':str(p),'truth_id':data.get('truth_id')}


def write_post_store_truth(output_dir, *, storage_image, storage_grid, before_snapshot, after_snapshot,
                           planned_anchor, planned_cells, diff_func, source_visual_offsets=None):
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    changed=[]
    try:
        d=diff_func(before_snapshot,after_snapshot) or {}
        for rec in d.get('changed_cells',[]) or []:
            if float(rec.get('pixel_diff',0) or 0) >= 8.0:
                changed.append((int(rec['row']),int(rec['col'])))
    except Exception:
        changed=[]
    planned=[int(planned_anchor[0]),int(planned_anchor[1])] if planned_anchor else None
    offsets=[]
    for raw in (source_visual_offsets or []):
        try:
            dr,dc=int(raw[0]),int(raw[1])
            if 0<=dr<10 and 0<=dc<6 and (dr,dc) not in offsets: offsets.append((dr,dc))
        except Exception:
            pass
    actual_anchor=None; actual_method='STORAGE_CHANGED_CELL_BOUNDING_TOP_LEFT'; best_score=0
    if changed and offsets:
        changed_set=set(changed); candidates={}
        for cr,cc in changed_set:
            for dr,dc in offsets:
                ar,ac=cr-dr,cc-dc
                if not (0<=ar<10 and 0<=ac<6): continue
                score=sum(1 for odr,odc in offsets if (ar+odr,ac+odc) in changed_set)
                candidates[(ar,ac)]=max(score,candidates.get((ar,ac),0))
        if candidates:
            # Prefer strongest translation match; deterministic row/col tie-break.
            best_anchor,best_score=sorted(candidates.items(),key=lambda kv:(-kv[1],kv[0][0],kv[0][1]))[0]
            actual_anchor=[int(best_anchor[0]),int(best_anchor[1])]
            actual_method='SOURCE_VISUAL_OFFSET_TRANSLATION'
    elif changed:
        actual_anchor=[min(r for r,c in changed),min(c for r,c in changed)]
    match=bool(actual_anchor is not None and planned==actual_anchor)
    result={
        'harness_version':HARNESS_VERSION,
        'planned_anchor':planned,
        'actual_anchor':actual_anchor,
        'actual_anchor_method':actual_method,
        'actual_anchor_match_score':int(best_score),
        'source_visual_offsets':[list(x) for x in offsets],
        'actual_changed_cells':[list(x) for x in changed],
        'planned_footprint_cells':[list(x) for x in (planned_cells or [])],
        'planned_anchor_equals_actual_anchor':match,
        'requires_human_visual_confirmation':True,
    }
    _draw_grid(storage_image,storage_grid,selected_cells=changed,title='STORAGE POST TRUTH').save(out/'STORAGE_POST_TRUTH.png')
    (out/'STORAGE_TRUTH_POST.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
