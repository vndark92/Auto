# Auto Pro By Eric V1.7.15-dev — bản nguồn chạy trên Windows

**Nguồn gốc:** tái dựng từ ZIP NoKey mà người dùng cung cấp, nâng cấp trực tiếp từ các file Python/HTML/CSS/JS được nhúng trong EXE. **Không phải EXE mới đã biên dịch.**

## Cách chạy thử

1. Giải nén thư mục này **riêng biệt**, không đè vào bản đang sử dụng. Sao lưu mọi profile/bộ lọc quan trọng trước khi thử.
2. Trên Windows 10/11 với Python 3.12, chạy `SETUP_AUTOPRO/INSTALL_ALL.bat` nếu thiếu dependencies; kiểm tra lại bằng `SETUP_AUTOPRO/CHECK_ENV.bat`.
3. Chạy `RUN_AUTOPRO.bat`. Đóng/mở game trong phiên thử nghiệm trước khi thực hiện thao tác vật phẩm thực tế.
4. Chạy unit tests (khi có đầy đủ OpenCV/Pillow/numpy): `py -3.12 -m unittest discover -s tests -v`.
5. Không chạy test DROP/STORE/ROLL trên vật phẩm giá trị khi chưa xác nhận nguồn OCR và hành vi game.

## Đã thay đổi

- **UI tối giản:** bổ sung `autopro_minimal_v1715.css`, loại nền ảnh/trang trí/glow, giảm màu sắc/đổ bóng và giữ các màn hình điều khiển cũ.
- **OCR tránh nhầm RESOURCE_MAX:** chỉ cấp canonical hint khi nhận đầy đủ tên riêng chính xác; với OCR mờ/trái dấu trả `UNKNOWN/AMBIGUOUS`, không tự đoán Sinh/Nội/Thể.
- **InputTool (Cast Bùa):** khi game Inventory dùng F4 và CHEST/ROLL/BOSS đang hoạt động, bỏ qua phím trùng để tránh gửi chen (các phím khác vẫn tiếp tục). Có đếm `skipped_count`. Đây là cơ chế guard, **chưa phải hàng đợi input nguyên tử xuyên mọi luồng**.
- **Cast Bùa không focus:** chọn `Settings > Chế độ thao tác > Nền` để gửi phím qua Windows `PostMessage` đúng một lần, không foreground, không `SendInput` ở đường Cast Bùa. API trả "acceptance_verified=false" nếu chỉ gửi thành công mà game chưa xác thực.
- **Log nhiều acc đồng thời:** lưu JSONL theo `(phiên app, PID tiến trình game, HWND)` trong `%LOCALAPPDATA%\AutoProByEric\logs\accounts` trên Windows, hỗ trợ nhiều phiên app chạy cạnh nhau và cả các bản nằm ở thư mục khác nhau; tab Logs có bộ lọc cửa sổ, hiển thị các log UI từ nhiều phiên và log thao tác START/STOP của Roll/Boss/Cast Bùa. Log backend cũ giữ nguyên ở `logs/`.
- **Khôi phục config:** ghi nguyên tử, `.bak` và file lock hỗ trợ nhiều tiến trình; trường hợp JSON lỗi khôi phục backup và ghi `logs/config_recovery.jsonl`.
- **Dọn logs:** xóa symlink trong thư mục logs mà không follow target.

## Kết quả test ngoại tuyến

- 9 unit tests PASS (config, log đa phiên, chính sách phím, OCR, cleanup).
- 49 ảnh holdout corpus cũ: **40 CONFIRMED đúng / 0 CONFIRMED sai / 9 chưa xác định**. **Không phải điểm đo chính xác in-game**, vì corpus còn trùng ảnh/mask giữa train và holdout.
- Code được AST-parsed; `autopro_multi_account_ui_v1715.js` qua `node --check`.
- **Chưa thử trên Windows và chưa thử tương tác thật với game.**

## Giới hạn phải biết

- **Không chiếm chuột hoàn toàn** chưa thể cam kết cho Auto Chest/Roll/Boss. Một số đường thao tác của engine cũ còn `SetCursorPos`, `SendInput`, focus HUD, tooltip từ cursor. Chỉ **Cast Bùa chế độ Background** có đường phím không cần chiếm chuột. Các thao tác kéo/thả vật phẩm cần thêm transport nền có phản hồi cảm biến và bằng chứng chấp nhận từ game; không thể chỉ đổi cài đặt thành Background rồi xem như an toàn.
- Chưa có scheduler multi-client hoạt động độc lập trong một app. Mỗi instance vẫn quản lý một client; `MultiAccountLog` tổng hợp qua nhiều instance. Các cài đặt chung trong cùng folder có thể ghi đè giá trị theo phiên; nên dùng **mỗi tài khoản một bản thư mục riêng** (nhật ký đa acc vẫn nằm chung trong LocalAppData) cho đến khi tách profile theo account_id.
- Chưa có EXE Windows mới. Trong môi trường phát triển hiện tại không có bộ công cụ build/QA Windows native nên không nên gắn nhãn binary đã kiểm nghiệm.
- Bộ cài của phiên bản cũ còn phụ thuộc tải về/các cài đặt bên ngoài, **chưa xác minh toàn bộ SHA-256**. Chỉ tải từ nguồn tin cậy và kiểm tra script trước khi chạy.
- Thay đổi CSS là mục tiêu giao diện tối giản, nhưng còn cần xác nhận bố cục với WebView2 và DPI 100/125/150% trên máy đích.

## Mục tiêu V1.7.16

1. `InputCoordinator` chung, khóa toàn bộ transaction đầu vào, không để Cast Bùa và engine Inventory tranh cùng key ở ranh giới START/STOP.
2. Điều khiển nền có xác nhận end-to-end bằng screenshot/ACK (trong phạm vi client hỗ trợ); không có xác nhận phải STOP an toàn.
3. Account Profiles theo PID/HWND + session + persistence tách biệt; dashboard trạng thái và log live đa acc, phát hiện đóng/mở lại cửa sổ.
4. Thu dữ liệu OCR độc lập, mở rộng 7 nhóm còn thiếu, kiểm thử Windows/in-game và chuẩn hóa bộ cài.
