"""Auto Pro By Eric V12.1 — owner-bound pending-item recovery.

The timer/controller only grants a one-shot claim. This coordinator owns the
actual recovery work: source inventory readiness -> same-item reidentification
-> fresh tooltip read -> fresh filter -> disposition. It intentionally delegates
all proven action primitives to the backend owner; it does not duplicate Drop,
Store, Filter, or OCR logic.
"""

RESUME_COORDINATOR_VERSION = 'RESUME_COORDINATOR_V12_1_OWNER_BOUND'

class ResumeCoordinator:
    VERSION = RESUME_COORDINATOR_VERSION
    def __init__(self, api_owner):
        self.api = api_owner

    def resolve_pending_item(self, hwnd, logical_item_id=None):
        """Resolve exactly the timer/manual owner supplied by the backend.

        V12.0 selected the first pending/deferred ledger entry. With multiple
        retained deferred items this could service an old item even when the
        current +60s timer belonged to a newer FILTER_RECHECK_PENDING item.
        V12.1 binds recovery to an explicit logical_item_id.
        """
        return self.api._v120_resume_resolve_pending_item_core(int(hwnd), logical_item_id=logical_item_id)
