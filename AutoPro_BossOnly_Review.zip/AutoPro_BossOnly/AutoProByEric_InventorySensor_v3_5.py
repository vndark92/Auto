from __future__ import annotations
from typing import Dict, Any, List, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import hashlib
import cv2
import numpy as np
from PIL import Image

# Verified JX1 800x600 inventory geometry.
CANONICAL_X = np.array([605, 633, 661, 689, 717, 745, 773], dtype=float)
CANONICAL_Y = np.array([92, 120, 148, 176, 204, 232, 260, 288, 316, 344, 372], dtype=float)

# Stage 24.5 / v9.2 personal HÀNH TRANG popup geometry.
# Recalibrated from the user's 800x600 JX1 client screenshot. The old v8.6 X
# anchor was ~5 px too far right, which made the edge search vulnerable while
# the popup was still animating. Keep this grid separate from the right source
# inventory grid.
PERSONAL_CANONICAL_X = np.array([358, 386, 414, 442, 470, 498, 526], dtype=float)
PERSONAL_CANONICAL_Y = np.array([142, 170, 198, 226, 254, 282, 310, 338, 366, 394, 422], dtype=float)


class GridOwner(str, Enum):
    PLAYER_INVENTORY = "PLAYER_INVENTORY"
    PERSONAL_STORAGE = "PERSONAL_STORAGE"


@dataclass
class StoragePanelIdentity:
    panel_rect: List[int]
    header_rect: List[int]
    grid_rect: List[int]
    footer_rect: List[int]
    title_rect: List[int]
    close_button_rect: List[int]
    structural_anchor_score: float
    confidence: float
    inner_grid_verified: bool = True
    owner: str = GridOwner.PERSONAL_STORAGE.value
    coordinate_space: str = "CLIENT"


@dataclass
class PlayerInventoryPanelIdentity:
    panel_rect: List[int]
    grid_rect: List[int]
    currency_area: List[int]
    action_buttons: List[int]
    structural_anchor_score: float
    confidence: float
    owner: str = GridOwner.PLAYER_INVENTORY.value
    coordinate_space: str = "CLIENT"


def _panel_edge_peak_vertical(gray: np.ndarray, x0: float, x1: float, y0: float, y1: float):
    h,w=gray.shape[:2]
    a=max(1,int(round(min(x0,x1)))); b=min(w-2,int(round(max(x0,x1))))
    ya=max(0,int(round(min(y0,y1)))); yb=min(h,int(round(max(y0,y1))))
    if b<a or yb<=ya:
        return None,0.0
    gx=np.abs(cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3))
    best=(-1.0,None)
    for x in range(a,b+1):
        score=float(np.mean(gx[ya:yb,x]))
        if score>best[0]:
            best=(score,x)
    return best[1],best[0]


def _panel_edge_peak_horizontal(gray: np.ndarray, y0: float, y1: float, x0: float, x1: float):
    h,w=gray.shape[:2]
    a=max(1,int(round(min(y0,y1)))); b=min(h-2,int(round(max(y0,y1))))
    xa=max(0,int(round(min(x0,x1)))); xb=min(w,int(round(max(x0,x1))))
    if b<a or xb<=xa:
        return None,0.0
    gy=np.abs(cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3))
    best=(-1.0,None)
    for y in range(a,b+1):
        score=float(np.mean(gy[y,xa:xb]))
        if score>best[0]:
            best=(score,y)
    return best[1],best[0]


def _estimate_panel_rect_from_grid(image: Image.Image, grid: Dict[str, Any]) -> Dict[str, Any]:
    """Find the current panel border around a proven 6x10 grid.

    This is panel-local and therefore follows a moved JX1 window/panel.  It does
    not use title OCR and does not assume an absolute desktop position.
    """
    try:
        arr=np.asarray(image.convert("RGB")); gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
        xs=[int(x) for x in (grid or {}).get("x_lines",[])]; ys=[int(y) for y in (grid or {}).get("y_lines",[])]
        if len(xs)!=7 or len(ys)!=11:
            return {"ok":False,"reason":"PANEL_GRID_TOPOLOGY_INVALID"}
        gx0,gy0,gx1,gy1=xs[0],ys[0],xs[-1],ys[-1]
        px=max(1.0,float(np.mean(np.diff(xs)))); py=max(1.0,float(np.mean(np.diff(ys))))
        left,ls=_panel_edge_peak_vertical(gray,gx0-1.25*px,gx0-.45*px,gy0-2.2*py,gy1+3.4*py)
        right,rs=_panel_edge_peak_vertical(gray,gx1+.45*px,gx1+1.25*px,gy0-2.2*py,gy1+3.4*py)
        top,ts=_panel_edge_peak_horizontal(gray,gy0-2.2*py,gy0-.60*py,gx0-1.3*px,gx1+1.3*px)
        bottom,bs=_panel_edge_peak_horizontal(gray,gy1+.25*py,gy1+2.50*py,gx0-1.3*px,gx1+1.3*px)
        if None in (left,right,top,bottom) or not (left<gx0<gx1<right and top<gy0<gy1<bottom):
            return {"ok":False,"reason":"PANEL_BORDER_NOT_RESOLVED",
                    "grid_rect":[gx0,gy0,gx1,gy1],"edge_scores":[ls,ts,rs,bs]}
        edge_mean=float(np.mean([ls,ts,rs,bs]))
        return {
            "ok":bool(edge_mean>=70.0),
            "panel_rect":[int(left),int(top),int(right),int(bottom)],
            "grid_rect":[gx0,gy0,gx1,gy1],
            "margins":[gx0-int(left),gy0-int(top),int(right)-gx1,int(bottom)-gy1],
            "edge_scores":[round(float(v),3) for v in (ls,ts,rs,bs)],
            "edge_mean":round(edge_mean,3),
            "coordinate_space":"CLIENT",
            "reason":None if edge_mean>=70.0 else "PANEL_BORDER_CONFIDENCE_LOW",
        }
    except Exception as e:
        return {"ok":False,"reason":"PANEL_BORDER_EXCEPTION","error":str(e)}


def _rect_intersection_area(a, b) -> int:
    if not a or not b or len(a)<4 or len(b)<4:
        return 0
    x0=max(int(a[0]),int(b[0])); y0=max(int(a[1]),int(b[1]))
    x1=min(int(a[2]),int(b[2])); y1=min(int(a[3]),int(b[3]))
    return max(0,x1-x0)*max(0,y1-y0)


def _panel_local_uniform_lattice(gray: np.ndarray, panel_rect, *, axis: str, count: int, seed_pitch: float) -> Dict[str, Any]:
    """Find a complete uniform lattice *inside* a proven panel.

    V12.9 rule: panel geometry and grid geometry are different objects.  This
    routine never uses panel.top/left as a grid origin.  It searches edge
    periodicity inside the panel and returns the first/last real cell borders.
    """
    try:
        x0,y0,x1,y1=[int(v) for v in panel_rect[:4]]
        h,w=gray.shape[:2]
        x0=max(0,min(w-2,x0)); x1=max(x0+2,min(w,x1))
        y0=max(0,min(h-2,y0)); y1=max(y0+2,min(h,y1))
        pw=max(2,x1-x0); ph=max(2,y1-y0)
        if axis=='x':
            grad=np.abs(cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3))
            ya=y0+max(12,int(round(ph*.08))); yb=y1-max(12,int(round(ph*.08)))
            if yb<=ya: return {'ok':False,'reason':'PANEL_LOCAL_X_PROFILE_EMPTY'}
            profile=grad[ya:yb,x0:x1].mean(axis=0); abs0=x0; plen=pw
            base=max(18.0,float(seed_pitch or pw/7.6))
            pmin=max(18.0,base*.82); pmax=min(40.0,base*1.18)
            start_lo=x0+max(8,int(round(pw*.06))); start_hi=x0+max(12,int(round(pw*.20)))
            ideal_lead=pw*.11; ideal_trail=pw*.11
        else:
            grad=np.abs(cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3))
            xa=x0+max(12,int(round(pw*.07))); xb=x1-max(12,int(round(pw*.07)))
            if xb<=xa: return {'ok':False,'reason':'PANEL_LOCAL_Y_PROFILE_EMPTY'}
            profile=grad[y0:y1,xa:xb].mean(axis=1); abs0=y0; plen=ph
            base=max(18.0,float(seed_pitch or ph/12.7))
            pmin=max(18.0,base*.82); pmax=min(40.0,base*1.18)
            # Header/footer are explicitly excluded from the candidate grid.
            start_lo=y0+max(10,int(round(ph*.07))); start_hi=y0+max(18,int(round(ph*.24)))
            ideal_lead=ph*.11; ideal_trail=ph*.09
        med=float(np.median(profile))+1e-3
        spread=float(np.percentile(profile,90)-np.percentile(profile,30))+1e-3
        best=None
        pitch=float(pmin)
        while pitch<=float(pmax)+1e-6:
            span=(int(count)-1)*pitch
            start=float(start_lo)
            while start<=float(start_hi)+1e-6:
                if start+span <= abs0+plen-5:
                    positions=[]; values=[]
                    for i in range(int(count)):
                        expected=start+i*pitch; pi=int(round(expected-abs0))
                        aa=max(0,pi-2); bb=min(plen,pi+3)
                        if bb<=aa: break
                        jj=aa+int(np.argmax(profile[aa:bb]))
                        positions.append(int(abs0+jj)); values.append(float(profile[jj]))
                    if len(positions)==int(count) and len(set(positions))==int(count):
                        diffs=np.diff(positions)
                        if len(diffs) and float(np.min(diffs))>=pmin-4 and float(np.max(diffs))<=pmax+4:
                            lead=positions[0]-abs0; trail=abs0+plen-positions[-1]
                            strength=float(np.mean([(v-med)/spread for v in values]))
                            uniform=max(0.0,1.0-float(np.std(diffs))/3.0)
                            margin=max(0.0,1.0-(abs(lead-ideal_lead)+abs(trail-ideal_trail))/max(20.0,ideal_lead+ideal_trail))
                            pitch_fit=max(0.0,1.0-abs(float(np.mean(diffs))-base)/max(3.0,base*.15))
                            score=strength+.65*uniform+.35*margin+.25*pitch_fit
                            cand=(score,positions,float(np.mean(diffs)),lead,trail,strength,uniform)
                            if best is None or cand[0]>best[0]: best=cand
                start+=.5
            pitch+=.5
        if best is None:
            return {'ok':False,'reason':'PANEL_LOCAL_LATTICE_NOT_FOUND','axis':axis}
        score,positions,mean_pitch,lead,trail,strength,uniform=best
        # Require a complete, panel-internal lattice with meaningful margins.
        ok=bool(score>=1.35 and lead>=6 and trail>=6 and uniform>=.20)
        return {
            'ok':ok,'reason':None if ok else 'PANEL_LOCAL_LATTICE_CONFIDENCE_LOW','axis':axis,
            'lines':[int(v) for v in positions],'pitch':round(float(mean_pitch),3),
            'lead_margin':int(lead),'trail_margin':int(trail),'score':round(float(score),3),
            'edge_strength_score':round(float(strength),3),'uniformity_score':round(float(uniform),3),
        }
    except Exception as e:
        return {'ok':False,'reason':'PANEL_LOCAL_LATTICE_EXCEPTION','axis':axis,'error':str(e)}


def _refine_personal_storage_inner_grid(image: Image.Image, panel_probe: Dict[str, Any], seed_grid: Dict[str, Any]) -> Dict[str, Any]:
    """V12.9 inner-grid authority.

    The seed grid may help locate the outer panel, but it is *never* accepted as
    the final destination geometry.  Final x/y lines must be re-detected inside
    that panel as a complete 6x10 lattice, excluding header and footer.
    """
    try:
        if image is None or not panel_probe or not panel_probe.get('ok'):
            return {'ok':False,'reason':'PERSONAL_STORAGE_PANEL_NOT_PROVEN'}
        panel=[int(v) for v in panel_probe.get('panel_rect',[])[:4]]
        if len(panel)!=4: return {'ok':False,'reason':'PERSONAL_STORAGE_PANEL_RECT_INVALID'}
        arr=np.asarray(image.convert('RGB')); gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
        seed_x=[int(v) for v in (seed_grid or {}).get('x_lines',[])]; seed_y=[int(v) for v in (seed_grid or {}).get('y_lines',[])]
        px=float(np.mean(np.diff(seed_x))) if len(seed_x)==7 else max(18.0,(panel[2]-panel[0])/7.6)
        py=float(np.mean(np.diff(seed_y))) if len(seed_y)==11 else max(18.0,(panel[3]-panel[1])/12.7)
        xfit=_panel_local_uniform_lattice(gray,panel,axis='x',count=7,seed_pitch=px)
        yfit=_panel_local_uniform_lattice(gray,panel,axis='y',count=11,seed_pitch=py)
        if not xfit.get('ok') or not yfit.get('ok'):
            return {'ok':False,'reason':'PERSONAL_STORAGE_INNER_GRID_NOT_VERIFIED','x_lattice':xfit,'y_lattice':yfit,'panel_rect':panel}
        xs=[int(v) for v in xfit['lines']]; ys=[int(v) for v in yfit['lines']]
        grid_rect=[xs[0],ys[0],xs[-1],ys[-1]]
        header_rect=[panel[0],panel[1],panel[2],ys[0]]
        footer_rect=[panel[0],ys[-1],panel[2],panel[3]]
        if not (panel[0] < xs[0] < xs[-1] < panel[2] and panel[1] < ys[0] < ys[-1] < panel[3]):
            return {'ok':False,'reason':'PERSONAL_STORAGE_GRID_NOT_INSIDE_PANEL','panel_rect':panel,'grid_rect':grid_rect}
        if _rect_intersection_area(grid_rect,header_rect)!=0 or _rect_intersection_area(grid_rect,footer_rect)!=0:
            return {'ok':False,'reason':'PERSONAL_STORAGE_GRID_INTERSECTS_HEADER_FOOTER','panel_rect':panel,'grid_rect':grid_rect,'header_rect':header_rect,'footer_rect':footer_rect}
        xr,yr=_grid_border_strength(arr,xs,ys)
        conf=min(0.99,max(0.0,.52+.12*min(1.0,float(xfit.get('score',0))/2.0)+.12*min(1.0,float(yfit.get('score',0))/2.0)+.12*min(1.0,float(xr)/4.0)+.12*min(1.0,float(yr)/4.0)))
        return {
            'ok':True,'kind':GridOwner.PERSONAL_STORAGE.value,'owner':GridOwner.PERSONAL_STORAGE.value,
            'coordinate_space':'CLIENT','inner_grid_verified':True,'lattice_source':'PANEL_LOCAL_REFINED_V12_9',
            'confidence':round(float(conf),3),'x_lines':xs,'y_lines':ys,'cols':6,'rows':10,
            'roi':grid_rect,'grid_rect':grid_rect,'panel_rect':panel,'header_rect':header_rect,'footer_rect':footer_rect,
            'spacing_x':[int(v) for v in np.diff(xs)],'spacing_y':[int(v) for v in np.diff(ys)],
            'pitch_x':round(float(np.mean(np.diff(xs))),3),'pitch_y':round(float(np.mean(np.diff(ys))),3),
            'x_border_ratio':round(float(xr),3),'y_border_ratio':round(float(yr),3),
            'x_lattice':xfit,'y_lattice':yfit,
            'panel_local_margins':[xs[0]-panel[0],ys[0]-panel[1],panel[2]-xs[-1],panel[3]-ys[-1]],
        }
    except Exception as e:
        return {'ok':False,'reason':'PERSONAL_STORAGE_INNER_GRID_EXCEPTION','error':str(e)}


def _container_norm_rect(rect, w, h):
    if not rect or len(rect)!=4 or not w or not h:
        return []
    return [float(rect[0])/w,float(rect[1])/h,float(rect[2])/w,float(rect[3])/h]


def _container_clamp01(v):
    return max(0.0,min(1.0,float(v)))


def _container_iou(a,b):
    if not a or not b or len(a)!=4 or len(b)!=4:return 0.0
    x0=max(a[0],b[0]); y0=max(a[1],b[1]); x1=min(a[2],b[2]); y1=min(a[3],b[3])
    inter=max(0,x1-x0)*max(0,y1-y0)
    aa=max(1,(a[2]-a[0])*(a[3]-a[1])); bb=max(1,(b[2]-b[0])*(b[3]-b[1]))
    return float(inter)/float(aa+bb-inter)


def _container_footer_signature(image:Image.Image, footer_rect, pitch_y):
    try:
        arr=np.asarray(image.convert('RGB')); h,w=arr.shape[:2]
        x0,y0,x1,y1=[int(v) for v in footer_rect]
        x0=max(0,min(w-1,x0)); x1=max(x0+1,min(w,x1)); y0=max(0,min(h-1,y0)); y1=max(y0+1,min(h,y1))
        crop=arr[y0:y1,x0:x1]
        if crop.size==0:return {'depth_cells':0.0,'edge_density':0.0,'component_count':0,'complexity':0.0}
        gray=cv2.cvtColor(crop,cv2.COLOR_RGB2GRAY); edges=cv2.Canny(gray,45,135)
        density=float(np.mean(edges>0)); n,labels,stats,_=cv2.connectedComponentsWithStats((edges>0).astype(np.uint8),8)
        comps=0
        for i in range(1,n):
            area=int(stats[i,cv2.CC_STAT_AREA])
            if 6<=area<=max(20,int(crop.shape[0]*crop.shape[1]*.30)):comps+=1
        depth=float(max(0,y1-y0))/max(1.0,float(pitch_y or 28.0))
        complexity=_container_clamp01(.55*min(1.0,density/.18)+.45*min(1.0,comps/24.0))
        return {'depth_cells':round(depth,3),'edge_density':round(density,4),'component_count':int(comps),'complexity':round(complexity,3)}
    except Exception:
        return {'depth_cells':0.0,'edge_density':0.0,'component_count':0,'complexity':0.0}


def _container_candidate_from_grid(image:Image.Image, grid:Dict[str,Any], source:str):
    if not isinstance(grid,dict) or not grid.get('ok'):return None
    xs=[int(v) for v in grid.get('x_lines',[])]; ys=[int(v) for v in grid.get('y_lines',[])]
    if len(xs)!=7 or len(ys)!=11:return None
    px=max(18.0,float(np.mean(np.diff(xs)))); py=max(18.0,float(np.mean(np.diff(ys))))
    # Container ownership needs the *full* footer, so use a wider border search
    # than the historical grid-only panel probe (Player Bag footer is ~3 cells deep).
    arr=np.asarray(image.convert('RGB')); gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
    gx0,gy0,gx1,gy1=xs[0],ys[0],xs[-1],ys[-1]
    left,ls=_panel_edge_peak_vertical(gray,gx0-1.45*px,gx0-.35*px,gy0-2.5*py,gy1+4.0*py)
    right,rs=_panel_edge_peak_vertical(gray,gx1+.35*px,gx1+1.45*px,gy0-2.5*py,gy1+4.0*py)
    top,ts=_panel_edge_peak_horizontal(gray,gy0-2.6*py,gy0-.45*py,gx0-1.5*px,gx1+1.5*px)
    bottom,bs=_panel_edge_peak_horizontal(gray,gy1+.20*py,gy1+4.0*py,gx0-1.5*px,gx1+1.5*px)
    if None not in (left,right,top,bottom) and left<gx0<gx1<right and top<gy0<gy1<bottom:
        panel=[int(left),int(top),int(right),int(bottom)]; edge_conf=_container_clamp01(float(np.mean([ls,rs,ts,bs]))/130.0)
    else:
        # Structure-safe envelope fallback. This does not assign owner; it only keeps
        # a candidate available for pairwise/profile scoring.
        panel=[max(0,int(round(xs[0]-.9*px))),max(0,int(round(ys[0]-1.7*py))),min(image.width,int(round(xs[-1]+.9*px))),min(image.height,int(round(ys[-1]+3.5*py)))]
        edge_conf=.30
    grid_rect=[xs[0],ys[0],xs[-1],ys[-1]]
    footer=[panel[0],grid_rect[3],panel[2],panel[3]]; header=[panel[0],panel[1],panel[2],grid_rect[1]]
    fs=_container_footer_signature(image,footer,py); w,h=image.width,image.height
    pid=hashlib.sha256(str([panel,grid_rect]).encode('utf-8')).hexdigest()[:10].upper()
    return {
        'candidate_id':'CC-'+pid,'source':str(source),'coordinate_space':'CLIENT',
        'x_lines':xs,'y_lines':ys,'cols':6,'rows':10,'panel_rect':panel,'grid_rect':grid_rect,'roi':grid_rect,
        'header_rect':header,'footer_rect':footer,'panel_norm':_container_norm_rect(panel,w,h),'grid_norm':_container_norm_rect(grid_rect,w,h),
        'panel_height_norm':round((panel[3]-panel[1])/max(1.0,h),5),'panel_width_norm':round((panel[2]-panel[0])/max(1.0,w),5),
        'top_norm':round(panel[1]/max(1.0,h),5),'footer_signature':fs,'edge_confidence':round(float(edge_conf),3),
        'detector_confidence':round(float(grid.get('confidence') or .60),3),
        # Diagnostic only; never consumed as owner truth.
        'bootstrap_owner_ignored':str(grid.get('owner') or grid.get('kind') or ''),
    }


def _container_line_integrals(gray):
    gx=np.abs(cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3)); gy=np.abs(cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3))
    return np.vstack([np.zeros((1,gx.shape[1]),np.float32),np.cumsum(gx,axis=0)]), np.hstack([np.zeros((gy.shape[0],1),np.float32),np.cumsum(gy,axis=1)])


def _container_generic_grid_candidates(image:Image.Image, limit:int=8):
    """Whole-client position-independent 6x10 lattice fallback.

    This exists specifically so moved/swapped panels do not depend on historical
    canonical X/Y anchors. It is a recovery candidate finder, not an owner classifier.
    """
    try:
        import heapq
        arr=np.asarray(image.convert('RGB')); gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY); h,w=gray.shape[:2]
        vint,hint=_container_line_integrals(gray); base=28.0*min(w/800.0,h/600.0)
        pmin=max(18,int(round(base*.78))); pmax=min(40,int(round(base*1.28))); top=[]
        for pitch in range(pmin,pmax+1):
            spanx=6*pitch; spany=10*pitch
            if spanx>=w or spany>=h:continue
            for y0 in range(max(22,int(.035*h)),h-spany-5,6):
                y1=y0+spany; vseg=(vint[y1,:]-vint[y0,:])/max(1,spany)
                for x0 in range(4,w-spanx-4,6):
                    xs=[x0+i*pitch for i in range(7)]; ys=[y0+j*pitch for j in range(11)]
                    score=float(np.mean(vseg[xs]))+float(np.mean([(hint[y,x0+spanx]-hint[y,x0])/max(1,spanx) for y in ys]))
                    row=(score,x0,y0,pitch)
                    if len(top)<32:heapq.heappush(top,row)
                    elif score>top[0][0]:heapq.heapreplace(top,row)
        raw=[]
        for score,x0,y0,pitch in sorted(top,reverse=True):
            if score<115.0:continue
            best=(score,x0,y0,pitch)
            for pp in range(max(pmin,pitch-2),min(pmax,pitch+2)+1):
                sx=6*pp; sy=10*pp
                for yy in range(max(2,y0-5),min(h-sy-2,y0+5)+1):
                    y1=yy+sy; vseg=(vint[y1,:]-vint[yy,:])/max(1,sy)
                    for xx in range(max(2,x0-5),min(w-sx-2,x0+5)+1):
                        xs=[xx+i*pp for i in range(7)]; ys=[yy+j*pp for j in range(11)]
                        sc=float(np.mean(vseg[xs]))+float(np.mean([(hint[y,xx+sx]-hint[y,xx])/max(1,sx) for y in ys]))
                        if sc>best[0]:best=(sc,xx,yy,pp)
            sc,xx,yy,pp=best; g={'ok':True,'x_lines':[int(xx+i*pp) for i in range(7)],'y_lines':[int(yy+j*pp) for j in range(11)],'confidence':_container_clamp01(sc/420.0)}
            c=_container_candidate_from_grid(image,g,'GENERIC_6X10_LATTICE')
            if not c:continue
            c['generic_score']=round(float(sc),2)
            # Collapse shifted lattice aliases of one physical panel before owner scoring.
            if any(_container_iou(c['panel_rect'],q['panel_rect'])>.35 or _container_iou(c['grid_rect'],q['grid_rect'])>.50 for q in raw):continue
            raw.append(c)
            if len(raw)>=limit:break
        return raw
    except Exception:
        return []


def detect_jx1_container_candidates(image:Image.Image) -> Dict[str,Any]:
    """Public owner-neutral inventory-like panel candidate discovery.

    This is intended for guided container learning. It never assigns PLAYER_BAG
    or STORAGE_CHEST ownership and never uses title OCR as owner truth. Legacy
    fixed-position detectors are anonymous bootstrap finders only; the whole-client
    lattice scan supplies movement/scale-tolerant recovery candidates.
    """
    if image is None:
        return {'ok':False,'reason':'CONTAINER_CAPTURE_FAILED','candidates':[],'count':0,'title_ocr_used':False}
    candidates=[]
    for name,fn in (('BOOTSTRAP_INVENTORY_GRID',detect_inventory_grid),('BOOTSTRAP_STORAGE_GRID',detect_personal_storage_grid)):
        try:g=fn(image)
        except Exception:continue
        c=_container_candidate_from_grid(image,g,name)
        if c and not any(_container_iou(c['grid_rect'],q['grid_rect'])>.58 for q in candidates):
            candidates.append(c)
    for c in _container_generic_grid_candidates(image):
        if any(_container_iou(c['panel_rect'],q['panel_rect'])>.48 or _container_iou(c['grid_rect'],q['grid_rect'])>.62 for q in candidates):
            continue
        candidates.append(c)
    # Collapse shifted aliases of one physical 6x10 lattice. Candidate ownership is
    # still unknown; this only de-duplicates geometry.
    ordered=sorted(candidates,key=lambda c:(float(c.get('generic_score') or 0.0),float(c.get('detector_confidence') or 0.0),float(c.get('edge_confidence') or 0.0)),reverse=True)
    dedup=[]
    for c in ordered:
        gx=c.get('grid_rect') or []; pn=c.get('panel_rect') or []
        if len(gx)!=4:continue
        cx=(gx[0]+gx[2])/2.0; cy=(gx[1]+gx[3])/2.0; gw=max(1.0,gx[2]-gx[0]); gh=max(1.0,gx[3]-gx[1])
        alias=False
        for q in dedup:
            qg=q.get('grid_rect') or []; qcx=(qg[0]+qg[2])/2.0; qcy=(qg[1]+qg[3])/2.0; qgw=max(1.0,qg[2]-qg[0]); qgh=max(1.0,qg[3]-qg[1])
            same_lattice=abs(gw-qgw)<=max(8.0,.12*max(gw,qgw)) and abs(gh-qgh)<=max(12.0,.12*max(gh,qgh))
            near_column=abs(cx-qcx)<=max(20.0,.18*max(gw,qgw))
            vertically_alias=abs(cy-qcy)<=max(55.0,.32*max(gh,qgh))
            if _container_iou(gx,qg)>.40 or (_container_iou(pn,q.get('panel_rect') or [])>.34) or (same_lattice and near_column and vertically_alias):
                alias=True;break
        if not alias:dedup.append(c)
    public=[]
    for c in dedup[:8]:
        d=dict(c)
        # Never leak/bootstrap an owner label into learning.
        d.pop('owner',None); d.pop('kind',None)
        d['owner']='UNASSIGNED'; d['title_ocr_used']=False
        d['candidate_quality']=round(_container_clamp01(.50*float(c.get('detector_confidence') or 0)+.30*float(c.get('edge_confidence') or 0)+.20*min(1.0,float(c.get('generic_score') or 0)/380.0)),4)
        public.append(d)
    return {'ok':bool(public),'reason':None if public else 'INVENTORY_PANEL_CANDIDATES_NOT_FOUND','candidates':public,'count':len(public),'title_ocr_used':False,'owner_assigned':False}


def score_jx1_container_profile(candidate:Dict[str,Any], profile:Dict[str,Any]) -> float:
    """Public scale-tolerant profile-match score for guided learning."""
    return float(_container_profile_score(dict(candidate or {}),dict(profile or {})))


def _container_profile_score(candidate,profile):
    if not isinstance(profile,dict) or not profile:return 0.0
    pn=candidate.get('panel_norm') or []; gn=candidate.get('grid_norm') or []
    pp=profile.get('panel_rect_norm') or profile.get('panel_norm') or []; gp=profile.get('grid_rect_norm') or profile.get('grid_norm') or []
    score=weight=0.0
    def sim(a,b,t):return _container_clamp01(1.0-abs(float(a)-float(b))/max(1e-6,float(t)))
    # Horizontal location is intentionally weak/secondary.
    if len(pn)==4 and len(pp)==4:
        for wt,val in ((.08,sim(pn[0],pp[0],.18)),(.18,sim(pn[1],pp[1],.12)),(.23,sim(pn[3]-pn[1],pp[3]-pp[1],.12)),(.10,sim(pn[2]-pn[0],pp[2]-pp[0],.12))):score+=wt*val;weight+=wt
    if len(gn)==4 and len(gp)==4:
        for wt,val in ((.13,sim(gn[2]-gn[0],gp[2]-gp[0],.08)),(.13,sim(gn[3]-gn[1],gp[3]-gp[1],.10))):score+=wt*val;weight+=wt
    fs=candidate.get('footer_signature') or {}; pfs=profile.get('footer_structure_signature') or {}
    if pfs:
        score+=.10*sim(fs.get('depth_cells',0),pfs.get('depth_cells',0),1.5);weight+=.10
        score+=.05*sim(fs.get('complexity',0),pfs.get('complexity',0),.45);weight+=.05
    return _container_clamp01(score/max(.001,weight)) if weight else 0.0


def _container_single_scores(c,profiles):
    fs=c.get('footer_signature') or {}; ph=float(c.get('panel_height_norm') or 0); top=float(c.get('top_norm') or .5); depth=float(fs.get('depth_cells') or 0); comp=float(fs.get('complexity') or 0)
    pprof=_container_profile_score(c,(profiles or {}).get('PLAYER_BAG') or {}); sprof=_container_profile_score(c,(profiles or {}).get('STORAGE_CHEST') or {})
    player=.34*_container_clamp01((depth-1.30)/2.20)+.18*_container_clamp01((ph-.48)/.22)+.10*_container_clamp01((.48-top)/.30)+.13*comp+.25*pprof
    storage=.30*_container_clamp01((2.05-depth)/1.50)+.16*_container_clamp01((.72-ph)/.24)+.08*_container_clamp01((top-.08)/.45)+.11*(1.0-comp)+.35*sprof
    return {'player':round(_container_clamp01(player),4),'storage':round(_container_clamp01(storage),4),'player_profile':round(pprof,4),'storage_profile':round(sprof,4)}


def _container_assignment_score(player,storage,image,profiles):
    ph=max(1.0,float(player['panel_rect'][3]-player['panel_rect'][1])); sh=max(1.0,float(storage['panel_rect'][3]-storage['panel_rect'][1])); H=max(1.0,float(image.height)); avg=(ph+sh)/2.0
    pt=float(player['panel_rect'][1]); st=float(storage['panel_rect'][1]); pfs=player.get('footer_signature') or {}; sfs=storage.get('footer_signature') or {}
    rel_h=_container_clamp01(.5+(ph-sh)/max(20.0,.22*avg)); rel_top=_container_clamp01(.5+(st-pt)/max(15.0,.16*H)); rel_footer=_container_clamp01(.5+(float(pfs.get('depth_cells') or 0)-float(sfs.get('depth_cells') or 0))/3.0); rel_complex=_container_clamp01(.5+(float(pfs.get('complexity') or 0)-float(sfs.get('complexity') or 0))/.8)
    ps=_container_single_scores(player,profiles); ss=_container_single_scores(storage,profiles); structural=.5*(float(player.get('edge_confidence') or 0)+float(storage.get('edge_confidence') or 0))
    structural_score=.28*rel_h+.25*rel_top+.18*rel_footer+.09*rel_complex+.08*ps['player']+.08*ss['storage']+.04*structural
    # Once the guided wizard has learned both owners, recorded geometry profiles
    # become primary owner evidence. Structural taller/higher/footer relations remain
    # important but may vary after UI movement/scale and must not override a strong
    # learned identity match. Horizontal X is still weak/secondary inside profile score.
    have_profiles=bool((profiles or {}).get('PLAYER_BAG')) and bool((profiles or {}).get('STORAGE_CHEST'))
    profile_pair=.5*(float(ps.get('player_profile') or 0.0)+float(ss.get('storage_profile') or 0.0))
    score=(.55*profile_pair+.45*structural_score) if have_profiles else structural_score
    return round(_container_clamp01(score),4),{'relative_height':round(rel_h,4),'relative_top':round(rel_top,4),'relative_footer':round(rel_footer,4),'relative_footer_complexity':round(rel_complex,4),'player_single':ps,'storage_single':ss,'structural':round(structural,4),'structural_score':round(float(structural_score),4),'profile_pair_score':round(float(profile_pair),4),'profile_primary':bool(have_profiles)}


def _container_grid_payload(c,owner):
    g={'ok':True,'kind':owner,'owner':owner,'coordinate_space':'CLIENT','x_lines':list(c.get('x_lines') or []),'y_lines':list(c.get('y_lines') or []),'cols':6,'rows':10,'roi':list(c.get('grid_rect') or []),'grid_rect':list(c.get('grid_rect') or []),'panel_rect':list(c.get('panel_rect') or []),'header_rect':list(c.get('header_rect') or []),'footer_rect':list(c.get('footer_rect') or []),'candidate_id':c.get('candidate_id'),'owner_confidence':c.get('owner_confidence'),'inner_grid_verified':True,'grid_authority':'CONTAINER_GEOMETRY_RESOLVER_V1_1'}
    if owner==GridOwner.PERSONAL_STORAGE.value:g['storage_owner_verified']=True
    return g


def _container_identity_payload(c,owner,score):
    panel=list(c.get('panel_rect') or []); grid=list(c.get('grid_rect') or []); footer=list(c.get('footer_rect') or []); header=list(c.get('header_rect') or [])
    if owner==GridOwner.PERSONAL_STORAGE.value:
        return asdict(StoragePanelIdentity(panel,header,grid,footer,[panel[0]+4,panel[1]+4,panel[2]-4,max(panel[1]+5,grid[1]-3)] if len(panel)==4 and len(grid)==4 else [],[panel[0]+8,grid[3]+2,panel[2]-8,panel[3]-2] if len(panel)==4 and len(grid)==4 else [],float(score),float(score),True))
    return asdict(PlayerInventoryPanelIdentity(panel,grid,[panel[0]+4,grid[3]+2,panel[2]-4,max(grid[3]+3,footer[1]+int(max(2,(footer[3]-footer[1])*.50)))] if len(panel)==4 and len(grid)==4 and len(footer)==4 else [],[panel[0]+4,max(grid[3]+2,footer[1]),panel[2]-4,panel[3]-3] if len(panel)==4 and len(grid)==4 else [],float(score),float(score)))


def resolve_jx1_container_candidates(candidates, image:Image.Image, profiles:Dict[str,Any]=None, require_storage:bool=True) -> Dict[str,Any]:
    """Resolve anonymous container candidates into explicit owner namespaces.

    This function is also used by QA to prove move/swap/resolution invariants without
    depending on any title text or fixed desktop coordinates.
    """
    profiles=dict(profiles or {}); cs=[dict(c) for c in (candidates or []) if isinstance(c,dict)]
    evidence={'title_ocr_used':False,'absolute_left_right_used':False,'first_grid_wins':False,'candidates':[],'minimum_confidence':.58,'confidence_margin':.10}
    # After the guided wizard has learned BOTH owners, use those profiles to prune
    # obvious lattice false positives before pair assignment. This is profile-based,
    # not absolute X/Y: moved/swapped panels remain valid while unrelated 6x10
    # patterns cannot collapse the pair margin.
    pp=(profiles or {}).get('PLAYER_BAG') or {}; sp=(profiles or {}).get('STORAGE_CHEST') or {}
    if len(cs)>2 and pp and sp:
        pr=[]
        for i,c in enumerate(cs):
            pscore=float(_container_profile_score(c,pp)); sscore=float(_container_profile_score(c,sp)); pr.append((max(pscore,sscore),pscore,sscore,i,c))
        pr.sort(reverse=True,key=lambda x:x[0])
        if len(pr)>=3 and float(pr[1][0])-float(pr[2][0])>=.08:
            evidence['profile_candidate_prune']={'before':len(cs),'after':2,'kept':[pr[0][4].get('candidate_id'),pr[1][4].get('candidate_id')],'third_best_max_profile':round(float(pr[2][0]),4)}
            cs=[pr[0][4],pr[1][4]]
    for c in cs:
        sc=_container_single_scores(c,profiles); c['single_scores']=sc
        evidence['candidates'].append({'candidate_id':c.get('candidate_id'),'panel_rect':c.get('panel_rect'),'grid_rect':c.get('grid_rect'),'footer_signature':c.get('footer_signature'),'panel_norm':c.get('panel_norm'),'source':c.get('source'),'bootstrap_owner_ignored':c.get('bootstrap_owner_ignored'),'scores':sc})
    if not cs:return {'ok':False,'reason':'CONTAINER_NOT_PRESENT','evidence':evidence}
    if len(cs)==1:
        c=cs[0]; sc=c['single_scores']; margin=float(sc['player'])-float(sc['storage']); evidence['single_candidate_margin']=round(margin,4)
        learned_player=(profiles or {}).get('PLAYER_BAG') or {}; learned_storage=(profiles or {}).get('STORAGE_CHEST') or {}
        pmatch=float(_container_profile_score(c,learned_player)) if learned_player else 0.0; smatch=float(_container_profile_score(c,learned_storage)) if learned_storage else 0.0
        evidence['single_profile_match']={'player':round(pmatch,4),'storage':round(smatch,4)}
        learned_accept=bool(learned_player and pmatch>=.62 and (not learned_storage or pmatch-smatch>=.08))
        structural_accept=bool(sc['player']>=.58 and margin>=.10)
        if not require_storage and (learned_accept or structural_accept):
            conf=max(float(sc['player']),pmatch); c['owner_confidence']=conf; evidence.update({'assignment':'SINGLE_PLAYER_BAG','player_candidate_id':c.get('candidate_id'),'profile_primary':bool(learned_accept)})
            ig=_container_grid_payload(c,GridOwner.PLAYER_INVENTORY.value); ii=_container_identity_payload(c,GridOwner.PLAYER_INVENTORY.value,conf)
            return {'ok':True,'reason':None,'inventory_grid':ig,'storage_grid':{},'inventory_identity':ii,'storage_identity':{},'confidence':conf,'structural_anchor_score':float(sc['player']),'evidence':evidence,'coordinate_space':'CLIENT','grid_authority':'CONTAINER_GEOMETRY_RESOLVER_V1_1'}
        return {'ok':False,'reason':'CONTAINER_OWNER_AMBIGUOUS','evidence':evidence}
    ranked=[]
    for i,p in enumerate(cs):
        for j,st in enumerate(cs):
            if i==j:continue
            if _container_iou(p['panel_rect'],st['panel_rect'])>.20:continue
            score,parts=_container_assignment_score(p,st,image,profiles);ranked.append((score,i,j,parts))
    ranked.sort(reverse=True,key=lambda x:x[0])
    if not ranked:return {'ok':False,'reason':'PAIR_RESOLUTION_FAILED','evidence':evidence}
    best=ranked[0]; second=ranked[1] if len(ranked)>1 else (0,None,None,{})
    margin=float(best[0])-float(second[0]); evidence['pair_ranked']=[{'score':r[0],'player_candidate_id':cs[r[1]].get('candidate_id'),'storage_candidate_id':cs[r[2]].get('candidate_id'),'parts':r[3]} for r in ranked[:6]];evidence['pair_margin']=round(margin,4)
    if best[0]<.58 or margin<.10:return {'ok':False,'reason':'CONTAINER_OWNER_AMBIGUOUS','confidence':float(best[0]),'evidence':evidence}
    p=cs[best[1]];st=cs[best[2]];p['owner_confidence']=best[0];st['owner_confidence']=best[0]
    evidence.update({'assignment':'PAIRWISE','player_candidate_id':p.get('candidate_id'),'storage_candidate_id':st.get('candidate_id'),'pairwise_relation_score':best[0]})
    ig=_container_grid_payload(p,GridOwner.PLAYER_INVENTORY.value);sg=_container_grid_payload(st,GridOwner.PERSONAL_STORAGE.value)
    sg['player_inventory_panel_rect']=list(p.get('panel_rect') or []);sg['player_inventory_grid_rect']=list(p.get('grid_rect') or [])
    ii=_container_identity_payload(p,GridOwner.PLAYER_INVENTORY.value,best[0]);si=_container_identity_payload(st,GridOwner.PERSONAL_STORAGE.value,best[0])
    return {'ok':True,'reason':None,'inventory_grid':ig,'storage_grid':sg,'inventory_identity':ii,'storage_identity':si,'confidence':float(best[0]),'structural_anchor_score':float(best[0]),'evidence':evidence,'distinct_grid_rects':True,'storage_left_of_inventory':None,'storage_compact_footer':(st.get('footer_signature') or {}).get('depth_cells',0)<(p.get('footer_signature') or {}).get('depth_cells',0),'inventory_deeper_footer':(p.get('footer_signature') or {}).get('depth_cells',0)>(st.get('footer_signature') or {}).get('depth_cells',0),'storage_header_excluded':True,'storage_footer_excluded':True,'coordinate_space':'CLIENT','grid_authority':'CONTAINER_GEOMETRY_RESOLVER_V1_1'}


def resolve_jx1_containers(image:Image.Image, profiles:Dict[str,Any]=None, require_storage:bool=True) -> Dict[str,Any]:
    """Canonical container ownership resolver for JX1.

    Title OCR, first-grid-wins and absolute left/right coordinates are explicitly
    excluded from owner truth. Candidate grids are anonymous until structural and
    pairwise scoring assigns PLAYER_INVENTORY / PERSONAL_STORAGE.
    """
    if image is None:return {'ok':False,'reason':'CONTAINER_CAPTURE_FAILED','title_ocr_used':False}
    profiles=dict(profiles or {}); candidates=[]
    # Fixed-position legacy detectors are retained only as fast anonymous candidate
    # finders for backward compatibility. Their owner labels are ignored.
    for name,fn in (('BOOTSTRAP_INVENTORY_GRID',detect_inventory_grid),('BOOTSTRAP_STORAGE_GRID',detect_personal_storage_grid)):
        try:g=fn(image)
        except Exception:continue
        c=_container_candidate_from_grid(image,g,name)
        if c and not any(_container_iou(c['grid_rect'],q['grid_rect'])>.58 for q in candidates):candidates.append(c)

    def resolve_list(cs):
        return resolve_jx1_container_candidates(cs,image,profiles,require_storage)

    result=resolve_list(candidates)
    if result.get('ok'):return result
    # Generic fallback scans the whole client and does not assume historical X/Y.
    merged=list(candidates)
    for c in _container_generic_grid_candidates(image):
        if any(_container_iou(c['panel_rect'],q['panel_rect'])>.35 or _container_iou(c['grid_rect'],q['grid_rect'])>.50 for q in merged):continue
        merged.append(c)
    if len(merged)>len(candidates):result=resolve_list(merged)
    return result


def detect_jx1_panel_identities(image: Image.Image) -> Dict[str, Any]:
    """Backward-compatible façade over the canonical container resolver.

    Existing StoreController callers keep the old key names, but ownership is no
    longer based on title OCR, first-grid selection, absolute left/right, or the
    previous ``storage_left_of_inventory`` gate.
    """
    return resolve_jx1_containers(image,profiles=None,require_storage=True)

def _nearest_edge_positions(gray: np.ndarray, expected_x, expected_y, radius_x=7, radius_y=7):
    h, w = gray.shape[:2]
    gx = np.abs(cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3))
    gy = np.abs(cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3))

    yA = max(0, int(min(expected_y) - 24))
    yB = min(h, int(max(expected_y) + 24))
    xA = max(0, int(min(expected_x) - 24))
    xB = min(w, int(max(expected_x) + 24))

    vx = gx[yA:yB, :].sum(axis=0)
    hy = gy[:, xA:xB].sum(axis=1)

    xs = []
    for x in expected_x:
        xx = int(round(x))
        a, b = max(0, xx-radius_x), min(w, xx+radius_x+1)
        if b <= a:
            return None
        seg = vx[a:b]
        xs.append(a + int(np.argmax(seg)))

    ys = []
    for y in expected_y:
        yy = int(round(y))
        a, b = max(0, yy-radius_y), min(h, yy+radius_y+1)
        if b <= a:
            return None
        seg = hy[a:b]
        ys.append(a + int(np.argmax(seg)))

    return xs, ys

def _find_regular_sequence(signal, n, start_lo, start_hi, dmin=26, dmax=30, prefer_end=None):
    L = len(signal)
    med = float(np.median(signal)) + 1e-6
    best = None

    for d in range(dmin, dmax+1):
        max_start = min(start_hi, L - 1 - (n-1)*d)
        for st in range(max(0, start_lo), max_start+1):
            pos, vals = [], []
            for k in range(n):
                p = st + k*d
                a, b = max(0, p-2), min(L, p+3)
                if b <= a:
                    break
                j = a + int(np.argmax(signal[a:b]))
                pos.append(j)
                vals.append(float(signal[j]))
            if len(pos) != n:
                continue
            if any((pos[i+1]-pos[i]) < d-5 or (pos[i+1]-pos[i]) > d+5 for i in range(n-1)):
                continue

            score = float(np.mean(vals) / med)
            if prefer_end is not None:
                score *= 1.0 / (1.0 + 0.02*abs(pos[-1]-prefer_end))

            if best is None or score > best[0]:
                best = (score, pos, d)

    return best

def _detect_cropped_grid(arr: np.ndarray):
    """Used for regression/test crops and for unusual capture geometries."""
    h, w = arr.shape[:2]
    gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
    gx = np.abs(cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3))
    gy = np.abs(cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3))

    vx = gx[int(0.10*h):, :].sum(axis=0)
    bx = _find_regular_sequence(vx, 7, 0, min(40, w-1), 26, 30, prefer_end=w-3)
    if bx is None:
        return None

    xs = bx[1]
    hy = gy[:, xs[0]:xs[-1]+1].sum(axis=1)
    by = _find_regular_sequence(hy, 11, max(10, int(.05*h)), min(int(.30*h), 90), 26, 30, prefer_end=h-3)
    if by is None:
        return None

    return xs, by[1]

def _grid_border_strength(arr: np.ndarray, xs: List[int], ys: List[int]):
    gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
    gx = np.abs(cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3))
    gy = np.abs(cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3))

    vx = gx[ys[0]:ys[-1]+1, :].sum(axis=0)
    hy = gy[:, xs[0]:xs[-1]+1].sum(axis=1)

    xv = []
    for x in xs:
        xv.append(float(np.max(vx[max(0,x-1):min(len(vx),x+2)])))
    yv = []
    for y in ys:
        yv.append(float(np.max(hy[max(0,y-1):min(len(hy),y+2)])))

    roi_v = vx[max(0,xs[0]-10):min(len(vx),xs[-1]+11)]
    roi_h = hy[max(0,ys[0]-10):min(len(hy),ys[-1]+11)]

    xr = float(np.mean(xv) / (float(np.median(roi_v)) + 1e-6))
    yr = float(np.mean(yv) / (float(np.median(roi_h)) + 1e-6))
    return xr, yr

def _cell_features(arr: np.ndarray, xs: List[int], ys: List[int]) -> List[Dict[str, Any]]:
    """
    Root fix:
    Empty JX1 inventory cells have textured stone backgrounds, so std/edge
    MUST NOT be used as an occupied signal. Real item sprites introduce
    bright/high-value and chromatic pixels; those are the primary evidence.
    """
    out = []
    for r in range(10):
        for c in range(6):
            padx = max(2, int((xs[c+1]-xs[c]) * 0.12))
            pady = max(2, int((ys[r+1]-ys[r]) * 0.12))
            x0, x1 = xs[c]+padx, xs[c+1]-padx
            y0, y1 = ys[r]+pady, ys[r+1]-pady
            cell = arr[y0:y1, x0:x1]

            if cell.size == 0:
                mean = std = edge = bright = sat = max90 = colorbright = 0.0
            else:
                gray = cv2.cvtColor(cell, cv2.COLOR_RGB2GRAY)
                hsv = cv2.cvtColor(cell, cv2.COLOR_RGB2HSV)
                mx = cell.max(axis=2)
                mn = cell.min(axis=2)

                mean = float(gray.mean())
                std = float(gray.std())
                edge = float((cv2.Canny(gray, 40, 90) > 0).mean())
                bright = float((gray > 80).mean())
                max90 = float((mx > 90).mean())
                colorbright = float(((mx > 80) & ((mx-mn) > 30)).mean())
                sat = float(hsv[...,1].mean())

            # Verified against both the original full 800x600 client fixture
            # and the user's current inventory screenshot.
            occupied = bool(
                bright > 0.06 or
                max90 > 0.08 or
                colorbright > 0.08
            )

            occupied_score = max(
                bright / 0.20,
                max90 / 0.24,
                colorbright / 0.22,
            )

            out.append({
                "row": r, "col": c,
                "mean": round(mean,3),
                "std": round(std,3),
                "edge": round(edge,4),
                "bright": round(bright,4),
                "max90": round(max90,4),
                "colorbright": round(colorbright,4),
                "sat": round(sat,3),
                "occupied": occupied,
                "occupied_score": round(float(min(1.0, max(0.0, occupied_score))),3),
                "rect": [int(xs[c]), int(ys[r]), int(xs[c+1]), int(ys[r+1])],
            })
    return out

def _robust_axis_lattice_fit(lines, expected_count: int, canonical_lines, scale: float) -> Dict[str, Any]:
    """Fit a detected boundary sequence to one global canonical lattice.

    This is a recovery-only geometry helper.  It tolerates at most one missing or
    one spurious detector line, or one locally shifted detector line, but keeps a
    strict client-scale/canonical prior so unrelated rectangular patterns cannot
    become an inventory grid.
    """
    vals = sorted(float(v) for v in (lines or []))
    n = int(expected_count)
    if n < 3 or abs(len(vals) - n) > 1:
        return {"ok": False, "reason": "LATTICE_LINE_COUNT_UNSUPPORTED", "observed_count": len(vals), "expected_count": n}

    canon = np.asarray(canonical_lines, dtype=float) * float(scale)
    if len(canon) != n:
        return {"ok": False, "reason": "LATTICE_CANONICAL_SHAPE_MISMATCH"}
    canonical_pitch = float(np.median(np.diff(canon)))
    canonical_origin = float(canon[0])
    if canonical_pitch <= 1.0:
        return {"ok": False, "reason": "LATTICE_CANONICAL_PITCH_INVALID"}

    # Candidate assignments support: exact count, one missing line, one spurious
    # line, and the common detector case where one missing line is replaced by one
    # nearby false line while the raw count remains unchanged.
    assignments = []
    m = len(vals)
    full_idx = list(range(n))
    if m == n:
        assignments.append((vals, full_idx, None, None, "DIRECT"))
        # Replacement candidate: ignore one observed line and one expected index.
        # The strict canonical prior/residual gates below prevent broad acceptance.
        for drop_obs in range(m):
            kept = [v for j, v in enumerate(vals) if j != drop_obs]
            for miss_idx in range(n):
                idxs = [i for i in full_idx if i != miss_idx]
                assignments.append((kept, idxs, miss_idx, drop_obs, "ONE_REPLACEMENT"))
    elif m == n - 1:
        for miss_idx in range(n):
            idxs = [i for i in full_idx if i != miss_idx]
            assignments.append((vals, idxs, miss_idx, None, "ONE_MISSING"))
    elif m == n + 1:
        for drop_obs in range(m):
            kept = [v for j, v in enumerate(vals) if j != drop_obs]
            assignments.append((kept, full_idx, None, drop_obs, "ONE_SPURIOUS"))

    best = None
    for obs, idxs, missing_idx, dropped_obs, mode in assignments:
        if len(obs) != len(idxs) or len(obs) < 3:
            continue
        obs_arr = np.asarray(obs, dtype=float)
        idx_arr = np.asarray(idxs, dtype=float)

        slopes = []
        for a in range(len(obs_arr)):
            for b in range(a + 1, len(obs_arr)):
                di = float(idx_arr[b] - idx_arr[a])
                if abs(di) > 1e-9:
                    slopes.append(float((obs_arr[b] - obs_arr[a]) / di))
        if not slopes:
            continue
        pitch0 = float(np.median(slopes))
        if pitch0 <= 1.0:
            continue
        origin0 = float(np.median(obs_arr - idx_arr * pitch0))
        residual0 = obs_arr - (origin0 + idx_arr * pitch0)
        inlier_tol0 = max(2.0 * float(scale), 0.14 * abs(pitch0))
        inliers0 = np.abs(residual0) <= inlier_tol0
        # One locally noisy line is recoverable; more than one is not.
        if int(np.sum(inliers0)) < len(obs_arr) - 1:
            continue

        # Refine on inliers only so a split/misaligned line cannot pull pitch.
        use = inliers0 if int(np.sum(inliers0)) >= 3 else np.ones_like(inliers0, dtype=bool)
        A = np.column_stack([np.ones(int(np.sum(use))), idx_arr[use]])
        try:
            origin, pitch = np.linalg.lstsq(A, obs_arr[use], rcond=None)[0]
        except Exception:
            origin, pitch = origin0, pitch0
        origin = float(origin); pitch = float(pitch)
        residual = obs_arr - (origin + idx_arr * pitch)
        abs_res = np.abs(residual)
        inlier_tol = max(2.0 * float(scale), 0.15 * abs(pitch))
        hard_tol = max(4.0 * float(scale), 0.35 * abs(pitch))
        inliers = abs_res <= inlier_tol
        outlier_count = int(len(abs_res) - np.sum(inliers))
        rmse = float(np.sqrt(np.mean(residual * residual)))
        max_res = float(np.max(abs_res)) if len(abs_res) else 999.0

        pitch_tol = max(1.5 * float(scale), 0.12 * canonical_pitch)
        origin_tol = max(5.0 * float(scale), 0.30 * canonical_pitch)
        end_tol = max(6.0 * float(scale), 0.32 * canonical_pitch)
        fitted_end = origin + float(n - 1) * pitch
        canonical_end = float(canon[-1])

        if abs(pitch - canonical_pitch) > pitch_tol:
            continue
        if abs(origin - canonical_origin) > origin_tol:
            continue
        if abs(fitted_end - canonical_end) > end_tol:
            continue
        if outlier_count > 1:
            continue
        if max_res > hard_tol:
            continue
        if rmse > max(2.5 * float(scale), 0.16 * abs(pitch)):
            continue

        # Geometry snapping uses the current client-scale canonical pitch, but
        # derives the origin from this frame.  This avoids letting one noisy local
        # line compress/stretch all downstream cell heights while still allowing a
        # small real panel translation.
        snap_pitch = canonical_pitch
        # Use the robustly fitted current-frame origin so a small real panel
        # translation is preserved; only pitch is canonicalized to client scale.
        snap_origin = origin
        if abs(snap_origin - canonical_origin) > origin_tol:
            continue
        reconstructed = [int(round(snap_origin + i * snap_pitch)) for i in range(n)]
        if any(reconstructed[i + 1] <= reconstructed[i] for i in range(n - 1)):
            continue
        # Small penalty for reconstruction complexity keeps DIRECT preferred.
        penalty = 0.0 if mode == "DIRECT" else (0.30 if mode in ("ONE_MISSING", "ONE_SPURIOUS") else 0.60)
        score = rmse + 0.20 * max_res + penalty
        row = {
            "ok": True,
            "mode": mode,
            "pitch": round(pitch, 4),
            "origin": round(origin, 4),
            "canonical_pitch": round(canonical_pitch, 4),
            "canonical_origin": round(canonical_origin, 4),
            "residuals": [round(float(x), 4) for x in residual],
            "rmse": round(rmse, 4),
            "max_residual": round(max_res, 4),
            "inlier_count": int(len(abs_res) - outlier_count),
            "outlier_count": outlier_count,
            "missing_index": missing_idx,
            "dropped_observed_index": dropped_obs,
            "snap_pitch": round(float(snap_pitch), 4),
            "snap_origin": round(float(snap_origin), 4),
            "reconstructed_lines": reconstructed,
            "score": round(float(score), 4),
        }
        if best is None or float(row["score"]) < float(best["score"]):
            best = row

    return best or {"ok": False, "reason": "LATTICE_FIT_REJECTED", "observed_count": len(vals), "expected_count": n}


def _robust_grid_lattice_validation(image: Image.Image, grid: Dict[str, Any]) -> Dict[str, Any]:
    """Recovery-only global lattice validation for the JX1 right-side 6x10 grid."""
    if image is None or not isinstance(grid, dict):
        return {"ok": False, "reason": "LATTICE_INPUT_INVALID"}
    arr = np.asarray(image.convert("RGB"))
    h, w = arr.shape[:2]
    if w < 600 or h < 450:
        return {"ok": False, "reason": "LATTICE_CLIENT_SIZE_UNSUPPORTED"}
    if int(grid.get("cols") or 0) != 6 or int(grid.get("rows") or 0) != 10:
        return {"ok": False, "reason": "LATTICE_DECLARED_TOPOLOGY_MISMATCH"}

    raw_x = [int(x) for x in grid.get("x_lines", [])]
    raw_y = [int(y) for y in grid.get("y_lines", [])]
    if abs(len(raw_x) - 7) > 1 or abs(len(raw_y) - 11) > 1:
        return {"ok": False, "reason": "LATTICE_RAW_TOPOLOGY_TOO_FAR"}

    sx, sy = w / 800.0, h / 600.0
    fx = _robust_axis_lattice_fit(raw_x, 7, CANONICAL_X, sx)
    fy = _robust_axis_lattice_fit(raw_y, 11, CANONICAL_Y, sy)
    if not fx.get("ok") or not fy.get("ok"):
        return {"ok": False, "reason": "LATTICE_AXIS_REJECTED", "x_fit": fx, "y_fit": fy}

    snapped_x = [int(v) for v in fx.get("reconstructed_lines", [])]
    snapped_y = [int(v) for v in fy.get("reconstructed_lines", [])]
    if len(snapped_x) != 7 or len(snapped_y) != 11:
        return {"ok": False, "reason": "LATTICE_RECONSTRUCTION_SHAPE_INVALID", "x_fit": fx, "y_fit": fy}
    if snapped_x[0] < int(w * 0.68):
        return {"ok": False, "reason": "LATTICE_NOT_RIGHT_SIDE", "x_fit": fx, "y_fit": fy}
    if snapped_x[0] < 0 or snapped_y[0] < 0 or snapped_x[-1] >= w or snapped_y[-1] >= h:
        return {"ok": False, "reason": "LATTICE_OUT_OF_BOUNDS", "x_fit": fx, "y_fit": fy}

    # Current frame must visibly support the lattice.  Use BOTH the detector's
    # current raw boundaries and the snapped lattice as live evidence.  This stays
    # image-authoritative while tolerating one split/misaligned raw line.
    raw_xr, raw_yr = _grid_border_strength(arr, raw_x, raw_y)
    snap_xr, snap_yr = _grid_border_strength(arr, snapped_x, snapped_y)
    xr = max(float(raw_xr), float(snap_xr))
    yr = max(float(raw_yr), float(snap_yr))
    if xr < 1.8 or yr < 1.8:
        return {
            "ok": False, "reason": "LATTICE_BORDER_NOT_VISIBLE",
            "x_border_ratio": round(float(xr), 3), "y_border_ratio": round(float(yr), 3),
            "raw_x_border_ratio": round(float(raw_xr), 3), "raw_y_border_ratio": round(float(raw_yr), 3),
            "snapped_x_border_ratio": round(float(snap_xr), 3), "snapped_y_border_ratio": round(float(snap_yr), 3),
            "x_fit": fx, "y_fit": fy,
        }
    confidence = float(grid.get("confidence") or 0.0)
    if confidence and confidence < 0.72:
        return {"ok": False, "reason": "LATTICE_DETECTOR_CONFIDENCE_LOW", "confidence": round(confidence, 3), "x_fit": fx, "y_fit": fy}

    return {
        "ok": True,
        "reason": "GRID_LATTICE_RECOVERED",
        "lattice_recovered": True,
        "fitted_pitch_x": fx.get("pitch"), "fitted_pitch_y": fy.get("pitch"),
        "fitted_origin_x": fx.get("origin"), "fitted_origin_y": fy.get("origin"),
        "x_residuals": fx.get("residuals"), "y_residuals": fy.get("residuals"),
        "x_inlier_count": fx.get("inlier_count"), "y_inlier_count": fy.get("inlier_count"),
        "x_outlier_count": fx.get("outlier_count"), "y_outlier_count": fy.get("outlier_count"),
        "raw_x_lines": raw_x, "raw_y_lines": raw_y,
        "snapped_x_lines": snapped_x, "snapped_y_lines": snapped_y,
        "reconstructed_lines": {"x": snapped_x, "y": snapped_y},
        "x_fit": fx, "y_fit": fy,
        "x_border_ratio": round(float(xr), 3), "y_border_ratio": round(float(yr), 3),
        "raw_x_border_ratio": round(float(raw_xr), 3), "raw_y_border_ratio": round(float(raw_yr), 3),
        "snapped_x_border_ratio": round(float(snap_xr), 3), "snapped_y_border_ratio": round(float(snap_yr), 3),
        "confidence": round(confidence, 3),
    }


def validate_known_grid(image: Image.Image, grid: Dict[str, Any]) -> Dict[str, Any]:
    if not grid:
        return {"ok": False, "reason": "NO_GRID"}
    arr = np.asarray(image.convert("RGB"))
    h,w = arr.shape[:2]
    xs = [int(x) for x in grid.get("x_lines",[])]
    ys = [int(y) for y in grid.get("y_lines",[])]

    declared_cols = grid.get("cols")
    declared_rows = grid.get("rows")
    if declared_cols is not None and int(declared_cols) != 6:
        return {"ok": False, "reason": "BAD_GRID_SHAPE"}
    if declared_rows is not None and int(declared_rows) != 10:
        return {"ok": False, "reason": "BAD_GRID_SHAPE"}
    if not xs or not ys or xs[0] < 0 or ys[0] < 0 or xs[-1] >= w or ys[-1] >= h:
        return {"ok": False, "reason": "GRID_OUT_OF_BOUNDS"}

    # NORMAL FAST PATH: byte/behavior intent is unchanged.  Robust lattice math
    # is not run unless raw adjacent spacing is locally inconsistent.
    if len(xs) == 7 and len(ys) == 11:
        dx = np.diff(xs)
        dy = np.diff(ys)
        spacing_ok = bool(np.all((dx >= 22) & (dx <= 34)) and np.all((dy >= 22) & (dy <= 34)))
        if spacing_ok:
            xr,yr = _grid_border_strength(arr,xs,ys)
            ok = xr >= 1.8 and yr >= 1.8
            return {
                "ok": bool(ok),
                "x_border_ratio": round(xr,3),
                "y_border_ratio": round(yr,3),
                "reason": None if ok else "GRID_BORDER_NOT_VISIBLE",
            }

    # Recovery path only: validate the complete 6x10 geometry as one lattice.
    robust = _robust_grid_lattice_validation(image, grid)
    if not robust.get("ok"):
        return {"ok": False, "reason": "BAD_GRID_SPACING", "robust_lattice": robust}

    # SNAP_TO_LATTICE is geometry-only.  The screenshot is untouched.  Mutating
    # this live grid object is intentional so subsequent sensing/click coordinates
    # use the reconstructed canonical lattice rather than the noisy local edges.
    raw_x = list(xs); raw_y = list(ys)
    grid["raw_x_lines_before_lattice"] = raw_x
    grid["raw_y_lines_before_lattice"] = raw_y
    grid["x_lines"] = list(robust["snapped_x_lines"])
    grid["y_lines"] = list(robust["snapped_y_lines"])
    grid["spacing_x"] = [int(x) for x in np.diff(grid["x_lines"])]
    grid["spacing_y"] = [int(y) for y in np.diff(grid["y_lines"])]
    grid["lattice_recovered"] = True
    grid["lattice_validation"] = robust
    return robust

def detect_inventory_grid(image: Image.Image) -> Dict[str, Any]:
    arr = np.asarray(image.convert("RGB"))
    h,w = arr.shape[:2]
    gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)

    if w >= 600 and h >= 450:
        sx,sy = w/800.0,h/600.0
        expected_x = CANONICAL_X*sx
        expected_y = CANONICAL_Y*sy
        found = _nearest_edge_positions(
            gray, expected_x, expected_y,
            radius_x=max(4,int(round(7*sx))),
            radius_y=max(4,int(round(7*sy))),
        )
        if found is None:
            return {"ok":False,"reason":"GRID_SEARCH_FAILED"}
        xs,ys = found
        exp_dx,exp_dy = 28*sx,28*sy
        dx,dy = np.diff(xs),np.diff(ys)

        spacing_x_err = float(np.mean(np.abs(dx-exp_dx))/max(1.0,exp_dx))
        spacing_y_err = float(np.mean(np.abs(dy-exp_dy))/max(1.0,exp_dy))
        pos_x_err = float(np.mean(np.abs(np.array(xs)-expected_x))/max(1.0,7*sx))
        pos_y_err = float(np.mean(np.abs(np.array(ys)-expected_y))/max(1.0,7*sy))

        confidence = 1.0 - min(1.0,
            0.35*spacing_x_err + 0.35*spacing_y_err +
            0.15*pos_x_err + 0.15*pos_y_err
        )
    else:
        found = _detect_cropped_grid(arr)
        if found is None:
            return {"ok":False,"reason":"GRID_SEARCH_FAILED"}
        xs,ys = found
        dx,dy = np.diff(xs),np.diff(ys)
        confidence = 0.95

    xs=[int(x) for x in xs]
    ys=[int(y) for y in ys]
    dx=np.diff(xs)
    dy=np.diff(ys)

    spacing_ok = bool(
        np.all((dx >= 20) & (dx <= 35)) and
        np.all((dy >= 20) & (dy <= 35))
    )
    if not spacing_ok:
        confidence *= 0.25

    xr,yr = _grid_border_strength(arr,xs,ys)
    if xr < 1.8 or yr < 1.8:
        confidence *= 0.45

    # v8.8 root fix: the lower consumable rows in the JX1 right-side HÀNH TRANG
    # can visually pull the last 3 horizontal edge searches away from the real
    # 28px cadence (e.g. 288 -> 323 -> 339 -> 378).  The panel itself does not
    # move, so when the canonical 800x600 geometry is strongly visible we prefer
    # that verified geometry instead of rejecting the whole source grid.
    canonical_fallback = False
    if w >= 600 and h >= 450 and confidence < 0.72:
        cxs = [int(round(x)) for x in expected_x]
        cys = [int(round(y)) for y in expected_y]
        if cxs[0] >= 0 and cys[0] >= 0 and cxs[-1] < w and cys[-1] < h:
            cxr, cyr = _grid_border_strength(arr, cxs, cys)
            # Deliberately strict: this path is only for the fixed right-side JX1
            # panel and must not turn arbitrary map/UI edges into an inventory.
            if cxr >= 3.0 and cyr >= 3.0:
                xs, ys = cxs, cys
                dx, dy = np.diff(xs), np.diff(ys)
                xr, yr = cxr, cyr
                confidence = max(confidence, 0.86)
                canonical_fallback = True

    features = _cell_features(arr,xs,ys)
    occupied_count = sum(1 for f in features if f["occupied"])

    # A valid grid can be full, so occupancy count is not used as a hard rejection.
    # We expose it for diagnostics only.
    ok = bool(confidence >= 0.72)

    return {
        "ok": ok,
        "kind": GridOwner.PLAYER_INVENTORY.value,
        "confidence": round(float(confidence),3),
        "x_lines": xs,
        "y_lines": ys,
        "cols": 6,
        "rows": 10,
        "roi": [xs[0],ys[0],xs[-1],ys[-1]],
        "spacing_x": [int(x) for x in dx],
        "spacing_y": [int(y) for y in dy],
        "x_border_ratio": round(xr,3),
        "y_border_ratio": round(yr,3),
        "occupied_preview": int(occupied_count),
        "canonical_fallback": bool(canonical_fallback),
        "reason": None if ok else "GRID_CONFIDENCE_LOW",
    }


def detect_personal_storage_grid(image: Image.Image) -> Dict[str, Any]:
    """Detect the center personal HÀNH TRANG popup.

    v9.2 fixes two real-client failure modes:
      1) the old canonical X anchor was ~5 px too far right;
      2) a single animated/partially-rendered frame could bend one edge search
         enough to reject an otherwise valid 6x10 personal bag.

    The normal edge detector remains the first choice. A strict canonical
    border-strength fallback is allowed only in the known center popup region.
    The source/opened-item grid on the right still uses detect_inventory_grid().
    """
    arr = np.asarray(image.convert("RGB"))
    h, w = arr.shape[:2]
    if w < 600 or h < 450:
        return {"ok": False, "reason": "PERSONAL_GRID_CLIENT_SIZE_UNSUPPORTED"}

    gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
    sx, sy = w / 800.0, h / 600.0
    expected_x = PERSONAL_CANONICAL_X * sx
    expected_y = PERSONAL_CANONICAL_Y * sy
    found = _nearest_edge_positions(
        gray, expected_x, expected_y,
        radius_x=max(4, int(round(7*sx))),
        radius_y=max(4, int(round(7*sy))),
    )

    xs = [int(round(x)) for x in expected_x]
    ys = [int(round(y)) for y in expected_y]
    confidence = 0.0
    local_search_ok = found is not None
    spacing_ok = False
    xr = yr = 0.0

    if found is not None:
        fxs, fys = found
        exp_dx, exp_dy = 28*sx, 28*sy
        dx0, dy0 = np.diff(fxs), np.diff(fys)
        spacing_x_err = float(np.mean(np.abs(dx0-exp_dx))/max(1.0, exp_dx))
        spacing_y_err = float(np.mean(np.abs(dy0-exp_dy))/max(1.0, exp_dy))
        pos_x_err = float(np.mean(np.abs(np.array(fxs)-expected_x))/max(1.0, 7*sx))
        pos_y_err = float(np.mean(np.abs(np.array(fys)-expected_y))/max(1.0, 7*sy))
        confidence = 1.0 - min(1.0,
            0.35*spacing_x_err + 0.35*spacing_y_err +
            0.15*pos_x_err + 0.15*pos_y_err
        )
        xs = [int(x) for x in fxs]
        ys = [int(y) for y in fys]
        dx = np.diff(xs); dy = np.diff(ys)
        spacing_ok = bool(
            np.all((dx >= max(18, int(round(20*sx)))) & (dx <= int(round(35*sx))+1)) and
            np.all((dy >= max(18, int(round(20*sy)))) & (dy <= int(round(35*sy))+1))
        )
        if not spacing_ok:
            confidence *= 0.25
        xr, yr = _grid_border_strength(arr, xs, ys)
        if xr < 1.8 or yr < 1.8:
            confidence *= 0.45

    # v9.2 strict fallback. This is intentionally much stricter than merely
    # trusting the expected coordinates: both vertical and horizontal grid
    # borders must be strongly visible in the center popup.
    canonical_fallback = False
    cxs = [int(round(x)) for x in expected_x]
    cys = [int(round(y)) for y in expected_y]
    if (found is None or confidence < 0.68):
        if cxs[0] >= 0 and cys[0] >= 0 and cxs[-1] < w and cys[-1] < h:
            cxr, cyr = _grid_border_strength(arr, cxs, cys)
            if cxr >= 2.6 and cyr >= 2.6:
                xs, ys = cxs, cys
                xr, yr = cxr, cyr
                confidence = max(confidence, 0.86)
                spacing_ok = True
                canonical_fallback = True

    dx = np.diff(xs); dy = np.diff(ys)
    features = _cell_features(arr, xs, ys)
    occupied_count = sum(1 for f in features if f["occupied"])
    ok = bool(confidence >= 0.68 and spacing_ok)

    return {
        "ok": ok,
        "kind": "PERSONAL_STORAGE",
        "confidence": round(float(confidence), 3),
        "x_lines": xs,
        "y_lines": ys,
        "cols": 6,
        "rows": 10,
        "roi": [xs[0], ys[0], xs[-1], ys[-1]],
        "spacing_x": [int(x) for x in dx],
        "spacing_y": [int(y) for y in dy],
        "x_border_ratio": round(float(xr), 3),
        "y_border_ratio": round(float(yr), 3),
        "occupied_preview": int(occupied_count),
        "canonical_fallback": bool(canonical_fallback),
        "local_search_ok": bool(local_search_ok),
        "reason": None if ok else ("PERSONAL_GRID_SEARCH_FAILED" if found is None else "PERSONAL_GRID_CONFIDENCE_LOW"),
    }



def canonical_inventory_grid_snapshot(grid: Dict[str, Any], image: Image.Image = None) -> Dict[str, Any]:
    """V10.6 canonical adapter shared by detector results and VerifiedGridLease.

    Converts every accepted 6x10 source-grid representation to the one schema
    consumed by snapshot_inventory/source fingerprint code.  No rediscovery and
    no hidden fallback are performed here.
    """
    g=dict(grid or {})
    xs=[int(x) for x in (g.get("x_lines") or [])]
    ys=[int(y) for y in (g.get("y_lines") or [])]
    if len(xs)!=7 or len(ys)!=11:
        return {"ok":False,"reason":"CANONICAL_GRID_TOPOLOGY_INVALID","x_lines":xs,"y_lines":ys}
    roi=g.get("roi") or g.get("grid_roi") or [xs[0],ys[0],xs[-1],ys[-1]]
    try: roi=[int(v) for v in roi]
    except Exception: roi=[xs[0],ys[0],xs[-1],ys[-1]]
    out=dict(g)
    out.update({
        "ok":bool(g.get("ok",True)), "kind":g.get("kind") or GridOwner.PLAYER_INVENTORY.value,
        "x_lines":xs,"y_lines":ys,"cols":6,"rows":10,"roi":roi,"grid_roi":list(roi),
        "spacing_x":[xs[i+1]-xs[i] for i in range(6)],
        "spacing_y":[ys[i+1]-ys[i] for i in range(10)],
        "origin_x":float(g.get("origin_x",xs[0])),"origin_y":float(g.get("origin_y",ys[0])),
        "pitch_x":float(g.get("pitch_x") or (sum(xs[i+1]-xs[i] for i in range(6))/6.0)),
        "pitch_y":float(g.get("pitch_y") or (sum(ys[i+1]-ys[i] for i in range(10))/10.0)),
        "confidence":float(g.get("confidence") or g.get("lattice_confidence") or 0.0),
    })
    if image is not None:
        out.setdefault("client_width",int(image.width)); out.setdefault("client_height",int(image.height))
    return out

def snapshot_inventory(image: Image.Image, grid: Dict[str, Any]) -> Dict[str, Any]:
    grid=canonical_inventory_grid_snapshot(grid,image)
    if not grid or not grid.get("ok"):
        return {"ok": False, "reason": grid.get("reason","GRID_NOT_READY") if isinstance(grid,dict) else "GRID_NOT_READY"}

    arr = np.asarray(image.convert("RGB"))
    xs=[int(x) for x in grid["x_lines"]]
    ys=[int(y) for y in grid["y_lines"]]
    cells=_cell_features(arr,xs,ys)

    for cell in cells:
        x0,y0,x1,y1=cell["rect"]
        pad=3
        crop=arr[max(0,y0+pad):max(0,y1-pad),max(0,x0+pad):max(0,x1-pad)]
        if crop.size:
            small=cv2.resize(crop,(12,12),interpolation=cv2.INTER_AREA)
            gray=cv2.cvtColor(small,cv2.COLOR_RGB2GRAY)
            cell["_sig"]=gray.astype(np.uint8).tolist()
        else:
            cell["_sig"]=[]

    return {
        "ok":True,
        "grid":{
            "x_lines":xs,"y_lines":ys,"rows":10,"cols":6,
            "roi":grid["roi"],"confidence":grid["confidence"],
        },
        "cells":cells,
        "occupied_count":sum(1 for c in cells if c["occupied"]),
        "free_count":sum(1 for c in cells if not c["occupied"]),
    }

def _sig_diff(a,b):
    if not a or not b:
        return 0.0
    aa=np.asarray(a,dtype=np.float32)
    bb=np.asarray(b,dtype=np.float32)
    if aa.shape!=bb.shape:
        return 255.0
    return float(np.mean(np.abs(aa-bb)))

def _cluster_cells(cells: List[Tuple[int,int]]) -> List[List[Tuple[int,int]]]:
    remaining=set(cells)
    groups=[]
    while remaining:
        seed=remaining.pop()
        group={seed}
        stack=[seed]
        while stack:
            r,c=stack.pop()
            for nb in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
                if nb in remaining:
                    remaining.remove(nb)
                    group.add(nb)
                    stack.append(nb)
        groups.append(sorted(group))
    return groups

def diff_snapshots(before: Dict[str,Any], after: Dict[str,Any]) -> Dict[str,Any]:
    if not before.get("ok") or not after.get("ok"):
        return {"ok":False,"reason":"SNAPSHOT_NOT_READY"}

    bmap={(c["row"],c["col"]):c for c in before["cells"]}
    amap={(c["row"],c["col"]):c for c in after["cells"]}

    changed=[]
    new_cells=[]
    vacated=[]

    for key in sorted(amap):
        b=bmap[key]
        a=amap[key]
        d=_sig_diff(b.get("_sig"),a.get("_sig"))

        occupancy_changed=b["occupied"]!=a["occupied"]
        materially_changed=bool(d>=10.0 or occupancy_changed)

        if materially_changed:
            changed.append({
                "row":key[0],"col":key[1],
                "before_occupied":b["occupied"],
                "after_occupied":a["occupied"],
                "pixel_diff":round(d,3),
                "rect":a["rect"],
            })

        # Root rule: only empty -> occupied can create a NEW item footprint.
        # Existing stack count changes remain excluded.
        if (not b["occupied"]) and a["occupied"] and d>=8.0:
            new_cells.append(key)

        if b["occupied"] and (not a["occupied"]) and d>=8.0:
            vacated.append(key)

    detection_mode = "STRICT_EMPTY_TO_OCCUPIED"
    candidate_cells = list(new_cells)

    # Root fix v4.4:
    # A dark/gray equipment sprite can alter an empty cell strongly while still
    # remaining below the occupancy brightness threshold. If strict transition
    # finds nothing, recover only cells that were EMPTY BEFORE and changed a lot.
    # Existing chest stacks are excluded because they were occupied before.
    if not candidate_cells:
        visual_fallback = []
        for rec in changed:
            if (not rec["before_occupied"]) and rec["pixel_diff"] >= 12.0:
                visual_fallback.append((rec["row"], rec["col"]))
        if visual_fallback:
            candidate_cells = visual_fallback
            detection_mode = "VISUAL_EMPTY_CELL_FALLBACK"

    clusters=_cluster_cells(candidate_cells)
    items=[]
    for i,group in enumerate(clusters,1):
        rs=[r for r,c in group]
        cs=[c for r,c in group]
        r0,r1=min(rs),max(rs)
        c0,c1=min(cs),max(cs)

        # Ignore implausibly huge visual clusters. JX1 equipment in this project
        # is at most a small multi-cell footprint.
        fw,fh = c1-c0+1,r1-r0+1
        if len(group) > 8 or fw > 4 or fh > 4:
            continue

        pixel_scores=[
            next(x["pixel_diff"] for x in changed if x["row"]==r and x["col"]==c)
            for r,c in group
        ]
        geometric_cells=[[rr,cc] for rr in range(r0,r1+1) for cc in range(c0,c1+1)]
        visual_cell_count=len(group)
        geometric_cell_count=int(fw*fh)
        items.append({
            "candidate_id":i,
            # `cells` remains the visually changed cells so hover/click code can
            # target real sprite pixels. Inventory occupancy uses geometric_cells.
            "cells":[[r,c] for r,c in group],
            "geometric_cells":geometric_cells,
            "anchor":[r0,c0],
            "footprint":[fw,fh],
            # Stage 29.3 invariant: public cell_count means geometric inventory
            # occupancy, never the number of painted/opaque sprite cells.
            "visual_cell_count":visual_cell_count,
            "geometric_cell_count":geometric_cell_count,
            "cell_count":geometric_cell_count,
            "geometry_invariant_ok":bool(geometric_cell_count==int(fw*fh)),
            "mean_pixel_diff":round(float(np.mean(pixel_scores)),3),
            "confidence":round(min(1.0,0.55+0.08*len(group)+min(pixel_scores)/100.0),3),
            "detection_mode":detection_mode,
        })

    def cleaned(snap):
        cells=[]
        for c in snap["cells"]:
            d={k:v for k,v in c.items() if k!="_sig"}
            cells.append(d)
        return {
            "ok":snap["ok"],"grid":snap["grid"],"cells":cells,
            "occupied_count":snap["occupied_count"],"free_count":snap["free_count"],
        }

    return {
        "ok":True,
        "changed_cells":changed,
        "new_cells":[[r,c] for r,c in new_cells],
        "vacated_cells":[[r,c] for r,c in vacated],
        "new_item_candidates":items,
        "new_item_count":len(items),
        "new_item_detection_mode": detection_mode if items else "NONE",
        "before":cleaned(before),
        "after":cleaned(after),
    }
