from __future__ import annotations

"""Canonical Option Registry for Auto Pro By Eric.

v10.5 adds semantic metadata without changing the existing option IDs,
filterable vocabulary, visibility, or user configuration contract.

Identity authority is deliberately separate from OCR fuzzy similarity:
  family -> qualifier -> unit -> value.
"""

SCHEMA_VERSION = 3

BLUE_FILTERABLE = [
    "Tốc độ đánh – ngoại công",
    "Tốc độ đánh – nội công",
    "Kỹ năng Võ công vốn có",
    "Tốc độ di chuyển",
    "Thời gian phục hồi",
    "Kháng tất cả",
    "Bỏ qua né tránh",
]

GRAY_FILTERABLE = [
    "Sát thương vật lý – ngoại công",
    "Sát thương vật lý – nội công",
    "Hỏa sát – ngoại công",
    "Hỏa sát – nội công",
    "Băng sát – ngoại công",
    "Băng sát – nội công",
    "Lôi sát – ngoại công",
    "Lôi sát – nội công",
    "Độc sát – ngoại công",
    "Độc sát – nội công",
    "Kháng băng",
    "Kháng độc",
    "Kháng lôi",
    "Kháng hỏa",
    "Chuyển hóa sát thương thành nội lực",
    "Thời gian trúng độc",
    "Thời gian làm chậm",
    "Thời gian choáng",
    "Phòng thủ vật lý",
]

# V1.7.5 user-taught slot-only filterable options. They are not global
# candidates: the active equipment scope must explicitly allow them.
SLOT_FILTERABLE = [
    "Tăng công kích kỹ năng",
    "Mức kháng tính tối đa",
    "Sinh lực tối đa",
]

KNOWN_IGNORE = [
    "Tăng độ chính xác đòn đánh cận chiến",
    "Nội lực tối đa",
    "Thể lực tối đa",
    "Phục hồi sinh lực",
    "Phục hồi nội lực",
]

# v10.5.1 domain truth: there is no INVALID option category.  The six
# historical placeholders were never real JX1 random options and are removed
# from registry/UI/wanted-set/rescue/test vocabulary entirely.
INVALID = []

UNIT_PERCENT = "PERCENT"
UNIT_POINT = "POINT"
UNIT_LEVEL = "LEVEL"
UNIT_NONE = "NONE"
UNIT_ENUM = (UNIT_PERCENT, UNIT_POINT, UNIT_LEVEL, UNIT_NONE)
UNIT_REGISTRY_VERSION = "OPTION_UNIT_REGISTRY_V1"

# Authoritative option -> unit contract.  This registry is evaluated only
# after semantic family + NỘI/NGOẠI qualifier identity has been established.
OPTION_UNIT_REGISTRY_V1 = {
    "Tốc độ đánh – ngoại công": UNIT_PERCENT,
    "Tốc độ đánh – nội công": UNIT_PERCENT,
    "Kỹ năng Võ công vốn có": UNIT_LEVEL,
    "Tốc độ di chuyển": UNIT_PERCENT,
    "Thời gian phục hồi": UNIT_NONE,
    "Kháng tất cả": UNIT_PERCENT,
    "Bỏ qua né tránh": UNIT_PERCENT,
    "Sát thương vật lý – ngoại công": UNIT_POINT,
    "Sát thương vật lý – nội công": UNIT_POINT,
    "Hỏa sát – ngoại công": UNIT_POINT,
    "Hỏa sát – nội công": UNIT_POINT,
    "Băng sát – ngoại công": UNIT_POINT,
    "Băng sát – nội công": UNIT_POINT,
    "Lôi sát – ngoại công": UNIT_POINT,
    "Lôi sát – nội công": UNIT_POINT,
    "Độc sát – ngoại công": UNIT_POINT,
    "Độc sát – nội công": UNIT_POINT,
    "Kháng băng": UNIT_PERCENT,
    "Kháng độc": UNIT_PERCENT,
    "Kháng lôi": UNIT_PERCENT,
    "Kháng hỏa": UNIT_PERCENT,
    "Chuyển hóa sát thương thành nội lực": UNIT_PERCENT,
    "Thời gian trúng độc": UNIT_PERCENT,
    "Thời gian làm chậm": UNIT_PERCENT,
    "Thời gian choáng": UNIT_PERCENT,
    "Phòng thủ vật lý": UNIT_PERCENT,
    # V1.7.5 user teaching: these three filters read NUMBER ONLY; unit is
    # implicit PERCENT. '%' glyph is not required for numeric authority.
    "Tăng công kích kỹ năng": UNIT_PERCENT,
    "Mức kháng tính tối đa": UNIT_PERCENT,
    "Tăng độ chính xác đòn đánh cận chiến": UNIT_POINT,
    "Sinh lực tối đa": UNIT_PERCENT,
    "Nội lực tối đa": UNIT_POINT,
    "Thể lực tối đa": UNIT_POINT,
    "Phục hồi sinh lực": UNIT_POINT,
    "Phục hồi nội lực": UNIT_POINT,
}

# ---------------------------------------------------------------------------
# v10.5 semantic identity model
# ---------------------------------------------------------------------------
# `option_family` identifies WHAT the option means. `qualifier` is a second
# independent gate for NỘI/NGOẠI variants. `unit_type` describes the expected
# numeric grammar; only families with proven unit contracts are enforced by
# the v10.5 patch (notably ATTACK_SPEED => PERCENT).
_SEMANTIC_META = {
    "Tốc độ đánh – ngoại công":            ("ATTACK_SPEED", "NGOAI", "PERCENT"),
    "Tốc độ đánh – nội công":              ("ATTACK_SPEED", "NOI", "PERCENT"),
    "Kỹ năng Võ công vốn có":              ("SKILL_LEVEL", None, "LEVEL"),
    "Tốc độ di chuyển":                    ("MOVE_SPEED", None, "PERCENT"),
    "Thời gian phục hồi":                  ("RECOVERY_TIME", None, UNIT_NONE),
    "Kháng tất cả":                        ("ALL_RESIST", None, "PERCENT"),
    "Bỏ qua né tránh":                     ("IGNORE_DODGE", None, "PERCENT"),

    "Sát thương vật lý – ngoại công":      ("PHYSICAL_DAMAGE", "NGOAI", "POINT"),
    "Sát thương vật lý – nội công":        ("PHYSICAL_DAMAGE", "NOI", "POINT"),
    "Hỏa sát – ngoại công":                ("FIRE_DAMAGE", "NGOAI", "POINT"),
    "Hỏa sát – nội công":                  ("FIRE_DAMAGE", "NOI", "POINT"),
    "Băng sát – ngoại công":               ("ICE_DAMAGE", "NGOAI", "POINT"),
    "Băng sát – nội công":                 ("ICE_DAMAGE", "NOI", "POINT"),
    "Lôi sát – ngoại công":                ("LIGHTNING_DAMAGE", "NGOAI", "POINT"),
    "Lôi sát – nội công":                  ("LIGHTNING_DAMAGE", "NOI", "POINT"),
    "Độc sát – ngoại công":                ("POISON_DAMAGE", "NGOAI", "POINT"),
    "Độc sát – nội công":                  ("POISON_DAMAGE", "NOI", "POINT"),

    "Kháng băng":                          ("ICE_RESIST", None, "PERCENT"),
    "Kháng độc":                           ("POISON_RESIST", None, "PERCENT"),
    "Kháng lôi":                           ("LIGHTNING_RESIST", None, "PERCENT"),
    "Kháng hỏa":                           ("FIRE_RESIST", None, "PERCENT"),
    "Chuyển hóa sát thương thành nội lực": ("DAMAGE_TO_MANA", None, "PERCENT"),
    "Thời gian trúng độc":                 ("POISON_DURATION", None, "PERCENT"),
    "Thời gian làm chậm":                  ("SLOW_DURATION", None, "PERCENT"),
    "Thời gian choáng":                    ("STUN_DURATION", None, "PERCENT"),
    # Historical knowledge contains both percent and point examples. Keep the
    # registry honest instead of forcing one parser family in this patch.
    "Phòng thủ vật lý":                    ("PHYSICAL_DEFENSE", None, UNIT_PERCENT),
    "Tăng công kích kỹ năng":              ("SKILL_ATTACK_BONUS", None, UNIT_PERCENT),
    "Mức kháng tính tối đa":               ("MAX_RESIST_CAP", None, UNIT_PERCENT),
    "Sinh lực tối đa":                     ("RESOURCE_MAX", None, UNIT_PERCENT),
}


def _slug(name: str) -> str:
    import unicodedata, re
    s = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii").lower()
    s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")
    return s


def semantic_meta(name: str) -> dict:
    family, qualifier, legacy_unit = _SEMANTIC_META.get(name, (None, None, None))
    unit_type = OPTION_UNIT_REGISTRY_V1.get(name, legacy_unit)
    return {
        "option_family": family,
        "qualifier": qualifier,
        "unit_type": unit_type,
    }

def option_unit_type(name: str):
    return OPTION_UNIT_REGISTRY_V1.get(str(name or ""))


def _entry(name: str, category: str, visibility: str | None, filterable: bool):
    meta = semantic_meta(name)
    return {
        "id": _slug(name),
        "display_name": name,
        "category": category,
        "visibility": visibility,
        "filterable": bool(filterable),
        **meta,
    }


REGISTRY = (
    [_entry(x, "FILTERABLE", "BLUE", True) for x in BLUE_FILTERABLE]
    + [_entry(x, "FILTERABLE", "GRAY", True) for x in GRAY_FILTERABLE]
    + [_entry(x, "FILTERABLE_SLOT_ONLY", "BLUE", True) for x in SLOT_FILTERABLE]
    + [_entry(x, "KNOWN_IGNORE", None, False) for x in KNOWN_IGNORE]
)

BY_NAME = {x["display_name"]: x for x in REGISTRY}
BY_ID = {x["id"]: x for x in REGISTRY}
FILTERABLE_OPTIONS = [x["display_name"] for x in REGISTRY if x["filterable"]]


def option_semantics(name: str) -> dict:
    """Return a copy so callers cannot mutate the canonical registry."""
    row = BY_NAME.get(str(name or "")) or {}
    return {
        "canonical_option_id": row.get("id"),
        "option_family": row.get("option_family"),
        "qualifier": row.get("qualifier"),
        "unit_type": row.get("unit_type"),
    }


# ---------------------------------------------------------------------------
# AutoRoll V1.7.5 — profile + slot-aware closed registries
# ---------------------------------------------------------------------------
# Stage 1 selects an equipment scope BEFORE OCR matching. V1.7.5 adds
# user-taught slot extensions while preserving the V1.7.4 broad profiles.
PROFILE_REGISTRY_VERSION = "PROFILE_SLOT_AWARE_CLOSED_REGISTRY_V1_7_5"
PROFILE_WEAPON = "WEAPON_CLOSED_9"
PROFILE_COMMON = "COMMON_GEAR_BASE_CLOSED_10"
PROFILE_ARMOR = "ARMOR_CLOSED_11"
PROFILE_GLOVES = "GLOVES_CLOSED_11"
PROFILE_ACCESSORY = "ACCESSORY_BASE_CLOSED_2"
PROFILE_NECKLACE = "NECKLACE_CLOSED_3"
PROFILE_JADE = "JADE_PENDANT_CLOSED_2"
PROFILE_GLOBAL_ACTIVE = "GLOBAL_ACTIVE_UNION"

WEAPON_REGISTRY_CLOSED_9 = (
    "Tốc độ đánh – ngoại công",
    "Tốc độ đánh – nội công",
    "Kỹ năng Võ công vốn có",
    "Sát thương vật lý – ngoại công",
    "Sát thương vật lý – nội công",
    "Hỏa sát – nội công",
    "Băng sát – nội công",
    "Lôi sát – nội công",
    "Độc sát – nội công",
)

COMMON_GEAR_REGISTRY_CLOSED_10 = (
    "Tốc độ di chuyển",
    "Thời gian phục hồi",
    "Kháng băng",
    "Kháng độc",
    "Kháng lôi",
    "Kháng hỏa",
    "Thời gian trúng độc",
    "Thời gian làm chậm",
    "Thời gian choáng",
    "Phòng thủ vật lý",
)

ARMOR_REGISTRY_CLOSED_11 = COMMON_GEAR_REGISTRY_CLOSED_10 + (
    "Sinh lực tối đa",
)

GLOVES_REGISTRY_CLOSED_11 = COMMON_GEAR_REGISTRY_CLOSED_10 + (
    "Tăng công kích kỹ năng",
)

ACCESSORY_REGISTRY_CLOSED_2 = (
    "Kỹ năng Võ công vốn có",
    "Kháng tất cả",
)

NECKLACE_REGISTRY_CLOSED_3 = ACCESSORY_REGISTRY_CLOSED_2 + (
    "Mức kháng tính tối đa",
)

JADE_PENDANT_REGISTRY_CLOSED_2 = ACCESSORY_REGISTRY_CLOSED_2

# User-taught value contract: identify option text, then read only the number.
# The percent unit is implicit and MUST NOT depend on OCR of '+' / ':' / '%'.
USER_TAUGHT_IMPLICIT_PERCENT_OPTIONS = frozenset((
    "Tăng công kích kỹ năng",
    "Mức kháng tính tối đa",
    "Sinh lực tối đa",
))

COMMON_GEAR_GROUP_IDS = frozenset(("non", "ao", "baotay", "dailung", "dai", "giay", "nhan"))
ACCESSORY_GROUP_IDS = frozenset(("daychuyen", "ngocboi", "jewelry"))

PROFILE_REGISTRIES = {
    PROFILE_WEAPON: WEAPON_REGISTRY_CLOSED_9,
    PROFILE_COMMON: COMMON_GEAR_REGISTRY_CLOSED_10,
    PROFILE_ARMOR: ARMOR_REGISTRY_CLOSED_11,
    PROFILE_GLOVES: GLOVES_REGISTRY_CLOSED_11,
    PROFILE_ACCESSORY: ACCESSORY_REGISTRY_CLOSED_2,
    PROFILE_NECKLACE: NECKLACE_REGISTRY_CLOSED_3,
    PROFILE_JADE: JADE_PENDANT_REGISTRY_CLOSED_2,
}

# GLOBAL remains the broad V1.7.4 union only. V1.7.5 taught slot extensions
# are intentionally NOT exposed in GLOBAL: the explicit Áo/Bao tay/Dây chuyền
# scope is required before those options may enter the OCR candidate set.
ACTIVE_FILTER_OPTIONS = tuple(dict.fromkeys(
    WEAPON_REGISTRY_CLOSED_9
    + COMMON_GEAR_REGISTRY_CLOSED_10
    + ACCESSORY_REGISTRY_CLOSED_2
))

def implicit_percent_number_only(name: str | None) -> bool:
    return str(name or "") in USER_TAUGHT_IMPLICIT_PERCENT_OPTIONS

def profile_key_for_scope(scope_value: str | None) -> str:
    s = str(scope_value or "GLOBAL").strip().lower()
    if s == "vukhi":
        return PROFILE_WEAPON
    # Specific slot scopes must be checked BEFORE broad group scopes.
    if s == "ao":
        return PROFILE_ARMOR
    if s == "baotay":
        return PROFILE_GLOVES
    if s == "daychuyen":
        return PROFILE_NECKLACE
    if s == "ngocboi":
        return PROFILE_JADE
    if s in COMMON_GEAR_GROUP_IDS or s in ("common", "do_chung", "đồ chung", "chung"):
        return PROFILE_COMMON
    if s in ACCESSORY_GROUP_IDS or s in ("accessory", "phu_kien"):
        return PROFILE_ACCESSORY
    return PROFILE_GLOBAL_ACTIVE

def profile_options(scope_value: str | None) -> list[str]:
    key = profile_key_for_scope(scope_value)
    if key == PROFILE_GLOBAL_ACTIVE:
        return list(ACTIVE_FILTER_OPTIONS)
    return list(PROFILE_REGISTRIES[key])

def profile_option_ids(scope_value: str | None) -> list[str]:
    return [BY_NAME[n]["id"] for n in profile_options(scope_value) if n in BY_NAME]

def option_allowed_for_scope(name: str, scope_value: str | None) -> bool:
    return str(name or "") in set(profile_options(scope_value))

def profile_registry_payload():
    return {
        "version": PROFILE_REGISTRY_VERSION,
        "profiles": {
            "vukhi": {"key": PROFILE_WEAPON, "count": len(WEAPON_REGISTRY_CLOSED_9), "options": list(WEAPON_REGISTRY_CLOSED_9)},
            "common": {"key": PROFILE_COMMON, "count": len(COMMON_GEAR_REGISTRY_CLOSED_10), "groups": ["non","ao","baotay","dailung","giay","nhan"], "options": list(COMMON_GEAR_REGISTRY_CLOSED_10)},
            "ao": {"key": PROFILE_ARMOR, "count": len(ARMOR_REGISTRY_CLOSED_11), "groups": ["ao"], "options": list(ARMOR_REGISTRY_CLOSED_11)},
            "baotay": {"key": PROFILE_GLOVES, "count": len(GLOVES_REGISTRY_CLOSED_11), "groups": ["baotay"], "options": list(GLOVES_REGISTRY_CLOSED_11)},
            "jewelry": {"key": PROFILE_ACCESSORY, "count": len(ACCESSORY_REGISTRY_CLOSED_2), "groups": ["daychuyen","ngocboi"], "options": list(ACCESSORY_REGISTRY_CLOSED_2)},
            "daychuyen": {"key": PROFILE_NECKLACE, "count": len(NECKLACE_REGISTRY_CLOSED_3), "groups": ["daychuyen"], "options": list(NECKLACE_REGISTRY_CLOSED_3)},
            "ngocboi": {"key": PROFILE_JADE, "count": len(JADE_PENDANT_REGISTRY_CLOSED_2), "groups": ["ngocboi"], "options": list(JADE_PENDANT_REGISTRY_CLOSED_2)},
            "GLOBAL": {"key": PROFILE_GLOBAL_ACTIVE, "count": len(ACTIVE_FILTER_OPTIONS), "options": list(ACTIVE_FILTER_OPTIONS)},
        },
        "slot_extensions": {
            "ao": {"option": "Sinh lực tối đa", "unit": "PERCENT", "numeric_policy": "NUMBER_ONLY_IMPLICIT_PERCENT"},
            "baotay": {"option": "Tăng công kích kỹ năng", "unit": "PERCENT", "numeric_policy": "NUMBER_ONLY_IMPLICIT_PERCENT"},
            "daychuyen": {"option": "Mức kháng tính tối đa", "unit": "PERCENT", "numeric_policy": "NUMBER_ONLY_IMPLICIT_PERCENT"},
        },
        "policy": {
            "stage_1": "FILTER_SCOPE_SELECTS_CLOSED_REGISTRY",
            "stage_2": "FAMILY_SUBTYPE_QUALIFIER_WITHIN_ACTIVE_REGISTRY",
            "stage_1b": "SLOT_EXTENSION_ONLY_WHEN_EXPLICIT_SLOT_SCOPE_ACTIVE",
            "outside_registry": "IGNORE_AS_WANTED_CANDIDATE",
            "attack_speed_qualifier": "NOI_NGOAI_REQUIRED_OR_UNRESOLVED",
            "implicit_percent": "THREE_USER_TAUGHT_OPTIONS_READ_NUMBER_ONLY_PERCENT_DEFAULT",
        },
    }


def registry_payload():
    return {
        "schema_version": SCHEMA_VERSION,
        "profile_registry": profile_registry_payload(),
        "counts": {
            "total": len(REGISTRY),
            "blue_filterable": len(BLUE_FILTERABLE),
            "gray_filterable": len(GRAY_FILTERABLE),
            "slot_filterable": len(SLOT_FILTERABLE),
            "known_ignore": len(KNOWN_IGNORE),
            "invalid": 0,
        },
        "entries": [dict(x) for x in REGISTRY],
    }


def validate_registry():
    ids = [x["id"] for x in REGISTRY]
    names = [x["display_name"] for x in REGISTRY]
    filterable_semantics = [
        x for x in REGISTRY
        if x["filterable"] and not x.get("option_family")
    ]
    return {
        "ok": (
            len(REGISTRY) == 34
            and len(BLUE_FILTERABLE) == 7
            and len(GRAY_FILTERABLE) == 19
            and len(SLOT_FILTERABLE) == 3
            and len(KNOWN_IGNORE) == 5
            and len(INVALID) == 0
            and len(OPTION_UNIT_REGISTRY_V1) == 34
            and set(OPTION_UNIT_REGISTRY_V1) == set(names)
            and all(v in UNIT_ENUM for v in OPTION_UNIT_REGISTRY_V1.values())
            and len(ids) == len(set(ids))
            and len(names) == len(set(names))
            and not filterable_semantics
        ),
        "schema_version": SCHEMA_VERSION,
        "total": len(REGISTRY),
        "unique_ids": len(set(ids)),
        "unique_names": len(set(names)),
        "filterable_missing_semantics": [x["display_name"] for x in filterable_semantics],
        "unit_registry_version": UNIT_REGISTRY_VERSION,
        "unit_registry_count": len(OPTION_UNIT_REGISTRY_V1),
        "unit_enum": list(UNIT_ENUM),
    }
