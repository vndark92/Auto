"""V1.7.16 cooperative, OS-backed single-owner leases for game windows.

A lease is advisory: only cooperating AutoPro instances honor it. It cannot
serialize actions sent by unrelated programs or by unguarded legacy helpers.
An OS byte lock is held for the lifetime of the claim and released on a crash.
"""
from __future__ import annotations

from pathlib import Path
import atexit
import json
import os
import re
import threading
import time

_LOCAL_GUARD = threading.RLock()
_HELD_LOCAL = set()


def _try_os_lock(stream):
    stream.seek(0)
    if os.name == 'nt':
        import msvcrt
        msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.lockf(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB, 1, 0, os.SEEK_SET)


def _unlock_os(stream):
    stream.seek(0)
    if os.name == 'nt':
        import msvcrt
        msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        import fcntl
        fcntl.lockf(stream.fileno(), fcntl.LOCK_UN, 1, 0, os.SEEK_SET)


class ClientOwnership:
    def __init__(self, root, shared=True):
        local = os.environ.get('LOCALAPPDATA') if shared else None
        self.root = (Path(local) / 'AutoProByEric' / 'owners') if local else (Path(root) / 'owners')
        self.root.mkdir(parents=True, exist_ok=True)
        self._held = {}
        self._guard = threading.RLock()
        atexit.register(self.close)

    def _lease_path(self, key):
        if not re.fullmatch(r'(?:client_\d+_\d+|global_physical_input)', key):
            raise ValueError('UNSAFE_LEASE_KEY')
        return self.root / (key + '.lock')

    def _acquire(self, key):
        with self._guard, _LOCAL_GUARD:
            if key in self._held:
                return {'ok': True, 'key': key, 'already_owned': True}
            path = self._lease_path(key)
            canonical = str(path.resolve())
            if canonical in _HELD_LOCAL:
                return {'ok': False, 'reason': 'OWNED_BY_ANOTHER_AUTOPRO_INSTANCE', 'key': key}
            # O_APPEND is unsafe here: byte 0 is the lock record and metadata
            # must be rewritten in-place, not appended on every claim.
            fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
            stream = os.fdopen(fd, 'r+b')
            try:
                stream.seek(0, os.SEEK_END)
                if stream.tell() < 1:
                    stream.write(b'\n')
                    stream.flush()
                _try_os_lock(stream)
                info = json.dumps({'owner_pid': os.getpid(), 'claimed_epoch': time.time(), 'key': key}, ensure_ascii=False).encode('utf-8')
                stream.seek(1)
                stream.write(info)
                stream.truncate()
                stream.flush()
                self._held[key] = stream
                _HELD_LOCAL.add(canonical)
                return {'ok': True, 'key': key, 'already_owned': False}
            except (OSError, BlockingIOError):
                stream.close()
                return {'ok': False, 'reason': 'OWNED_BY_ANOTHER_AUTOPRO_INSTANCE', 'key': key}
            except BaseException:
                stream.close()
                raise

    def claim_client(self, hwnd, game_pid):
        hwnd, game_pid = int(hwnd or 0), int(game_pid or 0)
        if hwnd <= 0 or game_pid <= 0:
            return {'ok': False, 'reason': 'INVALID_CLIENT_IDENTITY'}
        return self._acquire(f'client_{game_pid}_{hwnd}')

    def claim_physical_input(self):
        return self._acquire('global_physical_input')

    def owns_client(self, hwnd, game_pid):
        return f'client_{int(game_pid or 0)}_{int(hwnd or 0)}' in self._held

    def release(self, key):
        with self._guard, _LOCAL_GUARD:
            stream = self._held.pop(key, None)
            if stream is None:
                return
            try:
                _unlock_os(stream)
            finally:
                _HELD_LOCAL.discard(str(self._lease_path(key).resolve()))
                stream.close()

    def release_client(self, hwnd, game_pid):
        self.release(f'client_{int(game_pid or 0)}_{int(hwnd or 0)}')

    def close(self):
        with self._guard:
            for key in list(self._held):
                self.release(key)

    def status(self):
        with self._guard:
            return {'ok': True, 'owned_leases': sorted(self._held), 'root': str(self.root)}
