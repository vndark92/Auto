from __future__ import annotations

"""V11.0 tooltip foreground extraction.

The JX1 tooltip is translucent.  Runtime inventory icons, stack counts and other
objects can therefore be visible behind the six option rows.  V10.9 masked the
4x enlarged crop, which allowed anti-aliased fringes from bright background text
(e.g. 999 / 558) to survive.  V11.0 extracts foreground at native resolution
FIRST and only then enlarges the accepted glyph pixels.

This module owns image evidence only.  It does not decide filter PASS/FAIL.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import hashlib

import cv2
import numpy as np
from PIL import Image


EXTRACTOR_VERSION = "TOOLTIP_FOREGROUND_EXTRACTOR_V1_RAW_FIRST"


def _sha_pixels(img: Image.Image) -> str:
    im = img.convert("RGB")
    return hashlib.sha256(im.tobytes()).hexdigest()


def _split_text_masks_rgb(arr: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return blue, gray, skill/orange and combined masks at NATIVE resolution.

    The blue/gray contract mirrors the proven Stage16 JX1 mask but deliberately
    performs the white-core halo veto before any upscaling.  This is the key
    V11.0 change that removes translucent-background stack-count fringes.
    """
    if arr is None or getattr(arr, "size", 0) == 0:
        z = np.zeros((0, 0), dtype=np.uint8)
        return z, z, z, z

    bgr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
    b, g, r = cv2.split(bgr)
    bi, gi, ri = b.astype(np.int16), g.astype(np.int16), r.astype(np.int16)
    mx = np.maximum.reduce([bi, gi, ri])
    mn = np.minimum.reduce([bi, gi, ri])
    chroma = mx - mn

    blue = (
        (bi >= 76)
        & ((bi - ri) >= 18)
        & (bi + 12 >= gi)
        & (mx >= 88)
    )

    gray = (
        (chroma <= 20)
        & (mx >= 76)
        & (mx <= 172)
    )

    # Bright white labels / background stack counts are not option foreground.
    white_core = (mn >= 205) & (chroma <= 30)
    wc = white_core.astype(np.uint8) * 255
    # Native-resolution halo veto.  This becomes 12px at 4x and therefore
    # removes the anti-aliased fringe that survived the old zoom-first path.
    white_halo = cv2.dilate(wc, np.ones((3, 3), np.uint8), iterations=1) > 0

    # Skill level value is rendered orange/yellow in the live client.
    hsv = cv2.cvtColor(arr, cv2.COLOR_RGB2HSV)
    h, s, v = cv2.split(hsv)
    skill = (
        (h >= 3) & (h <= 38)
        & (s >= 75)
        & (v >= 105)
    )

    blue = blue & (~white_halo)
    gray = gray & (~white_halo)
    # Orange text can sit near bright item art; remove only direct white halo.
    skill = skill & (~white_halo)

    blue_u = blue.astype(np.uint8) * 255
    gray_u = gray.astype(np.uint8) * 255
    skill_u = skill.astype(np.uint8) * 255
    combined = ((blue | gray | skill).astype(np.uint8) * 255)
    return blue_u, gray_u, skill_u, combined


def _component_filter(mask: np.ndarray) -> np.ndarray:
    """Reject obvious non-glyph components while preserving bitmap text.

    The row crop is already narrow, so this is deliberately conservative.  We
    discard only huge blobs / isolated single-pixel noise; OCR uncertainty must
    remain UNKNOWN rather than being manufactured into a clean-looking glyph.
    """
    if mask is None or mask.size == 0:
        return mask
    h, w = mask.shape[:2]
    n, labels, stats, _ = cv2.connectedComponentsWithStats((mask > 0).astype(np.uint8), 8)
    out = np.zeros_like(mask)
    max_area = max(18, int(h * w * 0.18))
    max_w = max(10, int(w * 0.16))
    max_h = max(8, int(h * 0.95))
    for i in range(1, n):
        x, y, cw, ch, area = [int(v) for v in stats[i]]
        if area <= 1:
            continue
        if area > max_area and cw > max_w:
            continue
        if ch > max_h and cw > max_w:
            continue
        out[labels == i] = 255
    return out


def _clean_rgb_from_mask(raw: Image.Image, mask: np.ndarray) -> Image.Image:
    arr = np.asarray(raw.convert("RGB"))
    # Black background keeps future Stage16 blue/gray masking lossless: black
    # is not accepted, while original foreground colors are preserved exactly.
    clean = np.zeros_like(arr, dtype=np.uint8)
    if mask is not None and mask.size:
        clean[mask > 0] = arr[mask > 0]
    return Image.fromarray(clean, "RGB")


def _bw_canvas(mask: np.ndarray) -> Image.Image:
    if mask is None or mask.size == 0:
        return Image.new("L", (1, 1), 255)
    bw = np.full(mask.shape, 255, dtype=np.uint8)
    bw[mask > 0] = 0
    return Image.fromarray(bw, "L")


@dataclass
class RowForeground:
    physical_row_index: int
    raw_row: Image.Image
    blue_text_mask: np.ndarray
    gray_text_mask: np.ndarray
    skill_value_mask: np.ndarray
    combined_foreground_mask: np.ndarray
    clean_row_rgb: Image.Image
    clean_row_canvas: Image.Image
    clean_row_zoom4x: Image.Image
    raw_sha256: str
    foreground_sha256: str
    row_raw_path: Optional[str] = None
    row_foreground_path: Optional[str] = None

    def public_dict(self) -> Dict[str, Any]:
        return {
            "physical_row_index": self.physical_row_index,
            "raw_row_size": list(self.raw_row.size),
            "row_raw_sha256": self.raw_sha256,
            "row_foreground_sha256": self.foreground_sha256,
            "row_raw_path": self.row_raw_path,
            "row_foreground_path": self.row_foreground_path,
            "extractor_version": EXTRACTOR_VERSION,
        }


class TooltipForegroundExtractor:
    VERSION = EXTRACTOR_VERSION

    def __init__(self, zoom_scale: int = 4):
        self.zoom_scale = int(zoom_scale or 4)

    def extract_single_row(
        self,
        raw_row: Image.Image,
        physical_row_index: int = 0,
        proof_dir: Optional[Path] = None,
        stem: Optional[str] = None,
    ) -> RowForeground:
        raw_row = raw_row.convert("RGB")
        arr = np.asarray(raw_row)
        blue, gray, skill, combined = _split_text_masks_rgb(arr)
        combined = _component_filter(combined)
        # Keep component filtering consistent in the exported family masks.
        accepted = combined > 0
        blue = np.where(accepted, blue, 0).astype(np.uint8)
        gray = np.where(accepted, gray, 0).astype(np.uint8)
        skill = np.where(accepted, skill, 0).astype(np.uint8)

        clean_rgb = _clean_rgb_from_mask(raw_row, combined)
        canvas = _bw_canvas(combined)
        zoom = clean_rgb.resize(
            (max(1, clean_rgb.width * self.zoom_scale), max(1, clean_rgb.height * self.zoom_scale)),
            Image.Resampling.NEAREST,
        )
        row = RowForeground(
            physical_row_index=int(physical_row_index),
            raw_row=raw_row,
            blue_text_mask=blue,
            gray_text_mask=gray,
            skill_value_mask=skill,
            combined_foreground_mask=combined,
            clean_row_rgb=clean_rgb,
            clean_row_canvas=canvas,
            clean_row_zoom4x=zoom,
            raw_sha256=_sha_pixels(raw_row),
            foreground_sha256=_sha_pixels(clean_rgb),
        )
        if proof_dir is not None and stem:
            proof_dir = Path(proof_dir)
            proof_dir.mkdir(parents=True, exist_ok=True)
            rp = proof_dir / f"{stem}_row{int(physical_row_index)+1}_raw.png"
            fp = proof_dir / f"{stem}_row{int(physical_row_index)+1}_foreground.png"
            raw_row.save(rp)
            # Saved foreground is EXACTLY the color-preserving clean buffer used
            # to construct OCR inputs; no disconnected debug-only image.
            clean_rgb.save(fp)
            row.row_raw_path = str(rp)
            row.row_foreground_path = str(fp)
        return row

    def extract_final6(
        self,
        final6_raw: Image.Image,
        row_ranges: Sequence[Sequence[int]],
        proof_dir: Optional[Path] = None,
        stem: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Extract six physical rows from one native Final6 crop.

        row_ranges are coordinates RELATIVE to final6_raw.  No full-tooltip or
        4x image is accepted as the segmentation source.
        """
        final6_raw = final6_raw.convert("RGB")
        if len(row_ranges) != 6:
            return {"ok": False, "reason": "FOREGROUND_REQUIRES_SIX_ROWS", "rows": []}

        clean_full = Image.new("RGB", final6_raw.size, (0, 0, 0))
        rows: List[RowForeground] = []
        h = final6_raw.height
        for idx, rr in enumerate(row_ranges):
            y0, y1 = int(rr[0]), int(rr[1])
            # Small safe edge margin.  The option row itself remains the owner.
            p = max(1, int(round(max(1, y1 - y0 + 1) * 0.18)))
            cy0 = max(0, y0 - p)
            cy1 = min(h, y1 + p + 1)
            raw_row = final6_raw.crop((0, cy0, final6_raw.width, cy1))
            rf = self.extract_single_row(raw_row, idx, proof_dir=proof_dir, stem=stem)
            rows.append(rf)
            clean_full.paste(rf.clean_row_rgb, (0, cy0))

        clean_zoom = clean_full.resize(
            (max(1, clean_full.width * self.zoom_scale), max(1, clean_full.height * self.zoom_scale)),
            Image.Resampling.NEAREST,
        )
        result: Dict[str, Any] = {
            "ok": True,
            "extractor_version": self.VERSION,
            "raw_final6_sha256": _sha_pixels(final6_raw),
            "clean_final6_sha256": _sha_pixels(clean_full),
            "clean_final6_zoom4x_sha256": _sha_pixels(clean_zoom),
            "clean_final6_rgb": clean_full,
            "clean_final6_zoom4x": clean_zoom,
            "rows": rows,
            "row_provenance": [r.public_dict() for r in rows],
        }
        if proof_dir is not None and stem:
            proof_dir = Path(proof_dir)
            proof_dir.mkdir(parents=True, exist_ok=True)
            rawp = proof_dir / f"{stem}_final6_raw.png"
            cleanp = proof_dir / f"{stem}_final6_foreground.png"
            zoomp = proof_dir / f"{stem}_final6_foreground_zoom4x.png"
            final6_raw.save(rawp)
            clean_full.save(cleanp)
            clean_zoom.save(zoomp)
            result.update({
                "final6_raw_path": str(rawp),
                "final6_foreground_path": str(cleanp),
                "final6_foreground_zoom4x_path": str(zoomp),
            })
        return result
