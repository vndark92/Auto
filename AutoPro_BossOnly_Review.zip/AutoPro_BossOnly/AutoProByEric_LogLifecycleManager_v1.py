from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import os
import shutil
import threading


class LogLifecycleManager:
    """Single owner for deletion of runtime diagnostics inside canonical logs/.

    The manager never deletes the canonical root itself and never follows a
    symlink out of it. Runtime writers can share the lifecycle lock while
    opening/writing short-lived diagnostic files.
    """

    def __init__(self, canonical_log_root: Path):
        self.root = Path(canonical_log_root).resolve()
        self._lock = threading.RLock()
        self.generation = 0
        self.root.mkdir(parents=True, exist_ok=True)

    def _inside_root(self, path: Path) -> bool:
        try:
            p = Path(path).resolve(strict=False)
            p.relative_to(self.root)
            return p != self.root
        except Exception:
            return False

    @contextmanager
    def locked_writer(self):
        with self._lock:
            self.root.mkdir(parents=True, exist_ok=True)
            yield self.generation

    def ensure_root(self) -> None:
        with self._lock:
            self.root.mkdir(parents=True, exist_ok=True)

    def clear_all_logs(self) -> dict:
        with self._lock:
            # Never permit a suspicious canonical root.
            if str(self.root) in (self.root.anchor, '/', '\\') or self.root.parent == self.root:
                return {'ok': False, 'reason': 'CANONICAL_LOG_ROOT_UNSAFE', 'log_generation': self.generation}
            self.root.mkdir(parents=True, exist_ok=True)
            files_deleted = 0
            dirs_deleted = 0
            bytes_deleted = 0
            failures = []

            # Work bottom-up. Symlinks are unlinked as link objects and are
            # never traversed/followed.
            entries = sorted(self.root.rglob('*'), key=lambda p: len(p.parts), reverse=True)
            for entry in entries:
                try:
                    # A link under logs/ is safe to unlink even when its target
                    # resolves outside logs/. Never follow the target.
                    lexical_inside = (entry != self.root and entry.parent == self.root or self.root in entry.parents)
                    if entry.is_symlink():
                        if not lexical_inside:
                            failures.append({'path': str(entry), 'reason': 'PATH_ESCAPE_DENIED'})
                            continue
                        try:
                            bytes_deleted += int(entry.lstat().st_size)
                        except Exception:
                            pass
                        entry.unlink(missing_ok=True)
                        files_deleted += 1
                    elif not self._inside_root(entry):
                        failures.append({'path': str(entry), 'reason': 'PATH_ESCAPE_DENIED'})
                        continue
                    elif entry.is_file():
                        try:
                            bytes_deleted += int(entry.stat().st_size)
                        except Exception:
                            pass
                        entry.unlink(missing_ok=True)
                        files_deleted += 1
                    elif entry.is_dir():
                        try:
                            entry.rmdir()
                            dirs_deleted += 1
                        except OSError:
                            # A concurrently-created file may keep a directory
                            # non-empty. Remove only if it is still safely inside
                            # the log root; never recurse outside it.
                            if self._inside_root(entry):
                                shutil.rmtree(entry, ignore_errors=False)
                                dirs_deleted += 1
                except Exception as exc:
                    failures.append({'path': str(entry), 'reason': type(exc).__name__, 'detail': str(exc)})

            self.generation += 1
            self.root.mkdir(parents=True, exist_ok=True)
            return {
                'ok': len(failures) == 0,
                'reason': 'LOGS_CLEARED' if not failures else 'LOGS_CLEARED_WITH_FAILURES',
                'files_deleted': files_deleted,
                'dirs_deleted': dirs_deleted,
                'bytes_deleted': bytes_deleted,
                'log_generation': self.generation,
                'failures': failures[:20],
            }
