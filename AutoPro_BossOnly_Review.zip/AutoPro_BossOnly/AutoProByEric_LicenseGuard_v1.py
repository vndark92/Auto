"""License-free compatibility interface for the user-requested build.

No key, hardware identity, expiration, Internet time, or license monitor is used.
The public interface is kept for existing UI and automation callers.
"""
from __future__ import annotations
import json


class LicenseGuard:
    def status(self) -> dict:
        return {
            "ok": True, "active": True, "reason": "LICENSE_DISABLED",
            "last_ok_epoch": 0.0, "key_hint": "", "hwid_hint": "",
            "expires_at": 0, "expires_gmt7": "", "time_mode": "NOT_REQUIRED",
            "ip_observed": "", "server_url": "",
        }

    def load_config(self) -> dict:
        return {}

    def activate(self, interactive=False) -> dict:
        return self.status()

    def setup_gui_and_activate(self, initial_reason="") -> dict:
        return self.status()

    def startup_validate_with_setup(self) -> dict:
        return self.status()

    def startup_validate(self, interactive=False) -> dict:
        return self.status()

    def _refresh_once(self) -> dict:
        return self.status()

    def start_monitor(self, on_invalid=None) -> None:
        return None

    def stop_monitor(self) -> None:
        return None

    def release_best_effort(self) -> None:
        return None


LICENSE_GUARD = LicenseGuard()


def license_runtime_allowed() -> bool:
    return True


def license_status() -> dict:
    return LICENSE_GUARD.status()


def compute_hwid() -> dict:
    return {"ok": True, "reason": "HWID_NOT_REQUIRED", "hwid_hash": "", "hwid_hint": ""}


def _cli():
    import argparse
    parser = argparse.ArgumentParser(description="AutoPro license-free build")
    parser.add_argument("--activate", action="store_true")
    parser.add_argument("--show-hwid", action="store_true")
    parser.add_argument("--setup-gui", action="store_true")
    args = parser.parse_args()
    result = compute_hwid() if args.show_hwid else license_status()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
