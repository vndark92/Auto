from __future__ import annotations

from pathlib import Path
from dataclasses import dataclass, asdict, field
from enum import Enum
from typing import Any, Dict, List, Optional, Callable, Tuple
import base64
import copy
import ctypes
import hashlib
import io
import json
import math
import threading
import time
import uuid

import numpy as np
import cv2

from AutoProByEric_AutoRollRecordCoord_v1 import (
    AutoRollInputDispatcher,
    AutoRollInputPacing,
    InteractionTarget,
    SessionCancellationToken,
    AsyncJsonlLogWriter,
    AutoRollFilterAdapter,
    FilterVerdict,
)
from AutoProByEric_NewItemQueue_v4_0 import hover_points_for_candidate
from AutoProByEric_InventorySensor_v3_5 import detect_jx1_container_candidates, score_jx1_container_profile, resolve_jx1_container_candidates, detect_inventory_grid

BUILD_ID = 'AutoProByEric_V12.11_AutoBoss_V1.6.0_ReadUnstableContinueContractRootfix'
CONFIG_SCHEMA_VERSION = 12
CONTAINER_PLAYER = 'PLAYER_BAG'
CONTAINER_STORAGE = 'STORAGE_CHEST'
BOSS_KEY = '1'
LOOT_POLL_SEC = 0.22
LOOT_SETTLE_SEC = 0.85
BOSS_LOOT_TIMEOUT_SEC = 45.0
BOSS_LIVE_BAG_WAIT_SEC = 40.0
POINT_B_DELTA_CONFIRM_SEC = 4.0
BAG_REOPEN_COOLDOWN_SEC = 1.35
BAG_FOCUS_CONFIRM_SEC = 0.18
BAG_PRESENCE_DOUBLECHECK_SEC = 0.07
BAG_OPEN_CONFIRM_SEC = 1.80
BAG_SIG_DELTA_MIN_MAE = 11.0
BAG_SIG_DELTA_PERSIST_SEC = 0.55
BAG_SIG_DELTA_PERSIST_HITS = 3
NAV_TIMEOUT_SEC = 8.0
NAV_STABLE_FRAMES = 3
VK_LBUTTON = 0x01
ROUTE_POLL_SEC = 0.015
ROUTE_MIN_CLICK_GAP_MS = 90
ROUTE_MAX_HOLD_MS = 4000
ROUTE_LAST_HOLD_MS = 850
VK_CONTROL = 0x11
VK_F = 0x46
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008
INPUT_KEYBOARD = 1
SUPPORTED_FOOTPRINTS = ((1,1),(1,2),(2,1),(2,2),(1,3),(1,4),(4,1))


def _container_pair_separated(a,b):
    try:
        ar=a.get('panel_rect') or []; br=b.get('panel_rect') or []
        if len(ar)!=4 or len(br)!=4:return False
        x0=max(ar[0],br[0]); y0=max(ar[1],br[1]); x1=min(ar[2],br[2]); y1=min(ar[3],br[3])
        inter=max(0,x1-x0)*max(0,y1-y0)
        aa=max(1,(ar[2]-ar[0])*(ar[3]-ar[1])); bb=max(1,(br[2]-br[0])*(br[3]-br[1]))
        return float(inter)/float(aa+bb-inter)<0.20
    except Exception:return False


class BossVerdict(str, Enum):
    ACCEPT = 'ACCEPT'
    REJECT = 'REJECT'
    UNRESOLVED = 'UNRESOLVED'


class BossDisposition(str, Enum):
    KEEP = 'KEEP'
    DROP = 'DROP'
    STORE = 'STORE'
    NONE = 'NONE'


@dataclass
class BossErrorEnvelope:
    reason_code: str
    source_component: str
    source_state: str
    session_id: Optional[str]
    cycle_id: Optional[str] = None
    logical_item_id: Optional[str] = None
    recoverable: bool = False
    evidence_ref: Optional[str] = None
    last_event_seq: int = 0
    detail: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BossPoint:
    kind: str
    client_point: List[int]
    client_size: List[int]
    scene_signature: List[int]
    captured_at: float
    coordinate_space: str = 'CLIENT'


@dataclass
class ContainerItemRef:
    logical_id: str
    container_id: str
    candidate: Dict[str, Any]
    grid_anchor: List[int]
    footprint: List[int]
    icon_signature: str
    first_seen_cycle: int
    status: str = 'NEW_UNKNOWN'
    verdict: str = 'UNRESOLVED'
    disposition: str = 'NONE'
    queue_id: str = ''


@dataclass
class BossCycleContext:
    cycle_number: int
    cycle_id: str
    generation: int
    key1_dispatched: bool = False
    loot_stable: bool = False
    completed: bool = False


@dataclass
class ContainerResolution:
    ok: bool
    player_grid: Dict[str, Any] = field(default_factory=dict)
    storage_grid: Dict[str, Any] = field(default_factory=dict)
    player_panel: Dict[str, Any] = field(default_factory=dict)
    storage_panel: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    reason: Optional[str] = None
    evidence: Dict[str, Any] = field(default_factory=dict)


def _hash_json(value: Any) -> str:
    try:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',',':'), default=str).encode('utf-8')
        return hashlib.sha256(raw).hexdigest()
    except Exception:
        return ''


def _scene_signature(image, size=(48,32)) -> List[int]:
    if image is None:
        return []
    arr = np.asarray(image.convert('RGB'))
    h,w = arr.shape[:2]
    # Exclude top-right minimap and far-right inventory column from the coarse world signature.
    x1 = max(1, int(w*0.72)); y0 = max(0, int(h*0.08)); y1 = max(y0+1, int(h*0.82))
    crop = arr[y0:y1, 0:x1]
    if crop.size == 0:
        crop = arr
    gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
    small = cv2.resize(gray, size, interpolation=cv2.INTER_AREA)
    return small.astype(np.uint8).reshape(-1).tolist()


def _sig_mae(a,b) -> float:
    if not a or not b or len(a)!=len(b):
        return 255.0
    aa=np.asarray(a,dtype=np.float32); bb=np.asarray(b,dtype=np.float32)
    return float(np.mean(np.abs(aa-bb)))


def _snapshot_sig_mae(a,b) -> float:
    """Cell-signature delta used only by AutoBoss loot discovery.

    Unlike the shared occupied flag, this remains useful when the semi-transparent
    JX1 bag makes an empty slot look bright/colored because of the world behind it.
    """
    try:
        aa=np.asarray(a or [],dtype=np.float32); bb=np.asarray(b or [],dtype=np.float32)
        if aa.size==0 or bb.size==0 or aa.shape!=bb.shape:return 0.0
        return float(np.mean(np.abs(aa-bb)))
    except Exception:
        return 0.0


def _cell_signature(snapshot: Dict[str,Any], candidate: Dict[str,Any]) -> str:
    try:
        cmap={(int(c['row']),int(c['col'])):c for c in snapshot.get('cells',[])}
        payload=[]
        cells=candidate.get('geometric_cells') or candidate.get('cells') or []
        for r,c in sorted((int(x[0]),int(x[1])) for x in cells):
            rec=cmap.get((r,c),{})
            payload.append({'r':r,'c':c,'occupied':bool(rec.get('occupied')),'sig':rec.get('_sig') or []})
        return _hash_json(payload)
    except Exception:
        return ''


def _candidate_center(grid: Dict[str,Any], candidate: Dict[str,Any]) -> Optional[List[int]]:
    try:
        pts=hover_points_for_candidate(candidate,grid)
        if pts:
            return [int(pts[0][0]),int(pts[0][1])]
    except Exception:
        pass
    try:
        xs=[int(x) for x in grid.get('x_lines',[])]; ys=[int(y) for y in grid.get('y_lines',[])]
        r,c=[int(x) for x in candidate.get('anchor',[0,0])]
        fw,fh=[int(x) for x in candidate.get('footprint',[1,1])]
        if len(xs)>=c+fw+1 and len(ys)>=r+fh+1:
            return [int(round((xs[c]+xs[c+fw])/2)),int(round((ys[r]+ys[r+fh])/2))]
    except Exception:
        pass
    return None


def _candidate_cell_set(candidate: Dict[str,Any]) -> set:
    out=set()
    try:
        cells=candidate.get('geometric_cells') or candidate.get('cells') or []
        for rc in cells:
            if isinstance(rc,(list,tuple)) and len(rc)==2:
                r,c=int(rc[0]),int(rc[1])
                if 0<=r<10 and 0<=c<6:
                    out.add((r,c))
    except Exception:
        pass
    return out


def _candidate_from_cells(cells, template=None, detection_mode='AUTOBOSS_TEMPORAL_RESIDUAL'):
    cells=sorted({(int(r),int(c)) for r,c in (cells or []) if 0<=int(r)<10 and 0<=int(c)<6})
    if not cells:return None
    rs=[r for r,c in cells]; cs=[c for r,c in cells]
    r0,r1=min(rs),max(rs); c0,c1=min(cs),max(cs)
    fw,fh=c1-c0+1,r1-r0+1
    if len(cells)>8 or fw>4 or fh>4:return None
    base=dict(template or {})
    base.update({
        'cells':[[r,c] for r,c in cells],
        'geometric_cells':[[rr,cc] for rr in range(r0,r1+1) for cc in range(c0,c1+1)],
        'anchor':[r0,c0],
        'footprint':[fw,fh],
        'visual_cell_count':len(cells),
        'geometric_cell_count':int(fw*fh),
        'cell_count':int(fw*fh),
        'geometry_invariant_ok':True,
        'detection_mode':str(detection_mode),
    })
    return base


def _split_residual_candidate(candidate: Dict[str,Any], consumed_cells:set) -> List[Dict[str,Any]]:
    """Subtract already-confirmed loot cells, then split the remainder by connectivity.

    This prevents a later baseline delta A+B from replacing previously confirmed A
    with one merged candidate when the next Boss item lands directly beside it.
    """
    remaining=_candidate_cell_set(candidate)-set(consumed_cells or set())
    if not remaining:return []
    groups=[]
    pool=set(remaining)
    while pool:
        seed=pool.pop(); group={seed}; stack=[seed]
        while stack:
            r,c=stack.pop()
            for nb in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
                if nb in pool:
                    pool.remove(nb); group.add(nb); stack.append(nb)
        groups.append(sorted(group))
    out=[]
    for g in groups:
        x=_candidate_from_cells(g,candidate,'AUTOBOSS_TEMPORAL_RESIDUAL')
        if x:out.append(x)
    return out


class AutoBossEventLedger:
    def __init__(self, writer: Callable[[Dict[str,Any]],None]):
        self._writer=writer
        self._lock=threading.RLock()
        self._seq=0
        self._once=set()
        self.events=[]

    @property
    def last_seq(self):
        with self._lock:return int(self._seq)

    def reset(self):
        with self._lock:
            self._seq=0; self._once=set(); self.events=[]

    def emit(self, session_id, cycle_id, logical_item_id, event, state, payload=None, once_key=None):
        with self._lock:
            if once_key and once_key in self._once:
                return {'duplicate_blocked':True,'event_seq':self._seq,'event':event}
            if once_key:self._once.add(once_key)
            self._seq+=1
            rec={
                'event_seq':self._seq,'session_id':session_id,'cycle_id':cycle_id,
                'logical_item_id':logical_item_id,'event':str(event),'state':str(state),
                'monotonic_ns':time.monotonic_ns(),'payload':dict(payload or {})
            }
            self.events.append(rec)
            self._writer(rec)
            return rec


class IngameAutoArmController:
    """Ctrl+F is a non-idempotent session toggle. Dispatch at most once."""
    def __init__(self, core, telemetry):
        self.core=core; self.telemetry=telemetry; self.session_id=None; self.ctrl_f_sent=False; self.armed_for_session=False

    def reset(self, session_id):
        self.session_id=str(session_id); self.ctrl_f_sent=False; self.armed_for_session=False

    def _foreground_chord_once(self, hwnd):
        act=self.core._activate_window(int(hwnd))
        if not act.get('ok'):
            return {'ok':False,'reason':'CTRL_F_FOREGROUND_ACTIVATION_FAILED','activation':act}
        scan_ctrl=int(self.core.user32_bridge.MapVirtualKeyW(VK_CONTROL,self.core.MAPVK_VK_TO_VSC))
        scan_f=int(self.core.user32_bridge.MapVirtualKeyW(VK_F,self.core.MAPVK_VK_TO_VSC))
        seq=[(scan_ctrl,KEYEVENTF_SCANCODE),(scan_f,KEYEVENTF_SCANCODE),(scan_f,KEYEVENTF_SCANCODE|KEYEVENTF_KEYUP),(scan_ctrl,KEYEVENTF_SCANCODE|KEYEVENTF_KEYUP)]
        sent_total=0
        for idx,(scan,flags) in enumerate(seq):
            arr=(self.core.INPUT*1)(); arr[0].type=INPUT_KEYBOARD; arr[0].ki=self.core.KEYBDINPUT(0,scan,int(flags),0,0)
            sent_total+=int(self.core.user32_bridge.SendInput(1,ctypes.byref(arr),ctypes.sizeof(self.core.INPUT)))
            if idx==0:time.sleep(.020)
            elif idx==1:time.sleep(.045)
            elif idx==2:time.sleep(.015)
        return {'ok':sent_total==4,'sent_inputs':sent_total,'used_mode':'Foreground/SendInputChord'}

    def _background_chord_once(self, hwnd):
        target=int(self.core._largest_child(int(hwnd)))
        scan_ctrl=int(self.core.user32_bridge.MapVirtualKeyW(VK_CONTROL,self.core.MAPVK_VK_TO_VSC))
        scan_f=int(self.core.user32_bridge.MapVirtualKeyW(VK_F,self.core.MAPVK_VK_TO_VSC))
        def lp(scan,up=False):
            v=1|(int(scan)<<16)
            if up:v|=(1<<30)|(1<<31)
            return v
        u=self.core.user32_bridge; H=self.core.wintypes.HWND(target)
        ok=[]
        ok.append(bool(u.PostMessageW(H,WM_KEYDOWN,VK_CONTROL,lp(scan_ctrl)))); time.sleep(.020)
        ok.append(bool(u.PostMessageW(H,WM_KEYDOWN,VK_F,lp(scan_f)))); time.sleep(.045)
        ok.append(bool(u.PostMessageW(H,WM_KEYUP,VK_F,lp(scan_f,True)))); time.sleep(.015)
        ok.append(bool(u.PostMessageW(H,WM_KEYUP,VK_CONTROL,lp(scan_ctrl,True))))
        return {'ok':all(ok),'used_mode':'Background/PostMessageChord','target_hwnd':target,'messages':ok}

    def arm_once(self, hwnd, mode='Auto'):
        if self.ctrl_f_sent:
            self.telemetry('DUPLICATE_CTRL_F_BLOCKED',session_id=self.session_id)
            return {'ok':True,'already_armed':True,'duplicate_blocked':True,'ctrl_f_sent':True}
        mode=str(mode or 'Auto')
        result=self._background_chord_once(hwnd) if mode=='Background' else self._foreground_chord_once(hwnd)
        # Auto deliberately uses one foreground chord; no fallback can toggle twice.
        if result.get('ok'):
            self.ctrl_f_sent=True; self.armed_for_session=True
        return {**result,'exactly_once':True,'ctrl_f_sent':self.ctrl_f_sent,'armed_for_session':self.armed_for_session}


class BossBagRegistry:
    def __init__(self, path: Path):
        self.path=Path(path); self.items={}; self.baseline=None; self.generation=0; self.session_id=None

    def reset_session(self, session_id, baseline):
        self.session_id=str(session_id); self.baseline=copy.deepcopy(baseline); self.generation=1; self.items={}
        self._save()

    def commit_baseline(self, snapshot):
        self.baseline=copy.deepcopy(snapshot); self.generation+=1; self._save()

    def remember(self, item: ContainerItemRef, status: str):
        item.status=str(status); self.items[item.logical_id]=item; self._save()

    def _save(self):
        try:
            payload={'schema_version':1,'session_id':self.session_id,'generation':self.generation,
                     'items':{k:asdict(v) for k,v in self.items.items()},'updated_at':time.time()}
            self.path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
        except Exception:pass


class StorageRegistry:
    def __init__(self):self.items={}; self.generation=0
    def remember(self,item:ContainerItemRef):
        self.generation+=1; self.items[item.logical_id]={'logical_id':item.logical_id,'footprint':list(item.footprint),'stored_at':time.time(),'generation':self.generation}


class ContainerGeometryResolver:
    """Thin AutoBoss adapter over the shared canonical container resolver.

    The root owner model lives in InventorySensor ``resolve_jx1_containers`` so
    AutoBoss and StoreController cannot diverge. This adapter only supplies the
    AutoBoss recorded profiles and converts the shared payload to its local DTO.
    """
    MIN_OWNER_CONFIDENCE = 0.58
    MIN_ASSIGNMENT_MARGIN = 0.10

    def __init__(self, core, profiles_getter: Callable[[],Dict[str,Any]]):
        self.core=core; self.profiles_getter=profiles_getter

    @staticmethod
    def _norm(rect,w,h):
        if not rect or len(rect)!=4 or not w or not h:return []
        return [float(rect[0])/w,float(rect[1])/h,float(rect[2])/w,float(rect[3])/h]

    def resolve(self,image,require_storage=True) -> ContainerResolution:
        if image is None:return ContainerResolution(False,reason='CONTAINER_CAPTURE_FAILED')
        fn=getattr(self.core,'resolve_jx1_containers',None)
        if not callable(fn):return ContainerResolution(False,reason='CANONICAL_CONTAINER_RESOLVER_UNAVAILABLE')
        raw=fn(image,profiles=self.profiles_getter() or {},require_storage=bool(require_storage))
        if not raw.get('ok'):
            return ContainerResolution(False,confidence=float(raw.get('confidence') or 0.0),reason=raw.get('reason') or 'CONTAINER_OWNER_AMBIGUOUS',evidence=dict(raw.get('evidence') or {}))
        player_grid=dict(raw.get('inventory_grid') or {}); storage_grid=dict(raw.get('storage_grid') or {})
        player_panel=dict(raw.get('inventory_identity') or {}); storage_panel=dict(raw.get('storage_identity') or {})
        # Preserve footer structure evidence from canonical candidate ledger for profile recording.
        ev=dict(raw.get('evidence') or {})
        byid={str(x.get('candidate_id')):x for x in ev.get('candidates') or []}
        pc=byid.get(str(ev.get('player_candidate_id'))) or {}; sc=byid.get(str(ev.get('storage_candidate_id'))) or {}
        if pc:player_panel['footer_structure_signature']=dict(pc.get('footer_signature') or {})
        if sc:storage_panel['footer_structure_signature']=dict(sc.get('footer_signature') or {})
        return ContainerResolution(True,player_grid,storage_grid,player_panel,storage_panel,float(raw.get('confidence') or raw.get('structural_anchor_score') or 0.0),None,ev)

    def profile_from_resolution(self,resolution:ContainerResolution,kind,image):
        if not resolution.ok:return None
        panel=resolution.player_panel if kind==CONTAINER_PLAYER else resolution.storage_panel
        grid=resolution.player_grid if kind==CONTAINER_PLAYER else resolution.storage_grid
        if not panel or not grid:return None
        return {'schema_version':3,'container_id':kind,'panel_rect_norm':self._norm(panel.get('panel_rect'),image.width,image.height),'grid_rect_norm':self._norm(grid.get('grid_rect'),image.width,image.height),'footer_rect_norm':self._norm(panel.get('footer_rect'),image.width,image.height),'footer_structure_signature':dict(panel.get('footer_structure_signature') or {}),'recorded_client_size':[int(image.width),int(image.height)],'captured_at':time.time(),'title_ocr_used':False,'owner_authority':'GUIDED_PROFILE_LEARNING_PLUS_SHARED_CONTAINER_GEOMETRY_RESOLVER_V1_1_1'}


class StoragePlacementPlanner:
    @staticmethod
    def occupancy(snapshot: Dict[str,Any], rows=10, cols=6):
        occ=[[False for _ in range(cols)] for __ in range(rows)]
        for c in snapshot.get('cells',[]):
            r=int(c.get('row',-1)); col=int(c.get('col',-1))
            if 0<=r<rows and 0<=col<cols:occ[r][col]=bool(c.get('occupied'))
        return occ

    @staticmethod
    def find_fit(snapshot: Dict[str,Any], footprint: List[int]):
        try:fw,fh=int(footprint[0]),int(footprint[1])
        except Exception:return None
        rows=int((snapshot.get('grid') or {}).get('rows') or 10); cols=int((snapshot.get('grid') or {}).get('cols') or 6)
        occ=StoragePlacementPlanner.occupancy(snapshot,rows,cols)
        for r in range(0,rows-fh+1):
            for c in range(0,cols-fw+1):
                if all(not occ[rr][cc] for rr in range(r,r+fh) for cc in range(c,c+fw)):
                    return [r,c]
        return None


class AutoBossSessionController:
    def __init__(self, api, core, root: Path):
        self.api=api; self.core=core; self.root=Path(root)
        self.config_path=self.root/'AutoProByEric_AutoBoss_v1.json'
        self.registry_path=self.root/'AutoProByEric_AutoBoss_BagRegistry_v1.json'
        self.log_path=self.root/'logs'/'runtime'/'autoboss_v1.jsonl'
        self.config=self._load_config()
        self.lock=threading.RLock(); self.worker=None; self.state='IDLE'; self.running=False
        self.session_id=None; self.session_generation=0; self.cycle_number=0; self.active_cycle=None
        self.last_error=None; self.last_event=None; self.last_loot_queue=[]; self.counters={'kept':0,'stored':0,'dropped':0,'cycles':0}
        self.cancellation=SessionCancellationToken(); self._cancel_generation=0
        self.log_writer=AsyncJsonlLogWriter(self.log_path)
        self.ledger=AutoBossEventLedger(self.log_writer.submit)
        self.arm=IngameAutoArmController(core,self._telemetry)
        self.pacing=AutoRollInputPacing(self.config.get('input_pacing') or {})
        self.input_dispatcher=AutoRollInputDispatcher(core,self.pacing,self._telemetry,self._input_token_valid,self._other_automation_busy)
        self.filter_adapter=AutoRollFilterAdapter(core); self.filter_adapter.compile_profiles(self.config.get('filter_profile_ids') or [1,2,3,4])
        self.bag_registry=BossBagRegistry(self.registry_path); self.storage_registry=StorageRegistry()
        self.container_resolver=ContainerGeometryResolver(core,lambda:self.config.get('container_profiles') or {})
        self._bag_grid=None; self._bag_snapshot=None; self._bag_baseline_location=None; self._busy_action=None; self.last_container_resolution=None
        # V1.5.2: Player Bag remains open through Boss combat and is scanned continuously.
        # The inventory hotkey is a toggle, so self-healing never spams it blindly:
        # only repeated visual absence + a cooldown can emit one reopen key.
        self._bag_reopen_last_sent=0.0; self._bag_unresolved_streak=0; self._bag_live_scan_last_ok=0.0
        self._bag_focus_last_click=0.0; self._bag_focus_click_count=0
        self._route_record_lock=threading.RLock(); self._route_record_thread=None; self._route_record_stop=None
        self._route_record_state={'active':False,'route':None,'hwnd':0,'steps':[],'started_at':0.0,'recorded_clicks':0,'last_reason':None}

    def _default_config(self):
        return {
            'schema_version':CONFIG_SCHEMA_VERSION,'build_id':BUILD_ID,
            'points':{},'container_profiles':{},'container_resolution':{'minimum_confidence':0.58,'confidence_margin':0.10,'owner_authority':'RELATIVE_GEOMETRY_STRUCTURE_PAIRWISE_PROFILE'},
            'container_setup':{'state':'CONTAINER_SETUP_IDLE','pair_test_pass':False,'last_test':None,'last_action':None},'record_delay_ms':1200,
            'mode':'KEEP','ingame_auto_setup_confirmed':False,'boss_key':'1',
            'filter_profile_ids':[1,2,3,4],'safe_pause':True,
            'loot_timeout_sec':BOSS_LOOT_TIMEOUT_SEC,'loot_settle_sec':LOOT_SETTLE_SEC,
            'boss_wait_sec':BOSS_LIVE_BAG_WAIT_SEC,'point_b_delta_confirm_sec':POINT_B_DELTA_CONFIRM_SEC,'bag_runtime_policy':'OPEN_DURING_BOSS_CONTINUOUS_SCAN','bag_hotkey_policy':'FOCUS_CLIENT_CLICK_THEN_FOREGROUND_QF4',
            'nav_timeout_sec':NAV_TIMEOUT_SEC,'max_cycles':0,
            'navigation_routes':{
                'A_TO_B':{'ready':False,'steps':[],'recorded_client_size':[],'start_scene_signature':[],'end_scene_signature':[],'recorded_at':None,'record_mode':'USER_CLICK_TRACE'},
                'B_TO_A':{'ready':False,'steps':[],'recorded_client_size':[],'start_scene_signature':[],'end_scene_signature':[],'recorded_at':None,'record_mode':'USER_CLICK_TRACE'},
            },
            'navigation':{'mode':'RECORDED_CLICK_ROUTE_PREFERRED','input_policy':'AUTO_BACKGROUND_THEN_FOREGROUND','step_retry_once':True,'minimum_motion_mae':1.15,'motion_probe_sec':0.72,'motion_probe_poll_sec':0.06,'end_scene_soft_match_mae':34.0,'arrival_verify_sec':3.0,'arrival_match_frames':2},
            'input_pacing':dict(AutoRollInputPacing.DEFAULTS),
        }

    def _load_config(self):
        d=self._default_config()
        try:
            if self.config_path.exists():
                raw=json.loads(self.config_path.read_text(encoding='utf-8'))
                if isinstance(raw,dict):
                    d.update(raw); d['points']={**self._default_config()['points'],**dict(raw.get('points') or {})}
                    old_profiles=dict(raw.get('container_profiles') or {})
                    migrated={}
                    for kind,prof in old_profiles.items():
                        if not isinstance(prof,dict):continue
                        q=dict(prof); q['container_id']=str(kind)
                        # V1.0 profiles stored raw rect + client_size. Convert once to
                        # normalized schema V2; runtime thereafter consumes canonical names.
                        size=q.get('recorded_client_size') or q.get('client_size') or []
                        try:w,h=float(size[0]),float(size[1])
                        except Exception:w=h=0.0
                        if w>0 and h>0:
                            if not q.get('panel_rect_norm') and len(q.get('panel_rect') or [])==4:
                                r=q['panel_rect']; q['panel_rect_norm']=[r[0]/w,r[1]/h,r[2]/w,r[3]/h]
                            if not q.get('grid_rect_norm') and len(q.get('grid_rect') or [])==4:
                                r=q['grid_rect']; q['grid_rect_norm']=[r[0]/w,r[1]/h,r[2]/w,r[3]/h]
                        q['schema_version']=max(3,int(q.get('schema_version') or 0)); q['title_ocr_used']=False
                        q.setdefault('owner_authority','CONTROLLED_LEARNING_CONTEXT_PLUS_GEOMETRY_PROFILE')
                        migrated[str(kind)]=q
                    d['container_profiles']=migrated
                    setup=dict(raw.get('container_setup') or {})
                    d['container_setup']={**self._default_config()['container_setup'],**setup}
                    routes=dict(raw.get('navigation_routes') or {})
                    merged_routes={}
                    for rname,default_route in self._default_config()['navigation_routes'].items():
                        rr=dict(routes.get(rname) or {})
                        merged_routes[rname]={**copy.deepcopy(default_route),**rr}
                    d['navigation_routes']=merged_routes
                    d['navigation']={**self._default_config()['navigation'],**dict(raw.get('navigation') or {})}
                    # V1.5.2 migration: the previous 15s/closed-bag policy is retired.
                    # Existing users are migrated once to the new 40s persistent-open
                    # live-scan contract; later user edits to 3..120s are preserved.
                    try: old_schema=int(raw.get('schema_version') or 0)
                    except Exception: old_schema=0
                    old_policy=str(raw.get('bag_runtime_policy') or '')
                    if old_schema<9 and ('CLOSED' in old_policy.upper() or old_policy in ('BASELINE_AT_A_THEN_CLOSED_COMBAT_OPEN_AT_B','')):
                        d['boss_wait_sec']=40.0
                        d['bag_runtime_policy']='OPEN_DURING_BOSS_CONTINUOUS_SCAN'
        except Exception:pass
        if not isinstance(d.get('container_setup'),dict):d['container_setup']=dict(self._default_config()['container_setup'])
        d['schema_version']=CONFIG_SCHEMA_VERSION; d['build_id']=BUILD_ID
        return d

    def _save_config(self):
        self.config_path.write_text(json.dumps(self.config,ensure_ascii=False,indent=2),encoding='utf-8')

    def _telemetry(self,event,**payload):
        self.log_writer.submit({'layer':'INPUT_TELEMETRY','event':event,'session_id':self.session_id,'cycle_id':getattr(self.active_cycle,'cycle_id',None),'state':self.state,'monotonic_ns':time.monotonic_ns(),'payload':payload})

    def _domain(self,event,logical_item_id=None,once_key=None,**payload):
        rec=self.ledger.emit(self.session_id,getattr(self.active_cycle,'cycle_id',None),logical_item_id,event,self.state,payload,once_key)
        self.last_event=rec
        return rec

    def _set_state(self,state,**payload):
        self.state=str(state); self._domain('STATE_TRANSITION',new_state=self.state,**payload)

    def _error(self,reason,component,detail=None,recoverable=False,item_id=None):
        env=BossErrorEnvelope(str(reason),str(component),self.state,self.session_id,getattr(self.active_cycle,'cycle_id',None),item_id,bool(recoverable),None,self.ledger.last_seq,dict(detail or {}))
        self.last_error=asdict(env); self.state='SAFE_PAUSE' if recoverable else 'ERROR'; self._domain('SAFE_PAUSE' if recoverable else 'ERROR',logical_item_id=item_id,error=self.last_error)
        return {'ok':False,'reason':str(reason),'error':self.last_error,'safe_pause':bool(recoverable)}

    def _input_token_valid(self):return self.cancellation.is_valid(self._cancel_generation)
    def _cancelled(self):return not self._input_token_valid()

    def _other_automation_busy(self):
        try:
            guard=self.api.automation_mode_guard('BOSS')
            if not guard.get('ok'):
                return str(guard.get('blocking_mode') or 'UNKNOWN')
            return None
        except Exception:
            try:
                if getattr(self.api,'_auto_roll_record',None) is not None and self.api._auto_roll_record.is_running():return 'ROLL'
            except Exception:pass
            try:
                st=str(getattr(self.api,'_runtime_lifecycle_state','STOPPED') or 'STOPPED').upper()
                if st in ('STARTING','RUNNING','RECOVERY_WAIT','RECOVERY_RUNNING','STOPPING'):return 'CHEST'
            except Exception:pass
            return None

    def _set_running_flag(self,running):
        try:
            self.api._cfg.setdefault('runtime',{}).setdefault('module_running',{})['boss']=bool(running)
            self.core._save_app_config(self.api._cfg)
        except Exception:pass

    def is_running(self):return bool(self.running and self.worker and self.worker.is_alive())

    def update_config(self,payload):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        p=dict(payload or {})
        if 'mode' in p:
            m=str(p.get('mode') or '').upper()
            if m not in ('KEEP','STORE'):return {'ok':False,'reason':'AUTOBOSS_MODE_INVALID'}
            self.config['mode']=m
        for k in ('ingame_auto_setup_confirmed','safe_pause'):
            if k in p:self.config[k]=bool(p[k])
        if 'boss_wait_sec' in p:
            try:self.config['boss_wait_sec']=max(3.0,min(120.0,float(p.get('boss_wait_sec'))))
            except Exception:return {'ok':False,'reason':'BOSS_WAIT_SECONDS_INVALID'}
        if 'point_b_delta_confirm_sec' in p:
            try:self.config['point_b_delta_confirm_sec']=max(0.5,min(8.0,float(p.get('point_b_delta_confirm_sec'))))
            except Exception:return {'ok':False,'reason':'POINT_B_DELTA_CONFIRM_SECONDS_INVALID'}
        self.config['bag_runtime_policy']='OPEN_DURING_BOSS_CONTINUOUS_SCAN'
        if 'filter_profile_ids' in p:
            ids=[]
            for x in p.get('filter_profile_ids') or []:
                try:v=int(x)
                except Exception:continue
                if v in (1,2,3,4) and v not in ids:ids.append(v)
            if ids:self.config['filter_profile_ids']=ids
        self.config['boss_key']='1'; self._save_config(); self.filter_adapter.compile_profiles(self.config.get('filter_profile_ids'))
        return {'ok':True,'config':self.public_config()}

    def public_config(self):
        return {k:v for k,v in self.config.items() if k not in ('input_pacing',)}

    def record_point(self,hwnd,which,delay_ms=1200):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        hwnd=int(hwnd or 0); which=str(which or '').upper()
        if which not in ('A','B'):return {'ok':False,'reason':'BOSS_POINT_INVALID'}
        if not hwnd or not self.core.window_exists(hwnd):return {'ok':False,'reason':'NO_VALID_CLIENT'}
        time.sleep(max(0,min(4000,int(delay_ms or 0)))/1000.0)
        p=self.core.get_cursor_client(hwnd); img=self.core.capture_client(hwnd)
        if p is None or img is None:return {'ok':False,'reason':'BOSS_POINT_CAPTURE_FAILED'}
        x,y=int(p[0]),int(p[1])
        if not (0<=x<img.width and 0<=y<img.height):return {'ok':False,'reason':'CURSOR_NOT_INSIDE_SELECTED_JX1_CLIENT'}
        rec=BossPoint(which,[x,y],[int(img.width),int(img.height)],_scene_signature(img),time.time())
        point_payload=asdict(rec); point_payload['client_hwnd_at_record']=int(hwnd); point_payload['client_title']=self.core._window_title(int(hwnd))
        self.config.setdefault('points',{})[which]=point_payload; self._save_config()
        return {'ok':True,'which':which,'client_point':[x,y],'coordinate_space':'CLIENT'}

    def _container_setup(self):
        setup=self.config.setdefault('container_setup',{})
        defaults=self._default_config()['container_setup']
        for k,v in defaults.items():setup.setdefault(k,copy.deepcopy(v))
        return setup

    def _set_container_setup_state(self,state,**detail):
        setup=self._container_setup(); setup['state']=str(state); setup['last_action']={'state':str(state),'at':time.time(),**detail}; self._save_config()
        self._domain('CONTAINER_SETUP_STATE',setup_state=str(state),**detail)

    @staticmethod
    def _candidate_profile(candidate,kind,image):
        c=dict(candidate or {}); w=max(1,int(image.width)); h=max(1,int(image.height))
        panel=list(c.get('panel_rect') or []); grid=list(c.get('grid_rect') or []); footer=list(c.get('footer_rect') or [])
        xs=list(c.get('x_lines') or []); ys=list(c.get('y_lines') or [])
        pitch_x=float(np.mean(np.diff(xs))) if len(xs)>=2 else 0.0; pitch_y=float(np.mean(np.diff(ys))) if len(ys)>=2 else 0.0
        def norm(r):
            if len(r)!=4:return []
            return [float(r[0])/w,float(r[1])/h,float(r[2])/w,float(r[3])/h]
        geom={'panel_rect_norm':norm(panel),'grid_rect_norm':norm(grid),'footer_rect_norm':norm(footer),'rows':int(c.get('rows') or 10),'cols':int(c.get('cols') or 6),'pitch_norm':[pitch_x/w,pitch_y/h],'footer_structure_signature':dict(c.get('footer_signature') or {})}
        return {'schema_version':3,'container_id':str(kind),'panel_rect_norm':geom['panel_rect_norm'],'grid_rect_norm':geom['grid_rect_norm'],'footer_rect_norm':geom['footer_rect_norm'],'footer_structure_signature':geom['footer_structure_signature'],'recorded_client_size':[w,h],'grid_rows':geom['rows'],'grid_cols':geom['cols'],'grid_pitch_norm':geom['pitch_norm'],'panel_to_grid_offset_norm':([geom['grid_rect_norm'][0]-geom['panel_rect_norm'][0],geom['grid_rect_norm'][1]-geom['panel_rect_norm'][1]] if len(geom['grid_rect_norm'])==4 and len(geom['panel_rect_norm'])==4 else []),'visual_geometry_fingerprint':_hash_json(geom),'captured_at':time.time(),'profile_version':'AUTOBOSS_CONTAINER_LEARNING_V1','title_ocr_used':False,'owner_authority':'CONTROLLED_LEARNING_CONTEXT_PLUS_GEOMETRY_PROFILE'}

    @staticmethod
    def _grid_only_player_profile(grid,image):
        """Fallback learning profile for the canonical right-side Player Bag.

        Some JX1 skins make whole-panel/footer candidate extraction ambiguous even
        though the 6x10 Player Bag lattice itself is clearly detected. Learning
        the grid geometry is enough for KEEP runtime ownership and avoids forcing
        the user to repeatedly rescan a visible bag.
        """
        try:
            xs=[int(x) for x in (grid or {}).get('x_lines',[])]; ys=[int(y) for y in (grid or {}).get('y_lines',[])]
            if len(xs)!=7 or len(ys)!=11 or image is None:return None
            w=max(1,int(image.width)); h=max(1,int(image.height))
            gr=[xs[0]/w,ys[0]/h,xs[-1]/w,ys[-1]/h]
            pitch_x=float(np.mean(np.diff(xs))) if len(xs)>=2 else 0.0
            pitch_y=float(np.mean(np.diff(ys))) if len(ys)>=2 else 0.0
            geom={'grid_rect_norm':gr,'rows':10,'cols':6,'pitch_norm':[pitch_x/w,pitch_y/h]}
            return {'schema_version':4,'container_id':CONTAINER_PLAYER,'panel_rect_norm':[],
                    'grid_rect_norm':gr,'footer_rect_norm':[],'footer_structure_signature':{},
                    'recorded_client_size':[w,h],'grid_rows':10,'grid_cols':6,
                    'grid_pitch_norm':[pitch_x/w,pitch_y/h],'panel_to_grid_offset_norm':[],
                    'visual_geometry_fingerprint':_hash_json(geom),'captured_at':time.time(),
                    'profile_version':'AUTOBOSS_PLAYER_GRID_FALLBACK_V1_5_3','title_ocr_used':False,
                    'owner_authority':'SHARED_CANONICAL_PLAYER_BAG_GRID_CONTROLLED_LEARNING'}
        except Exception:
            return None

    @staticmethod
    def _candidate_public(c):
        if not isinstance(c,dict):return {}
        return {k:copy.deepcopy(c.get(k)) for k in ('candidate_id','panel_rect','grid_rect','footer_rect','panel_norm','grid_norm','panel_height_norm','panel_width_norm','top_norm','footer_signature','candidate_quality','source') if k in c}

    def _learning_candidates(self,img):
        raw=detect_jx1_container_candidates(img)
        cs=[dict(x) for x in (raw.get('candidates') or []) if isinstance(x,dict)]
        strong=[c for c in cs if float(c.get('candidate_quality') or 0.0)>=0.62]
        return {'ok':bool(strong),'reason':None if strong else raw.get('reason') or 'INVENTORY_PANEL_CANDIDATES_NOT_FOUND','candidates':strong,'all_candidates':cs,'count':len(strong)}

    def learn_player_bag(self,hwnd):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        hwnd=int(hwnd or 0)
        if not hwnd or not self.core.window_exists(hwnd):return {'ok':False,'reason':'NO_VALID_CLIENT'}
        self._set_container_setup_state('LEARN_PLAYER_BAG_REQUEST')
        self._domain('CONTAINER_LEARN_BEGIN',type=CONTAINER_PLAYER); self._set_container_setup_state('SCAN_PLAYER_BAG')

        # V1.5.1 focused UX rootfix: the Player-Bag learn button is allowed to
        # prepare only the container-learning view.  It does NOT start AutoBoss,
        # move the character, press Ctrl+F, or touch Key1.  If the bag is closed,
        # reuse the proven inventory-ready helper to open it.  If both container
        # panels are visible, close only the small storage panel once and rescan.
        img=self.core.capture_client(hwnd)
        if img is None:
            self._set_container_setup_state('PLAYER_BAG_SCAN_FAILED',reason='CAPTURE_FAILED'); return {'ok':False,'reason':'CAPTURE_FAILED'}
        det=self._learning_candidates(img); cs=det.get('candidates') or []
        if len(cs)>1:
            closed_storage=self._close_storage_if_open_once(hwnd)
            self._domain('PLAYER_BAG_LEARN_STORAGE_CLEAR_ATTEMPT',ok=bool(closed_storage.get('ok')),detail={k:v for k,v in closed_storage.items() if k!='image'})
            if closed_storage.get('ok'):
                time.sleep(.12)
                img=self.core.capture_client(hwnd)
                det=self._learning_candidates(img) if img is not None else {'candidates':[]}
                cs=det.get('candidates') or []
        if len(cs)==0:
            # V1.5.3: this JX1 client consumes Q/F4 only after a real click inside
            # the game client. Reuse the runtime focus+hotkey contract for setup.
            ready=self._ensure_player_bag_open_live(int(hwnd),'LEARN_PLAYER_BAG')
            self._domain('PLAYER_BAG_LEARN_AUTO_OPEN_ATTEMPT',ok=bool(ready.get('ok')),reason=ready.get('reason'))
            if ready.get('ok'):
                img=ready.get('image') or self.core.capture_client(hwnd)
                det=self._learning_candidates(img) if img is not None else {'candidates':[]}
                cs=det.get('candidates') or []
        self._domain('INVENTORY_PANEL_CANDIDATES',count=len(cs),candidates=[self._candidate_public(c) for c in cs])
        if len(cs)!=1:
            # Focused root fallback: decorative panel detection may be ambiguous
            # while the canonical right-side Player Bag lattice is still exact.
            shared=detect_inventory_grid(img) if img is not None else {'ok':False}
            prof=self._grid_only_player_profile(shared,img) if shared.get('ok') else None
            if prof:
                profiles=self.config.setdefault('container_profiles',{}); profiles[CONTAINER_PLAYER]=prof
                setup=self._container_setup(); setup['pair_test_pass']=False; setup['last_test']=None
                self._save_config()
                self._domain('PLAYER_BAG_PROFILE_SAVED_GRID_FALLBACK',grid_rect_norm=prof.get('grid_rect_norm'),candidate_count=len(cs))
                self._set_container_setup_state('PLAYER_BAG_PROFILE_SAVED',learning_mode='SHARED_CANONICAL_GRID_FALLBACK')
                return {'ok':True,'container_id':CONTAINER_PLAYER,'profile':prof,'candidate':{},
                        'status':'READY','instruction_complete':True,'learning_mode':'SHARED_CANONICAL_GRID_FALLBACK'}
            self._set_container_setup_state('PLAYER_BAG_SCAN_FAILED',candidate_count=len(cs))
            return {'ok':False,'reason':'PLAYER_BAG_SCAN_FAILED','candidate_count':len(cs),'candidates':[self._candidate_public(c) for c in cs],
                    'message':'Chưa khóa được Player Bag. Auto đã tự click vào client, thử Q/F4 và fallback grid chính; hãy bảo đảm cửa Hành Trang lớn đang hiện rồi QUÉT lại.'}
        c=cs[0]; prof=self._candidate_profile(c,CONTAINER_PLAYER,img)
        profiles=self.config.setdefault('container_profiles',{}); profiles[CONTAINER_PLAYER]=prof
        setup=self._container_setup(); setup['pair_test_pass']=False; setup['last_test']=None
        self._save_config(); self._domain('PLAYER_BAG_PROFILE_CAPTURED',candidate=self._candidate_public(c),profile=prof); self._domain('PLAYER_BAG_PROFILE_SAVED',profile=prof)
        self._set_container_setup_state('PLAYER_BAG_PROFILE_SAVED',candidate_id=c.get('candidate_id'))
        return {'ok':True,'container_id':CONTAINER_PLAYER,'profile':prof,'candidate':self._candidate_public(c),'status':'READY','instruction_complete':True}

    def learn_storage(self,hwnd):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        hwnd=int(hwnd or 0); profiles=self.config.setdefault('container_profiles',{}); pprof=profiles.get(CONTAINER_PLAYER)
        if not pprof:return {'ok':False,'reason':'CONTAINER_SETUP_REQUIRED','missing':[CONTAINER_PLAYER]}
        if not hwnd or not self.core.window_exists(hwnd):return {'ok':False,'reason':'NO_VALID_CLIENT'}
        self._set_container_setup_state('LEARN_STORAGE_REQUEST')
        img=self.core.capture_client(hwnd)
        if img is None:
            self._set_container_setup_state('STORAGE_SCAN_FAILED',reason='CAPTURE_FAILED'); return {'ok':False,'reason':'CAPTURE_FAILED'}
        self._domain('CONTAINER_LEARN_BEGIN',type=CONTAINER_STORAGE); self._set_container_setup_state('SCAN_CONTAINER_PAIR')
        det=self._learning_candidates(img); cs=det.get('candidates') or []
        self._domain('INVENTORY_PANEL_CANDIDATES',count=len(cs),candidates=[self._candidate_public(c) for c in cs])
        if len(cs)<2:
            self._set_container_setup_state('STORAGE_SCAN_FAILED',candidate_count=len(cs)); return {'ok':False,'reason':'STORAGE_SCAN_FAILED','candidate_count':len(cs),'candidates':[self._candidate_public(c) for c in cs]}
        ranked=sorted([(float(score_jx1_container_profile(c,pprof)),i,c) for i,c in enumerate(cs)],reverse=True,key=lambda x:x[0])
        best=ranked[0]; second=ranked[1] if len(ranked)>1 else (0.0,-1,{})
        margin=float(best[0])-float(second[0])
        self._domain('EXISTING_PLAYER_BAG_MATCH',candidate_id=best[2].get('candidate_id'),confidence=best[0],second_confidence=second[0],margin=margin)
        if best[0]<0.52 or margin<0.08:
            self._set_container_setup_state('STORAGE_SCAN_FAILED',reason='PLAYER_BAG_PROFILE_MATCH_AMBIGUOUS',best=best[0],margin=margin)
            return {'ok':False,'reason':'PLAYER_BAG_PROFILE_MATCH_AMBIGUOUS','best_confidence':best[0],'margin':margin,'candidates':[self._candidate_public(c) for c in cs]}
        player=best[2]; others=[c for _,i,c in ranked if i!=best[1] and _container_pair_separated(player,c)]
        if not others:
            self._set_container_setup_state('STORAGE_SCAN_FAILED',reason='STORAGE_CANDIDATE_NOT_FOUND'); return {'ok':False,'reason':'STORAGE_CANDIDATE_NOT_FOUND'}
        storage=None
        if len(others)==1:storage=others[0]
        else:
            pair=resolve_jx1_container_candidates(cs,img,{CONTAINER_PLAYER:pprof},True)
            if pair.get('ok'):
                sid=(pair.get('evidence') or {}).get('storage_candidate_id'); storage=next((c for c in cs if str(c.get('candidate_id'))==str(sid)),None)
        if storage is None:
            self._set_container_setup_state('STORAGE_SCAN_FAILED',reason='STORAGE_CANDIDATE_AMBIGUOUS',candidate_count=len(cs)); return {'ok':False,'reason':'STORAGE_CANDIDATE_AMBIGUOUS','candidate_count':len(cs)}
        sprof=self._candidate_profile(storage,CONTAINER_STORAGE,img); profiles[CONTAINER_STORAGE]=sprof
        setup=self._container_setup(); setup['pair_test_pass']=False; setup['last_test']=None
        self._save_config(); self._domain('PLAYER_BAG_MATCHED',candidate_id=player.get('candidate_id'),confidence=best[0]); self._domain('STORAGE_CANDIDATE',candidate=self._candidate_public(storage)); self._domain('STORAGE_PROFILE_SAVED',profile=sprof)
        self._set_container_setup_state('STORAGE_PROFILE_SAVED',player_candidate_id=player.get('candidate_id'),storage_candidate_id=storage.get('candidate_id'))
        return {'ok':True,'container_id':CONTAINER_STORAGE,'profile':sprof,'player_match_confidence':best[0],'player_match_margin':margin,'player_candidate':self._candidate_public(player),'storage_candidate':self._candidate_public(storage),'status':'READY'}

    def _pair_debug_preview(self,img,r):
        try:
            arr=np.asarray(img.convert('RGB')).copy()
            pr=(r.player_panel or {}).get('panel_rect') or (r.player_grid or {}).get('panel_rect') or []; sr=(r.storage_panel or {}).get('panel_rect') or (r.storage_grid or {}).get('panel_rect') or []
            if len(pr)==4:
                cv2.rectangle(arr,(int(pr[0]),int(pr[1])),(int(pr[2]),int(pr[3])),(0,255,0),3); cv2.putText(arr,'PLAYER_BAG',(int(pr[0])+4,max(18,int(pr[1])-6)),cv2.FONT_HERSHEY_SIMPLEX,.55,(0,255,0),2,cv2.LINE_AA)
            if len(sr)==4:
                cv2.rectangle(arr,(int(sr[0]),int(sr[1])),(int(sr[2]),int(sr[3])),(255,190,0),3); cv2.putText(arr,'STORAGE_CHEST',(int(sr[0])+4,max(18,int(sr[1])-6)),cv2.FONT_HERSHEY_SIMPLEX,.55,(255,190,0),2,cv2.LINE_AA)
            ok,buf=cv2.imencode('.png',cv2.cvtColor(arr,cv2.COLOR_RGB2BGR))
            return ('data:image/png;base64,'+base64.b64encode(buf.tobytes()).decode('ascii')) if ok else None
        except Exception:return None

    def test_container_pair(self,hwnd):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        hwnd=int(hwnd or 0); profiles=self.config.get('container_profiles') or {}; missing=[k for k in (CONTAINER_PLAYER,CONTAINER_STORAGE) if not profiles.get(k)]
        if missing:return {'ok':False,'reason':'CONTAINER_SETUP_REQUIRED','missing':missing}
        if not hwnd or not self.core.window_exists(hwnd):return {'ok':False,'reason':'NO_VALID_CLIENT'}
        self._set_container_setup_state('CONTAINER_PAIR_TEST'); self._domain('PAIR_RESOLVE_BEGIN')
        img=self.core.capture_client(hwnd); r=self.container_resolver.resolve(img,require_storage=True) if img is not None else ContainerResolution(False,reason='CAPTURE_FAILED')
        self._log_container_resolution(r,'CONTAINER_SETUP_TEST')
        setup=self._container_setup(); setup['pair_test_pass']=bool(r.ok); setup['last_test']={'ok':bool(r.ok),'reason':r.reason,'confidence':float(r.confidence or 0.0),'at':time.time(),'player_rect':(r.player_panel or {}).get('panel_rect'),'storage_rect':(r.storage_panel or {}).get('panel_rect')}; self._save_config()
        if not r.ok:
            self._set_container_setup_state('CONTAINER_PAIR_AMBIGUOUS' if r.reason=='CONTAINER_OWNER_AMBIGUOUS' else 'CONTAINER_PAIR_FAILED',reason=r.reason,confidence=r.confidence)
            return {'ok':False,'reason':r.reason or 'PAIR_RESOLUTION_FAILED','confidence':r.confidence,'evidence':r.evidence,'preview':self._pair_debug_preview(img,r) if img is not None else None}
        self._domain('PLAYER_BAG_RESOLVED',confidence=r.confidence,panel_rect=(r.player_panel or {}).get('panel_rect')); self._domain('STORAGE_CHEST_RESOLVED',confidence=r.confidence,panel_rect=(r.storage_panel or {}).get('panel_rect')); self._domain('PAIR_RESOLUTION_PASS',confidence=r.confidence)
        self._set_container_setup_state('CONTAINER_SETUP_READY',confidence=r.confidence)
        return {'ok':True,'status':'PASS','confidence':r.confidence,'player_bag':{'confidence':r.confidence,'panel_rect':(r.player_panel or {}).get('panel_rect'),'grid_rect':(r.player_grid or {}).get('grid_rect')},'storage':{'confidence':r.confidence,'panel_rect':(r.storage_panel or {}).get('panel_rect'),'grid_rect':(r.storage_grid or {}).get('grid_rect')},'evidence':r.evidence,'preview':self._pair_debug_preview(img,r)}

    def reset_container_profiles(self,scope='ALL'):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        scope=str(scope or 'ALL').upper(); profiles=self.config.setdefault('container_profiles',{})
        if scope in ('ALL','BOTH'):
            profiles.pop(CONTAINER_PLAYER,None); profiles.pop(CONTAINER_STORAGE,None)
        elif scope in ('PLAYER','PLAYER_BAG'):
            profiles.pop(CONTAINER_PLAYER,None); profiles.pop(CONTAINER_STORAGE,None)
        elif scope in ('STORAGE','STORAGE_CHEST'):
            profiles.pop(CONTAINER_STORAGE,None)
        else:return {'ok':False,'reason':'CONTAINER_RESET_SCOPE_INVALID'}
        setup=self._container_setup(); setup.update({'state':'CONTAINER_SETUP_IDLE','pair_test_pass':False,'last_test':None,'last_action':{'state':'CONTAINER_SETUP_IDLE','at':time.time(),'reset_scope':scope}}); self.last_container_resolution=None; self._save_config(); self._domain('CONTAINER_PROFILE_RESET',scope=scope)
        return {'ok':True,'scope':scope,'container_profiles':{CONTAINER_PLAYER:bool(profiles.get(CONTAINER_PLAYER)),CONTAINER_STORAGE:bool(profiles.get(CONTAINER_STORAGE))}}

    def record_container_profile(self,hwnd,kind):
        kind=str(kind or '').upper()
        if kind==CONTAINER_PLAYER:return self.learn_player_bag(hwnd)
        if kind==CONTAINER_STORAGE:return self.learn_storage(hwnd)
        return {'ok':False,'reason':'CONTAINER_PROFILE_KIND_INVALID'}

    @staticmethod
    def _route_name(route):
        r=str(route or '').upper().replace('→','_TO_').replace('->','_TO_').replace('-','_')
        aliases={'AB':'A_TO_B','A_B':'A_TO_B','A2B':'A_TO_B','BA':'B_TO_A','B_A':'B_TO_A','B2A':'B_TO_A'}
        r=aliases.get(r,r)
        return r if r in ('A_TO_B','B_TO_A') else None

    def _route_for_target(self,which):
        return 'A_TO_B' if str(which).upper()=='B' else 'B_TO_A'

    def _route_config(self,route):
        r=self._route_name(route)
        if not r:return None
        routes=self.config.setdefault('navigation_routes',{})
        if r not in routes:
            routes[r]=copy.deepcopy(self._default_config()['navigation_routes'][r])
        return routes[r]

    def _route_ready(self,route):
        rec=self._route_config(route) or {}
        return bool(rec.get('ready') and len(rec.get('steps') or [])>=1)

    def start_route_record(self,hwnd,route):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        route=self._route_name(route)
        if not route:return {'ok':False,'reason':'NAV_ROUTE_INVALID'}
        hwnd=int(hwnd or 0)
        if not hwnd or not self.core.window_exists(hwnd):return {'ok':False,'reason':'NO_VALID_CLIENT'}
        with self._route_record_lock:
            if self._route_record_state.get('active'):return {'ok':False,'reason':'NAV_ROUTE_RECORD_ALREADY_ACTIVE','active_route':self._route_record_state.get('route')}
            img=self.core.capture_client(hwnd)
            if img is None:return {'ok':False,'reason':'CAPTURE_FAILED'}
            self._route_record_stop=threading.Event()
            self._route_record_state={
                'active':True,'route':route,'hwnd':hwnd,'steps':[],'started_at':time.time(),'recorded_clicks':0,'last_reason':None,
                'client_size':[int(img.width),int(img.height)],'start_scene_signature':_scene_signature(img),'last_click_mono':None,
            }
            self._route_record_thread=threading.Thread(target=self._route_record_worker,args=(hwnd,route,self._route_record_stop),daemon=True,name=f'AutoBossRouteRecord-{route}')
            self._route_record_thread.start()
        self._domain('NAV_ROUTE_RECORD_BEGIN',route=route,hwnd=hwnd)
        return {'ok':True,'route':route,'state':'RECORDING','instruction':'Di chuyển nhân vật thủ công bằng click trong JX1; tool sẽ ghi từng click làm waypoint.'}

    def _route_record_worker(self,hwnd,route,stop_event):
        prev_down=False
        try:
            while not stop_event.is_set():
                down=bool(int(self.core.user32_bridge.GetAsyncKeyState(VK_LBUTTON)) & 0x8000)
                if down and not prev_down:
                    fg=int(self.core.user32_bridge.GetForegroundWindow() or 0)
                    if fg!=int(hwnd):
                        prev_down=down; time.sleep(ROUTE_POLL_SEC); continue
                    img=self.core.capture_client(int(hwnd))
                    p=self.core.get_cursor_client(int(hwnd))
                    if img is not None and p is not None:
                        x,y=int(p[0]),int(p[1]); w,h=int(img.width),int(img.height)
                        if 0<=x<w and 0<=y<h:
                            now=time.monotonic()
                            with self._route_record_lock:
                                st=self._route_record_state
                                if st.get('active') and st.get('route')==route:
                                    last=st.get('last_click_mono')
                                    gap_ms=int((now-last)*1000.0) if last is not None else 0
                                    if last is None or gap_ms>=ROUTE_MIN_CLICK_GAP_MS:
                                        step={
                                            'index':len(st['steps'])+1,
                                            'client_point':[x,y],
                                            'norm':[round(x/max(1,w),6),round(y/max(1,h),6)],
                                            'delay_from_previous_ms':gap_ms,
                                            'recorded_client_size':[w,h],
                                        }
                                        st['steps'].append(step); st['recorded_clicks']=len(st['steps']); st['last_click_mono']=now
                                        self._domain('NAV_ROUTE_WAYPOINT_RECORDED',route=route,index=step['index'],client_point=step['client_point'],norm=step['norm'],gap_ms=gap_ms)
                prev_down=down
                time.sleep(ROUTE_POLL_SEC)
        except Exception as e:
            with self._route_record_lock:
                if self._route_record_state.get('active'):
                    self._route_record_state['last_reason']='NAV_ROUTE_RECORD_WORKER_FAILED:'+type(e).__name__
            self._domain('NAV_ROUTE_RECORD_WORKER_FAILED',route=route,error_type=type(e).__name__,error=str(e))

    def stop_route_record(self,route=None):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        with self._route_record_lock:
            if not self._route_record_state.get('active'):return {'ok':False,'reason':'NAV_ROUTE_RECORD_NOT_ACTIVE'}
            active_route=self._route_record_state.get('route'); requested=self._route_name(route) if route else active_route
            if requested and requested!=active_route:return {'ok':False,'reason':'NAV_ROUTE_RECORD_ROUTE_MISMATCH','active_route':active_route}
            ev=self._route_record_stop; th=self._route_record_thread
            if ev:ev.set()
        if th and th.is_alive():th.join(timeout=1.0)
        with self._route_record_lock:
            st=dict(self._route_record_state); steps=[dict(x) for x in st.get('steps') or []]
        if not steps:
            with self._route_record_lock:
                self._route_record_state={'active':False,'route':None,'hwnd':0,'steps':[],'started_at':0.0,'recorded_clicks':0,'last_reason':'NAV_ROUTE_EMPTY'}
            return {'ok':False,'reason':'NAV_ROUTE_EMPTY'}
        hwnd=int(st.get('hwnd') or 0); img=self.core.capture_client(hwnd) if hwnd and self.core.window_exists(hwnd) else None
        # Convert the manual gap before the NEXT click into the replay hold after the CURRENT click.
        for i,step in enumerate(steps):
            if i+1<len(steps):hold=int(steps[i+1].get('delay_from_previous_ms') or 0)
            else:hold=ROUTE_LAST_HOLD_MS
            step['hold_after_ms']=max(180,min(ROUTE_MAX_HOLD_MS,hold if hold>0 else 350))
        rec=self._route_config(active_route)
        rec.update({
            'ready':True,'steps':steps,'recorded_client_size':st.get('client_size') or [],
            'start_scene_signature':st.get('start_scene_signature') or [],
            'end_scene_signature':_scene_signature(img) if img is not None else [],
            'recorded_at':time.time(),'record_mode':'USER_CLICK_TRACE',
        })
        self._save_config()
        with self._route_record_lock:
            self._route_record_state={'active':False,'route':None,'hwnd':0,'steps':[],'started_at':0.0,'recorded_clicks':0,'last_reason':None}
            self._route_record_thread=None; self._route_record_stop=None
        self._domain('NAV_ROUTE_RECORD_SAVED',route=active_route,step_count=len(steps))
        return {'ok':True,'route':active_route,'step_count':len(steps),'ready':True}

    def reset_route(self,route='ALL'):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        with self._route_record_lock:
            if self._route_record_state.get('active'):return {'ok':False,'reason':'NAV_ROUTE_RECORD_ACTIVE'}
        route=str(route or 'ALL').upper()
        names=('A_TO_B','B_TO_A') if route in ('ALL','BOTH') else (self._route_name(route),)
        if not names[0]:return {'ok':False,'reason':'NAV_ROUTE_INVALID'}
        for name in names:self.config.setdefault('navigation_routes',{})[name]=copy.deepcopy(self._default_config()['navigation_routes'][name])
        self._save_config(); self._domain('NAV_ROUTE_RESET',route=route)
        return {'ok':True,'routes':{k:self._route_ready(k) for k in ('A_TO_B','B_TO_A')}}

    def _sleep_cancelable(self,seconds):
        end=time.monotonic()+max(0.0,float(seconds or 0.0))
        while time.monotonic()<end:
            if self._cancelled():return False
            time.sleep(min(.05,max(0.0,end-time.monotonic())))
        return True

    def _nav_background_click(self,hwnd,x,y,action_id,purpose):
        """Navigation-safe background click using the proven JX1 child-window path."""
        fn=getattr(self.core,'_post_left_click_client',None)
        if not callable(fn):
            return {'ok':False,'reason':'NAV_BACKGROUND_CLICK_UNAVAILABLE','action_id':action_id}
        try:
            ok,target,p=fn(int(hwnd),int(x),int(y))
            out={'ok':bool(ok),'action_id':action_id,'purpose':purpose,'used_mode':'Background/PostMessageLeftClick',
                 'target_hwnd':int(target or 0),'target_point':list(p) if p else [int(x),int(y)],'client_point':[int(x),int(y)]}
            if not ok:out['reason']='NAV_BACKGROUND_LEFT_CLICK_FAILED'
            self._telemetry('NAV_INPUT_DISPATCHED',**out)
            return out
        except Exception as e:
            return {'ok':False,'reason':'NAV_BACKGROUND_CLICK_EXCEPTION','error_type':type(e).__name__,'error':str(e),'action_id':action_id}

    def _nav_foreground_click(self,hwnd,x,y,w,h,action_id,purpose):
        """Foreground movement click through the canonical atomic pointer dispatcher."""
        target=InteractionTarget.client(str(purpose),[int(x),int(y)],14,[int(w),int(h)])
        out=self.input_dispatcher.click(int(hwnd),target,str(action_id),str(purpose),require_foreground=True)
        if out.get('ok'):out['nav_dispatch_mode']='Foreground/SendInputLeftClick'
        return out

    def _nav_probe_motion(self,hwnd,baseline_sig,probe_sec=None):
        nav=self.config.get('navigation') or {}
        duration=max(.20,min(1.50,float(probe_sec if probe_sec is not None else nav.get('motion_probe_sec') or .72)))
        poll=max(.035,min(.18,float(nav.get('motion_probe_poll_sec') or .06)))
        min_motion=float(nav.get('minimum_motion_mae') or 1.15)
        if not baseline_sig:
            first=self.core.capture_client(int(hwnd)); baseline_sig=_scene_signature(first)
        if not baseline_sig:
            return {'ok':False,'reason':'NAV_MOTION_BASELINE_CAPTURE_FAILED','motion':False,'motion_mae':0.0,'samples':[]}
        deadline=time.monotonic()+duration
        max_motion=0.0; samples=[]; last_sig=baseline_sig
        while time.monotonic()<deadline:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP','motion_mae':max_motion,'samples':samples}
            img=self.core.capture_client(int(hwnd)); sig=_scene_signature(img)
            if baseline_sig and sig:
                from_base=_sig_mae(baseline_sig,sig); max_motion=max(max_motion,float(from_base))
            else:from_base=0.0
            if last_sig and sig:frame_motion=_sig_mae(last_sig,sig)
            else:frame_motion=0.0
            samples.append({'from_base':round(float(from_base),2),'frame':round(float(frame_motion),2)})
            if from_base>=min_motion:
                return {'ok':True,'motion':True,'motion_mae':round(float(max_motion),2),'samples':samples[-8:]}
            last_sig=sig
            time.sleep(poll)
        return {'ok':True,'motion':False,'motion_mae':round(float(max_motion),2),'samples':samples[-8:]}

    def _nav_click_with_auto_fallback(self,hwnd,x,y,w,h,action_base,purpose,baseline_sig):
        """Auto mode: Background first, then Foreground only when the game shows no motion.

        A ground movement click is idempotent enough for this fallback: the second click
        targets the same client point and cannot spawn a Boss or toggle JX1 Auto.
        """
        requested=str(getattr(self.api,'_cfg',{}).get('input_mode','Auto') or 'Auto')
        req_upper=requested.upper()
        attempts=[]
        if req_upper=='BACKGROUND': order=('BACKGROUND',)
        elif req_upper=='FOREGROUND': order=('FOREGROUND',)
        else: order=('BACKGROUND','FOREGROUND')
        base_sig=baseline_sig
        for i,mode in enumerate(order,1):
            aid=f'{action_base}:{mode}:TRY{i}'
            if mode=='BACKGROUND': dispatched=self._nav_background_click(hwnd,x,y,aid,purpose)
            else: dispatched=self._nav_foreground_click(hwnd,x,y,w,h,aid,purpose)
            attempt={'mode':mode,'dispatch':dispatched}
            if not dispatched.get('ok'):
                attempts.append(attempt)
                continue
            probe=self._nav_probe_motion(hwnd,base_sig)
            attempt['probe']=probe; attempts.append(attempt)
            if probe.get('reason')=='USER_STOP':return {'ok':False,'reason':'USER_STOP','attempts':attempts}
            if probe.get('motion'):
                self._domain('NAV_INPUT_CONSUMED',input_mode=mode,target=[int(x),int(y)],motion_mae=probe.get('motion_mae'),purpose=purpose)
                return {'ok':True,'motion':True,'used_mode':mode,'motion_mae':probe.get('motion_mae'),'attempts':attempts}
            # Auto is the only mode allowed to try the alternate transport.
            if req_upper!='AUTO':break
            latest=self.core.capture_client(int(hwnd)); latest_sig=_scene_signature(latest)
            if latest_sig:base_sig=latest_sig
        self._domain('NAV_INPUT_NOT_CONSUMED',target=[int(x),int(y)],purpose=purpose,requested_mode=requested,attempts=attempts)
        return {'ok':False,'reason':'NAV_CLICK_NOT_CONSUMED','motion':False,'requested_mode':requested,'attempts':attempts}

    def _navigate_route(self,hwnd,route,which):
        rec=self._route_config(route) or {}; steps=rec.get('steps') or []
        if not rec.get('ready') or not steps:return {'ok':False,'reason':'NAV_ROUTE_NOT_CONFIGURED','route':route}
        img=self.core.capture_client(int(hwnd))
        if img is None:return {'ok':False,'reason':'CAPTURE_FAILED','route':route}
        w,h=int(img.width),int(img.height); motion_seen=False; no_motion=0; samples=[]
        self._set_state('NAVIGATE_'+str(which).upper(),route=route,route_steps=len(steps),navigation_mode='RECORDED_CLICK_ROUTE_V1_3')
        for idx,step in enumerate(steps,1):
            if self._cancelled():return {'ok':False,'reason':'USER_STOP','route':route,'step':idx}
            norm=step.get('norm') or []
            if len(norm)==2:
                x=max(0,min(w-1,int(round(float(norm[0])*w)))); y=max(0,min(h-1,int(round(float(norm[1])*h))))
            else:
                p=step.get('client_point') or []
                if len(p)!=2:return {'ok':False,'reason':'NAV_ROUTE_STEP_INVALID','route':route,'step':idx}
                rw,rh=(step.get('recorded_client_size') or rec.get('recorded_client_size') or [w,h])[:2]
                x=max(0,min(w-1,int(round(float(p[0])*w/max(1,float(rw)))))); y=max(0,min(h-1,int(round(float(p[1])*h/max(1,float(rh))))))
            prior=self.core.capture_client(int(hwnd)); prior_sig=_scene_signature(prior)
            action_base=f'{self.session_id or "TEST"}:{getattr(self.active_cycle,"cycle_id","NO")}:ROUTE:{route}:{idx}:{self.ledger.last_seq+1}'
            started=time.monotonic()
            nav=self._nav_click_with_auto_fallback(int(hwnd),x,y,w,h,action_base,f'NAV_ROUTE_{route}_{idx}',prior_sig)
            motion=bool(nav.get('motion')); motion_mae=float(nav.get('motion_mae') or 0.0)
            if motion:
                motion_seen=True; no_motion=0
            else:
                no_motion+=1
            hold_ms=max(180,min(ROUTE_MAX_HOLD_MS,int(step.get('hold_after_ms') or 350)))
            elapsed_ms=int((time.monotonic()-started)*1000.0)
            remain_ms=max(0,hold_ms-elapsed_ms)
            if remain_ms and not self._sleep_cancelable(remain_ms/1000.0):return {'ok':False,'reason':'USER_STOP','route':route,'step':idx}
            sample={'step':idx,'target':[x,y],'hold_ms':hold_ms,'motion_mae':round(motion_mae,2),'motion':motion,
                    'no_motion':no_motion,'used_mode':nav.get('used_mode'),'dispatch_reason':nav.get('reason')}
            samples.append(sample); self._domain('NAV_ROUTE_STEP_COMMITTED',route=route,**sample)
            # One recorded click may be a harmless focus/no-op click. Two consecutive
            # waypoints with no scene motion means the playback transport is not consumed.
            if no_motion>=2:
                return {'ok':False,'reason':'NAV_ROUTE_NO_PROGRESS','route':route,'step':idx,'samples':samples[-6:],'last_input':nav}
        # V1.5 root rule: route playback completion / scene motion is NOT arrival truth.
        # A route can dispatch every click and still stop short of B/A.  Confirm the
        # recorded destination scene over multiple fresh frames before declaring arrival.
        end_ref=rec.get('end_scene_signature') or []
        if not end_ref:
            return {'ok':False,'reason':'NAV_DESTINATION_ANCHOR_MISSING','route':route,'route_steps':len(steps),'motion_seen':motion_seen,'samples':samples[-8:]}
        nav_cfg=self.config.get('navigation') or {}
        soft=float(nav_cfg.get('end_scene_soft_match_mae') or 34.0)
        verify_sec=max(.6,min(6.0,float(nav_cfg.get('arrival_verify_sec') or 3.0)))
        need=max(2,min(5,int(nav_cfg.get('arrival_match_frames') or 2)))
        self._set_state('VERIFY_'+str(which).upper(),route=route,arrival_evidence='DESTINATION_SCENE_MULTI_FRAME')
        deadline=time.monotonic()+verify_sec; consecutive=0; best_mae=255.0; arrival_samples=[]
        while time.monotonic()<deadline:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP','route':route}
            cur=self.core.capture_client(int(hwnd)); sig=_scene_signature(cur); mae=_sig_mae(end_ref,sig) if sig else 255.0
            best_mae=min(best_mae,float(mae)); match=bool(mae<=soft)
            consecutive=(consecutive+1) if match else 0
            arrival_samples.append({'mae':round(float(mae),2),'match':match,'consecutive':consecutive})
            if consecutive>=need:
                self._domain('POINT_'+str(which).upper()+'_CONFIRMED',once_key=f'{getattr(self.active_cycle,"cycle_id","SESSION")}:{which}:CONFIRMED',navigation_mode='RECORDED_CLICK_ROUTE_V1_5',route=route,route_steps=len(steps),motion_seen=motion_seen,end_scene_mae=mae,end_scene_soft_match=True,arrival_match_frames=consecutive)
                return {'ok':True,'route':route,'route_steps':len(steps),'motion_seen':motion_seen,'end_scene_mae':round(float(mae),2),'end_scene_soft_match':True,'arrival_match_frames':consecutive,'samples':samples[-8:],'arrival_samples':arrival_samples[-8:]}
            time.sleep(.10)
        self._domain('NAV_DESTINATION_NOT_CONFIRMED',route=route,target=str(which).upper(),best_mae=round(float(best_mae),2),threshold=soft,motion_seen=motion_seen)
        return {'ok':False,'reason':'NAV_DESTINATION_NOT_CONFIRMED','route':route,'route_steps':len(steps),'motion_seen':motion_seen,'best_end_scene_mae':round(float(best_mae),2),'threshold':soft,'samples':samples[-8:],'arrival_samples':arrival_samples[-8:]}

    def test_route(self,hwnd,route):
        if self.is_running():return {'ok':False,'reason':'AUTOBOSS_RUNNING'}
        route=self._route_name(route)
        if not route:return {'ok':False,'reason':'NAV_ROUTE_INVALID'}
        if not self._route_ready(route):return {'ok':False,'reason':'NAV_ROUTE_NOT_CONFIGURED','route':route}
        target='B' if route=='A_TO_B' else 'A'
        sid=self.session_id
        if not sid:
            self.session_id='ABR-'+uuid.uuid4().hex[:10].upper(); self._cancel_generation=self.cancellation.reset(); self.input_dispatcher.reset()
        try:return self._navigate_route(int(hwnd),route,target)
        finally:
            if sid is None:self.session_id=None; self.cancellation.cancel('TEST_END')

    def _point_target(self,which):
        rec=(self.config.get('points') or {}).get(str(which).upper()) or {}; p=rec.get('client_point') or []
        if len(p)!=2:return None
        return InteractionTarget.client('BOSS_POINT_'+str(which).upper(),[int(p[0]),int(p[1])],8,rec.get('client_size') or [])

    def _focus_client(self,hwnd):
        wr=self.core._window_rect(int(hwnd)); co=self.core._client_origin_screen(int(hwnd))
        if not wr or not co:return {'ok':False,'reason':'WINDOW_GEOMETRY_FAILED'}
        left,top,right,bottom=[int(x) for x in wr]; client_x,client_y=[int(x) for x in co]; caption_h=client_y-top
        if caption_h<8:return {'ok':False,'reason':'FOCUS_CLICK_UNAVAILABLE'}
        x=left+max(70,min(220,(right-left)//3)); x=min(x,right-150); y=top+max(4,min(caption_h-3,caption_h//2))
        r=self.input_dispatcher.click(int(hwnd),InteractionTarget.screen('CLIENT_FOCUS',[x,y],8),f'{self.session_id}:FOCUS','AUTOBOSS_CLIENT_FOCUS',require_foreground=False)
        if not r.get('ok'):return r
        fg=int(self.core.user32_bridge.GetForegroundWindow() or 0)
        return {'ok':fg==int(hwnd),'foreground_hwnd':fg}

    def _log_container_resolution(self,r,context):
        ev=dict((r.evidence or {}));
        self.last_container_resolution={'ok':bool(r.ok),'reason':r.reason,'confidence':float(r.confidence or 0.0),'context':str(context),'assignment':ev.get('assignment'),'player_candidate_id':ev.get('player_candidate_id'),'storage_candidate_id':ev.get('storage_candidate_id'),'pair_margin':ev.get('pair_margin'),'title_ocr_used':False,'left_right_hardcoded':False}
        for c in ev.get('candidates') or []:
            self._domain('CONTAINER_CANDIDATE',context=context,candidate=c)
        for rank in ev.get('pair_ranked') or []:
            self._domain('CONTAINER_PAIR_SCORE',context=context,rank=rank)
        if r.ok:
            self._domain('CONTAINER_RESOLVED',context=context,player_candidate_id=ev.get('player_candidate_id'),storage_candidate_id=ev.get('storage_candidate_id'),confidence=r.confidence,assignment=ev.get('assignment'))
        else:
            self._domain('CONTAINER_OWNER_AMBIGUOUS' if r.reason=='CONTAINER_OWNER_AMBIGUOUS' else 'CONTAINER_RESOLUTION_NOT_READY',context=context,reason=r.reason,evidence=ev)

    def _focus_game_client_for_inventory_hotkey(self,hwnd,context='PLAYER_BAG'):
        """Give the JX1 child real mouse focus before Q/F4.

        On the user's client, SetForegroundWindow alone is insufficient: Q/F4 is
        consumed only after a real click inside the game client. The click is
        placed in the top HUD strip, outside the navigable world field.
        """
        if not self.is_running() and not self._input_token_valid():
            # Guided learning/test commands run outside a Boss session. A previous
            # USER STOP must not leave their one safe focus click permanently cancelled.
            self._cancel_generation=self.cancellation.reset(); self.input_dispatcher.reset()
        img=self.core.capture_client(int(hwnd))
        if img is None:return {'ok':False,'reason':'PLAYER_BAG_FOCUS_CAPTURE_FAILED'}
        w,h=int(img.width),int(img.height)
        x=max(120,min(w-180,int(round(w*0.50))))
        y=max(6,min(18,int(round(h*0.018))))
        action_id=f'{self.session_id or "SETUP"}:BAGFOCUS:{str(context)}:{self.ledger.last_seq+1}:{time.monotonic_ns()}'
        target=InteractionTarget.client('JX1_INVENTORY_FOCUS_HUD',[x,y],6,[w,h])
        r=self.input_dispatcher.click(int(hwnd),target,action_id,'AUTOBOSS_PLAYER_BAG_FOCUS',require_foreground=True)
        self._bag_focus_last_click=time.monotonic(); self._bag_focus_click_count+=1
        self._domain('PLAYER_BAG_CLIENT_FOCUS_CLICK',context=str(context),ok=bool(r.get('ok')),
                     client_point=[x,y],foreground_hwnd=r.get('foreground_hwnd'),click_count=self._bag_focus_click_count)
        if not r.get('ok'):return {'ok':False,'reason':'PLAYER_BAG_FOCUS_CLICK_FAILED','detail':r}
        time.sleep(BAG_FOCUS_CONFIRM_SEC)
        fg=int(self.core.user32_bridge.GetForegroundWindow() or 0)
        if fg!=int(hwnd):
            return {'ok':False,'reason':'PLAYER_BAG_FOCUS_NOT_CONFIRMED','foreground_hwnd':fg,'expected_hwnd':int(hwnd)}
        return {'ok':True,'client_point':[x,y],'foreground_hwnd':fg}

    def _send_inventory_hotkey_focused_once(self,hwnd,context='PLAYER_BAG'):
        focus=self._focus_game_client_for_inventory_hotkey(int(hwnd),context)
        if not focus.get('ok'):return focus
        key=self.api.get_inventory_hotkey()
        sent=self.api.send_client_key_once(int(hwnd),key,'Foreground')
        self._domain('PLAYER_BAG_HOTKEY_SENT_AFTER_CLIENT_CLICK',context=str(context),hotkey=key,
                     ok=bool(sent.get('ok')),responded=bool(sent.get('responded')),
                     used_mode=sent.get('used_mode'),attempt_count=sent.get('attempt_count'))
        if not sent.get('ok'):
            return {'ok':False,'reason':'PLAYER_BAG_REOPEN_INPUT_FAILED','detail':sent,'focus':focus}
        return {'ok':True,'hotkey':key,'input':sent,'focus':focus}

    def _probe_player_bag_presence(self,hwnd,context='PLAYER_BAG_PRESENCE'):
        """Resolve BAG OPEN/CLOSED independently from destructive owner actions.

        V1.5.6 gives presence one authority:
          1) learned PLAYER_BAG geometry/profile match when available;
          2) canonical right-side 6x10 lattice fallback;
          3) only if BOTH fail do we report the bag region absent.

        Crucially, the Final6 reader no longer has permission to toggle Q/F4, so a
        positive presence result cannot be immediately undone by a second owner.
        """
        img=self.core.capture_client(int(hwnd))
        if img is None:
            return {'ok':False,'present':False,'reason':'PLAYER_BAG_PRESENCE_CAPTURE_FAILED'}

        # Profile-aware presence path. This is not pair resolution and does not need
        # Storage. It answers only: "is the learned main bag lattice visible now?"
        profile=((self.config.get('container_profiles') or {}).get(CONTAINER_PLAYER) or {})
        if profile:
            try:
                det=detect_jx1_container_candidates(img)
                ranked=[]
                for c in det.get('candidates') or []:
                    score=float(score_jx1_container_profile(c,profile) or 0.0)
                    quality=float(c.get('candidate_quality') or 0.0)
                    ranked.append((score,quality,c))
                ranked.sort(key=lambda x:(x[0],x[1]),reverse=True)
                if ranked and ranked[0][0]>=0.56 and ranked[0][1]>=0.48:
                    score,quality,c=ranked[0]
                    xs=[int(x) for x in (c.get('x_lines') or [])]; ys=[int(y) for y in (c.get('y_lines') or [])]
                    if len(xs)==7 and len(ys)==11:
                        g={'ok':True,'kind':CONTAINER_PLAYER,'container_id':CONTAINER_PLAYER,
                           'x_lines':xs,'y_lines':ys,'cols':6,'rows':10,
                           'roi':list(c.get('grid_rect') or [xs[0],ys[0],xs[-1],ys[-1]]),
                           'grid_rect':list(c.get('grid_rect') or [xs[0],ys[0],xs[-1],ys[-1]]),
                           'panel_rect':list(c.get('panel_rect') or []),
                           'owner_authority':'PLAYER_BAG_PROFILE_PRESENCE',
                           'owner_confidence':round(score,4)}
                        snap=self.core.snapshot_inventory(img,g)
                        if snap.get('ok'):
                            snap['container_id']=CONTAINER_PLAYER
                            self._bag_grid=g; self._bag_snapshot=snap; self._bag_unresolved_streak=0; self._bag_live_scan_last_ok=time.monotonic()
                            self._domain('PLAYER_BAG_PRESENCE_CONFIRMED',context=str(context),presence_truth='LEARNED_PLAYER_BAG_PROFILE',confidence=round(score,4),candidate_quality=round(quality,4),grid_rect=g.get('grid_rect'))
                            return {'ok':True,'present':True,'image':img,'grid':g,'snapshot':snap,'owner_mode':'PROFILE_PRESENCE','presence_truth':'GRID_VISIBLE'}
            except Exception as e:
                self._domain('PLAYER_BAG_PROFILE_PRESENCE_PROBE_FAILED',context=str(context),error_type=type(e).__name__,error=str(e))

        # Canonical main-bag lattice remains the no-profile/default recovery truth.
        shared=detect_inventory_grid(img)
        if shared.get('ok'):
            g=dict(shared); g['container_id']=CONTAINER_PLAYER; g['owner_authority']='CANONICAL_PLAYER_BAG_LATTICE_PRESENCE'
            snap=self.core.snapshot_inventory(img,g)
            if snap.get('ok'):
                snap['container_id']=CONTAINER_PLAYER
                self._bag_grid=g; self._bag_snapshot=snap; self._bag_unresolved_streak=0; self._bag_live_scan_last_ok=time.monotonic()
                self._domain('PLAYER_BAG_PRESENCE_CONFIRMED',context=str(context),presence_truth='CANONICAL_6X10_LATTICE',confidence=shared.get('confidence'),grid_rect=shared.get('grid_rect'))
                return {'ok':True,'present':True,'image':img,'grid':g,'snapshot':snap,'owner_mode':'CANONICAL_LATTICE_PRESENCE','presence_truth':'GRID_VISIBLE'}

        # No learned/canonical Player-Bag lattice in this frame. Only absence is
        # reported; _ensure_player_bag_open_live confirms a second frame before Q/F4.
        self._domain('PLAYER_BAG_EXPECTED_REGION_EMPTY',context=str(context),presence_truth='NO_PLAYER_BAG_LATTICE',detector_reason=shared.get('reason'),confidence=shared.get('confidence'))
        return {'ok':True,'present':False,'image':img,'reason':'PLAYER_BAG_GRID_ABSENT','presence_truth':'EXPECTED_REGION_EMPTY'}

    def _capture_player_bag(self,hwnd,try_open=True):
        """Capture PLAYER_BAG with an owner-aware resolver first, then a KEEP-mode
        runtime fallback to the proven shared inventory detector.

        V1.5.2 deliberately makes manual Player-Bag profile learning optional for
        KEEP mode.  Storage is kept closed during the Boss loop, so a verified
        shared 6x10 inventory grid can safely serve as PLAYER_BAG if the dedicated
        geometry resolver is temporarily uncertain.  STORE mode still requires
        explicit dual-container ownership.
        """
        img=self.core.capture_client(int(hwnd))
        r=self.container_resolver.resolve(img,require_storage=False) if img is not None else ContainerResolution(False,reason='CAPTURE_FAILED')
        opened=None
        if not r.ok and try_open:
            # Fast shared path first; it verifies an existing grid and only toggles
            # Q/F4 after foreground evidence says the grid is absent.
            fn=getattr(self.api,'_capture_inventory_loop_fast',None)
            opened=fn(int(hwnd),try_open=True) if callable(fn) else self.api._capture_inventory_ready(int(hwnd),try_open=True)
            if opened.get('ok'):
                img=opened.get('image') or self.core.capture_client(int(hwnd))
                r=self.container_resolver.resolve(img,require_storage=False) if img is not None else ContainerResolution(False,reason='CAPTURE_FAILED')
        self._log_container_resolution(r,'PLAYER_BAG_CAPTURE')
        if r.ok and r.player_grid:
            g=dict(r.player_grid); g['container_id']=CONTAINER_PLAYER
            snap=self.core.snapshot_inventory(img,g)
            if not snap.get('ok'):return {'ok':False,'reason':'PLAYER_BAG_SNAPSHOT_FAILED','detail':snap}
            snap['container_id']=CONTAINER_PLAYER; self._bag_grid=g; self._bag_snapshot=snap; self._bag_unresolved_streak=0; self._bag_live_scan_last_ok=time.monotonic()
            return {'ok':True,'image':img,'grid':g,'snapshot':snap,'owner_resolution':r,'opened':bool((opened or {}).get('opened')),'owner_mode':'GEOMETRY_PROFILE'}

        # KEEP-mode self-healing fallback: the small Storage panel is not used by
        # this mode, and the shared detector is already the canonical Auto Pro
        # detector for the player's main 6x10 bag.  Do not use this fallback for
        # STORE where two container owners must remain explicit.
        if str(self.config.get('mode') or 'KEEP').upper()=='KEEP':
            if not opened:
                fn=getattr(self.api,'_capture_inventory_loop_fast',None)
                opened=fn(int(hwnd),try_open=bool(try_open)) if callable(fn) else self.api._capture_inventory_ready(int(hwnd),try_open=bool(try_open))
            if opened and opened.get('ok') and opened.get('grid'):
                img=opened.get('image') or img
                g=dict(opened.get('grid') or {}); g['container_id']=CONTAINER_PLAYER; g['owner_authority']='SHARED_MAIN_BAG_RUNTIME_FALLBACK'
                snap=self.core.snapshot_inventory(img,g) if img is not None else {'ok':False}
                if snap.get('ok'):
                    snap['container_id']=CONTAINER_PLAYER; self._bag_grid=g; self._bag_snapshot=snap; self._bag_unresolved_streak=0; self._bag_live_scan_last_ok=time.monotonic()
                    self._domain('PLAYER_BAG_RUNTIME_SHARED_GRID_FALLBACK',capture_mode=opened.get('capture_mode'),hotkey=self.api.get_inventory_hotkey(),profile_present=bool((self.config.get('container_profiles') or {}).get(CONTAINER_PLAYER)))
                    return {'ok':True,'image':img,'grid':g,'snapshot':snap,'owner_resolution':r,'opened':bool(opened.get('opened')),'owner_mode':'SHARED_MAIN_BAG_RUNTIME_FALLBACK'}
        self._bag_unresolved_streak+=1
        return {'ok':False,'reason':'PLAYER_BAG_OWNER_UNRESOLVED' if r.reason in ('CONTAINER_OWNER_AMBIGUOUS','CONTAINER_NOT_PRESENT','STORAGE_NOT_PRESENT') else r.reason,'evidence':r.evidence}

    def _ensure_player_bag_open_live(self,hwnd,context='LIVE_SCAN'):
        """Self-heal Player Bag visibility without producing false owner errors.

        V1.5.5 rootfix:
        1) Detect the canonical Player-Bag lattice directly from the JX1 frame.
        2) If visible, use it immediately even when geometry/profile owner scoring is
           uncertain.
        3) Only when *two consecutive* frames show no canonical bag lattice may the
           runtime click the real JX1 client and send Q/F4 once.
        4) Q/F4 success is confirmed by the bag lattice reappearing, not by owner text
           or a profile score.
        """
        first=self._probe_player_bag_presence(int(hwnd),str(context))
        if first.get('present'):
            return first
        if not first.get('ok'):
            return first

        if self._cancelled():
            return {'ok':False,'reason':'USER_STOP'}
        time.sleep(BAG_PRESENCE_DOUBLECHECK_SEC)
        second=self._probe_player_bag_presence(int(hwnd),str(context)+'_CONFIRM_ABSENCE')
        if second.get('present'):
            return second
        if not second.get('ok'):
            return second

        self._bag_unresolved_streak=max(2,int(self._bag_unresolved_streak or 0)+1)
        now=time.monotonic()
        if now-float(self._bag_reopen_last_sent or 0.0)<BAG_REOPEN_COOLDOWN_SEC:
            return {'ok':False,'reason':'PLAYER_BAG_OPEN_COOLDOWN','streak':self._bag_unresolved_streak,'recoverable':True}

        # Absence has now been proven independently of owner/profile resolution.
        # Give the client a real click, then toggle Q/F4 exactly once.
        self._domain('PLAYER_BAG_ABSENCE_CONFIRMED_OPEN_REQUIRED',context=str(context),absence_samples=2,action='FOCUS_CLIENT_THEN_QF4_ONCE')
        sent=self._send_inventory_hotkey_focused_once(int(hwnd),str(context))
        self._bag_reopen_last_sent=time.monotonic()
        if not sent.get('ok'):
            return sent

        end=time.monotonic()+BAG_OPEN_CONFIRM_SEC
        while time.monotonic()<end:
            if self._cancelled():
                return {'ok':False,'reason':'USER_STOP'}
            probe=self._probe_player_bag_presence(int(hwnd),str(context)+'_AFTER_QF4')
            if probe.get('present'):
                self._bag_unresolved_streak=0; self._bag_live_scan_last_ok=time.monotonic()
                self._domain('PLAYER_BAG_AUTO_REOPEN_CONFIRMED',context=str(context),hotkey=sent.get('hotkey'),owner_mode=probe.get('owner_mode'),presence_truth=probe.get('presence_truth'))
                return probe
            time.sleep(.08)

        # Important: this is an input/open-confirmation problem, NOT an owner problem.
        self._domain('PLAYER_BAG_OPEN_NOT_CONFIRMED',context=str(context),hotkey=sent.get('hotkey'),streak=self._bag_unresolved_streak)
        return {'ok':False,'reason':'PLAYER_BAG_OPEN_NOT_CONFIRMED','streak':self._bag_unresolved_streak,'recoverable':True}

    def _close_player_bag_if_open(self,hwnd):
        """Close Player Bag exactly once when it is confidently visible.

        V1.4 policy: the bag must be closed while Boss combat/auto-loot runs, but
        close *confirmation* is not allowed to kill the whole Boss session.  The
        hotkey is a toggle, so a second blind retry could reopen the bag.  We send
        the configured hotkey once, probe briefly, then continue with a structured
        non-blocking warning if the visual resolver still sees the panel.
        """
        img=self.core.capture_client(int(hwnd))
        if img is None:return {'ok':False,'reason':'CAPTURE_FAILED'}
        r=self.container_resolver.resolve(img,require_storage=False)
        if not r.ok or not r.player_grid:
            if r.reason in ('CONTAINER_NOT_PRESENT','STORAGE_NOT_PRESENT','PLAYER_BAG_PROFILE_MATCH_AMBIGUOUS'):
                return {'ok':True,'already_closed':True,'confirmed':True}
            # During a close request, unresolved owner is safer to treat as already
            # not-confirmed-visible than to fire an extra toggle.
            self._domain('PLAYER_BAG_CLOSE_VISIBILITY_UNRESOLVED',reason=r.reason,evidence=r.evidence)
            return {'ok':True,'already_closed':True,'confirmed':False,'warning':'PLAYER_BAG_VISIBILITY_UNRESOLVED'}
        key=self.api.get_inventory_hotkey(); sent=self._send_inventory_hotkey_focused_once(int(hwnd),'PLAYER_BAG_CLOSE')
        if not sent.get('ok'):return {'ok':False,'reason':'PLAYER_BAG_CLOSE_INPUT_FAILED','detail':sent}
        self._domain('PLAYER_BAG_CLOSE_SENT',hotkey=key,policy='EXACTLY_ONCE_NO_RETOGGLE')
        deadline=time.monotonic()+0.65
        while time.monotonic()<deadline:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
            cur=self.core.capture_client(int(hwnd)); rr=self.container_resolver.resolve(cur,require_storage=False) if cur is not None else ContainerResolution(False,reason='CAPTURE_FAILED')
            if not rr.ok or not rr.player_grid:
                self._domain('PLAYER_BAG_CLOSE_CONFIRMED',hotkey=key)
                return {'ok':True,'closed':True,'confirmed':True,'hotkey':key}
            time.sleep(.05)
        # IMPORTANT: do NOT send the toggle again.  A late first toggle could have
        # succeeded and a retry would reopen the bag.  Continue the Boss flow and
        # keep this as telemetry only.
        self._domain('PLAYER_BAG_CLOSE_UNCONFIRMED_NONBLOCKING',hotkey=key)
        return {'ok':True,'closed':False,'confirmed':False,'hotkey':key,'warning':'PLAYER_BAG_CLOSE_UNCONFIRMED_NONBLOCKING'}

    def _close_storage_if_open_once(self,hwnd):
        """Close only the small personal-storage panel when it is actually open.

        Runtime Boss combat must never require both 'Hành Trang' windows to stay
        visible.  Storage is setup/STORE-only UI.  Reuse the proven owner-aware
        storage close primitive and never click a guessed footer coordinate.
        """
        fn=getattr(self.core,'_try_personal_storage_close_owner_once_v1211',None)
        if not callable(fn):
            return {'ok':True,'closed':False,'confirmed':False,'warning':'STORAGE_CLOSE_HELPER_UNAVAILABLE'}
        img=self.core.capture_client(int(hwnd))
        try:
            probe=self.core.detect_personal_storage_grid(img) if img is not None and hasattr(self.core,'detect_personal_storage_grid') else {'ok':False}
        except Exception:
            probe={'ok':False}
        if not isinstance(probe,dict) or not probe.get('ok'):
            return {'ok':True,'already_closed':True,'confirmed':True}
        out=fn(int(hwnd),img,self.api._cfg.get('input_mode','Auto'),proof_dir=None)
        if out.get('ok') and (out.get('storage_closed_confirmed') or out.get('closed')):
            self._domain('STORAGE_CLOSE_CONFIRMED_FOR_BOSS_FIELD',close_owner=out.get('close_owner'))
            return {'ok':True,'closed':True,'confirmed':True,'detail':out}
        self._domain('STORAGE_CLOSE_NOT_CONFIRMED_FOR_BOSS_FIELD',detail={k:v for k,v in out.items() if k!='image'})
        return {'ok':False,'reason':out.get('reason') or 'STORAGE_CLOSE_NOT_CONFIRMED','detail':out}

    @staticmethod
    def _free_fit(snapshot,footprint):return StoragePlacementPlanner.find_fit(snapshot,list(footprint)) is not None

    def _capacity_status(self,snapshot):
        if not snapshot or not snapshot.get('ok'):return {'status':'CAPACITY_UNCERTAIN','reason':'SNAPSHOT_NOT_READY'}
        free=int(snapshot.get('free_count') or 0)
        if free<=0:return {'status':'FULL','free_cells':free}
        fits={f'{w}x{h}':self._free_fit(snapshot,(w,h)) for w,h in SUPPORTED_FOOTPRINTS}
        max_safe=bool(fits.get('1x4') or fits.get('4x1') or fits.get('2x2'))
        if max_safe:return {'status':'NOT_FULL','free_cells':free,'fits':fits}
        if any(fits.values()):return {'status':'CAPACITY_UNCERTAIN','free_cells':free,'fits':fits}
        return {'status':'FULL','free_cells':free,'fits':fits}

    def _validate_start(self,hwnd):
        if not hwnd or not self.core.window_exists(int(hwnd)):return {'ok':False,'reason':'GAME_CLIENT_NOT_FOUND'}
        if self._other_automation_busy():return {'ok':False,'reason':'ACTIVE_AUTOMATION_MODE_'+str(self._other_automation_busy())}
        pts=self.config.get('points') or {}
        routes_ready=bool(self._route_ready('A_TO_B') and self._route_ready('B_TO_A'))
        missing=[x for x in ('A','B') if len((pts.get(x) or {}).get('client_point') or [])!=2]
        if missing and not routes_ready:return {'ok':False,'reason':'AUTOBOSS_NAV_SETUP_INCOMPLETE','missing_points':missing,'routes_ready':routes_ready,'message':'Cần ghi đủ Điểm A/B cho đường ngắn hoặc ghi đủ hai tuyến A→B và B→A cho đường xa.'}
        if not self.config.get('ingame_auto_setup_confirmed'):return {'ok':False,'reason':'INGAME_AUTO_SETUP_NOT_CONFIRMED'}
        if str(self.config.get('boss_key'))!='1':return {'ok':False,'reason':'BOSS_KEY_MUST_BE_1'}
        try:
            filter_guard=self.api.filter_runtime_guard(
                'AUTO_BOSS',
                selected_profile_ids=self.config.get('filter_profile_ids') or [1,2,3,4],
                require_enabled_rules=True,
            )
        except Exception as e:
            filter_guard={'ok':False,'reason':'AUTO_BOSS_FILTER_PREFLIGHT_EXCEPTION','error':str(e)}
        if not filter_guard.get('ok'):
            return {'ok':False,'reason':filter_guard.get('reason','AUTO_BOSS_FILTER_STARTUP_FAILED'),
                    'startup_contract':filter_guard,'no_input_sent':True}
        profiles=self.config.get('container_profiles') or {}; setup=self._container_setup()
        # KEEP mode can self-detect/open the canonical Player Bag at runtime; manual
        # geometry learning is optional. STORE still requires explicit two-owner truth.
        if str(self.config.get('mode')).upper()=='STORE':
            missing_profiles=[k for k in (CONTAINER_PLAYER,CONTAINER_STORAGE) if not profiles.get(k)]
            if missing_profiles:return {'ok':False,'reason':'CONTAINER_SETUP_REQUIRED','missing':missing_profiles,'message':'Chưa quét Hành Trang và Rương. Hãy thực hiện bước thiết lập Container.'}
            if not bool(setup.get('pair_test_pass')):
                return {'ok':False,'reason':'CONTAINER_PAIR_TEST_REQUIRED','message':'Hãy mở cả hai cửa sổ và bấm KIỂM TRA PHÂN BIỆT trước khi chạy STORE.'}
        return {'ok':True}

    def start(self,hwnd,test_one_cycle=False):
        hwnd=int(hwnd or 0)
        with self.lock:
            if self.is_running():return {'ok':False,'reason':'AUTOBOSS_ALREADY_RUNNING'}
            v=self._validate_start(hwnd)
            if not v.get('ok'):return v
            self.session_id='ABS-'+uuid.uuid4().hex[:12].upper(); self.session_generation+=1; self.cycle_number=0; self.active_cycle=None
            self._cancel_generation=self.cancellation.reset(); self.ledger.reset(); self.input_dispatcher.reset(); self.arm.reset(self.session_id)
            self.running=True; self.last_error=None; self.last_loot_queue=[]; self.counters={'kept':0,'stored':0,'dropped':0,'cycles':0}
            self.filter_adapter.compile_profiles(self.config.get('filter_profile_ids') or [1,2,3,4])
            self._set_running_flag(True); self._set_state('SESSION_START',hwnd=hwnd,test_one_cycle=bool(test_one_cycle))
            self._domain('AUTOBOSS_SESSION_START',once_key=f'{self.session_id}:START',hwnd=hwnd,mode=self.config.get('mode'),build_id=BUILD_ID)
            self.worker=threading.Thread(target=self._run,args=(hwnd,bool(test_one_cycle)),daemon=True,name='AutoBossV1Session')
            self.worker.start(); return {'ok':True,'session_id':self.session_id,'state':self.state,'engine':'AUTOBOSS_V1_5_3_CLIENT_FOCUS_LOOT_TRUTH_ROOTFIX'}

    def stop(self,reason='USER_STOP'):
        self.cancellation.cancel(str(reason or 'USER_STOP'))
        self._domain('USER_STOP_REQUESTED',once_key=f'{self.session_id}:STOP',reason=str(reason or 'USER_STOP'))
        self.state='STOPPING'
        # Keep boss ownership/module flag until the worker exits so AutoRoll/AutoChest
        # cannot start while a cancelled atomic action is still unwinding.
        return {'ok':True,'running':self.is_running(),'state':self.state,'ctrl_f_retoggled':False}

    def _new_cycle(self):
        self.cycle_number+=1
        self.active_cycle=BossCycleContext(self.cycle_number,f'BC-{self.cycle_number:06d}',self.session_generation)
        self._set_state('BOSS_CYCLE_BEGIN',cycle=self.cycle_number); self._domain('BOSS_CYCLE_BEGIN',once_key=f'{self.session_id}:{self.active_cycle.cycle_id}:BEGIN',cycle=self.cycle_number)
        return self.active_cycle

    def _dispatch_key1_once(self,hwnd,cycle):
        if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
        if int(cycle.generation)!=int(self.session_generation):return {'ok':False,'reason':'STALE_CALLBACK_DROPPED'}
        if cycle.key1_dispatched:return {'ok':False,'reason':'DUPLICATE_KEY1_BLOCKED'}
        r=self.api.send_client_key_once(int(hwnd),'1',self.api._cfg.get('input_mode','Auto'))
        if not r.get('ok'):return {'ok':False,'reason':'KEY1_DISPATCH_FAILED','detail':r}
        cycle.key1_dispatched=True; self._domain('KEY1_DISPATCHED',once_key=f'{cycle.cycle_id}:KEY1',used_mode=r.get('used_mode'))
        return {'ok':True}

    def _navigate(self,hwnd,which):
        which=str(which).upper(); route=self._route_for_target(which)
        if self._route_ready(route):
            return self._navigate_route(int(hwnd),route,which)
        target=self._point_target(which)
        if target is None:return {'ok':False,'reason':'NAVIGATION_POINT_NOT_CONFIGURED','route_fallback_missing':route}
        self._set_state('NAVIGATE_'+which,navigation_mode='SINGLE_CLICK_POINT_FALLBACK')
        before=self.core.capture_client(int(hwnd)); before_sig=_scene_signature(before)
        p=list(target.center); img_now=before or self.core.capture_client(int(hwnd))
        if img_now is None:return {'ok':False,'reason':'CAPTURE_FAILED'}
        action_base=f'{self.session_id}:{getattr(self.active_cycle,"cycle_id","NO")}:NAV:{which}:{self.ledger.last_seq+1}'
        r=self._nav_click_with_auto_fallback(int(hwnd),int(p[0]),int(p[1]),int(img_now.width),int(img_now.height),action_base,f'NAVIGATE_{which}',before_sig)
        if not r.get('ok'):return {'ok':False,'reason':r.get('reason') or 'NAVIGATION_INPUT_FAILED','detail':r}
        rec=(self.config.get('points') or {}).get(which) or {}; target_sig=rec.get('scene_signature') or []
        deadline=time.monotonic()+float(self.config.get('nav_timeout_sec') or NAV_TIMEOUT_SEC); stable=0; moved=False; last_sig=before_sig; samples=[]
        while time.monotonic()<deadline:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
            img=self.core.capture_client(int(hwnd)); sig=_scene_signature(img); motion=_sig_mae(last_sig,sig) if last_sig and sig else 255.0; target_mae=_sig_mae(target_sig,sig) if target_sig and sig else 255.0
            moved=moved or motion>=2.5
            is_stable=motion<=1.8
            stable=stable+1 if is_stable else 0; samples.append({'motion_mae':round(motion,2),'target_mae':round(target_mae,2),'stable':stable})
            # V1.5: movement settling is not destination truth.  Require the
            # recorded destination scene itself to match on stable frames.
            if target_sig and target_mae<=16.0 and stable>=2:
                self._set_state('VERIFY_'+which); self._domain('POINT_'+which+'_CONFIRMED',once_key=f'{getattr(self.active_cycle,"cycle_id","SESSION")}:{which}:CONFIRMED',target_mae=target_mae,motion_seen=moved,arrival_evidence='POINT_SCENE_SIGNATURE')
                return {'ok':True,'samples':samples[-8:],'target_mae':target_mae,'motion_seen':moved,'arrival_evidence':'POINT_SCENE_SIGNATURE'}
            last_sig=sig; time.sleep(.12)
        return {'ok':False,'reason':'NAV_DESTINATION_NOT_CONFIRMED','samples':samples[-8:]}

    def _wait_boss_and_autoloot_live_bag(self,hwnd):
        """Keep PLAYER_BAG open and accumulate each Boss pickup as a distinct event.

        V1.5.6 root cause fix:
        V1.5.5 always compared every frame to one fixed pre-Boss baseline. If item B
        landed directly beside already-detected item A, the changed cells became one
        connected A+B component. `latest` was then replaced by that merged component,
        so the Final6 queue could contain only one physical target.

        This version keeps a rolling scan baseline AND a persistent discovered list.
        Confirmed cells are consumed once; later adjacent pickups are residualized
        against those cells and become their own queue candidates.
        """
        baseline=self.bag_registry.baseline
        if baseline is None:return {'ok':False,'reason':'PLAYER_BAG_BASELINE_MISSING'}
        scan_baseline=copy.deepcopy(baseline)
        wait_sec=max(3.0,min(120.0,float(self.config.get('boss_wait_sec') or BOSS_LIVE_BAG_WAIT_SEC)))
        self._set_state('WAIT_BOSS_LOOT_LIVE_BAG',wait_sec=wait_sec,bag_policy='OPEN_DURING_BOSS_CONTINUOUS_SCAN')
        self._domain('BOSS_LIVE_BAG_SCAN_BEGIN',wait_sec=wait_sec,bag_policy='OPEN_DURING_BOSS_CONTINUOUS_SCAN',hotkey=self.api.get_inventory_hotkey())
        start=time.monotonic(); next_tick=1; last_snapshot=None; last_grid=None; last_diff=None
        tracks={}; discovered=[]; discovered_cells=set(); discovered_keys=set()
        settle=max(.25,min(3.0,float(self.config.get('loot_settle_sec') or LOOT_SETTLE_SEC)))
        while True:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
            elapsed=time.monotonic()-start
            cap=self._ensure_player_bag_open_live(hwnd,'BOSS_WAIT')
            if cap.get('ok'):
                snap=cap['snapshot']; last_snapshot=snap; last_grid=cap['grid']
                occ=self._autoboss_occupancy_delta_candidates(scan_baseline,snap)
                sig=self._autoboss_signature_delta_candidates(scan_baseline,snap)
                diff=self.core.diff_snapshots(scan_baseline,snap); last_diff=diff
                merged={}
                for c in list(sig)+list(occ):
                    key=(tuple(c.get('anchor') or []),tuple(c.get('footprint') or []),tuple(sorted(_candidate_cell_set(c))))
                    if len(key[0])!=2:continue
                    old=merged.get(key)
                    if old is None or str(c.get('detection_mode','')).startswith('AUTOBOSS_OCCUPANCY'):
                        merged[key]=c
                now=time.monotonic(); seen=set(merged)
                for key,c in merged.items():
                    t=tracks.get(key) or {'first':now,'last':0.0,'hits':0,'candidate':c}
                    if now-float(t.get('last') or 0.0)<=.55:t['hits']=int(t.get('hits') or 0)+1
                    else:t['hits']=1; t['first']=now
                    t['last']=now; t['candidate']=c; tracks[key]=t
                for key in list(tracks):
                    if key not in seen and now-float(tracks[key].get('last') or 0.0)>.65:
                        tracks.pop(key,None)

                newly_confirmed=[]
                for key,t in list(tracks.items()):
                    age=now-float(t.get('first') or now)
                    if int(t.get('hits') or 0)<BAG_SIG_DELTA_PERSIST_HITS or age<BAG_SIG_DELTA_PERSIST_SEC:
                        continue
                    for residual in _split_residual_candidate(t['candidate'],discovered_cells):
                        rid=(tuple(residual.get('anchor') or []),tuple(residual.get('footprint') or []),tuple(sorted(_candidate_cell_set(residual))))
                        if rid in discovered_keys:continue
                        discovered_keys.add(rid); discovered.append(residual); newly_confirmed.append(residual)
                        discovered_cells.update(_candidate_cell_set(residual))
                    tracks.pop(key,None)

                if newly_confirmed:
                    # Consume the current visual state. The next pickup is compared
                    # against this state instead of the original pre-Boss image, so
                    # adjacency cannot absorb a previously confirmed item.
                    scan_baseline=copy.deepcopy(snap)
                    tracks.clear()
                    self._domain('BOSS_LIVE_BAG_NEW_LOOT_COMMITTED',new_count=len(newly_confirmed),total_discovered=len(discovered),elapsed_sec=round(elapsed,2),
                                 candidates=[{'anchor':c.get('anchor'),'footprint':c.get('footprint'),'cells':c.get('cells')} for c in newly_confirmed])
                if discovered:
                    self._domain('BOSS_LIVE_BAG_NEW_LOOT_DETECTED',candidate_count=len(discovered),elapsed_sec=round(elapsed,2),
                                 detection_modes=sorted({str(c.get('detection_mode')) for c in discovered}))
                self._bag_snapshot=snap; self._bag_grid=cap['grid']
            else:
                self._domain('BOSS_LIVE_BAG_SCAN_PROBE_MISS',reason=cap.get('reason'),elapsed_sec=round(elapsed,2))
            if elapsed>=wait_sec:break
            whole=int(elapsed)
            if whole>=next_tick:
                self._domain('BOSS_LIVE_BAG_SCAN_PROGRESS',elapsed_sec=round(elapsed,2),
                             remaining_sec=round(max(0.0,wait_sec-elapsed),2),candidate_count=len(discovered),
                             bag_visible=bool(cap.get('ok')),tracked_delta_count=len(tracks))
                next_tick=whole+1
            time.sleep(.14)

        # Edge recovery: preserve everything already confirmed, and append only the
        # residual cells that appeared after the latest rolling baseline.
        if last_snapshot is not None:
            final_occ=self._autoboss_occupancy_delta_candidates(scan_baseline,last_snapshot)
            final_sig=self._autoboss_signature_delta_candidates(scan_baseline,last_snapshot)
            for c in list(final_occ)+list(final_sig):
                for residual in _split_residual_candidate(c,discovered_cells):
                    rid=(tuple(residual.get('anchor') or []),tuple(residual.get('footprint') or []),tuple(sorted(_candidate_cell_set(residual))))
                    if rid in discovered_keys:continue
                    discovered_keys.add(rid); discovered.append(residual); discovered_cells.update(_candidate_cell_set(residual))
                    self._domain('BOSS_LIVE_BAG_FINAL_DELTA_RECOVERY_ITEM',anchor=residual.get('anchor'),footprint=residual.get('footprint'))
        self._domain('BOSS_LIVE_BAG_SCAN_COMPLETE',elapsed_sec=round(time.monotonic()-start,3),
                     candidate_count=len(discovered),bag_opened_during_wait=True,temporal_accumulation=True)
        return {'ok':True,'wait_sec':wait_sec,'bag_opened_during_wait':True,
                'candidates':discovered,'snapshot':last_snapshot,'grid':last_grid,'diff':last_diff}

    def _autoboss_occupancy_delta_candidates(self,before,after):
        """AutoBoss-local conservative fallback for obvious empty→occupied cells.

        Shared InventorySensor behavior is intentionally left untouched so AutoRoll
        and AutoChest cannot regress.  This fallback is only used after the normal
        shared diff returns no new candidates.
        """
        try:
            bmap={(int(c['row']),int(c['col'])):c for c in before.get('cells',[])}
            amap={(int(c['row']),int(c['col'])):c for c in after.get('cells',[])}
            cells=[k for k,a in amap.items() if k in bmap and (not bool(bmap[k].get('occupied'))) and bool(a.get('occupied'))]
            remaining=set(cells); groups=[]
            while remaining:
                seed=remaining.pop(); group={seed}; stack=[seed]
                while stack:
                    r,c=stack.pop()
                    for nb in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
                        if nb in remaining:
                            remaining.remove(nb); group.add(nb); stack.append(nb)
                groups.append(sorted(group))
            out=[]
            for i,g in enumerate(groups,1):
                rs=[r for r,c in g]; cs=[c for r,c in g]; r0,r1=min(rs),max(rs); c0,c1=min(cs),max(cs)
                fw,fh=c1-c0+1,r1-r0+1
                if len(g)>8 or fw>4 or fh>4:continue
                out.append({'candidate_id':i,'cells':[[r,c] for r,c in g],
                            'geometric_cells':[[rr,cc] for rr in range(r0,r1+1) for cc in range(c0,c1+1)],
                            'anchor':[r0,c0],'footprint':[fw,fh],'visual_cell_count':len(g),
                            'geometric_cell_count':int(fw*fh),'cell_count':int(fw*fh),'geometry_invariant_ok':True,
                            'mean_pixel_diff':0.0,'confidence':0.82,'detection_mode':'AUTOBOSS_OCCUPANCY_EMPTY_TO_OCCUPIED_FALLBACK'})
            return out
        except Exception as e:
            self._domain('AUTOBOSS_OCCUPANCY_FALLBACK_FAILED',error_type=type(e).__name__,error=str(e))
            return []

    def _autoboss_signature_delta_candidates(self,before,after):
        """Discover localized item insertion without trusting occupied flags.

        The semi-transparent Player Bag can make empty cells look occupied because
        terrain/VFX shines through. We instead look for compact, localized
        signature changes from the pre-Boss baseline. Multi-frame persistence in
        the caller filters transient combat VFX.
        """
        try:
            if not before or not after or not before.get('ok') or not after.get('ok'):return []
            bmap={(int(c['row']),int(c['col'])):c for c in before.get('cells',[])}
            amap={(int(c['row']),int(c['col'])):c for c in after.get('cells',[])}
            recs=[]
            for k,a in amap.items():
                b=bmap.get(k)
                if not b:continue
                d=_snapshot_sig_mae(b.get('_sig'),a.get('_sig'))
                recs.append((k,d,b,a))
            if not recs:return []
            vals=np.asarray([x[1] for x in recs],dtype=np.float32)
            med=float(np.median(vals)); mad=float(np.median(np.abs(vals-med)))
            threshold=max(float(BAG_SIG_DELTA_MIN_MAE),med+max(5.0,3.2*mad))
            cells=[]
            for k,d,b,a in recs:
                before_score=float(b.get('occupied_score') or 0.0)
                after_score=float(a.get('occupied_score') or 0.0)
                score_gain=after_score-before_score
                chrom_gain=float(a.get('colorbright') or 0.0)-float(b.get('colorbright') or 0.0)
                strong=bool(d>=threshold and (score_gain>=.05 or chrom_gain>=.012 or d>=threshold+7.0))
                if strong:cells.append(k)
            if not cells:return []
            remaining=set(cells); groups=[]
            while remaining:
                seed=remaining.pop(); group={seed}; stack=[seed]
                while stack:
                    r,c=stack.pop()
                    for nb in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
                        if nb in remaining:
                            remaining.remove(nb); group.add(nb); stack.append(nb)
                groups.append(sorted(group))
            out=[]; bykey={x[0]:x for x in recs}
            for i,g in enumerate(groups,1):
                rs=[r for r,c in g]; cs=[c for r,c in g]; r0,r1=min(rs),max(rs); c0,c1=min(cs),max(cs)
                fw,fh=c1-c0+1,r1-r0+1
                if len(g)>8 or fw>4 or fh>4:continue
                ds=[float(bykey[k][1]) for k in g if k in bykey]
                if not ds:continue
                out.append({'candidate_id':i,'cells':[[r,c] for r,c in g],
                            'geometric_cells':[[rr,cc] for rr in range(r0,r1+1) for cc in range(c0,c1+1)],
                            'anchor':[r0,c0],'footprint':[fw,fh],
                            'visual_cell_count':len(g),'geometric_cell_count':int(fw*fh),'cell_count':int(fw*fh),
                            'geometry_invariant_ok':True,'mean_pixel_diff':round(float(np.mean(ds)),3),
                            'confidence':round(min(.96,.66+.015*max(ds)+.035*len(g)),3),
                            'detection_mode':'AUTOBOSS_PERSISTENT_SIGNATURE_DELTA',
                            'signature_threshold':round(float(threshold),3),
                            'signature_median':round(float(med),3),'signature_mad':round(float(mad),3)})
            return out
        except Exception as e:
            self._domain('AUTOBOSS_SIGNATURE_DELTA_FAILED',error_type=type(e).__name__,error=str(e))
            return []

    def _autoboss_scene_independent_score_candidates(self,before,after):
        """First-cycle fallback when baseline was captured at Point A.

        JX1 inventory is semi-transparent, so raw per-cell pixel MAE across A->B
        is not authoritative.  This fallback uses only the current frame's
        item-likeness features on cells that were EMPTY in the pre-Boss baseline.
        It is deliberately AutoBoss-local; shared InventorySensor behavior stays
        byte-identical for AutoRoll/AutoChest.
        """
        try:
            bmap={(int(c['row']),int(c['col'])):c for c in before.get('cells',[])}
            amap={(int(c['row']),int(c['col'])):c for c in after.get('cells',[])}
            empty=[k for k,b in bmap.items() if not bool(b.get('occupied')) and k in amap]
            if not empty:return []
            scores=np.asarray([float(amap[k].get('occupied_score') or 0.0) for k in empty],dtype=np.float32)
            med=float(np.median(scores)) if scores.size else 0.0
            mad=float(np.median(np.abs(scores-med))) if scores.size else 0.0
            threshold=max(0.24,med+max(0.12,3.0*mad))
            cells=[]
            for k in empty:
                a=amap[k]; score=float(a.get('occupied_score') or 0.0)
                chrom=float(a.get('colorbright') or 0.0); mx=float(a.get('max90') or 0.0); br=float(a.get('bright') or 0.0)
                if bool(a.get('occupied')) or (score>=threshold and (chrom>=0.035 or mx>=0.055 or br>=0.035)):
                    cells.append(k)
            if not cells:return []
            remaining=set(cells); groups=[]
            while remaining:
                seed=remaining.pop(); group={seed}; stack=[seed]
                while stack:
                    r,c=stack.pop()
                    for nb in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
                        if nb in remaining:
                            remaining.remove(nb); group.add(nb); stack.append(nb)
                groups.append(sorted(group))
            out=[]
            for i,g in enumerate(groups,1):
                rs=[r for r,c in g]; cs=[c for r,c in g]; r0,r1=min(rs),max(rs); c0,c1=min(cs),max(cs)
                fw,fh=c1-c0+1,r1-r0+1
                if len(g)>8 or fw>4 or fh>4:continue
                conf=min(0.94,0.68+0.05*len(g)+0.10*max(float(amap[k].get('occupied_score') or 0.0) for k in g))
                out.append({'candidate_id':i,'cells':[[r,c] for r,c in g],
                            'geometric_cells':[[rr,cc] for rr in range(r0,r1+1) for cc in range(c0,c1+1)],
                            'anchor':[r0,c0],'footprint':[fw,fh],'visual_cell_count':len(g),
                            'geometric_cell_count':int(fw*fh),'cell_count':int(fw*fh),'geometry_invariant_ok':True,
                            'mean_pixel_diff':0.0,'confidence':round(float(conf),3),
                            'detection_mode':'AUTOBOSS_POINT_A_BASELINE_SCENE_INDEPENDENT_ITEM_SCORE'})
            self._domain('PLAYER_BAG_SCENE_INDEPENDENT_SCORE_SCAN',candidate_count=len(out),score_median=round(med,3),score_mad=round(mad,3),threshold=round(threshold,3))
            return out
        except Exception as e:
            self._domain('AUTOBOSS_SCENE_INDEPENDENT_SCORE_FALLBACK_FAILED',error_type=type(e).__name__,error=str(e))
            return []

    def _wait_point_b_loot_delta_stable(self,hwnd,initial_cap=None):
        """At Point B only: open Player Bag, resolve new loot and wait briefly
        for the full set of new item candidates to become stable.
        """
        if self.bag_registry.baseline is None:return {'ok':False,'reason':'PLAYER_BAG_BASELINE_MISSING'}
        confirm_sec=max(.5,min(8.0,float(self.config.get('point_b_delta_confirm_sec') or POINT_B_DELTA_CONFIRM_SEC)))
        settle_sec=max(.25,min(3.0,float(self.config.get('loot_settle_sec') or LOOT_SETTLE_SEC)))
        deadline=time.monotonic()+confirm_sec
        stable_since=None; last_key=None; latest=[]; last_snapshot=None; last_grid=None; last_diff=None
        cap=initial_cap
        self._set_state('OPEN_BAG_AT_POINT_B',confirm_sec=confirm_sec)
        self._domain('PLAYER_BAG_OPEN_AT_POINT_B',confirm_sec=confirm_sec)
        while time.monotonic()<deadline:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
            if not cap:
                cap=self._ensure_player_bag_open_live(hwnd,'POINT_B_DELTA')
            if not cap.get('ok'):
                cap=None; time.sleep(.12); continue
            snap=cap['snapshot']; diff=self.core.diff_snapshots(self.bag_registry.baseline,snap); last_snapshot=snap; last_grid=cap['grid']; last_diff=diff
            cross_scene=(str(self._bag_baseline_location or '').upper()=='POINT_A')
            # V1.5.1: first cycle baseline is captured at A so START never walks to B.
            # For that one cross-scene comparison, raw pixel MAE is invalid because
            # JX1's bag is translucent.  Empty->occupied truth is primary; a
            # current-frame item-score outlier fallback handles dark sprites.
            if cross_scene:
                candidates=self._autoboss_occupancy_delta_candidates(self.bag_registry.baseline,snap)
                detection_mode='AUTOBOSS_POINT_A_BASELINE_OCCUPANCY_PRIMARY'
                if not candidates:
                    candidates=self._autoboss_scene_independent_score_candidates(self.bag_registry.baseline,snap)
                    detection_mode='AUTOBOSS_POINT_A_BASELINE_SCENE_INDEPENDENT_ITEM_SCORE' if candidates else 'NONE'
                diff=dict(diff or {}); diff['new_item_candidates']=candidates; diff['new_item_count']=len(candidates); diff['new_item_detection_mode']=detection_mode
                self._domain('PLAYER_BAG_CROSS_SCENE_DELTA_AT_POINT_B',candidate_count=len(candidates),baseline_location='POINT_A',baseline_occupied=self.bag_registry.baseline.get('occupied_count'),current_occupied=snap.get('occupied_count'),detection_mode=detection_mode)
            else:
                candidates=(diff.get('new_item_candidates') or []) if diff.get('ok') else []
                if not candidates and diff.get('ok'):
                    candidates=self._autoboss_occupancy_delta_candidates(self.bag_registry.baseline,snap)
                    if candidates:
                        diff=dict(diff); diff['new_item_candidates']=candidates; diff['new_item_count']=len(candidates); diff['new_item_detection_mode']='AUTOBOSS_OCCUPANCY_EMPTY_TO_OCCUPIED_FALLBACK'
                        self._domain('PLAYER_BAG_DELTA_OCCUPANCY_FALLBACK_AT_POINT_B',candidate_count=len(candidates),baseline_occupied=self.bag_registry.baseline.get('occupied_count'),current_occupied=snap.get('occupied_count'))
            self._domain('PLAYER_BAG_POINT_B_DIFF_PROBE',baseline_occupied=self.bag_registry.baseline.get('occupied_count'),current_occupied=snap.get('occupied_count'),changed_count=len((diff or {}).get('changed_cells') or []),candidate_count=len(candidates),detection_mode=(diff or {}).get('new_item_detection_mode'))
            if candidates:
                keys=[]
                for c in candidates:keys.append((tuple(c.get('anchor') or []),tuple(c.get('footprint') or []),_cell_signature(snap,c)))
                key=tuple(sorted(str(x) for x in keys))
                if key!=last_key:
                    last_key=key; stable_since=time.monotonic(); latest=candidates
                    self._domain('PLAYER_BAG_DELTA_DETECTED_AT_POINT_B',candidate_count=len(candidates),detection_mode=diff.get('new_item_detection_mode'))
                elif stable_since is not None and time.monotonic()-stable_since>=settle_sec:
                    self._domain('LOOT_DELTA_STABLE_AT_POINT_B',once_key=f'{self.active_cycle.cycle_id}:LOOT_STABLE_B',candidate_count=len(latest))
                    return {'ok':True,'candidates':latest,'snapshot':last_snapshot,'grid':last_grid,'diff':last_diff}
            cap=None; time.sleep(.10)
        if latest:
            self._domain('LOOT_DELTA_ACCEPTED_AT_POINT_B_TIMEOUT_EDGE',candidate_count=len(latest))
            return {'ok':True,'candidates':latest,'snapshot':last_snapshot,'grid':last_grid,'diff':last_diff}
        return {'ok':False,'reason':'BOSS_CYCLE_NO_GREEN_LOOT_AT_POINT_B','last_snapshot':last_snapshot,'diff':last_diff}

    def _loot_candidate_identity_key(self,candidate):
        """Stable physical-target key for AutoBoss queue construction.

        V1.5.4 rootfix: exact duplicate detections of the same physical target must
        never become two queue rows, otherwise the reader can revisit one item and
        make it look as if queue advancement is broken.  This key is deliberately
        AutoBoss-local; shared InventorySensor / Final6 ownership is unchanged.
        """
        try:
            anchor=tuple(int(x) for x in (candidate.get('anchor') or [0,0])[:2])
            footprint=tuple(int(x) for x in (candidate.get('footprint') or [1,1])[:2])
            cells=candidate.get('geometric_cells') or candidate.get('cells') or []
            norm_cells=tuple(sorted((int(rc[0]),int(rc[1])) for rc in cells if isinstance(rc,(list,tuple)) and len(rc)==2))
            return (anchor,footprint,norm_cells)
        except Exception:
            return (tuple(candidate.get('anchor') or []),tuple(candidate.get('footprint') or []),())

    def _autoboss_tooltip_fingerprint(self, crop_path):
        """Compact perceptual fingerprint used ONLY to demerge adjacent Boss loot.

        A real multi-cell item produces the same tooltip when any occupied cell of
        that item is hovered.  Two adjacent physical items normally produce
        different tooltip content.  This lets AutoBoss split a connected visual
        delta without assuming every item is 1x1.
        """
        try:
            from PIL import Image, ImageOps
            p=Path(str(crop_path or ''))
            if not p.exists(): return None
            im=Image.open(p).convert('L')
            size=[int(im.width),int(im.height)]
            im=ImageOps.autocontrast(im,cutoff=1).resize((64,32))
            a=np.asarray(im,dtype=np.float32)/255.0
            norm=(a-float(a.mean()))/(float(a.std())+1e-6)
            # Keep a gradient bit sketch plus normalized luminance. The latter is
            # substantially more discriminative for two different tooltip texts,
            # while same-item re-hover crops remain close at the same Point-B scene.
            gx=a[:,1:]-a[:,:-1]
            gy=a[1:,:]-a[:-1,:]
            bits=np.concatenate([(gx>0).reshape(-1),(gy>0).reshape(-1)]).astype(np.uint8)
            return {'bits':bits,'norm':norm.astype(np.float32),'size':size}
        except Exception:
            return None

    @staticmethod
    def _autoboss_tooltip_fp_distance(a,b):
        try:
            if not a or not b:return 1.0
            sa=a.get('size') or []; sb=b.get('size') or []
            if len(sa)!=2 or len(sb)!=2:return 1.0
            # Clearly different tooltip extents imply different physical items.
            wr=abs(float(sa[0])-float(sb[0]))/max(1.0,float(max(sa[0],sb[0])))
            hr=abs(float(sa[1])-float(sb[1]))/max(1.0,float(max(sa[1],sb[1])))
            if wr>.14 or hr>.14:return 1.0
            na=np.asarray(a.get('norm'),dtype=np.float32); nb=np.asarray(b.get('norm'),dtype=np.float32)
            if na.size and nb.size and na.shape==nb.shape:
                # Normalized MAE: same physical item should remain tightly aligned;
                # distinct tooltip text normally separates strongly.
                return float(np.mean(np.abs(na-nb)))
            aa=np.asarray(a.get('bits'),dtype=np.uint8); bb=np.asarray(b.get('bits'),dtype=np.uint8)
            if aa.size==0 or aa.shape!=bb.shape:return 1.0
            return float(np.mean(aa!=bb))
        except Exception:return 1.0

    def _autoboss_demerge_suspicious_candidates(self, hwnd, candidates, grid):
        """Split a connected multi-cell delta only when tooltip evidence proves it.

        Root cause addressed: if two Boss drops are picked up between two 140ms bag
        scans and land in adjacent cells, connected-cell clustering can create ONE
        candidate.  Fair Final6 cannot inspect an item that never received its own
        queue row.  We therefore probe each changed cell at Point B.  Cells whose
        hover produces the same tooltip remain one physical item; cells with
        different tooltip fingerprints become separate candidates.

        Safety: if any probe is missing/ambiguous, preserve the original candidate
        rather than inventing a split.
        """
        src=list(candidates or [])
        if not src or not grid:return src
        out=[]
        old_grid=getattr(self.api,'_inventory_grid',None)
        try:
            self.api._inventory_grid=grid
            focus=self._focus_game_client_for_inventory_hotkey(hwnd,'LOOT_DEMERGE')
            self._domain('LOOT_DEMERGE_BEGIN',candidate_count=len(src),focus_ok=bool(focus.get('ok')))
            for ci,c in enumerate(src,1):
                cells=[]
                for raw in (c.get('cells') or c.get('geometric_cells') or []):
                    try: rc=(int(raw[0]),int(raw[1]))
                    except Exception: continue
                    if rc not in cells:cells.append(rc)
                if len(cells)<=1 or len(cells)>8:
                    out.append(c); continue
                # Probe every changed cell independently.  All probes must resolve
                # before a destructive queue split is trusted.
                probes=[]; failed=False
                for pi,(r,col) in enumerate(cells,1):
                    single={'candidate_id':f'{ci}:{pi}','cells':[[r,col]],'geometric_cells':[[r,col]],
                            'anchor':[r,col],'footprint':[1,1],'visual_cell_count':1,
                            'geometric_cell_count':1,'cell_count':1,'detection_mode':'AUTOBOSS_DEMERGE_PROBE'}
                    stamp=time.strftime('%Y%m%d_%H%M%S')+f'_DEMERGE_{ci}_{pi}_{uuid.uuid4().hex[:4]}'
                    try: hover=self.api._capture_tooltip_at_candidate(int(hwnd),single,stamp,reuse_session=True)
                    except Exception as e: hover={'ok':False,'reason':'DEMERGE_CAPTURE_EXCEPTION','error':str(e)}
                    if not hover.get('ok'):
                        failed=True
                        self._domain('LOOT_DEMERGE_CELL_PROBE_MISS',candidate_index=ci,cell=[r,col],reason=hover.get('reason'))
                        break
                    fp=self._autoboss_tooltip_fingerprint(hover.get('first_crop'))
                    if fp is None:
                        failed=True; break
                    probes.append({'cell':(r,col),'fp':fp,'crop':hover.get('first_crop')})
                    time.sleep(.025)
                if failed or len(probes)!=len(cells):
                    out.append(c)
                    self._domain('LOOT_DEMERGE_PRESERVED_ORIGINAL',candidate_index=ci,reason='INCOMPLETE_CELL_PROOF',cell_count=len(cells))
                    continue

                groups=[]
                for pr in probes:
                    placed=False
                    for g in groups:
                        d=self._autoboss_tooltip_fp_distance(pr['fp'],g['rep']['fp'])
                        if d<=.080:
                            g['members'].append(pr); placed=True; break
                    if not placed: groups.append({'rep':pr,'members':[pr]})
                if len(groups)<=1:
                    out.append(c)
                    self._domain('LOOT_DEMERGE_SINGLE_PHYSICAL_ITEM',candidate_index=ci,cell_count=len(cells))
                    continue

                pieces=[]
                for gi,g in enumerate(groups,1):
                    gcs=sorted([x['cell'] for x in g['members']])
                    rs=[x[0] for x in gcs]; cs=[x[1] for x in gcs]
                    r0,r1=min(rs),max(rs); c0,c1=min(cs),max(cs)
                    q=copy.deepcopy(c)
                    q.update({'candidate_id':f'{c.get("candidate_id",ci)}-D{gi}',
                              'cells':[[r,cc] for r,cc in gcs],
                              'geometric_cells':[[rr,cc] for rr in range(r0,r1+1) for cc in range(c0,c1+1)],
                              'anchor':[r0,c0],'footprint':[c1-c0+1,r1-r0+1],
                              'visual_cell_count':len(gcs),'geometric_cell_count':(c1-c0+1)*(r1-r0+1),
                              'cell_count':(c1-c0+1)*(r1-r0+1),
                              'detection_mode':str(c.get('detection_mode') or '')+'+TOOLTIP_DEMERGED'})
                    pieces.append(q)
                out.extend(pieces)
                self._domain('ADJACENT_LOOT_CANDIDATE_DEMERGED',candidate_index=ci,original_cells=[list(x) for x in cells],piece_count=len(pieces),pieces=[{'anchor':p.get('anchor'),'footprint':p.get('footprint'),'cells':p.get('cells')} for p in pieces])
            self._domain('LOOT_DEMERGE_COMPLETE',input_count=len(src),output_count=len(out))
            return out
        finally:
            self.api._inventory_grid=old_grid

    def _build_loot_queue(self,candidates,snapshot,grid):
        # V1.5.4: build one queue row per UNIQUE physical target.
        # Do not change the detector itself; dedupe only exact duplicate ownership.
        unique=[]; seen=set()
        for c in candidates or []:
            key=self._loot_candidate_identity_key(c)
            if key in seen:
                self._domain('DUPLICATE_LOOT_CANDIDATE_SUPPRESSED',anchor=list(c.get('anchor') or []),footprint=list(c.get('footprint') or []))
                continue
            seen.add(key); unique.append(c)
        out=[]
        for i,c in enumerate(unique,1):
            sig=_cell_signature(snapshot,c); lid='L-'+uuid.uuid4().hex[:12].upper(); qid=f'L{i:02d}'
            ref=ContainerItemRef(lid,CONTAINER_PLAYER,dict(c),list(c.get('anchor') or [0,0]),list(c.get('footprint') or [1,1]),sig,self.cycle_number,'NEW_UNKNOWN','UNRESOLVED','NONE',qid)
            out.append(ref); self._domain('NEW_ITEM_FOUND',logical_item_id=lid,queue_id=qid,anchor=ref.grid_anchor,footprint=ref.footprint,container_id=CONTAINER_PLAYER)
        self.last_loot_queue=out
        self._domain('BOSS_LOOT_QUEUE_BUILT',queue_count=len(out),input_candidate_count=len(candidates or []),deduped_count=max(0,len(candidates or [])-len(out)))
        return out


    # V1.5.7 — AutoBoss-local tooltip OCR hardening for translucent JX1 UI.
    # Shared Final6 Reader remains unchanged; this layer only supplies cleaner
    # tooltip evidence / recapture timing from AutoBoss.
    def _autoboss_tooltip_preprocess(self, pil_img):
        """
        Build multiple OCR-friendly views from a translucent JX1 tooltip crop.
        We deliberately do NOT replace the shared reader.  The goal is to reduce
        world/map bleed-through before OCR while preserving glyph strokes.
        """
        try:
            from PIL import ImageEnhance, ImageFilter, ImageOps
            import numpy as _np
            if pil_img is None:
                return []
            rgb = pil_img.convert("RGB")

            # Keep the original as one candidate.
            out = [("original", rgb)]

            # Luminance / local contrast candidate.
            gray = ImageOps.grayscale(rgb)
            gray = ImageOps.autocontrast(gray, cutoff=1)
            gray = ImageEnhance.Contrast(gray).enhance(1.8)
            gray = ImageEnhance.Sharpness(gray).enhance(1.35)
            out.append(("gray_contrast", gray.convert("RGB")))

            # Dark-background suppression.  JX1 tooltip text is normally much
            # brighter / more chromatic than the moving world behind it.
            arr = _np.asarray(rgb, dtype=_np.uint8)
            mx = arr.max(axis=2).astype(_np.int16)
            mn = arr.min(axis=2).astype(_np.int16)
            sat = mx - mn
            lum = arr.mean(axis=2)
            # Preserve likely glyph pixels, suppress low-contrast scenery.
            glyph = ((lum >= 118) | ((sat >= 38) & (lum >= 82)))
            cleaned = _np.zeros_like(arr)
            cleaned[glyph] = arr[glyph]
            cimg = Image.fromarray(cleaned, "RGB")
            cimg = ImageEnhance.Contrast(cimg).enhance(1.65)
            cimg = ImageEnhance.Sharpness(cimg).enhance(1.4)
            out.append(("fg_suppress", cimg))

            # High-contrast binary-ish view for weak strokes.
            g = _np.asarray(ImageOps.grayscale(rgb), dtype=_np.uint8)
            # Adaptive threshold based on crop brightness, bounded to avoid
            # over-whitening bright maps.
            th = int(max(92, min(168, float(_np.percentile(g, 71)))))
            bw = _np.where(g >= th, 255, 0).astype(_np.uint8)
            bimg = Image.fromarray(bw, "L").filter(ImageFilter.MedianFilter(3))
            out.append(("binary", bimg.convert("RGB")))

            # 2x scale is intentionally local to tooltip OCR, not global UI.
            scaled = []
            for name, im in out:
                try:
                    scaled.append((name + "_2x", im.resize((im.width*2, im.height*2))))
                except Exception:
                    pass
            out.extend(scaled)
            return out
        except Exception:
            try:
                return [("original", pil_img.convert("RGB"))] if pil_img is not None else []
            except Exception:
                return []

    def _autoboss_stable_tooltip_frames(self, hwnd, item, grid, frames=3, interval=0.055):
        """
        Re-hover the SAME logical item and collect several quick tooltip frames.
        This combats animation/VFX bleed-through.  It never advances item state.
        """
        captures = []
        last = None
        for i in range(max(1, int(frames))):
            if self._cancelled():
                break
            try:
                # Existing hover/capture path remains authoritative.
                cap = self._capture_tooltip_for_item(hwnd, item, grid) if hasattr(self, "_capture_tooltip_for_item") else None
            except Exception:
                cap = None
            if cap is not None:
                captures.append(cap)
                last = cap
            if i + 1 < frames:
                time.sleep(max(0.02, float(interval)))
        return captures or ([last] if last is not None else [])

    def _autoboss_translucent_ocr_rescue(self, hwnd, item, grid):
        """AutoBoss-only OCR rescue for translucent JX1 tooltips.

        Shared Final6/Filter code remains the authority.  This function only
        recaptures the SAME logical item, suppresses moving world/VFX background,
        and passes multiple cleaned crops into the existing fast multi-profile
        evaluator.  It never invents PASS/FAIL on its own.
        """
        try:
            if str(item.container_id) != CONTAINER_PLAYER:
                return {'ok':False,'reason':'OCR_RESCUE_WRONG_CONTAINER'}
            candidate=copy.deepcopy(item.candidate)
            candidate.update({'queue_id':item.queue_id,'status':'PENDING','decision':'PENDING',
                              'reason':None,'container_id':CONTAINER_PLAYER})
            # Locate backend globals through the injected core module.  Do not
            # import Stage17 here (avoids circular import from LockedUI).
            fast_eval=getattr(self.core,'_fast_evaluate_profiles',None)
            load_filter=getattr(self.core,'_load_option_filter',None)
            if not callable(fast_eval):
                return {'ok':False,'reason':'OCR_RESCUE_FAST_EVALUATOR_UNAVAILABLE'}
            try:
                cfg=getattr(self.api,'_batch_filter_cache',None)
                if not isinstance(cfg,dict):
                    cfg=load_filter() if callable(load_filter) else None
            except Exception:
                cfg=None
            if not isinstance(cfg,dict):
                return {'ok':False,'reason':'OCR_RESCUE_FILTER_CONFIG_UNAVAILABLE'}

            proof_dir=self.root/'logs'/'proof'/'autoboss_ocr'
            proof_dir.mkdir(parents=True,exist_ok=True)
            selected_paths=[]; source_crops=[]; view_meta=[]
            # Two near-adjacent frames are enough to decorrelate moving world/VFX
            # without adding large latency.  This is rescue-only, not hot path.
            for fi in range(2):
                if self._cancelled():
                    return {'ok':False,'reason':'USER_STOP'}
                stamp=time.strftime('%Y%m%d_%H%M%S')+f'_{item.queue_id}_ocr{fi+1}_{uuid.uuid4().hex[:5]}'
                try:
                    hover=self.api._capture_tooltip_at_candidate(int(hwnd),candidate,stamp,reuse_session=True)
                except Exception as e:
                    hover={'ok':False,'reason':'OCR_RESCUE_CAPTURE_EXCEPTION','error':str(e)}
                if not hover.get('ok'):
                    self._domain('FINAL6_OCR_RESCUE_FRAME_MISS',queue_id=item.queue_id,frame=fi+1,reason=hover.get('reason'))
                    time.sleep(.055)
                    continue
                cp=Path(str(hover.get('first_crop') or ''))
                if not cp.exists():
                    time.sleep(.055); continue
                source_crops.append(str(cp))
                try:
                    from PIL import Image
                    im=Image.open(cp).convert('RGB')
                    views=self._autoboss_tooltip_preprocess(im)
                except Exception:
                    views=[]
                # Prefer cleaned 2x evidence. Original is already handled by the
                # canonical reader; don't waste rescue OCR on it again.
                wanted=('fg_suppress_2x','gray_contrast_2x','binary_2x')
                by_name={n:v for n,v in views}
                for vn in wanted:
                    vi=by_name.get(vn)
                    if vi is None: continue
                    outp=proof_dir/f'{stamp}_{vn}.png'
                    try:
                        vi.save(outp)
                        selected_paths.append(str(outp))
                        view_meta.append({'frame':fi+1,'view':vn,'path':str(outp)})
                    except Exception:
                        pass
                time.sleep(.055)
            if not selected_paths:
                return {'ok':False,'reason':'OCR_RESCUE_NO_CLEAN_CROPS','source_crops':source_crops}

            self._domain('FINAL6_OCR_RESCUE_EVIDENCE_READY',queue_id=item.queue_id,
                         crop_count=len(selected_paths),source_frame_count=len(source_crops))
            try:
                ff=fast_eval(selected_paths,cfg)
            except Exception as e:
                return {'ok':False,'reason':'OCR_RESCUE_EVALUATOR_EXCEPTION','error':str(e),'views':view_meta}
            read_like={'ok':True,'filter':ff,'autoboss_ocr_rescue':{
                'policy':'TRANSLUCENT_BG_SUPPRESS_MULTIFRAME_V1','source_crops':source_crops,
                'views':view_meta,'decision':ff.get('decision'),'filter_result':ff.get('filter_result')
            }}
            ev_id='BE-'+uuid.uuid4().hex[:12].upper()
            result=self.filter_adapter.evaluate(read_like,None,item.queue_id,self.session_generation,ev_id)
            if result.verdict==FilterVerdict.ACCEPT: verdict=BossVerdict.ACCEPT
            elif result.verdict==FilterVerdict.REJECT: verdict=BossVerdict.REJECT
            else: verdict=BossVerdict.UNRESOLVED
            self._domain('FINAL6_OCR_RESCUE_RESULT',queue_id=item.queue_id,verdict=verdict.value,
                         decision=ff.get('decision'),evidence_id=ev_id,crop_count=len(selected_paths))
            return {'ok':True,'verdict':verdict,'read':read_like,'filter':asdict(result),
                    'evidence_id':ev_id,'ocr_rescue':True}
        except Exception as e:
            return {'ok':False,'reason':'OCR_RESCUE_EXCEPTION','error':str(e)}

    def _read_item(self,hwnd,item,grid):
        # V1.5.7: translucent UI OCR policy. AutoBoss owns recapture cadence;
        # shared Final6 parsing/filter truth remains unchanged.
        try:
            self._domain("FINAL6_TRANSLUCENT_OCR_MODE", owner="AUTOBOSS", policy="MULTIFRAME_FOREGROUND_SUPPRESS_2X")
        except Exception:
            pass
        if str(item.container_id)!=CONTAINER_PLAYER:return {'ok':False,'verdict':BossVerdict.UNRESOLVED,'reason':'FILTER_WRONG_CONTAINER_BLOCKED'}
        candidate=copy.deepcopy(item.candidate); candidate.update({'queue_id':item.queue_id,'status':'PENDING','decision':'PENDING','reason':None,'container_id':CONTAINER_PLAYER})
        old_q=self.api._new_item_queue; old_results=self.api._queue_read_results; old_grid=self.api._inventory_grid
        try:
            self.api._new_item_queue=[candidate]; self.api._queue_read_results=[]; self.api._inventory_grid=grid
            # V1.5.6 single-owner rule: AutoBoss already confirmed PLAYER_BAG open.
            # The shared reader is therefore run in an existing inventory session
            # and MUST NOT call its legacy _capture_inventory_ready/Q/F4 path again.
            # Two independent toggle owners were able to close the bag between items.
            read=self.api._read_queue_item_internal(int(hwnd),0,batch_session=True,execution_mode='READER_TEST')
            ev_id='BE-'+uuid.uuid4().hex[:12].upper(); result=self.filter_adapter.evaluate(read,None,item.queue_id,self.session_generation,ev_id)
            if result.verdict==FilterVerdict.ACCEPT:v=BossVerdict.ACCEPT
            elif result.verdict==FilterVerdict.REJECT:v=BossVerdict.REJECT
            else:v=BossVerdict.UNRESOLVED
            canonical={'ok':bool(read.get('ok')),'verdict':v,'read':read,'filter':asdict(result),'evidence_id':ev_id}
            if v!=BossVerdict.UNRESOLVED:
                return canonical
            # V1.5.7 rescue is evidence-preparation only. Canonical reader gets
            # first authority; only an unresolved result triggers translucent-UI
            # cleanup + multi-frame fast-profile evaluation on the SAME item.
            rescue=self._autoboss_translucent_ocr_rescue(hwnd,item,grid)
            if rescue.get('ok') and rescue.get('verdict') in (BossVerdict.ACCEPT,BossVerdict.REJECT):
                return rescue
            canonical['ocr_rescue']=rescue
            return canonical
        finally:
            self.api._new_item_queue=old_q; self.api._queue_read_results=old_results; self.api._inventory_grid=old_grid

    def _classify_loot(self,hwnd,items,grid):
        """Fair queue classification: no single difficult item may monopolize Final6.

        V1.5.3 retried the CURRENT item up to 10 consecutive times.  Therefore one
        tooltip that remained UNRESOLVED was intentionally hovered again and again,
        while L02/L03/... were never given a turn.  That is the exact observed
        "soi 1 món đi soi lại, không soi món khác" failure.

        V1.5.4 makes Final6 scheduling round-robin:
          * every pending item gets one read attempt per pass;
          * UNRESOLVED becomes DEFERRED for the remainder of that pass;
          * resolved items are removed from the pending set;
          * only after ALL pending items had a turn do we retry deferred items;
          * no unresolved item is dropped/kept/stored; if bounded passes finish with
            unresolved rows, stop safely AFTER the other loot has still been read.
        """
        accept=[]; reject=[]
        pending=list(items or [])
        attempts={item.logical_id:0 for item in pending}
        last_result={}
        max_passes=5
        current_grid=grid
        total=len(pending)
        pass_no=0

        while pending and pass_no<max_passes:
            pass_no+=1
            next_pending=[]
            self._domain('FINAL6_QUEUE_PASS_BEGIN',pass_no=pass_no,pending_count=len(pending),total=total)
            # One foreground handshake per pass. The reader itself is deliberately
            # forbidden from reopening/toggling the bag.
            focus=self._focus_game_client_for_inventory_hotkey(hwnd,'FINAL6_PASS')
            self._domain('FINAL6_PASS_CLIENT_FOCUS',pass_no=pass_no,ok=bool(focus.get('ok')),foreground_hwnd=focus.get('foreground_hwnd'))

            for item in pending:
                if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
                attempts[item.logical_id]=int(attempts.get(item.logical_id,0))+1
                ordinal=next((i for i,x in enumerate(items,1) if x.logical_id==item.logical_id),0)
                self._set_state('ITEM_CLASSIFY',logical_item_id=item.logical_id,index=ordinal,total=total,queue_id=item.queue_id,pass_no=pass_no,attempt=attempts[item.logical_id])
                self._domain('FINAL6_TARGET_BEGIN',logical_item_id=item.logical_id,queue_id=item.queue_id,anchor=item.grid_anchor,footprint=item.footprint,pass_no=pass_no,attempt=attempts[item.logical_id])

                cap=self._ensure_player_bag_open_live(hwnd,'FINAL6')
                if cap.get('ok'):current_grid=cap.get('grid') or current_grid
                rd=self._read_item(hwnd,item,current_grid); last_result[item.logical_id]=rd
                verdict=rd.get('verdict')

                if verdict in (BossVerdict.ACCEPT,BossVerdict.REJECT):
                    item.verdict=verdict.value
                    item.status='CLASSIFIED'
                    self._domain('FINAL6_RESOLVED',logical_item_id=item.logical_id,queue_id=item.queue_id,evidence_id=rd.get('evidence_id'),pass_no=pass_no,attempt=attempts[item.logical_id])
                    self._domain('FILTER_'+item.verdict,logical_item_id=item.logical_id,queue_id=item.queue_id)
                    (accept if item.verdict=='ACCEPT' else reject).append(item)
                else:
                    item.status='DEFERRED_FINAL6'
                    next_pending.append(item)
                    self._domain('FINAL6_DEFERRED_TO_NEXT_QUEUE_PASS',logical_item_id=item.logical_id,queue_id=item.queue_id,pass_no=pass_no,attempt=attempts[item.logical_id],pending_after_this=len(next_pending))

                # Critical fairness rule: NEVER retry this same item immediately while
                # another unresolved queue row is waiting for its first turn.
                time.sleep(.035)

            pending=next_pending
            self._domain('FINAL6_QUEUE_PASS_COMPLETE',pass_no=pass_no,resolved_count=len(accept)+len(reject),deferred_count=len(pending),total=total)
            if pending and pass_no<max_passes:
                time.sleep(min(.18,.055+.02*pass_no))

        unresolved=[]
        if pending:
            # V1.7.14 global contract: reader instability never stops AutoBoss.
            # Unknown loot is left untouched in Player Bag, registered as a safe
            # deferred item, and included in the next committed bag baseline.
            # It is NEVER converted to REJECT and no Drop/Store action is emitted.
            for item in pending:
                item.verdict='UNRESOLVED'
                item.status='DEFERRED_UNRESOLVED_SAFE_KEEP'
                item.disposition='NONE'
                self.bag_registry.remember(item,'DEFERRED_UNRESOLVED_SAFE_KEEP')
                unresolved.append({'logical_id':item.logical_id,'queue_id':item.queue_id,'anchor':list(item.grid_anchor),'footprint':list(item.footprint),'attempts':attempts.get(item.logical_id,0),'last':last_result.get(item.logical_id)})
            self._domain('FINAL6_UNRESOLVED_ITEMS_DEFERRED_CONTINUE',unresolved_count=len(unresolved),resolved_count=len(accept)+len(reject),total=total,items=[{'logical_id':x['logical_id'],'queue_id':x['queue_id'],'anchor':x['anchor'],'attempts':x['attempts']} for x in unresolved])

        return {'ok':True,'accept':accept,'reject':reject,'unresolved_items':unresolved,
                'deferred_unresolved':len(unresolved),'passes':pass_no,'attempts':attempts}

    def _with_backend_queue_item(self,item,decision,fn):
        candidate=copy.deepcopy(item.candidate); candidate.update({'queue_id':item.queue_id,'status':'PENDING','decision':decision,'reason':None,'container_id':CONTAINER_PLAYER})
        old_q=self.api._new_item_queue; old_results=self.api._queue_read_results; old_grid=self.api._inventory_grid
        try:
            self.api._new_item_queue=[candidate]; self.api._queue_read_results=[]; self.api._inventory_grid=self._bag_grid
            return fn()
        finally:
            self.api._new_item_queue=old_q; self.api._queue_read_results=old_results; self.api._inventory_grid=old_grid

    def _drop_item(self,hwnd,item):
        if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
        if str(item.container_id)!=CONTAINER_PLAYER:return {'ok':False,'reason':'DROP_WRONG_CONTAINER_BLOCKED'}
        if item.disposition!='NONE':return {'ok':False,'reason':'EXACTLY_ONCE_DISPOSITION_VIOLATION'}
        self._set_state('DROP_ITEM',logical_item_id=item.logical_id)
        r=self._with_backend_queue_item(item,'FAIL',lambda:self.api.chest_drop_queue_item(int(hwnd),0))
        if r.get('ok') and (r.get('dropped') or r.get('already_dropped')):
            item.disposition='DROP'; item.status='DROPPED'; self.counters['dropped']+=1; self.bag_registry.remember(item,'DROPPED'); self._domain('DROP_COMMITTED',logical_item_id=item.logical_id)
            return {'ok':True}
        return {'ok':False,'reason':r.get('reason') or 'DROP_COMMIT_UNCERTAIN','detail':r}

    def _resolve_store_containers(self,hwnd):
        img=self.core.capture_client(int(hwnd)); r=self.container_resolver.resolve(img,require_storage=True)
        self._log_container_resolution(r,'STORE_PAIR_RESOLVE')
        if not r.ok:return {'ok':False,'reason':r.reason,'evidence':r.evidence}
        self._domain('CONTAINER_PAIR_RESOLVED',player_owner=CONTAINER_PLAYER,storage_owner=CONTAINER_STORAGE,confidence=r.confidence,evidence=r.evidence)
        return {'ok':True,'resolution':r}

    def _store_item(self,hwnd,item):
        if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
        if str(item.container_id)!=CONTAINER_PLAYER:return {'ok':False,'reason':'STORE_SOURCE_WRONG_CONTAINER_BLOCKED'}
        if item.disposition!='NONE':return {'ok':False,'reason':'EXACTLY_ONCE_DISPOSITION_VIOLATION'}
        profiles=self.config.get('container_profiles') or {}
        if not profiles.get(CONTAINER_PLAYER) or not profiles.get(CONTAINER_STORAGE):
            return {'ok':False,'reason':'CONTAINER_OWNER_AMBIGUOUS'}
        pair=self._resolve_store_containers(hwnd)
        if not pair.get('ok'):return {'ok':False,'reason':pair.get('reason') or 'CONTAINER_OWNER_AMBIGUOUS','detail':pair}
        rr=pair['resolution']
        if str(rr.player_grid.get('container_id'))!=CONTAINER_PLAYER or str(rr.storage_grid.get('container_id'))!=CONTAINER_STORAGE:
            return {'ok':False,'reason':'CONTAINER_OWNER_AMBIGUOUS','detail':pair}
        self._set_state('STORE_ITEM',logical_item_id=item.logical_id)
        # V12.11 StoreController opens storage, resolves PLAYER_INVENTORY/PERSONAL_STORAGE
        # structurally, plans full-footprint placement, then verifies source-absent + destination-present.
        r=self._with_backend_queue_item(item,'KEEP',lambda:self.api.chest_store_queue_item(int(hwnd),0))
        if r.get('ok') and (r.get('stored') or r.get('already_stored') or r.get('store_committed') or r.get('committed')):
            item.disposition='STORE'; item.status='STORED'; self.counters['stored']+=1; self.bag_registry.remember(item,'MOVED_TO_STORAGE'); self.storage_registry.remember(item); self._domain('STORE_COMMITTED',logical_item_id=item.logical_id,verified_two_sided=True)
            return {'ok':True}
        reason=str(r.get('reason') or 'STORE_COMMIT_UNCERTAIN')
        if 'FULL' in reason or 'NO_FIT' in reason or 'CAPACITY' in reason:
            return {'ok':False,'reason':'STORAGE_CAPACITY_EXHAUSTED','safe_stop':True,'detail':r}
        if 'OWNER' in reason or 'GRID' in reason:
            return {'ok':False,'reason':'CONTAINER_OWNER_AMBIGUOUS','detail':r}
        return {'ok':False,'reason':reason,'detail':r}

    def _process_loot(self,hwnd,items,grid):
        """Classify fairly and commit every AUTHORITATIVE resolved disposition.

        V1.5.7 bug: if even one sibling item remained Final6 UNRESOLVED,
        _classify_loot returned ok=False and this method returned immediately.
        Therefore already-authoritative REJECT items were never dropped.  This
        rootfix commits resolved REJECTs (and KEEP accepts) before safe-stopping
        on the remaining unresolved items.  UNRESOLVED itself is NEVER treated
        as REJECT.
        """
        cls=self._classify_loot(hwnd,items,grid)
        accepts=list(cls.get('accept') or [])
        rejects=list(cls.get('reject') or [])
        disposition={'dropped':0,'kept':0,'stored':0,'deferred_store':0}

        # Authoritative REJECT is safe to execute even when another sibling is
        # unresolved.  Fixed-slot JX1 bag geometry does not compact on drop.
        for item in rejects:
            r=self._drop_item(hwnd,item)
            if not r.get('ok'):return r
            disposition['dropped']+=1

        mode=str(self.config.get('mode') or 'KEEP').upper()
        if mode=='KEEP':
            # KEEP causes no mouse/item movement, so authoritative accepts can be
            # committed even if a different item is still unresolved.
            for item in accepts:
                if item.disposition!='NONE':continue
                item.disposition='KEEP'; item.status='KEPT'; self.counters['kept']+=1
                self.bag_registry.remember(item,'KNOWN_KEPT'); self._domain('KEEP_COMMITTED',logical_item_id=item.logical_id)
                disposition['kept']+=1
        elif cls.get('ok'):
            # STORE mutates a second container; keep it behind full-classification
            # success so unresolved anchors cannot be disturbed by a storage UI.
            for item in accepts:
                r=self._store_item(hwnd,item)
                if not r.get('ok'):return r
                disposition['stored']+=1
        else:
            disposition['deferred_store']=len(accepts)
            if accepts:
                self._domain('STORE_ACCEPTS_DEFERRED_DUE_UNRESOLVED_SIBLING',count=len(accepts),items=[x.logical_id for x in accepts])

        if not cls.get('ok'):
            self._domain('PARTIAL_DISPOSITION_COMMITTED_BEFORE_SAFE_STOP',reason=cls.get('reason'),resolved_accept=len(accepts),resolved_reject=len(rejects),disposition=disposition,unresolved_count=len(cls.get('unresolved_items') or []))
            out=dict(cls); out['partial_disposition']=disposition
            return out
        return {'ok':True,'accept_count':len(accepts),'reject_count':len(rejects),
                'deferred_unresolved_count':len(cls.get('unresolved_items') or []),
                'unresolved_items':list(cls.get('unresolved_items') or []),'disposition':disposition}

    def _postprocess_checkpoint(self,hwnd):
        cap=self._ensure_player_bag_open_live(hwnd,'POSTPROCESS')
        if not cap.get('ok'):return cap
        self.bag_registry.commit_baseline(cap['snapshot']); self._bag_snapshot=cap['snapshot']; self._bag_grid=cap['grid']; self._bag_baseline_location='POINT_B'
        self._domain('BAG_REGISTRY_COMMITTED',occupied=cap['snapshot'].get('occupied_count'),free=cap['snapshot'].get('free_count'),generation=self.bag_registry.generation)
        return {'ok':True,'snapshot':cap['snapshot']}

    def _run_one_cycle(self,hwnd):
        cycle=self._new_cycle()
        # V1.5.6: Player Bag is a persistent live sensor with one visibility owner.  Keep it open before the
        # spawn, throughout combat/loot, navigation to B, Final6, and the return to A.
        cap=self._ensure_player_bag_open_live(hwnd,'PRE_SPAWN')
        if not cap.get('ok'):
            return {'ok':False,'reason':cap.get('reason') or 'PLAYER_BAG_OPEN_NOT_CONFIRMED','detail':cap}
        snap=cap['snapshot']; self._bag_snapshot=snap; self._bag_grid=cap['grid']
        if self.bag_registry.baseline is None:
            self.bag_registry.reset_session(self.session_id,snap); self._bag_baseline_location='POINT_A'
        capacity=self._capacity_status(snap); self._domain('PRE_SPAWN_CAPACITY_'+capacity['status'],capacity=capacity,source='LIVE_PLAYER_BAG')
        if capacity['status']=='FULL':return {'ok':False,'reason':'PLAYER_BAG_FULL','capacity':capacity}
        if capacity['status']=='CAPACITY_UNCERTAIN':
            # Do not kill a live session merely because the footprint planner cannot
            # prove a large-item fit.  The bag is continuously visible/scanned and
            # a definite FULL result remains blocking.
            self._domain('PRE_SPAWN_CAPACITY_UNCERTAIN_NONBLOCKING',capacity=capacity)

        # Storage is unrelated to Boss loot discovery and remains closed unless an
        # accepted STORE transaction later needs it. Player Bag deliberately stays open.
        stc=self._close_storage_if_open_once(hwnd)
        if not stc.get('ok'):return stc
        self._domain('BOSS_FIELD_PLAYER_BAG_LIVE',player_bag_open=True,storage_closed=bool(stc.get('confirmed') or stc.get('already_closed')),runtime_policy='OPEN_DURING_BOSS_CONTINUOUS_SCAN')
        spawn=self._dispatch_key1_once(hwnd,cycle)
        if not spawn.get('ok'):return spawn

        wait=self._wait_boss_and_autoloot_live_bag(hwnd)
        if not wait.get('ok'):return wait
        live_candidates=wait.get('candidates') or []
        navb=self._navigate(hwnd,'B')
        if not navb.get('ok'):return navb

        # Bag should still be open. Reacquire it without forcing a blind toggle.
        at_b=self._ensure_player_bag_open_live(hwnd,'POINT_B')
        if not at_b.get('ok'):return {'ok':False,'reason':at_b.get('reason') or 'PLAYER_BAG_OPEN_NOT_CONFIRMED','detail':at_b}
        if live_candidates:
            # Candidates were detected at A while the translucent background matched
            # the baseline; keep those anchors/footprints and read them at B.
            loot={'ok':True,'candidates':live_candidates,'snapshot':at_b['snapshot'],'grid':at_b['grid'],'diff':wait.get('diff'),'source':'LIVE_SCAN_AT_A'}
            self._domain('BOSS_LOOT_QUEUE_FROM_LIVE_SCAN',candidate_count=len(live_candidates))
        else:
            # Recovery/fallback only: if live scan never saw the pickup, run the
            # existing Point-B cross-scene-safe delta path.
            loot=self._wait_point_b_loot_delta_stable(hwnd,initial_cap=at_b)
            if not loot.get('ok'):return loot
        candidates=loot.get('candidates') or []
        # V1.5.8: fair scheduling can only inspect queue rows that exist. If adjacent
        # pickups were merged into one connected delta, prove/split physical items
        # by per-cell tooltip identity before building L01/L02/...
        candidates=self._autoboss_demerge_suspicious_candidates(hwnd,candidates,loot.get('grid') or at_b['grid'])
        items=self._build_loot_queue(candidates,loot.get('snapshot') or at_b['snapshot'],loot.get('grid') or at_b['grid'])
        if not items:return {'ok':False,'reason':'BOSS_CYCLE_NO_GREEN_LOOT_AT_POINT_B'}
        processed=self._process_loot(hwnd,items,loot.get('grid') or at_b['grid'])
        if not processed.get('ok'):return processed
        post=self._postprocess_checkpoint(hwnd)
        if not post.get('ok'):return post
        stc2=self._close_storage_if_open_once(hwnd)
        if not stc2.get('ok'):return stc2
        # Player Bag intentionally remains OPEN while returning to A and into the
        # next Boss cycle, so live scanning never loses continuity.
        nava=self._navigate(hwnd,'A')
        if not nava.get('ok'):return nava
        keep_open=self._ensure_player_bag_open_live(hwnd,'RETURNED_A')
        if not keep_open.get('ok'):
            self._domain('PLAYER_BAG_RETURN_A_REOPEN_PENDING',reason=keep_open.get('reason'))
        cycle.completed=True; self.counters['cycles']+=1; self._domain('BOSS_CYCLE_COMPLETE',once_key=f'{cycle.cycle_id}:COMPLETE',cycle=cycle.cycle_number,player_bag_kept_open=True)
        return {'ok':True,'cycle':cycle.cycle_number}

    def _run(self,hwnd,test_one_cycle):
        try:
            self._set_state('CLIENT_BIND'); f=self._focus_client(hwnd)
            if not f.get('ok'):
                self._error(f.get('reason','CLIENT_NOT_READY'),'InputDispatcher',f); return
            self._domain('CLIENT_BOUND',once_key=f'{self.session_id}:CLIENT',hwnd=int(hwnd))
            if self._cancelled():self.state='STOPPED'; return

            # V1.5.2 persistent-bag rootfix:
            # START stays at A, opens/locks Player Bag once, captures the baseline,
            # and then KEEPS that bag visible for continuous scanning during Boss
            # combat/auto-loot. Storage remains closed unless STORE disposition needs it.
            stc=self._close_storage_if_open_once(hwnd)
            if not stc.get('ok'):
                self._error(stc.get('reason','STORAGE_CLOSE_NOT_CONFIRMED'),'ContainerRuntime',stc,True); return
            self._set_state('BASELINE_CAPTURE_POINT_A')
            cap=self._ensure_player_bag_open_live(hwnd,'SESSION_BASELINE')
            if not cap.get('ok'):
                self._error(cap.get('reason','INVENTORY_GRID_NOT_FOUND'),'BossBagRegistry',cap); return
            self.bag_registry.reset_session(self.session_id,cap['snapshot'])
            self._bag_snapshot=cap['snapshot']; self._bag_grid=cap['grid']; self._bag_baseline_location='POINT_A'
            self._domain('PLAYER_BAG_BASELINE',once_key=f'{self.session_id}:BASELINE_A',occupied=cap['snapshot'].get('occupied_count'),free=cap['snapshot'].get('free_count'),baseline_location='POINT_A',baseline_policy='OCCUPANCY_PRIMARY_CROSS_SCENE_SAFE')
            self._domain('PLAYER_BAG_PERSISTENT_OPEN_ARMED',hotkey=self.api.get_inventory_hotkey(),runtime_policy='OPEN_DURING_BOSS_CONTINUOUS_SCAN')
            stc2=self._close_storage_if_open_once(hwnd)
            if not stc2.get('ok'):
                self._error(stc2.get('reason','STORAGE_CLOSE_NOT_CONFIRMED'),'ContainerRuntime',stc2,True); return

            # Arm JX1 Auto immediately at Point A. No navigation occurs before Boss #1.
            if self._cancelled():self.state='STOPPED'; return
            self._set_state('ARM_INGAME_AUTO'); arm=self.arm.arm_once(hwnd,self.api._cfg.get('input_mode','Auto'))
            if not arm.get('ok'):
                self._error(arm.get('reason','CTRL_F_SEND_FAILED'),'IngameAutoArmController',arm); return
            self._domain('CTRL_F_SENT_ONCE',once_key=f'{self.session_id}:CTRL_F',used_mode=arm.get('used_mode')); self._domain('INGAME_AUTO_ARM_LOCKED',once_key=f'{self.session_id}:ARMED')

            max_cycles=1 if test_one_cycle else int(self.config.get('max_cycles') or 0)
            while not self._cancelled():
                if max_cycles and self.counters['cycles']>=max_cycles:break
                r=self._run_one_cycle(hwnd)
                if not r.get('ok'):
                    reason=str(r.get('reason') or 'FATAL_RUNTIME_ERROR')
                    if reason=='USER_STOP':break
                    # V1.7.14 fallback contract: even if an older/read-side branch
                    # surfaces a pure read-instability reason, AutoBoss does not
                    # terminate the session. No uncertain item action is executed;
                    # continue to the next cycle after a short bounded yield.
                    if reason in ('TOOLTIP_UNRESOLVED','FINAL6_UNRESOLVED','FINAL6_UNRESOLVED_ITEMS'):
                        self._domain('READ_UNSTABLE_SESSION_CONTINUE',reason=reason,cycle=self.counters.get('cycles'),destructive_input_count=0)
                        time.sleep(.12)
                        continue
                    recoverable=reason in ('NAVIGATION_TEMPORARY_FAILURE','NAV_DESTINATION_NOT_CONFIRMED','INVENTORY_NOT_VISIBLE','PLAYER_BAG_OWNER_UNRESOLVED','PLAYER_BAG_TEMPORARILY_UNRESOLVED','PLAYER_BAG_OPEN_NOT_CONFIRMED','PLAYER_BAG_OPEN_COOLDOWN','INPUT_TARGET_DRIFT','BOSS_CYCLE_NO_GREEN_LOOT_AT_POINT_B')
                    self._error(reason,'AutoBossSessionController',r,recoverable); return
            if self._cancelled():self.state='STOPPED'; self._domain('AUTOBOSS_STOPPED',once_key=f'{self.session_id}:STOPPED',reason=self.cancellation.snapshot()[2])
            else:self.state='SESSION_COMPLETE' if test_one_cycle else 'STOPPED'; self._domain('AUTOBOSS_SESSION_COMPLETE',once_key=f'{self.session_id}:COMPLETE',cycles=self.counters['cycles'])
        except Exception as e:
            self._error('FATAL_RUNTIME_ERROR','AutoBossSessionController',{'exception_type':type(e).__name__,'exception_message':str(e)},False)
        finally:
            self.running=False; self._set_running_flag(False); self.log_writer.flush()

    def status(self):
        points=self.config.get('points') or {}; profiles=self.config.get('container_profiles') or {}; setup=self._container_setup()
        with self._route_record_lock:
            route_record_public={k:v for k,v in self._route_record_state.items() if k not in ('steps','last_click_mono','start_scene_signature')}
        player_ready=bool(profiles.get(CONTAINER_PLAYER)); storage_ready=bool(profiles.get(CONTAINER_STORAGE)); pair_pass=bool(setup.get('pair_test_pass'))
        if not player_ready and str(self.config.get('mode')).upper()=='STORE': setup_public_state='CONTAINER_SETUP_REQUIRED'
        elif not player_ready: setup_public_state='PLAYER_BAG_AUTO_RUNTIME'
        elif str(self.config.get('mode')).upper()=='STORE' and not storage_ready: setup_public_state='CONTAINER_SETUP_REQUIRED'
        elif str(self.config.get('mode')).upper()=='STORE' and not pair_pass: setup_public_state='CONTAINER_PAIR_TEST_REQUIRED'
        else: setup_public_state='CONTAINER_SETUP_READY'
        q=[]
        for item in self.last_loot_queue:
            q.append({'id':item.queue_id,'logical_id':item.logical_id,'footprint':item.footprint,'filter':item.verdict,'action':item.disposition,'status':item.status})
        return {
            'ok':True,'build_id':BUILD_ID,'running':self.is_running(),'state':self.state,'session_id':self.session_id,
            'session_generation':self.session_generation,'cycle':self.cycle_number,'ctrl_f_sent':bool(self.arm.ctrl_f_sent),'ingame_auto_armed':bool(self.arm.armed_for_session),
            'points':{k:{'ready':len((v or {}).get('client_point') or [])==2,'client_point':(v or {}).get('client_point')} for k,v in points.items()},
            'routes':{k:{'ready':self._route_ready(k),'step_count':len((self._route_config(k) or {}).get('steps') or []),'record_mode':(self._route_config(k) or {}).get('record_mode')} for k in ('A_TO_B','B_TO_A')},
            'route_recording':route_record_public,
            'mode':self.config.get('mode'),'ingame_auto_setup_confirmed':bool(self.config.get('ingame_auto_setup_confirmed')),
            'boss_wait_sec':float(self.config.get('boss_wait_sec') or BOSS_LIVE_BAG_WAIT_SEC),'bag_runtime_policy':str(self.config.get('bag_runtime_policy') or 'OPEN_DURING_BOSS_CONTINUOUS_SCAN'),'bag_hotkey_policy':str(self.config.get('bag_hotkey_policy') or 'FOCUS_CLIENT_CLICK_THEN_FOREGROUND_QF4'),
            'container_profiles':{CONTAINER_PLAYER:player_ready,CONTAINER_STORAGE:storage_ready},
            'container_setup':{'state':setup_public_state,'runtime_state':setup.get('state'),'player_bag_status':'READY' if player_ready else 'CHƯA QUÉT','storage_status':'READY' if storage_ready else 'CHƯA QUÉT','pair_test_pass':pair_pass,'pair_status':'PASS' if pair_pass else ('CHƯA KIỂM TRA' if player_ready and storage_ready else 'CẦN THIẾT LẬP'),'last_test':setup.get('last_test'),'last_action':setup.get('last_action')},
            'loot_queue':q,'loot_count':len(q),'counters':dict(self.counters),'bag_registry_generation':self.bag_registry.generation,
            'bag_occupied':(self._bag_snapshot or {}).get('occupied_count'),'bag_free':(self._bag_snapshot or {}).get('free_count'),'bag_baseline_location':self._bag_baseline_location,
            'storage_known_count':len(self.storage_registry.items),'last_error':self.last_error,'last_event':self.last_event,'container_resolution':self.last_container_resolution,
            'preflight_config_ready':bool(((len(((points.get('A') or {}).get('client_point') or []))==2 and len(((points.get('B') or {}).get('client_point') or []))==2) or (self._route_ready('A_TO_B') and self._route_ready('B_TO_A'))) and self.config.get('ingame_auto_setup_confirmed') and (player_ready or str(self.config.get('mode')).upper()!='STORE') and (str(self.config.get('mode')).upper()!='STORE' or (storage_ready and pair_pass))),
            'engine':'AUTOBOSS_V1_5_3_CLIENT_FOCUS_LOOT_TRUTH_ROOTFIX','ctrl_f_policy':'EXACTLY_ONCE_PER_SESSION_NO_STOP_TOGGLE','key1_policy':'EXACTLY_ONCE_PER_CYCLE',
            'loot_discovery_container':CONTAINER_PLAYER,'title_ocr_container_owner':False,'container_owner_authority':'GUIDED_PROFILE_LEARNING_PLUS_RELATIVE_GEOMETRY_STRUCTURE_PAIRWISE','left_right_hardcoded':False,
        }
