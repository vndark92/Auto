@echo off
setlocal
cd /d "%~dp0"
py -3.12 PADDLEOCR_SETUP.py
set "RC=%ERRORLEVEL%"
echo.
pause
exit /b %RC%
