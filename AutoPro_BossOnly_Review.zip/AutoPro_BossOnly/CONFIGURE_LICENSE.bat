@echo off
setlocal
cd /d "%~dp0"
title Auto Pro By Eric - License Setup
py -3.12 AutoProByEric_LicenseGuard_v1.py --setup-gui
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" (
  echo.
  echo LICENSE READY.
) else (
  echo.
  echo LICENSE SETUP NOT COMPLETED.
)
pause
exit /b %RC%
