"""Conservative start gates; no fake confirmation of DirectInput/PostMessage acceptance."""

# The existing legacy Chest/Roll/Boss engines are NOT proven non-intrusive:
# even though individual click/key paths can use PostMessage, tooltip capture,
# item drag and native focus/cursor helpers remain. Fail closed.
UNVERIFIED_BACKGROUND_AUTOMATIONS = frozenset(('CHEST', 'ROLL', 'BOSS'))


def background_start_gate(module, input_mode):
    if str(input_mode or 'Auto') == 'Background' and str(module or '').upper() in UNVERIFIED_BACKGROUND_AUTOMATIONS:
        return {
            'ok': False, 'reason': 'BACKGROUND_ENGINE_UNVERIFIED', 'safe_pause': True,
            'note': 'Auto Chest/Roll/Boss chưa bảo đảm không chiếm chuột; cần test và thay thế toàn bộ thao tác con trỏ/tooltip trên Windows.',
        }
    return {'ok': True, 'reason': 'START_GATE_READY'}
