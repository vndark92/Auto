"""Auto Pro By Eric V12.1 — centralized runtime proof artifact ownership.

All subsystems write under logs/proof/<subsystem>. Build/revision identity belongs
in metadata, never in version-numbered directory names. This module does not
change perception/action logic; it only owns proof paths and metadata sidecars.
"""
from __future__ import annotations
import json, time
from pathlib import Path

PROOF_ARTIFACT_MANAGER_VERSION = 'PROOF_ARTIFACT_MANAGER_V12_1'

class ProofArtifactManager:
    SUBSYSTEMS = ('foreground','skill_value','option_vision','resume_drop','filter','storage')
    def __init__(self, log_root, *, build_id, subsystem_revisions=None):
        self.log_root = Path(log_root)
        self.root = self.log_root / 'proof'
        self.build_id = str(build_id)
        self.subsystem_revisions = dict(subsystem_revisions or {})

    def subdir(self, subsystem):
        name = str(subsystem or '').strip().lower()
        if name not in self.SUBSYSTEMS:
            raise ValueError(f'UNKNOWN_PROOF_SUBSYSTEM:{name}')
        p = self.root / name
        p.mkdir(parents=True, exist_ok=True)
        return p

    def metadata(self, subsystem, *, logical_item_id=None, timestamp=None, extra=None):
        subsystem = str(subsystem or '').strip().lower()
        data = {
            'build_id': self.build_id,
            'subsystem': subsystem,
            'subsystem_revision': self.subsystem_revisions.get(subsystem),
            'logical_item_id': logical_item_id,
            'timestamp': float(timestamp if timestamp is not None else time.time()),
            'proof_manager_version': PROOF_ARTIFACT_MANAGER_VERSION,
        }
        if isinstance(extra, dict):
            data.update(extra)
        return data

    def record_artifact(self, artifact_path, subsystem, *, logical_item_id=None, extra=None):
        try:
            p = Path(artifact_path)
            meta = self.metadata(subsystem, logical_item_id=logical_item_id, extra=extra)
            mp = p.with_suffix(p.suffix + '.meta.json')
            mp.write_text(json.dumps(meta, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
            return str(mp)
        except Exception:
            return None

    def save_image(self, subsystem, filename, image, *, logical_item_id=None, extra=None):
        if image is None or not hasattr(image, 'save'):
            return None
        p = self.subdir(subsystem) / str(filename)
        image.save(p)
        self.record_artifact(p, subsystem, logical_item_id=logical_item_id, extra=extra)
        return str(p)

    def legacy_dirs(self):
        return [
            self.log_root / 'v110_foreground_proof',
            self.log_root / 'v113_resume_drop_proof',
            self.log_root / 'v116_skill_value_proof',
            self.log_root / 'v120_vision_proof',
        ]
