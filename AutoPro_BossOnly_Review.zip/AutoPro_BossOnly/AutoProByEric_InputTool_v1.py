from __future__ import annotations

from pathlib import Path
from AutoProByEric_ConfigStore_v1715 import save_json as _safe_save_json, load_json as _safe_load_json
import atexit
import ctypes
from ctypes import wintypes
import json
import os
import threading
import time

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "input_tool.json"

ALLOWED_KEYS = tuple(f"F{i}" for i in range(3, 10))
DEFAULT_CONFIG = {
    "selected_keys": ["F5", "F6", "F7"],
    "delay_ms": 300,
    "continuous": True,
}


def _atomic_json_write(path: Path, payload: dict) -> None:
    _safe_save_json(path,payload)


def _normalize_config(payload=None) -> dict:
    src = dict(DEFAULT_CONFIG)
    if isinstance(payload, dict):
        src.update(payload)
    raw = src.get("selected_keys") or []
    if isinstance(raw, str):
        raw = [raw]
    selected = []
    for key in ALLOWED_KEYS:
        if key in {str(x or "").upper().strip() for x in raw}:
            selected.append(key)
    try:
        delay = int(src.get("delay_ms", 300))
    except Exception:
        delay = 300
    delay = min(5000, max(50, delay))
    return {
        "selected_keys": selected,
        "delay_ms": delay,
        "continuous": bool(src.get("continuous", True)),
    }


class InputToolController:
    """Independent F3-F9 SendInput sequencer.

    The controller deliberately owns no AutoRoll/AutoChest/AutoBoss state.  A caller
    supplies the real JX1 key sender, the current target HWND provider, and license
    status callback.  F10/F11 are optional Windows global Start/Stop hotkeys.
    """

    HOTKEY_ID_START = 0xA510
    HOTKEY_ID_STOP = 0xA511
    VK_F10 = 0x79
    VK_F11 = 0x7A
    WM_HOTKEY = 0x0312

    def __init__(self, send_key_once, target_provider, license_checker, start_guard=None):
        self._send_key_once = send_key_once
        self._target_provider = target_provider
        self._license_checker = license_checker
        self._start_guard = start_guard
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread = None
        self._running = False
        self._reason = "STOPPED"
        self._target_hwnd = 0
        self._last_key = ""
        self._sent_count = 0
        self._cycle_count = 0
        self._skipped_count = 0
        self._last_error = ""
        self._hotkeys_ready = False
        self._hotkey_error = ""
        self._hotkey_thread = None
        self._load_or_create_config()
        self._start_hotkey_thread()
        atexit.register(self.shutdown)

    def _load_or_create_config(self):
        cfg = None
        if CONFIG_PATH.exists():
            try:
                data = _safe_load_json(CONFIG_PATH)
                if isinstance(data, dict):
                    cfg = data
            except Exception:
                cfg = None
        cfg = _normalize_config(cfg)
        self._cfg = cfg
        if not CONFIG_PATH.exists():
            try:
                _atomic_json_write(CONFIG_PATH, cfg)
            except Exception:
                pass

    def config(self) -> dict:
        with self._lock:
            return dict(self._cfg)

    def save_config(self, payload) -> dict:
        cfg = _normalize_config(payload)
        if not cfg["selected_keys"]:
            return {"ok": False, "reason": "INPUT_TOOL_NO_KEY_SELECTED", **self.status()}
        try:
            _atomic_json_write(CONFIG_PATH, cfg)
        except Exception as e:
            return {"ok": False, "reason": "INPUT_TOOL_CONFIG_SAVE_FAILED", "error": str(e), **self.status()}
        with self._lock:
            self._cfg = cfg
        return {"ok": True, **self.status()}

    def status(self) -> dict:
        with self._lock:
            return {
                "running": bool(self._running),
                "reason": str(self._reason),
                "target_hwnd": int(self._target_hwnd or 0),
                "last_key": str(self._last_key or ""),
                "sent_count": int(self._sent_count),
                "cycle_count": int(self._cycle_count),
                "skipped_count": int(self._skipped_count),
                "last_error": str(self._last_error or ""),
                "hotkeys_ready": bool(self._hotkeys_ready),
                "hotkey_error": str(self._hotkey_error or ""),
                **dict(self._cfg),
            }

    def start(self, hwnd=0) -> dict:
        if not bool(self._license_checker()):
            return {"ok": False, "reason": "LICENSE_NOT_ACTIVE", **self.status()}
        try:
            hwnd = int(hwnd or self._target_provider() or 0)
        except Exception:
            hwnd = 0
        if hwnd <= 0:
            return {"ok": False, "reason": "INPUT_TOOL_NO_CLIENT", **self.status()}
        # Both the UI START and the Windows F10 hotkey reach this gate.
        # Hotkeys must never bypass per-window/global input ownership.
        if self._start_guard is not None:
            try:
                gate = self._start_guard(hwnd)
            except Exception as exc:
                gate = {'ok': False, 'reason': 'INPUT_TOOL_GATE_EXCEPTION', 'error': str(exc)}
            if not isinstance(gate, dict) or not gate.get('ok'):
                gate = gate if isinstance(gate, dict) else {'reason': 'INPUT_TOOL_GATE_FAILED'}
                return {**self.status(), **gate, 'ok': False}
        with self._lock:
            if self._running and self._thread and self._thread.is_alive():
                return {"ok": True, "reason": "ALREADY_RUNNING", **self.status()}
            cfg = dict(self._cfg)
            if not cfg.get("selected_keys"):
                return {"ok": False, "reason": "INPUT_TOOL_NO_KEY_SELECTED", **self.status()}
            self._stop.clear()
            self._running = True
            self._reason = "RUNNING"
            self._target_hwnd = hwnd
            self._last_error = ""
            self._thread = threading.Thread(
                target=self._run_loop,
                args=(hwnd, cfg),
                name="AutoProInputTool",
                daemon=True,
            )
            self._thread.start()
        return {"ok": True, **self.status()}

    def stop(self, reason="MANUAL_STOP") -> dict:
        self._stop.set()
        with self._lock:
            if self._running:
                self._reason = str(reason or "MANUAL_STOP")
            else:
                self._reason = str(reason or self._reason or "STOPPED")
        return {"ok": True, **self.status()}

    def _finish(self, reason, error=""):
        with self._lock:
            self._running = False
            self._reason = str(reason or "STOPPED")
            self._last_error = str(error or "")

    def _run_loop(self, hwnd: int, cfg: dict):
        keys = list(cfg.get("selected_keys") or [])
        delay_sec = max(0.05, int(cfg.get("delay_ms", 300)) / 1000.0)
        continuous = bool(cfg.get("continuous", True))
        try:
            while not self._stop.is_set():
                if not bool(self._license_checker()):
                    self._finish("LICENSE_NOT_ACTIVE")
                    return
                for idx, key in enumerate(keys):
                    if self._stop.is_set():
                        self._finish(self._reason or "MANUAL_STOP")
                        return
                    if not bool(self._license_checker()):
                        self._finish("LICENSE_NOT_ACTIVE")
                        return
                    try:
                        result = self._send_key_once(hwnd, key)
                    except Exception as e:
                        self._finish("INPUT_TOOL_SEND_EXCEPTION", str(e))
                        return
                    if not isinstance(result, dict) or not result.get("ok"):
                        reason = "INPUT_TOOL_SEND_FAILED"
                        error = ""
                        if isinstance(result, dict):
                            reason = str(result.get("reason") or reason)
                            error = str(result.get("error") or "")
                        self._finish(reason, error)
                        return
                    with self._lock:
                        if result.get('skipped'):
                            self._skipped_count += 1
                        else:
                            self._last_key = key
                            self._sent_count += 1
                    is_last = idx == (len(keys) - 1)
                    if (not is_last) or continuous:
                        if self._stop.wait(delay_sec):
                            self._finish(self._reason or "MANUAL_STOP")
                            return
                with self._lock:
                    self._cycle_count += 1
                if not continuous:
                    self._finish("ONE_SHOT_COMPLETE")
                    return
            self._finish(self._reason or "MANUAL_STOP")
        except Exception as e:
            self._finish("INPUT_TOOL_LOOP_EXCEPTION", str(e))

    def _start_hotkey_thread(self):
        if os.name != "nt":
            return
        self._hotkey_thread = threading.Thread(
            target=self._hotkey_loop,
            name="AutoProInputToolHotkeys",
            daemon=True,
        )
        self._hotkey_thread.start()

    def _hotkey_loop(self):
        try:
            user32 = ctypes.windll.user32
            ok_start = bool(user32.RegisterHotKey(None, self.HOTKEY_ID_START, 0x4000, self.VK_F10))
            ok_stop = bool(user32.RegisterHotKey(None, self.HOTKEY_ID_STOP, 0x4000, self.VK_F11))
            with self._lock:
                self._hotkeys_ready = bool(ok_start and ok_stop)
                if not self._hotkeys_ready:
                    self._hotkey_error = "REGISTER_HOTKEY_FAILED"
            if not (ok_start and ok_stop):
                try:
                    user32.UnregisterHotKey(None, self.HOTKEY_ID_START)
                    user32.UnregisterHotKey(None, self.HOTKEY_ID_STOP)
                except Exception:
                    pass
                return
            msg = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message != self.WM_HOTKEY:
                    continue
                if int(msg.wParam) == self.HOTKEY_ID_START:
                    try:
                        self.start(0)
                    except Exception:
                        pass
                elif int(msg.wParam) == self.HOTKEY_ID_STOP:
                    try:
                        self.stop("F11_STOP")
                    except Exception:
                        pass
        except Exception as e:
            with self._lock:
                self._hotkeys_ready = False
                self._hotkey_error = str(e)
        finally:
            if os.name == "nt":
                try:
                    user32 = ctypes.windll.user32
                    user32.UnregisterHotKey(None, self.HOTKEY_ID_START)
                    user32.UnregisterHotKey(None, self.HOTKEY_ID_STOP)
                except Exception:
                    pass

    def shutdown(self):
        self.stop("APP_EXIT")


__all__ = ["InputToolController", "ALLOWED_KEYS", "DEFAULT_CONFIG"]
