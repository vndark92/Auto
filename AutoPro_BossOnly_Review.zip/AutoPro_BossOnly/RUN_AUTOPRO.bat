@echo off
cd /d "%~dp0"
".venv-onefile\Scripts\python.exe" boss_only_app.py
pause
