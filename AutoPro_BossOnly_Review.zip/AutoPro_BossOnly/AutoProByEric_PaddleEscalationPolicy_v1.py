from __future__ import annotations

"""Adaptive PaddleOCR escalation policy for Auto Pro By Eric.

Paddle is a slow NAME/FAMILY rescue engine.  It is not numeric authority and it
must not be paid on every tooltip when the fast Tesseract + ClosedWorld path has
already produced enough authoritative evidence.

Safety contract:
- PASS is always escalated to Paddle before KEEP.
- UNKNOWN is always escalated.
- FAIL_VALUE_CONFIRMED may stay on the fast path only when the failed target is
  visibly present in Tesseract text as well (Paddle cannot change numeric truth).
- FAIL_ABSENT_CONFIRMED may stay on the fast path only when ClosedWorld already
  excluded the target and Tesseract has no near-target hint in any of six rows.
  Any lexical hint causes Paddle escalation.  This preserves the V1.7.8
  false-absence veto while avoiding Paddle on clearly unrelated options.
"""

import difflib
import re
import unicodedata

POLICY_VERSION = "ADAPTIVE_PADDLE_ESCALATION_V1_7_10"
ABSENCE_HINT_SCORE = 0.55
VALUE_CONFIRM_SCORE = 0.58


def _norm(text):
    s = unicodedata.normalize("NFKD", str(text or ""))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower().replace("đ", "d")
    s = re.sub(r"[^a-z0-9]+", " ", s).strip()
    return s


def lexical_score(raw, target):
    """Conservative cheap hint score, deliberately not Filter authority."""
    a = _norm(raw)
    b = _norm(target)
    if not a or not b:
        return 0.0
    direct = difflib.SequenceMatcher(None, a, b).ratio()
    # Long OCR rows can contain a split neighbour/value.  Compare a bounded
    # sliding window against the target too, but never promote this score into
    # PASS/FAIL; it only decides whether Paddle rescue is required.
    if len(a) > len(b) + 6:
        span = max(len(b), 4)
        step = max(1, span // 5)
        partial = 0.0
        for i in range(0, max(1, len(a) - span + 1), step):
            partial = max(partial, difflib.SequenceMatcher(None, a[i:i+span], b).ratio())
        direct = max(direct, partial)
    return float(direct)


def _row_texts(scans):
    out = []
    for scan in scans or []:
        if not isinstance(scan, dict) or not scan.get("complete"):
            continue
        rows = list(scan.get("row_evidence") or [])
        for row in rows:
            if not isinstance(row, dict):
                continue
            out.append(str(row.get("tesseract_text") or row.get("text") or ""))
    return out


def _max_target_hint(scans, target):
    vals = [lexical_score(t, target) for t in _row_texts(scans)]
    return max(vals) if vals else 0.0


def _all_profiles_authoritative_fail(profile_results):
    prs = [p for p in (profile_results or []) if isinstance(p, dict) and p.get("enabled", True)]
    if not prs:
        return False
    return all(
        str(p.get("decision") or "").upper() == "FAIL"
        and str(p.get("reject_authority") or "").upper() == "AUTHORITATIVE_REJECT"
        for p in prs
    )


def evaluate(profile_results, scans):
    """Return whether the slow Paddle stage is needed and why."""
    prs = [p for p in (profile_results or []) if isinstance(p, dict) and p.get("enabled", True)]
    if not prs:
        return {"policy": POLICY_VERSION, "escalate": True, "reason": "NO_PROFILE_RESULT"}

    # KEEP is high-value/destructive-policy sensitive: always verify with Paddle.
    if any(str(p.get("decision") or "").upper() == "PASS" for p in prs):
        return {"policy": POLICY_VERSION, "escalate": True, "reason": "PASS_REQUIRES_PADDLE_CONFIRM"}

    if any(str(p.get("decision") or "").upper() not in ("FAIL",) for p in prs):
        return {"policy": POLICY_VERSION, "escalate": True, "reason": "UNKNOWN_OR_PENDING_REQUIRES_PADDLE"}

    if not _all_profiles_authoritative_fail(prs):
        return {"policy": POLICY_VERSION, "escalate": True, "reason": "NON_AUTHORITATIVE_FAIL_REQUIRES_PADDLE"}

    diagnostics = []
    for p in prs:
        rules = list(p.get("rule_results") or [])
        if not rules:
            return {"policy": POLICY_VERSION, "escalate": True, "reason": "FAIL_WITHOUT_RULE_EVIDENCE"}
        # AND profile returns immediately on its first authoritative failed rule.
        failed = next((r for r in rules if str(r.get("state") or "").upper().startswith("FAIL")), None)
        if not failed:
            return {"policy": POLICY_VERSION, "escalate": True, "reason": "FAILED_PROFILE_WITHOUT_FAILED_RULE"}
        target = str(failed.get("option_name") or "").strip()
        state = str(failed.get("state") or "").upper()
        hint = _max_target_hint(scans, target)
        diagnostics.append({"profile_id": p.get("profile_id"), "target": target, "state": state, "tesseract_hint": round(hint, 4)})

        if state == "FAIL_VALUE_CONFIRMED":
            # Target identity already exists in ClosedWorld and numeric authority
            # is independent of Paddle.  Require a second cheap textual witness.
            if hint < VALUE_CONFIRM_SCORE:
                return {
                    "policy": POLICY_VERSION, "escalate": True,
                    "reason": "VALUE_FAIL_TEXT_WITNESS_WEAK", "diagnostics": diagnostics,
                }
            continue

        if state == "FAIL_ABSENT_CONFIRMED":
            # This is exactly the V1.7.8 danger zone.  Any Tesseract resemblance
            # to the supposedly absent target forces Paddle as a tie-breaker.
            if hint >= ABSENCE_HINT_SCORE:
                return {
                    "policy": POLICY_VERSION, "escalate": True,
                    "reason": "ABSENCE_HAS_TESSERACT_TARGET_HINT", "diagnostics": diagnostics,
                }
            continue

        return {
            "policy": POLICY_VERSION, "escalate": True,
            "reason": "UNSUPPORTED_FAIL_STATE_REQUIRES_PADDLE", "diagnostics": diagnostics,
        }

    return {
        "policy": POLICY_VERSION,
        "escalate": False,
        "reason": "FAST_AUTHORITATIVE_REJECT_SAFE",
        "diagnostics": diagnostics,
        "absence_hint_score": ABSENCE_HINT_SCORE,
        "value_confirm_score": VALUE_CONFIRM_SCORE,
    }
