from __future__ import annotations
from pathlib import Path
from collections import defaultdict
import argparse, difflib, json, os, re, unicodedata

import cv2
import numpy as np
from PIL import Image
import pytesseract
from AutoProByEric_OptionRegistry_v1 import option_semantics, option_unit_type

try:
    from AutoProByEric_PaddleOCRHybrid_v1 import recognize as paddleocr_recognize, engine_status as paddleocr_engine_status
except Exception:
    paddleocr_recognize=None
    def paddleocr_engine_status():
        return {"available":False,"initialized":False,"last_error":"HYBRID_MODULE_IMPORT_FAILED"}

ROOT = Path(__file__).resolve().parent
DICT_PATH = ROOT / "AutoProByEric_OptionDictionary_v0.1.json"
KNOW_PATH = ROOT / "AutoProByEric_HybridV2_Knowledge_v1.5.json"
BUNDLED_TESSDATA = ROOT / "runtime" / "tessdata"

# Use bundled language data when present. The Tesseract executable can still be
# external during Stage 17, but ENG/VIE traineddata now travels with Auto Pro.
if BUNDLED_TESSDATA.exists():
    os.environ["TESSDATA_PREFIX"] = str(BUNDLED_TESSDATA)

OPTION_DB = json.loads(DICT_PATH.read_text(encoding="utf-8"))
KNOW = json.loads(KNOW_PATH.read_text(encoding="utf-8"))

UNIQUE_UNITS = {}
for k, v in KNOW.get("unique_unit_by_group_option", {}).items():
    gid, name = k.split("||", 1)
    UNIQUE_UNITS[(gid, name)] = v

AMBIGUOUS_UNITS = {}
for k, v in KNOW.get("ambiguous_unit_by_group_option", {}).items():
    gid, name = k.split("||", 1)
    AMBIGUOUS_UNITS[(gid, name)] = list(v)

VALUE_RANGES = {}
for k, v in KNOW.get("verified_value_ranges", {}).items():
    gid, name, unit = k.split("||", 2)
    VALUE_RANGES[(gid, name, unit)] = v


def _tessdata_config() -> str:
    if BUNDLED_TESSDATA.exists():
        return f'--tessdata-dir "{BUNDLED_TESSDATA}"'
    return ""


def available_ocr_languages():
    """Union bundled tessdata and the Windows/system Tesseract installation.

    v6.2 could silently downgrade to ENG when the bundled --tessdata-dir query
    failed even though the system installation had VIE.  v6.3 probes both.
    """
    langs = set()
    configs = []
    bundled = _tessdata_config()
    if bundled:
        configs.append(bundled)
    configs.append("")
    for cfg in configs:
        try:
            langs.update(pytesseract.get_languages(config=cfg))
        except Exception as e:
            _record_ocr_error(f"LANGS|{cfg or 'SYSTEM'}", e)
    ordered=[]
    if "vie" in langs: ordered.append("vie")
    if "eng" in langs: ordered.append("eng")
    return ordered or sorted(langs)[:1] or ["eng"]


def _preferred_lang() -> str:
    langs = available_ocr_languages()
    if "vie" in langs and "eng" in langs:
        return "vie+eng"
    if "vie" in langs:
        return "vie"
    if "eng" in langs:
        return "eng"
    return langs[0]


OCR_ERRORS = []

def _record_ocr_error(tag, exc):
    try:
        OCR_ERRORS.append(f"{tag}: {type(exc).__name__}: {exc}")
        if len(OCR_ERRORS) > 24:
            del OCR_ERRORS[:-24]
    except Exception:
        pass


def safe_ocr_string(image, config="--psm 7"):
    """Retry individual Windows Tesseract language models and keep errors."""
    available = available_ocr_languages()
    langs = []
    for lang in ("vie+eng", "vie", "eng"):
        parts = lang.split("+")
        if all(p in available for p in parts) and lang not in langs:
            langs.append(lang)
    if not langs:
        langs = [_preferred_lang()]

    bundled = " ".join(x for x in (_tessdata_config(), config) if x).strip()
    plain = str(config or "").strip()
    configs = [bundled]
    if plain and plain != bundled:
        configs.append(plain)

    for cfg in configs:
        for lang in langs:
            try:
                text = pytesseract.image_to_string(
                    image, lang=lang, config=cfg, timeout=1.8
                ).strip()
                if text:
                    return [(lang, text)]
            except Exception as e:
                _record_ocr_error(f"{lang}|{cfg}", e)
    return []


def norm_text(s: str) -> str:
    s = str(s).lower().replace("đ", "d").replace("–", "-").replace("—", "-").replace("−", "-")
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = re.sub(r"[^a-z0-9 +%\-]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


# ---------------------------------------------------------------------------
# Robust LAST-6 segmentation v2.8
# ---------------------------------------------------------------------------

def _cv_imread_unicode(path, flags=cv2.IMREAD_COLOR):
    """Unicode-safe OpenCV loader for Windows paths."""
    try:
        buf = np.fromfile(str(path), dtype=np.uint8)
        if buf.size == 0:
            return None
        return cv2.imdecode(buf, flags)
    except Exception:
        return None


def _cv_imwrite_unicode(path, image, ext=None):
    """Unicode-safe OpenCV writer for Windows paths."""
    try:
        p = Path(path)
        suffix = ext or p.suffix or ".png"
        ok, encoded = cv2.imencode(suffix, image)
        if not ok:
            return False
        encoded.tofile(str(p))
        return True
    except Exception:
        return False


def _blue_gray_mask_bgr(img):
    """Hard OCR mask for the REAL JX1 option colors only.

    Runtime contract v7.0:
      * KEEP blue/cyan option glyphs.
      * KEEP the darker neutral-gray option glyphs.
      * REMOVE white tooltip text, including white [min-max] ranges.
      * REMOVE the anti-aliased halo around white glyphs before OCR.

    The halo veto is important because after rasterization a white glyph can
    leave mid-gray edge pixels that would otherwise look like legitimate gray
    option text.
    """
    if img is None or getattr(img, "size", 0) == 0:
        return np.zeros((0, 0), dtype=np.uint8)

    b, g, r = cv2.split(img)
    bi, gi, ri = b.astype(np.int16), g.astype(np.int16), r.astype(np.int16)
    mx = np.maximum.reduce([bi, gi, ri])
    mn = np.minimum.reduce([bi, gi, ri])
    chroma = mx - mn

    # Real blue/cyan option text.
    blue = (
        (bi >= 76) &
        ((bi - ri) >= 18) &
        (bi + 12 >= gi) &
        (mx >= 88)
    )

    # Real gray option text is visibly darker than the white labels/ranges.
    # Cap the neutral band aggressively so white cores cannot pass as gray.
    gray = (
        (chroma <= 20) &
        (mx >= 76) &
        (mx <= 172)
    )

    # White core detector. The live tooltip uses ~248-255 neutral white for
    # labels and bracketed reference ranges.
    white_core = (mn >= 205) & (chroma <= 30)

    # Expand the veto around white cores to erase anti-aliased gray fringes.
    # A 3x3 dilation removes the raster halo without touching neighboring
    # blue/gray option glyphs that are separated by normal character spacing.
    wc = (white_core.astype(np.uint8) * 255)
    white_halo = cv2.dilate(wc, np.ones((3,3), np.uint8), iterations=1) > 0

    keep = (blue | gray) & (~white_halo)
    return keep.astype(np.uint8) * 255


def _blue_gray_mask_rgb(arr):
    """RGB-array companion used by per-line OCR preprocessors."""
    if arr is None or getattr(arr, "size", 0) == 0:
        return np.zeros((0, 0), dtype=np.uint8)
    return _blue_gray_mask_bgr(cv2.cvtColor(arr, cv2.COLOR_RGB2BGR))


def _blue_gray_clean_rgb(arr, white_background=False):
    """Remove every non BLUE/GRAY pixel before OCR."""
    mask = _blue_gray_mask_rgb(arr)
    if arr.size == 0:
        return arr, mask
    fill = 255 if white_background else 0
    clean = np.full_like(arr, fill, dtype=np.uint8)
    clean[mask > 0] = arr[mask > 0]
    return clean, mask


def option_mask(img):
    """v6.9 compatibility alias: BLUE + GRAY only, WHITE forbidden."""
    return _blue_gray_mask_bgr(img)


def _bands(signal, threshold, gap=1):
    active = signal > threshold
    out, start, last = [], None, None
    for i, v in enumerate(active):
        if v:
            if start is None:
                start = i
            last = i
        elif start is not None and i - last > gap:
            out.append((start, last))
            start = None
    if start is not None:
        out.append((start, last))
    return out


def _mask_strategies(img):
    """v6.9: row segmentation sees BLUE/GRAY glyphs only.

    Old gray/max/top-hat sweeps could resurrect white tooltip text, so they are
    deliberately removed from the live option-row segmentation path.
    """
    mask = _blue_gray_mask_bgr(img)
    base = mask > 0
    strategies = [("blue_gray_only", base)]

    # Morphological variants are derived ONLY from the same allowed-color mask;
    # they improve tiny bitmap continuity without reintroducing white pixels.
    kx = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 1))
    ky = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 2))
    strategies.append(("blue_gray_close_x", cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kx) > 0))
    strategies.append(("blue_gray_close_y", cv2.morphologyEx(mask, cv2.MORPH_CLOSE, ky) > 0))
    return strategies

def _rows_from_mask(mask, gap=1):
    mask = mask.astype(np.uint8)
    h, w = mask.shape
    x0, x1 = int(w * 0.02), int(w * 0.985)
    roi = mask[:, x0:x1]
    signal = (roi > 0).sum(axis=1)
    # Scale threshold with crop width; keep it low enough for short options.
    threshold = max(5, int((x1 - x0) * 0.022))
    raw = _bands(signal, threshold=threshold, gap=int(gap))
    rows = []
    max_h = max(24, int(h * 0.075))
    min_pixels = max(12, int(w * 0.03))
    min_span = max(30, int(w * 0.085))

    for a, b in raw:
        hh = b - a + 1
        if not (3 <= hh <= max_h):
            continue
        sub = roi[a:b + 1]
        ys, xs = np.where(sub > 0)
        if len(xs) < min_pixels:
            continue
        span = int(xs.max() - xs.min() + 1)
        if span < min_span:
            continue
        peak = int(signal[a:b + 1].max())
        rows.append((a, b, span, peak))
    return rows


def _repair_physical_option_rows_v165(mask, rows):
    """Geometry-only repair for real JX1 Final6 option rows.

    Repairs two failures observed in the attached runtime proof:
      * ultra-thin stray blue/gray band above the true option block;
      * two adjacent option rows fused into one over-tall band.

    It never invents OCR text, values, units, options, PASS or FAIL.
    """
    if not rows:
        return rows

    m = mask.astype(np.uint8)
    h, w = m.shape
    x0, x1 = int(w * 0.02), int(w * 0.985)
    roi = m[:, x0:x1]
    signal = (roi > 0).sum(axis=1)

    heights = [int(b - a + 1) for a, b, _, _ in rows]
    plausible = [hh for hh in heights if 5 <= hh <= 18]
    med_h = float(np.median(plausible if plausible else heights)) if heights else 10.0
    med_h = max(4.0, med_h)

    min_pixels = max(12, int(w * 0.03))
    min_span = max(30, int(w * 0.085))
    repaired = []

    for a, b, span, peak in rows:
        a, b = int(a), int(b)
        hh = int(b - a + 1)

        # Remove only a strong low-height outlier relative to this tooltip.
        if hh < max(4.0, med_h * 0.55):
            continue

        split_done = False
        if hh >= max(18.0, med_h * 1.65):
            side_guard = max(5, int(round(hh * 0.28)))
            lo = a + side_guard
            hi = b - side_guard

            if lo <= hi:
                center = (a + b) / 2.0
                valley, _, cut = min(
                    (int(signal[y]), abs(float(y) - center), int(y))
                    for y in range(lo, hi + 1)
                )
                peak_local = float(max(signal[a:b + 1])) if b >= a else 1.0
                left_h = int(cut - a + 1)
                right_h = int(b - cut)

                # V1.7.3: real JX1 glyph rows can be 1-2px taller when
                # Vietnamese accents / anti-aliasing touch the inter-line band.
                # V1.7.2 used 1.55x and rejected the observed 13px + 10px split
                # of a genuine 23px fused pair (median row ~8px).
                # Keep the strong projection-valley requirement, but allow
                # a physically plausible half up to 1.75x the live median.
                halves_plausible = (
                    max(5.0, med_h * 0.60) <= left_h <= med_h * 1.75 and
                    max(5.0, med_h * 0.60) <= right_h <= med_h * 1.75
                )
                valley_is_real = float(valley) <= max(12.0, peak_local * 0.28)

                if halves_plausible and valley_is_real:
                    made = []
                    for sa, sb in ((a, cut), (cut + 1, b)):
                        sub = roi[sa:sb + 1]
                        ys, xs = np.where(sub > 0)
                        if len(xs) < min_pixels:
                            made = []
                            break
                        sp = int(xs.max() - xs.min() + 1)
                        if sp < min_span:
                            made = []
                            break
                        pk = int(signal[sa:sb + 1].max())
                        made.append((int(sa), int(sb), sp, pk))

                    if len(made) == 2:
                        repaired.extend(made)
                        split_done = True

        if not split_done:
            repaired.append((a, b, int(span), int(peak)))

    repaired.sort(key=lambda x: (x[0] + x[1]) / 2.0)
    return repaired


def _score_six(rows, h, w):
    if len(rows) != 6:
        return -1e9

    centers = np.array([(a + b) / 2.0 for a, b, _, _ in rows], dtype=float)
    gaps = np.diff(centers)
    heights = np.array([b - a + 1 for a, b, _, _ in rows], dtype=float)

    # V1.7.3 absolute geometry invariant:
    # two different Final6 physical rows may never overlap in Y.
    # The 20261008 runtime log contained a false-pass pair:
    #   row5 = 262..270
    #   row6 = 265..287
    # which caused duplicate/merged OCR evidence.
    for i in range(len(rows)-1):
        if int(rows[i+1][0]) <= int(rows[i][1]):
            return -1e9

    if np.any(gaps < 4) or np.any(gaps > max(52, h * 0.18)):
        return -1e9

    # A single row much taller than the live row family is also forbidden.
    # It is almost always a fused pair or background contamination.
    med_h_guard = float(np.median(heights)) if len(heights) else 0.0
    if med_h_guard > 0 and float(np.max(heights)) > max(18.0, med_h_guard * 1.85):
        return -1e9

    med_gap = float(np.median(gaps))
    gap_mad = float(np.median(np.abs(gaps - med_gap)))
    gap_spread = float(np.max(gaps) - np.min(gaps)) if len(gaps) else 999.0
    gap_score = max(0.0, 1.0 - gap_mad / max(2.0, med_gap * 0.38))

    # v8.9 LAST6 ROOT FIX:
    # The six random option rows in JX1 form one tight cadence block. A stray
    # blue/gray fixed-stat line can sit ~40 px above that block. v8.8 could
    # choose that stray line as OPT1 because the real OPT6 touched the tightened
    # tooltip crop edge and received a large edge penalty.
    #
    # Prefer a geometrically coherent six-row cadence before considering crop
    # edge aesthetics. This exactly matches the runtime truth gate thresholds.
    strict_cadence = bool(
        8.0 <= med_gap <= 18.5 and
        gap_mad <= 2.2 and
        gap_spread <= 6.5 and
        5 <= int(round(float(np.median(heights)))) <= 14
    )

    # Detect a single bad terminal gap that MAD can miss.
    max_gap_dev = float(np.max(np.abs(gaps - med_gap)))
    rhythm_edge_score = max(
        0.0,
        1.0 - max_gap_dev / max(2.0, med_gap * 0.28)
    )

    med_h = float(np.median(heights))
    h_mad = float(np.median(np.abs(heights - med_h)))
    height_score = max(0.0, 1.0 - h_mad / max(2.0, med_h * 0.65))
    min_height_ratio = float(np.min(heights) / max(1.0, med_h))

    bottom = centers[-1] / max(1.0, h)
    first = centers[0] / max(1.0, h)
    bottom_score = np.clip((bottom - 0.45) / 0.50, 0.0, 1.0)
    lower_score = np.clip((first - 0.20) / 0.45, 0.0, 1.0)

    bottom_margin = max(0.0, (h - 1) - rows[-1][1])
    bottom_margin_score = 1.0 - min(
        1.0, bottom_margin / max(12.0, h * 0.18)
    )

    # A regular LAST6 block is allowed to touch the crop edge because the
    # detector intentionally tightens the tooltip to visible text. Only penalize
    # edge contact when cadence itself is not trustworthy.
    if strict_cadence:
        bottom_edge_penalty = 0.0
    elif bottom_margin <= 2:
        bottom_edge_penalty = 2.70
    elif bottom_margin <= 4:
        bottom_edge_penalty = 0.80
    else:
        bottom_edge_penalty = 0.0

    span_score = float(np.mean([
        min(1.0, s / max(80.0, w * 0.38))
        for _, _, s, _ in rows
    ]))

    cadence_bonus = 5.0 if strict_cadence else 0.0

    return float(
        cadence_bonus +
        3.0 * gap_score +
        2.2 * rhythm_edge_score +
        1.0 * height_score +
        0.7 * min_height_ratio +
        1.2 * bottom_score +
        2.4 * bottom_margin_score +
        0.4 * lower_score +
        0.5 * span_score -
        bottom_edge_penalty
    )


def _best_window(rows, h, w, n=6):
    if len(rows) < n:
        return None, -1e9
    best, best_score = None, -1e9
    for i in range(len(rows) - n + 1):
        win = rows[i:i+n]
        score = _score_six(win, h, w) if n == 6 else -1e9
        if score > best_score:
            best, best_score = win, score
    return best, best_score


def _cluster_rows(rows_by_strategy, h, w):
    points = []
    for method, rows in rows_by_strategy:
        for a, b, span, peak in rows:
            points.append(((a + b) / 2.0, a, b, span, peak, method))
    if not points:
        return []
    points.sort(key=lambda x: x[0])
    clusters = []
    tol = max(2.5, h * 0.009)
    for p in points:
        if not clusters or abs(p[0] - np.mean([q[0] for q in clusters[-1]])) > tol:
            clusters.append([p])
        else:
            clusters[-1].append(p)

    out = []
    for c in clusters:
        methods = {q[5] for q in c}
        if len(methods) < 2:
            continue
        a = int(round(np.median([q[1] for q in c])))
        b = int(round(np.median([q[2] for q in c])))
        span = int(round(np.median([q[3] for q in c])))
        peak = int(round(np.median([q[4] for q in c])))
        out.append((a, b, span, peak, len(methods)))
    return out


def _infer_six_from_five(rows, h, w):
    """Safe fallback: infer a missing slot, but OCR must still validate it later."""
    if len(rows) != 5:
        return None
    centers = np.array([(a + b) / 2.0 for a, b, _, _ in rows], dtype=float)
    gaps = np.diff(centers)
    if len(gaps) < 2:
        return None
    med = float(np.median(gaps))
    if med < 5 or med > max(42, h * 0.16):
        return None
    heights = [b - a + 1 for a, b, _, _ in rows]
    hh = int(round(np.median(heights)))

    # First preference: a visible doubled gap means one weak row disappeared.
    idx = int(np.argmax(gaps))
    if gaps[idx] > med * 1.55:
        cy = (centers[idx] + centers[idx + 1]) / 2.0
        inferred = (max(0, int(round(cy - hh/2))), min(h-1, int(round(cy + hh/2))), int(w * .45), 0)
        return rows[:idx+1] + [inferred] + rows[idx+1:]

    # If five rows form a regular block at the very bottom, the missed option is
    # usually directly above that block. This is common when the first option has
    # a dimmer color. Do not infer below the crop edge.
    bottom_margin = h - 1 - rows[-1][1]
    if bottom_margin <= max(18, int(h * 0.08)):
        cy = centers[0] - med
        if cy > 2:
            inferred = (max(0, int(round(cy - hh/2))), min(h-1, int(round(cy + hh/2))), int(w * .45), 0)
            return [inferred] + rows
    return None


def extract_last6_boxes(image_path, return_debug=False):
    img = _cv_imread_unicode(image_path)
    if img is None:
        debug = {"status": "IMAGE_READ_FAILED", "method": None, "boxes": [], "image_loader": "unicode-safe-imdecode"}
        return ([], debug) if return_debug else []
    h, w = img.shape[:2]
    rows_by_strategy = []
    best_rows, best_score, best_method = None, -1e9, None

    for method, mask in _mask_strategies(img):
        # Stage 29.6.2: evaluate both the historical tolerant row grouping and
        # a strict no-gap grouping. The latter prevents two adjacent 13px option
        # rows from being merged through a one-pixel anti-aliased bridge.
        for row_gap, suffix in ((1, ""), (0, "_strict_rows")):
            raw_rows = _rows_from_mask(mask, gap=row_gap)
            rows = _repair_physical_option_rows_v165(mask, raw_rows)
            strategy_name = method + suffix
            rows_by_strategy.append((strategy_name, rows))
            win, score = _best_window(rows, h, w, 6)
            if win is not None and score > best_score:
                best_rows, best_score, best_method = win, score, strategy_name

    # Cross-threshold consensus. This recovers dim rows that appear only under
    # some brightness masks while rejecting one-off background texture.
    clustered = _cluster_rows(rows_by_strategy, h, w)
    cluster_rows = [(a, b, span, peak) for a, b, span, peak, support in clustered]
    win, score = _best_window(cluster_rows, h, w, 6)
    if win is not None and score > best_score:
        best_rows, best_score, best_method = win, score, "cluster-consensus"

    inferred = False
    if best_rows is None:
        # Find the best regular five-row block in the lower part and infer one
        # missing slot. The inferred line is NOT considered READY unless OCR
        # later recognizes a valid option + value + unit.
        best5 = None
        best5_score = -1e9
        for method, rows in rows_by_strategy:
            for i in range(max(0, len(rows)-8), max(0, len(rows)-4)):
                win5 = rows[i:i+5]
                if len(win5) != 5:
                    continue
                centers = np.array([(a+b)/2 for a,b,_,_ in win5], dtype=float)
                gaps = np.diff(centers)
                if np.any(gaps < 4):
                    continue
                med = float(np.median(gaps))
                mad = float(np.median(np.abs(gaps-med)))
                reg = 1.0 - min(1.0, mad/max(2.0, med*.4))
                bottom = centers[-1]/max(1,h)
                sc = reg*3 + bottom*2
                if sc > best5_score:
                    best5_score, best5 = sc, win5
        if best5 is not None:
            candidate = _infer_six_from_five(best5, h, w)
            if candidate is not None and len(candidate) == 6:
                # Stage 29.6.2: inferred geometry is never trusted merely because
                # six rows exist. It must pass the same structural cadence gate as
                # a directly detected six-row block. This rejects the real
                # 98/97/18/19/14px malformed sequence from the 092057 log.
                candidate_score = _score_six(candidate, h, w)
                if candidate_score > -1e8:
                    best_rows, best_score, best_method, inferred = candidate, candidate_score, "inferred-from-5", True

    # Final structural guard. A malformed six-row set may never leave this
    # function with status OK, regardless of which fallback produced it.
    cadence_valid = bool(best_rows is not None and len(best_rows) == 6 and _score_six(best_rows, h, w) > -1e8)
    if not cadence_valid:
        best_rows = None
        best_method = None
        inferred = False

    boxes = [] if best_rows is None else [(int(a), int(b)) for a, b, _, _ in best_rows]
    debug = {
        "status": "OK" if len(boxes) == 6 else "SEGMENTATION_INVALID_CADENCE",
        "image_loader": "unicode-safe-imdecode",
        "method": best_method,
        "score": round(float(best_score), 3) if best_score > -1e8 else None,
        "inferred": inferred,
        "boxes": boxes,
        "centers": [round((a+b)/2.0, 2) for a,b in boxes],
        "gaps": [
            round(((boxes[i+1][0]+boxes[i+1][1])-(boxes[i][0]+boxes[i][1]))/2.0, 2)
            for i in range(max(0, len(boxes)-1))
        ],
        "selection_policy": "V8_9_STRICT_CADENCE_LAST6_FIRST",
        "bottom_margin": None if not boxes else int((h-1)-boxes[-1][1]),
        "strategy_counts": {method: len(rows) for method, rows in rows_by_strategy},
        "cluster_count": len(clustered),
        "image_size": [int(w), int(h)],
    }
    return (boxes, debug) if return_debug else boxes


# ---------------------------------------------------------------------------
# OCR / dictionary matcher v2.8
# ---------------------------------------------------------------------------

def _candidate_options(group_id):
    if group_id == "__all__":
        opts=[]
        seen=set()
        for g in OPTION_DB["groups"].values():
            for name in g.get("options", []):
                if name not in seen:
                    seen.add(name); opts.append(name)
        for extra in ("Phục hồi nội lực mỗi nửa giây", "Hồi phục sinh lực"):
            if extra not in seen:
                opts.append(extra)
        return opts

    opts = list(OPTION_DB["groups"][group_id]["options"])
    if group_id == "nhan" and "Phục hồi nội lực mỗi nửa giây" not in opts:
        opts.append("Phục hồi nội lực mỗi nửa giây")
    if group_id == "ao" and "Hồi phục sinh lực" not in opts:
        opts.append("Hồi phục sinh lực")
    return opts


def _name_score(raw, option):
    a, b = norm_text(raw), norm_text(option)
    a = re.sub(r"[+\-tT†‡]?[ ]*[0-9SOIlB]{1,5}[ ]*%?", " ", a)
    for junk in ("diem", "didm", "dvem", "dem", "cap"):
        a = a.replace(junk, " ")
    a = re.sub(r"\s+", " ", a).strip()
    seq = difflib.SequenceMatcher(None, a, b).ratio()

    def grams(s):
        s = s.replace(" ", "")
        return {s[i:i+3] for i in range(max(0, len(s)-2))}

    ga, gb = grams(a), grams(b)
    gram = (2 * len(ga & gb) / (len(ga) + len(gb))) if ga and gb else 0.0

    # Short options (e.g. Kháng độc) are easily drowned by inventory/background
    # garbage around the line. Compare the target against the best same-length
    # substring of the compact OCR string as a partial-match signal.
    ac, bc = a.replace(" ", ""), b.replace(" ", "")
    partial = 0.0
    if bc and ac:
        if len(ac) <= len(bc):
            partial = difflib.SequenceMatcher(None, ac, bc).ratio()
        else:
            span = len(bc)
            for i in range(0, len(ac)-span+1):
                partial = max(partial, difflib.SequenceMatcher(None, ac[i:i+span], bc).ratio())
    base = 0.72 * seq + 0.28 * gram
    partial_score = 0.88 * partial + 0.12 * gram
    return max(base, partial_score)


def normalize_numeric_ocr(text):
    if not text:
        return ""
    t = str(text).replace("–", "-").replace("—", "-").replace("−", "-")
    t = t.replace("†", "+").replace("‡", "+")
    # In JX1 bitmap font, '+' is often read as t/T/f.
    t = re.sub(r"(?<![A-Za-z])[tTf](?=\s*[0-9SOIlBs])", "+", t)
    trans = str.maketrans({"S":"5","s":"5","O":"0","o":"0","I":"1","l":"1","|":"1","B":"8","E":"8","e":"8"})

    def fix(m):
        sign = m.group(1)
        body = re.sub(r"[^0-9]", "", m.group(2).translate(trans))
        return sign + body if body else m.group(0)

    return re.sub(r"([+\-])\s*([0-9SOIlBsEe]{1,5})", fix, t)


def _visible_range_from_text(text):
    """Parse displayed [min - max] metadata without treating it as item value.

    The JX1 tooltip prints the legal range after the actual signed value. This
    helper is intentionally conservative and only accepts an explicit bracketed
    two-number range.
    """
    raw = str(text or "").replace("–", "-").replace("—", "-").replace("−", "-")
    raw = normalize_numeric_ocr(raw)
    m = re.search(r"[\[\{]\s*([+\-]?\d{1,4})\s*-\s*([+\-]?\d{1,4})", raw)
    if not m:
        return None
    try:
        a, b = int(m.group(1)), int(m.group(2))
    except Exception:
        return None
    lo, hi = (a, b) if a <= b else (b, a)
    return (lo, hi)


def _primary_value_token(text):
    """Return the actual signed value token before unit/range metadata.

    Root fix v10.2: a percent glyph can be OCR'd as a trailing ``8``. The old
    parser accepted the entire signed digit run, so ``+114% [100-250]`` could
    become ``+1148``. We now bind to the primary token and use the displayed
    range only as a sanity check. Range digits never become the actual value.
    """
    raw = str(text or "").replace("–", "-").replace("—", "-").replace("−", "-")
    rng = _visible_range_from_text(raw)
    t = normalize_numeric_ocr(raw)
    head = re.split(r"[\[\{£]", t, maxsplit=1)[0]
    matches = list(re.finditer(r"([+\-])\s*(\d{1,5})", head))
    if not matches:
        return {
            "value": None, "raw_value": None, "range": rng,
            "percent_suffix": False, "percent_glyph_repaired": False,
        }
    m = matches[-1]
    sign = -1 if m.group(1) == "-" else 1
    digits = m.group(2)
    value = sign * int(digits)
    suffix = head[m.end():m.end()+16]
    suffix_norm = norm_text(suffix)
    has_percent = "%" in suffix
    has_explicit_unit = any(tok in suffix_norm for tok in ("diem","didm","dvem","dem","cap"))
    repaired = False

    # Conservative repair for the real JX1 bitmap artifact: '%' -> trailing 8.
    # A LEGITIMATE point/level value such as +1148 điểm must remain 1148.
    # Therefore range-based trailing-8 repair is permitted only when the token
    # has no explicit point/level unit (percent glyph present or likely lost).
    if rng and len(digits) >= 2 and digits.endswith("8") and not has_explicit_unit:
        lo, hi = rng
        mag = abs(value)
        cand_mag = int(digits[:-1]) if digits[:-1] else 0
        if not (lo <= mag <= hi) and lo <= cand_mag <= hi:
            value = sign * cand_mag
            repaired = True

    return {
        "value": value, "raw_value": sign * int(digits), "range": rng,
        "percent_suffix": has_percent, "percent_glyph_repaired": repaired,
    }


def _numeric_candidates(text):
    t = normalize_numeric_ocr(text or "")
    found = []
    for m in re.finditer(r"([+\-])\s*(\d{1,4})", t):
        v = int(m.group(2))
        found.append(-v if m.group(1) == "-" else v)

    # Safe unsigned fallback: option names do not contain numeric digits. Only
    # accept a final number when it sits next to a unit-looking token.
    n = norm_text(t)
    for m in re.finditer(r"(\d{1,4})\s*(?:%|diem|didm|dvem|dem|cap)\b", n):
        found.append(int(m.group(1)))
    return found


def _primary_numeric_candidates(text):
    """JX1 primary value token, excluding unit and [min-max] metadata."""
    info = _primary_value_token(text)
    value = info.get("value")
    return [value] if value is not None else []


def parse_signed_number(text):
    vals = _numeric_candidates(text)
    return vals[-1] if vals else None


def infer_unit_from_text(*texts):
    raw = " ".join(str(x or "") for x in texts)
    n = norm_text(raw)
    if "%" in raw or re.search(r"\bphan tram\b", n):
        return "%"
    if any(x in n for x in ("diem", "didm", "dvem", "dem")):
        return "điểm"
    if "cap" in n:
        return "cấp"
    return None


def _global_units_for_option(option_name):
    units=[]
    for (gid,name),unit in UNIQUE_UNITS.items():
        if name==option_name and unit not in units:
            units.append(unit)
    for (gid,name),arr in AMBIGUOUS_UNITS.items():
        if name==option_name:
            for unit in arr:
                if unit not in units:
                    units.append(unit)
    for gid,name,unit in VALUE_RANGES:
        if name==option_name and unit not in units:
            units.append(unit)
    return units


def _global_ranges(option_name, unit):
    return [v for (gid,name,u),v in VALUE_RANGES.items() if name==option_name and u==unit]


def infer_unit(group_id, option_name, *raw_texts):
    direct = infer_unit_from_text(*raw_texts)
    if direct is not None:
        return direct
    if not option_name:
        return None
    if group_id == "__all__":
        units=_global_units_for_option(option_name)
        return units[0] if len(units)==1 else None
    return UNIQUE_UNITS.get((group_id, option_name))


def _infer_ambiguous_unit_by_values(group_id, option_name, values):
    units = (_global_units_for_option(option_name) if group_id=="__all__" else AMBIGUOUS_UNITS.get((group_id, option_name), []))
    if not units or not values:
        return None
    winners = []
    for unit in units:
        best = max((_value_plausibility(group_id, option_name, unit, v) for v in values), default=0.0)
        if best >= 0.95:
            winners.append(unit)
    return winners[0] if len(winners) == 1 else None


def _value_plausibility(group_id, option_name, unit, value):
    if value is None:
        return 0.0
    if unit:
        ranges = (_global_ranges(option_name, unit) if group_id=="__all__" else [VALUE_RANGES.get((group_id, option_name, unit))])
        ranges=[rr for rr in ranges if rr]
        if ranges:
            for rr in ranges:
                lo, hi = float(rr["min"]), float(rr["max"])
                pad = max(3.0, abs(hi-lo)*0.35)
                if lo-pad <= value <= hi+pad:
                    return 1.0
            return 0.15
    return 0.65 if -5000 <= value <= 5000 else 0.1


def apply_numeric_guards(group_id, option_name, value, unit):
    fixes = []
    if value is None or not option_name:
        return value, fixes
    if unit == "%":
        sign = -1 if value < 0 else 1
        digits = str(abs(int(value)))
        rr = None if group_id=="__all__" else VALUE_RANGES.get((group_id, option_name, "%"))
        if rr and len(digits) >= 2 and digits.endswith("1"):
            stripped = sign * int(digits[:-1])
            hi = max(abs(rr["min"]), abs(rr["max"]))
            lo = min(abs(rr["min"]), abs(rr["max"]))
            if abs(value) > max(100, hi * 1.5) and max(0, lo - 10) <= abs(stripped) <= hi + 10:
                value = stripped
                fixes.append("PERCENT_GLYPH_TRAILING_1")
    return value, fixes


def _trim_option_row(pil_line):
    p = pil_line.convert("RGB")
    if p.height > 10:
        trim = min(3, max(1, (p.height-8)//3))
        p = p.crop((0, trim, p.width, p.height-trim))
    return p


def _numeric_whitelist_reads(pil_line, fractions, include_percent):
    p = _trim_option_row(pil_line)
    arr = np.asarray(p)
    h,w = arr.shape[:2]
    out = []
    whitelist = "+-0123456789%[]" if include_percent else "+-0123456789[]"
    for frac in fractions:
        cut = arr[:, int(w*frac):]
        allowed = _blue_gray_mask_rgb(cut)
        up = cv2.resize(allowed, None, fx=8, fy=8, interpolation=cv2.INTER_NEAREST)
        bw = up
        cfg = f"--psm 7 -c tessedit_char_whitelist={whitelist}"
        configs=[]
        bundled=" ".join(x for x in (_tessdata_config(), cfg) if x).strip()
        if bundled: configs.append(bundled)
        if cfg not in configs: configs.append(cfg)
        for runtime_cfg in configs:
            try:
                text = pytesseract.image_to_string(
                    Image.fromarray(bw), lang="eng", config=runtime_cfg,
                    timeout=1.5
                ).strip()
                if text:
                    out.append(text)
                    break
            except Exception as e:
                _record_ocr_error(f"NUMERIC@{frac}|{runtime_cfg}", e)
    return out




def _normalize_percent_token_body(token):
    """Contextual bitmap-glyph repair INSIDE a validated numeric token only."""
    table=str.maketrans({"O":"0","o":"0","T":"7","t":"7","I":"1","l":"1","|":"1","S":"5","s":"5"})
    body=str(token or "").translate(table)
    body=re.sub(r"[^0-9]","",body)
    if not body or len(body)>3:
        return None
    try:
        value=int(body)
    except Exception:
        return None
    return value if 0 <= value <= 200 else None


def _percent_token_candidates(raw, allow_missing_percent=False):
    """Extract same-row percent value candidates without swallowing nearby glyphs.

    Sign authority belongs only to the sign immediately attached to the token.
    Repeated '--' / decorative strokes are rejected instead of turning a positive
    JX1 value into a negative number.
    """
    text=str(raw or '').replace('–','-').replace('—','-').replace('−','-')
    head=re.split(r"[\[\{£]", text, maxsplit=1)[0]
    out=[]
    pat=r"([+\-]?)\s*([0-9OoTtIl|Ss]{1,3})\s*(%)"
    for m in re.finditer(pat, head):
        sign=m.group(1) or ''
        # reject a sign that is actually the second glyph in '--'
        if sign=='-' and m.start(1)>0 and head[m.start(1)-1]=='-':
            continue
        mag=_normalize_percent_token_body(m.group(2))
        if mag is None:
            continue
        remainder=head[:m.start()]+head[m.end():]
        outside_alnum=re.sub(r'[^A-Za-z0-9]+','',remainder)
        direct_suffix_clean=bool(len(str(m.group(2)))==2 and not re.search(r'\d',head[m.end():]))
        strong_visual=bool(not outside_alnum)
        out.append({'value':(-mag if sign=='-' else mag),'explicit_percent':True,'token':m.group(0),'span':[m.start(),m.end()],'strong_visual':strong_visual})
    if out or not allow_missing_percent:
        return out
    # A no-% token is only supporting evidence during a tight same-row reread;
    # it can never create authority by itself.
    for m in re.finditer(r"([+\-]?)\s*([0-9OoTtIl|Ss]{1,3})(?![0-9A-Za-z])", head):
        sign=m.group(1) or ''
        if sign=='-' and m.start(1)>0 and head[m.start(1)-1]=='-':
            continue
        mag=_normalize_percent_token_body(m.group(2))
        if mag is None:
            continue
        out.append({'value':(-mag if sign=='-' else mag),'explicit_percent':False,'token':m.group(0),'span':[m.start(),m.end()]})
    return out


def _attack_speed_percent_tight_reads(pil_line):
    """Bounded PercentValueROI rereads of the EXACT physical Final6 row.

    Two narrow x-bands isolate the value column; each band gets only cheap
    same-row transforms.  This prevents neighboring row/range/ornament digits
    from being concatenated into the attack-speed value.
    """
    p=pil_line.convert('RGB')
    arr=np.asarray(p)
    if arr.size==0:
        return []
    h,w=arr.shape[:2]
    # Current JX1 tooltip crop places the numeric value around 60-83% of row width.
    bands=((0.588,0.765),(0.60,0.80),(0.63,0.83))
    reads=[]
    whitelist='+-0123456789%TtOoIlSs'
    for bidx,(fa,fb) in enumerate(bands):
        x0=max(0,min(w-1,int(round(w*fa)))); x1=max(x0+1,min(w,int(round(w*fb))))
        cut=arr[:,x0:x1]
        mask=_blue_gray_mask_rgb(cut)
        gray=cv2.cvtColor(cut,cv2.COLOR_RGB2GRAY)
        rr,gg,bb=cv2.split(cut)
        blue=(((bb>90) & (bb>rr+20) & (bb>=gg-25)).astype(np.uint8)*255)
        # One stable transform per band keeps this reader cheap. The direct
        # same-row OCR is independent corroboration; extra transforms previously
        # created false competing tokens (-485/-467/89) rather than evidence.
        variants=(
            ('MASK_CUBIC',cv2.resize(mask,None,fx=7,fy=7,interpolation=cv2.INTER_CUBIC)),
        )
        for tag,img in variants:
            cfg=f'--psm 7 -c tessedit_char_whitelist={whitelist}'
            try:
                raw=pytesseract.image_to_string(Image.fromarray(img),lang='eng',config=cfg,timeout=.65).strip()
            except Exception as e:
                _record_ocr_error(f'PERCENT_TIGHT_{bidx}_{tag}',e); raw=''
            if raw:
                reads.append({'raw':raw,'kind':tag,'bbox':[x0,0,x1,h]})
    return reads


def parse_attack_speed_percent_evidence(reads, generic_value=None, contextual=False):
    """Consensus parser for ATTACK_SPEED PERCENT evidence.

    One noisy OCR string is never enough.  A winning value needs either two
    supporting observations or a direct same-row observation plus a corroborating
    tight-ROI read, and at least one supporting observation must actually contain
    a percent glyph.
    """
    parsed=[]; normalized=[]
    for raw in reads or []:
        if isinstance(raw,dict):
            text=str(raw.get('raw') or ''); kind=str(raw.get('kind') or 'TARGETED')
        else:
            text=str(raw or ''); kind='DIRECT'
        if not text.strip():
            continue
        normalized.append(text)
        cands=_percent_token_candidates(text, allow_missing_percent=bool(contextual and kind!='DIRECT'))
        for c in cands:
            c=dict(c); c['raw']=text; c['kind']=kind
            if kind!='DIRECT' and kind!='MASK_CUBIC':
                c['strong_visual']=False
            if kind=='DIRECT' and c.get('explicit_percent'):
                token_body=re.sub(r'[^0-9OoTtIl|Ss]','',str(c.get('token') or ''))
                after=text[int((c.get('span') or [0,0])[1]):]
                if len(token_body)==2 and not re.search(r'\d',after):
                    c['strong_visual']=True
            parsed.append(c)
    if not parsed:
        return {'value':None,'numeric_unit':'PERCENT','authoritative':False,'percent_glyph_evidence':False,
                'reason':'VALUE_UNRESOLVED','numeric_source':'NON_AUTHORITATIVE_GENERIC_VALUE',
                'generic_value':generic_value,'reads':normalized,'candidate_evidence':[]}
    scores=defaultdict(float); explicit=defaultdict(int); votes=defaultdict(int); strong=defaultdict(int)
    for c in parsed:
        v=int(c['value']); votes[v]+=1
        weight=1.15 if c.get('kind')=='DIRECT' else (1.0 if c.get('explicit_percent') else 0.72)
        if c.get('strong_visual'):
            weight += 1.0
            strong[v] += 1
        scores[v]+=weight
        explicit[v]+=int(bool(c.get('explicit_percent')))
    winner=max(scores,key=lambda v:(strong[v],scores[v],votes[v],explicit[v],-abs(v)))
    other_strong=sum(n for v,n in strong.items() if v!=winner)
    # Either consensus OR one clean token in the already validated physical row.
    # Competing clean tokens remain unresolved rather than guessed.
    authoritative=bool(explicit[winner]>=1 and other_strong==0 and (strong[winner]>=1 or (votes[winner]>=2 and scores[winner]>=1.70)))
    conflict=(generic_value is not None and authoritative and int(generic_value)!=int(winner))
    return {
        'value':int(winner) if authoritative else None,
        'numeric_unit':'PERCENT','authoritative':authoritative,
        'percent_glyph_evidence':bool(explicit[winner]),
        'reason':'PERCENT_VALUE_AUTHORITATIVE' if authoritative else 'VALUE_UNRESOLVED',
        'numeric_source':'ATTACK_SPEED_PERCENT_AUTHORITY' if authoritative else 'NON_AUTHORITATIVE_GENERIC_VALUE',
        'generic_value':generic_value,'generic_conflict':bool(conflict),
        'generic_conflict_reason':('GENERIC_PERCENT_GLYPH_CORRUPTION_REJECTED' if conflict else None),
        'reads':normalized,'observed_values':[int(c['value']) for c in parsed],
        'candidate_evidence':parsed,'winner_votes':int(votes[winner]),'winner_score':round(float(scores[winner]),3),'winner_strong_visual':int(strong[winner]),
    }


def read_attack_speed_percent_authority(pil_line, option_name, generic_value=None, raw_text=None):
    """Shared same-row AttackSpeedPercentReader for NỘI and NGOẠI."""
    meta=option_semantics(option_name)
    if meta.get('option_family')!='ATTACK_SPEED' or meta.get('unit_type')!='PERCENT':
        return {'value':None,'numeric_unit':'PERCENT','authoritative':False,'reason':'UNIT_MISMATCH',
                'numeric_source':'ATTACK_SPEED_PERCENT_AUTHORITY','reads':[]}
    tight=_attack_speed_percent_tight_reads(pil_line)
    evidence=[]
    if raw_text:
        evidence.append({'raw':raw_text,'kind':'DIRECT'})
    evidence.extend(tight)
    out=parse_attack_speed_percent_evidence(evidence,generic_value=generic_value,contextual=True)
    out['authority_path']='TIGHT_SAME_ROW_PERCENT_CONSENSUS'
    out['percent_value_roi_reads']=tight
    return out


def _percent_value_rescue(pil_line, generic_sign=None):
    reads = _numeric_whitelist_reads(
        pil_line, (0.28,0.30,0.38,0.42,0.50), True
    )
    vals = []
    for text in reads:
        m = re.search(r"([+\-])\s*(\d{1,4})\s*%", text)
        if m:
            vals.append(int(m.group(2)))
    if not vals:
        return None, reads
    counts = defaultdict(int)
    for v in vals:
        counts[v] += 1
    magnitude = sorted(counts, key=lambda v:(-counts[v], v))[0]
    sign = -1 if generic_sign is not None and generic_sign < 0 else 1
    return sign*magnitude, reads


def _point_value_rescue(pil_line, option_name, generic_sign=None):
    reads = _numeric_whitelist_reads(
        pil_line, (0.28,0.34,0.42), False
    )
    repaired = []
    for text in reads:
        head = text.split("[",1)[0]

        # Signed token first.
        mm = re.search(r"([+\-])\s*(\d{1,4})", head)
        candidate = None
        if mm:
            candidate = int(mm.group(2))
            if generic_sign is not None:
                candidate = -candidate if generic_sign < 0 else candidate
            elif mm.group(1) == "-":
                candidate = -candidate
        else:
            # If sign disappeared, use the last digit run before '['.
            nums = re.findall(r"\d{1,4}", head)
            if nums:
                candidate = int(nums[-1])
                if generic_sign is not None and generic_sign < 0:
                    candidate = -candidate

        if candidate is None:
            continue

        fixed, _ = _range_repair(
            "__all__", option_name, "điểm", candidate
        )
        repaired.append(fixed)

    if not repaired:
        return None, reads

    counts = defaultdict(int)
    for v in repaired:
        counts[v] += 1
    winner = sorted(counts, key=lambda v:(-counts[v], abs(v)))[0]
    return winner, reads


def _prepare_line_variants(pil_line):
    # v6.9 hard contract: Tesseract never receives white tooltip glyphs.
    w, h = pil_line.size
    crop = pil_line.crop((max(0, int(w*.08)), 0, w, h)).convert("RGB")
    arr = np.array(crop)
    clean, mask = _blue_gray_clean_rgb(arr)

    # Binary variant is the primary view because it contains ONLY allowed
    # blue/gray glyph pixels.  Grayscale/RGB variants are also masked first.
    bw = cv2.resize(mask, None, fx=4, fy=4, interpolation=cv2.INTER_NEAREST)

    gray = cv2.cvtColor(clean, cv2.COLOR_RGB2GRAY)
    gray = cv2.resize(gray, None, fx=4, fy=4, interpolation=cv2.INTER_NEAREST)

    rgb = cv2.resize(clean, None, fx=4, fy=4, interpolation=cv2.INTER_NEAREST)
    return [Image.fromarray(bw), Image.fromarray(gray), Image.fromarray(rgb)]


def _prepare_numeric_variant(pil_line):
    w, h = pil_line.size
    crop = pil_line.crop((max(0, int(w*.055)), 0, w, h)).convert("RGB")
    arr = np.array(crop)
    _, mask = _blue_gray_clean_rgb(arr)
    up = cv2.resize(mask, None, fx=4, fy=4, interpolation=cv2.INTER_NEAREST)
    return Image.fromarray(up)


def _live_rescue_readings(pil_line):
    """Live-only OCR rescue for wide crops that include map texture."""
    w,h = pil_line.size
    if w < 500:
        return []

    p = pil_line.crop((0,1,w,h-1)) if h >= 4 else pil_line
    arr = np.array(p.convert("RGB"))

    xa = int(w * .33)
    xb = int(w * .98)
    arr = arr[:, xa:xb]
    if arr.size == 0:
        return []

    mask = _blue_gray_mask_rgb(arr) > 0
    ys,xs = np.where(mask)
    if len(xs) >= 10:
        x0=max(0,int(xs.min())-8)
        x1=min(arr.shape[1],int(xs.max())+9)
        arr=arr[:,x0:x1]

    # Re-mask after horizontal crop; all rescue OCR remains BLUE/GRAY only.
    clean, mask2 = _blue_gray_clean_rgb(arr)
    up=cv2.resize(clean,None,fx=5,fy=5,interpolation=cv2.INTER_NEAREST)
    variants=[Image.fromarray(up)]
    variants.append(Image.fromarray(cv2.resize(mask2,None,fx=5,fy=5,interpolation=cv2.INTER_NEAREST)))
    gray=cv2.cvtColor(up,cv2.COLOR_RGB2GRAY)
    variants.append(Image.fromarray(gray))
    _,bw=cv2.threshold(gray,100,255,cv2.THRESH_BINARY)
    variants.append(Image.fromarray(bw))

    readings=[]
    lang=_preferred_lang()
    cfg=" ".join(x for x in (_tessdata_config(),"--psm 7") if x).strip()
    for variant in variants:
        try:
            t=pytesseract.image_to_string(variant,lang=lang,config=cfg).strip()
            if t:
                readings.append((lang,t))
        except Exception:
            pass
    return readings


def _looks_like_dark_green_tooltip(pil_line):
    arr=np.asarray(pil_line.convert("RGB"))
    if arr.size==0:
        return False
    R=arr[:,:,0].astype(np.int16)
    G=arr[:,:,1].astype(np.int16)
    B=arr[:,:,2].astype(np.int16)
    mean=(R+G+B)/3.0
    green=((G-R)>4) & (mean<95)
    return float(green.mean()) >= 0.18


def _color_glyph_rescue_readings(pil_line):
    """
    OCR rescue for tiny JX1 colored bitmap option text.

    We remove the dark-green textured tooltip background and keep only
    bright/colored glyph pixels, then upscale with nearest-neighbor.
    This worked on the user's real Q01 crop where ordinary OCR returned "".
    """
    if not _looks_like_dark_green_tooltip(pil_line):
        return []

    arr=np.asarray(pil_line.convert("RGB"))
    h,w=arr.shape[:2]
    if h < 3 or w < 80:
        return []

    # Avoid segmentation borders while preserving the full text/value width.
    if h >= 5:
        arr=arr[1:-1,:,:]

    mx=arr.max(axis=2).astype(np.int16)
    mn=arr.min(axis=2).astype(np.int16)

    # v6.9: ONLY blue/cyan + gray option glyphs. White is forbidden.
    mask=_blue_gray_mask_rgb(arr) > 0

    ys,xs=np.where(mask)
    if len(xs)<8:
        return []

    x0=max(0,int(xs.min())-4)
    x1=min(arr.shape[1],int(xs.max())+5)
    arr=arr[:,x0:x1]
    mask=mask[:,x0:x1]

    gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
    clean=np.zeros_like(gray,dtype=np.uint8)
    clean[mask]=255

    readings=[]
    lang=_preferred_lang()
    tesscfg=_tessdata_config()

    variants=[]
    # v7.0: NEVER feed original RGB to OCR. Build RGB only from the allowed
    # blue/gray mask so white text cannot re-enter through rescue OCR.
    rgb_clean=np.zeros_like(arr,dtype=np.uint8)
    rgb_clean[mask]=arr[mask]
    rgb=cv2.resize(rgb_clean,None,fx=6,fy=6,interpolation=cv2.INTER_NEAREST)
    rgb=cv2.copyMakeBorder(rgb,18,18,18,18,cv2.BORDER_CONSTANT,value=(0,0,0))
    variants.append(Image.fromarray(rgb))

    bw=cv2.resize(clean,None,fx=6,fy=6,interpolation=cv2.INTER_NEAREST)
    bw=cv2.copyMakeBorder(bw,18,18,18,18,cv2.BORDER_CONSTANT,value=0)
    variants.append(Image.fromarray(bw))

    for variant in variants:
        for psm in (7,6,13):
            cfg=" ".join(x for x in (tesscfg,f"--psm {psm}") if x).strip()
            try:
                text=pytesseract.image_to_string(variant,lang=lang,config=cfg).strip()
                if text:
                    readings.append((lang,text))
            except Exception:
                pass

    return readings


def _range_repair(group_id, option_name, unit, value):
    """Conservative digit repair from verified ranges, including __all__."""
    if value is None or not option_name or not unit:
        return value, []

    if group_id == "__all__":
        ranges = _global_ranges(option_name, unit)
    else:
        rr = VALUE_RANGES.get((group_id, option_name, unit))
        ranges = [rr] if rr else []

    if not ranges:
        return value, []

    def inside(v):
        for rr in ranges:
            lo, hi = float(rr["min"]), float(rr["max"])
            pad = max(2.0, abs(hi-lo)*0.20)
            if lo-pad <= v <= hi+pad:
                return True
        return False

    if inside(value):
        return value, []

    sign = -1 if value < 0 else 1
    digits = str(abs(int(value)))
    variants = set()
    if len(digits) >= 2:
        variants.add(sign*int(digits[1:]))
        variants.add(sign*int(digits[:-1]))
    if len(digits) >= 3:
        variants.add(sign*int(digits[-2:]))
        variants.add(sign*int(digits[:2]))
    if len(digits) >= 4:
        variants.add(sign*int(digits[-3:]))
        variants.add(sign*int(digits[:3]))

    valid = sorted(v for v in variants if inside(v))
    if len(valid) == 1:
        return valid[0], ["GLOBAL_RANGE_DIGIT_REPAIR"]
    return value, []


def recognize_line(pil_line, group_id):
    readings = []
    variants = _prepare_line_variants(pil_line)

    # Name path: PSM-7 over grayscale, brightness mask and original RGB.
    for variant in variants:
        readings.extend(safe_ocr_string(variant, config="--psm 7"))

    def best_name_from(reads):
        best = (0.0, None, "")
        for lang, raw in reads:
            for option in _candidate_options(group_id):
                sc = _name_score(raw, option)
                if sc > best[0]:
                    best = (sc, option, raw)
        return best

    best = best_name_from(readings)
    if best[0] < 0.43:
        readings.extend(safe_ocr_string(variants[0], config="--psm 6"))
        best = best_name_from(readings)

    option_name = best[1]
    raw_join = " | ".join(f"{lang}:{raw}" for lang, raw in readings if raw)
    unit = infer_unit(group_id, option_name, raw_join)

    all_numbers = []
    for _, raw in readings:
        all_numbers.extend(_numeric_candidates(raw))
    if unit is None:
        unit = _infer_ambiguous_unit_by_values(group_id, option_name, all_numbers)

    def best_numeric(nums):
        if not nums:
            return None, 0, 0.0
        counts = defaultdict(int)
        for v in nums:
            counts[v] += 1
        scored = []
        for v, count in counts.items():
            plaus = _value_plausibility(group_id, option_name, unit, v)
            # Plausibility is deliberately strong; it prevents a repeated stray
            # UI digit from beating a plausible option value.
            scored.append((plaus*4.0 + count*1.1, count, v, plaus))
        scored.sort(reverse=True)
        _, count, v, plaus = scored[0]
        return v, count, plaus

    value, value_count, plaus = best_numeric(all_numbers)

    # Numeric rescue path: use a slightly wider grayscale crop. It is invoked
    # only when current OCR is missing/implausible, so normal live reads stay fast.
    if value is None or plaus < 0.80:
        num_reads = safe_ocr_string(_prepare_numeric_variant(pil_line), config="--psm 7")
        for lang, raw in num_reads:
            readings.append((lang, raw))
            all_numbers.extend(_numeric_candidates(raw))
        value, value_count, plaus = best_numeric(all_numbers)
        raw_join = " | ".join(f"{lang}:{raw}" for lang, raw in readings if raw)
        if unit is None:
            unit = infer_unit(group_id, option_name, raw_join)
        if unit is None:
            unit = _infer_ambiguous_unit_by_values(group_id, option_name, all_numbers)
        value, value_count, plaus = best_numeric(all_numbers)

    # Rescue only unresolved wide live lines. Already-correct lines keep the
    # original verified OCR result, so rescue noise cannot override them.
    needs_live_rescue = (
        pil_line.size[0] >= 500 and (
            option_name is None or
            best[0] < 0.55 or
            value is None or
            unit is None
        )
    )
    if needs_live_rescue:
        rescue_reads = _live_rescue_readings(pil_line)
        if rescue_reads:
            readings.extend(rescue_reads)
            best = best_name_from(readings)
            option_name = best[1]
            raw_join = " | ".join(f"{lang}:{raw}" for lang, raw in readings if raw)
            unit = infer_unit(group_id, option_name, raw_join)
            all_numbers = []
            for _, raw in readings:
                all_numbers.extend(_numeric_candidates(raw))
            if unit is None:
                unit = _infer_ambiguous_unit_by_values(group_id, option_name, all_numbers)
            value, value_count, plaus = best_numeric(all_numbers)

    # v4.8 color-glyph rescue: only when normal OCR is incomplete.
    needs_color_rescue = (
        option_name is None or best[0] < 0.55 or
        value is None or unit is None
    )
    if needs_color_rescue:
        color_reads = _color_glyph_rescue_readings(pil_line)
        if color_reads:
            readings.extend(color_reads)

            best = best_name_from(readings)
            option_name = best[1]

            raw_join = " | ".join(f"{lang}:{raw}" for lang,raw in readings if raw)
            unit = infer_unit(group_id, option_name, raw_join)

            all_numbers=[]
            for _,raw in readings:
                all_numbers.extend(_numeric_candidates(raw))

            if unit is None:
                unit=_infer_ambiguous_unit_by_values(
                    group_id, option_name, all_numbers
                )

            value,value_count,plaus=best_numeric(all_numbers)

    # Generic signed value before [range].
    primary_numbers = []
    for _, raw in readings:
        primary_numbers.extend(_primary_numeric_candidates(raw))
    if primary_numbers:
        value, value_count, plaus = best_numeric(primary_numbers)

    specialist_ocr = []
    generic_sign = primary_numbers[0] if primary_numbers else value

    attack_speed_percent_authority = None
    if unit == "%":
        if option_semantics(option_name).get("option_family") == "ATTACK_SPEED":
            attack_speed_percent_authority = read_attack_speed_percent_authority(
                pil_line, option_name, generic_value=generic_sign, raw_text=raw_join
            )
            specialist_ocr = list(attack_speed_percent_authority.get("reads") or [])
            if attack_speed_percent_authority.get("authoritative"):
                value = int(attack_speed_percent_authority.get("value"))
                value_count = max(value_count, 2)
                plaus = _value_plausibility(group_id, option_name, unit, value)
            else:
                # A generic integer without percent authority must not become
                # a PASS-capable attack-speed value. Keep it diagnostic only.
                value = None
        else:
            specialist_value, specialist_ocr = _percent_value_rescue(
                pil_line, generic_sign=generic_sign
            )
            if specialist_value is not None:
                value = specialist_value
                value_count = max(value_count, 2)
                plaus = _value_plausibility(
                    group_id, option_name, unit, value
                )
    elif unit == "điểm" and option_name:
        specialist_value, specialist_ocr = _point_value_rescue(
            pil_line, option_name, generic_sign=generic_sign
        )
        if specialist_value is not None:
            value = specialist_value
            value_count = max(value_count, 2)
            plaus = _value_plausibility(
                group_id, option_name, unit, value
            )

    value, range_fixes = _range_repair(group_id, option_name, unit, value)
    value, guard_fixes = apply_numeric_guards(group_id, option_name, value, unit)
    fixes = range_fixes + guard_fixes

    if value is None:
        value_conf = 0.0
    else:
        plaus2 = _value_plausibility(group_id, option_name, unit, value)
        value_conf = min(1.0, 0.50 + 0.16*max(1, value_count) + 0.30*plaus2)
        if fixes:
            value_conf = min(value_conf, 0.86)

    return {
        "name": option_name,
        "name_confidence": round(float(best[0]), 3),
        "value": value,
        "value_confidence": round(float(value_conf), 3),
        "unit": unit,
        "fixes": fixes,
        "raw_ocr": raw_join,
        "ocr_reads": [raw for _, raw in readings if raw],
        "numeric_candidates": all_numbers,
        "specialist_numeric_ocr": specialist_ocr,
        "attack_speed_percent_authority": attack_speed_percent_authority,
        "ocr_errors": list(OCR_ERRORS[-6:]),
    }

def recognize_name(pil_line, group_id):
    x = recognize_line(pil_line, group_id)
    return {"name": x["name"], "confidence": x["name_confidence"], "raw_ocr": x["raw_ocr"], "all_ocr": x["ocr_reads"]}


def recognize_value(pil_line):
    # Compatibility helper. read_single_tooltip uses recognize_line to avoid
    # duplicate OCR work.
    readings = []
    for variant in _prepare_line_variants(pil_line):
        readings.extend(safe_ocr_string(variant, config="--psm 7"))
    vals = []
    for _, raw in readings:
        vals.extend(_numeric_candidates(raw))
    if not vals:
        return {"value":None,"confidence":0.0,"raw_ocr":" | ".join(raw for _,raw in readings),"numeric_candidates":[]}
    counts = defaultdict(int)
    for v in vals:
        counts[v] += 1
    winner = max(counts, key=counts.get)
    conf = min(1.0, 0.60 + 0.20 * counts[winner])
    return {"value":winner,"confidence":round(conf,3),"raw_ocr":" | ".join(raw for _,raw in readings),"numeric_candidates":vals}


def _save_last6_overlay(image_path, boxes):
    try:
        im=_cv_imread_unicode(image_path)
        if im is None or len(boxes)!=6:
            return None
        h,w=im.shape[:2]
        for i,(y0,y1) in enumerate(boxes,1):
            # OPT1 starts the locked six-line option block; OPT6 is final gray row.
            color=(0,255,0) if i<6 else (210,210,210)
            cv2.rectangle(im,(1,max(0,y0-2)),(w-2,min(h-1,y1+2)),color,1)
            cv2.putText(im,f"OPT{i}",(5,max(12,y0-3)),
                        cv2.FONT_HERSHEY_SIMPLEX,.34,color,1,cv2.LINE_AA)
        cv2.putText(im,"FINAL 6 OPTION ROWS",(5,13),
                    cv2.FONT_HERSHEY_SIMPLEX,.34,(0,255,255),1,cv2.LINE_AA)
        p=Path(image_path)
        out=p.with_name(p.stem+"_LAST6_OVERLAY.png")
        ok=_cv_imwrite_unicode(out,im)
        return str(out) if ok else None
    except Exception:
        return None


def _grammar_direct_name(raw, group_id):
    """
    High-precision semantic aliases for real JX1 bitmap OCR.
    Only fires on discriminative multi-token signatures.
    """
    n = norm_text(raw or "")
    candidates = set(_candidate_options(group_id))

    tests = [
        ("Kỹ năng Võ công vốn có",
         [r"\b(?:ky|ey)\s+(?:nang|mang)\b",
          r"\b(?:vorceng|vilcing|voceng|vo\s+cong)\b"]),

        ("Kháng lôi",
         [r"\b(?:khang|kang)\b",
          r"\b(?:loi|lei|116i|1e6i|l6i|1oi)\b"]),

        ("Tăng độ chính xác đòn đánh cận chiến",
         [r"\b(?:chinh|chink)\b", r"\bxac\b",
          r"\b(?:danh|dank)\b"]),

        ("Độc sát – nội công",
         [r"\b(?:hee|he|doc)\b", r"\bsat\b",
          r"\b(?:mnei|omei|sonei|noi|nei|neip)\b",
          r"\b(?:ceng|cing|cong)\b"]),

        ("Tốc độ đánh – nội công",
         [r"\b(?:tect|tee|toc)\b",
          r"\b(?:dgndanhy|danhy|danh|dank)\b",
          r"\b(?:nei|neip|neij|nsi|noi)\b",
          r"\b(?:ceng|cing|cong)\b"]),

        ("Độc sát – ngoại công",
         [r"\b(?:pec|doc)\b", r"\bsat\b",
          r"\b(?:nzgoal|ngoai|ngoal)\b",
          r"\b(?:ceng|cing|cong)\b"]),

        ("Tốc độ đánh – ngoại công",
         [r"\b(?:toc|tac|tec|tic)\b",
          r"\b(?:danh|dank)\b",
          r"\b(?:ngoai|ngoal|ngoair)\b",
          r"\b(?:cong|ceng|cing|on)\b"]),

        ("Sát thương vật lý – ngoại công",
         [r"\b(?:sat|saf)\b",
          r"\b(?:thuong|thisng)\b",
          r"\b(?:vat|v4t)\b",
          r"\b(?:ly|1y|ty)\b",
          r"\b(?:ngoai|ngoair|ngogi)\b"]),

        ("Sát thương vật lý – nội công",
         [r"\b(?:sat|saf)\b",
          r"\b(?:thuong|thisng)\b",
          r"\b(?:vat|v4t)\b",
          r"\b(?:ly|1y|ty)\b",
          r"\b(?:noi|nei|mnei)\b"]),

        ("Lôi sát – nội công",
         [r"\b(?:loi|lei|l1|li)\b",
          r"\b(?:sat)\b",
          r"\b(?:noi|nei|mnei)\b",
          r"\b(?:cong|ceng)\b"]),

        ("Lôi sát – ngoại công",
         [r"\b(?:loi|lei|l1|li)\b",
          r"\b(?:sat)\b",
          r"\b(?:ngoai|ngoal)\b",
          r"\b(?:cong|ceng)\b"]),

        ("Tốc độ di chuyển",
         [r"\b(?:toc|tac)\b",
          r"\b(?:do)\b",
          r"\b(?:di)\b",
          r"\b(?:chuyen)\b"]),

        ("Thời gian phục hồi",
         [r"\b(?:thoi)\b",
          r"\b(?:gian|cian)\b",
          r"\b(?:phuc)\b",
          r"\b(?:hoi)\b"]),
    ]

    for canonical, patterns in tests:
        if canonical not in candidates:
            continue
        if all(re.search(p, n) for p in patterns):
            return canonical
    return None


def _grammar_unit(option_name, fallback=None):
    unit_type=option_unit_type(option_name)
    if unit_type == "NONE":
        return "NONE"
    if unit_type == "LEVEL":
        return "cấp"
    if unit_type == "PERCENT":
        return "%"
    if unit_type == "POINT":
        # Preserve the Reader's historical display grammar while unit semantics
        # remain canonical POINT in OptionRegistry.
        if option_name in (
            "Độc sát – nội công", "Độc sát – ngoại công",
            "Hỏa sát – nội công", "Hỏa sát – ngoại công",
            "Lôi sát – nội công", "Lôi sát – ngoại công",
            "Băng sát – nội công", "Băng sát – ngoại công",
        ):
            return "điểm/lần"
        return "điểm"
    if option_name == "Kỹ năng Võ công vốn có":
        return "cấp"
    if option_name and option_name.startswith("Kháng "):
        return "%"
    if option_name == "Tăng độ chính xác đòn đánh cận chiến":
        return "điểm"
    if option_name and option_name.startswith("Tốc độ đánh"):
        return "%"
    if option_name == "Tốc độ di chuyển":
        return "%"
    if option_name and option_name.startswith("Sát thương vật lý"):
        return "điểm"
    if option_name in (
        "Độc sát – nội công", "Độc sát – ngoại công",
        "Hỏa sát – nội công", "Hỏa sát – ngoại công",
        "Lôi sát – nội công", "Lôi sát – ngoại công",
        "Băng sát – nội công", "Băng sát – ngoại công",
    ):
        return "điểm/lần"
    return fallback


def _grammar_visible_range(raw):
    s = normalize_numeric_ocr(str(raw or ""))
    m = re.search(r"[\[\{]\s*(\d{1,4})\s*[-=]\s*(\d{1,4})", s)
    if not m:
        return None
    a,b = int(m.group(1)), int(m.group(2))
    return min(a,b), max(a,b)


def _repair_value_to_visible_range(value, visible_range):
    if value is None or visible_range is None:
        return value
    lo,hi = visible_range
    sign = -1 if int(value) < 0 else 1
    digits = str(abs(int(value)))

    if lo <= abs(int(value)) <= hi:
        return value

    candidates = []
    if len(digits) >= 2:
        candidates += [int(digits[:-1]), int(digits[1:])]
    if len(digits) >= 3:
        candidates += [int(digits[:-2]), int(digits[-2:])]

    valid = sorted(set(v for v in candidates if lo <= v <= hi))
    if len(valid) == 1:
        return sign * valid[0]
    return value


def _grammar_primary_value(raw, unit):
    """
    Deterministic OPTION:+VALUE parser.
    - Never reads MIN/MAX as VALUE.
    - Accepts signed percent values even when '%' glyph was lost.
    - Trims one OCR-junk digit only when the visible [min-max] uniquely proves it.
    """
    t = str(raw or "")
    t = t.replace("–","-").replace("—","-").replace("−","-")
    t = re.sub(r"([#$†‡¢])\s*(?=\d)", "+", t)

    head = re.split(r"[\[\{£]", t, maxsplit=1)[0]
    vr = _grammar_visible_range(t)

    if unit == "%":
        mm = re.search(r"([+\-])\s*(\d{1,4})", head)
        if mm:
            v = int(mm.group(2))
            v = -v if mm.group(1) == "-" else v
            v = _repair_value_to_visible_range(v, vr)
            if abs(v) <= 200:
                return v

        mm = re.search(r"(?<!\d)(\d{2,3})\s*%", head)
        if mm:
            tok = mm.group(1)
            if len(tok) == 3 and tok.startswith("4"):
                v = int(tok[1:])
                if 0 <= v <= 100:
                    return v
            v = int(tok)
            if 0 <= v <= 100:
                return v
        return None

    mm = re.search(r"([+\-])\s*(\d{1,4})", head)
    if mm:
        v = int(mm.group(2))
        v = -v if mm.group(1) == "-" else v
        return _repair_value_to_visible_range(v, vr)
    return None


def _targeted_hf_rescue(pil_line, line_obj, group_id):
    """
    Targeted fallback only for a compound option that v5.4 collapsed into
    a generic name (example: 'Lôi sát – nội công' -> 'Nội công').

    One grayscale/NEAREST OCR call; v5.4 remains the primary Reader.
    """
    pre_name = line_obj.get("pre_grammar_name")
    reads = " ".join(line_obj.get("all_name_ocr") or [])
    nr = norm_text(reads)
    generic = {"Nội công","Sức mạnh","Thân pháp"}

    if not (
        pre_name in generic and
        "sat" in nr and
        ("noi" in nr or "ngoai" in nr) and
        ("cong" in nr or "ceng" in nr)
    ):
        return line_obj

    try:
        arr = np.asarray(pil_line.convert("RGB"))
        allowed = _blue_gray_mask_rgb(arr)
        up = cv2.resize(allowed, None, fx=6, fy=6, interpolation=cv2.INTER_NEAREST)
        cfg = " ".join(x for x in (_tessdata_config(),"--psm 7") if x).strip()
        raw = pytesseract.image_to_string(
            Image.fromarray(up), lang="vie+eng", config=cfg, timeout=1.8
        ).strip()
    except Exception:
        return line_obj

    if not raw:
        return line_obj

    hint = _grammar_direct_name(raw, group_id)
    nr2 = norm_text(raw)

    # Real current frame: "Lõi sắt - nổi cổng: +326 điểm [300 - 2500]"
    if hint is None and (
        re.search(r"\b(?:loi|lai|lei)\b", nr2)
        and "sat" in nr2
        and ("noi" in nr2 or "nei" in nr2)
        and ("cong" in nr2 or "ceng" in nr2)
        and "Lôi sát – nội công" in _candidate_options(group_id)
    ):
        hint = "Lôi sát – nội công"

    if hint is None:
        return line_obj

    out = dict(line_obj)
    out["name"] = hint
    out["name_confidence"] = max(float(out.get("name_confidence") or 0), 0.97)
    out["unit"] = _grammar_unit(hint, out.get("unit"))

    hv = _grammar_primary_value(raw, out.get("unit"))
    if hv is not None:
        out["value"] = hv
        out["value_confidence"] = max(float(out.get("value_confidence") or 0), 0.96)

    out["targeted_hf_ocr"] = raw
    fixes = list(out.get("fixes") or [])
    fixes.append("TARGETED_COMPOUND_RESCUE")
    out["fixes"] = list(dict.fromkeys(fixes))

    out["status"] = "READY" if (
        out.get("name") is not None and
        out.get("value") is not None and
        out.get("unit") is not None and
        float(out.get("name_confidence") or 0) >= 0.43 and
        float(out.get("value_confidence") or 0) >= 0.70
    ) else "UNCERTAIN"
    return out


def _grammar_repair_line(line_result, group_id):
    out = dict(line_result)
    out["pre_grammar_name"] = line_result.get("name")
    reads = list(out.get("all_name_ocr") or [])
    if not reads:
        return out

    # Semantic votes from this line only.
    votes = defaultdict(int)
    for raw in reads:
        hint = _grammar_direct_name(raw, group_id)
        if hint:
            votes[hint] += 1

    if votes:
        best_name = max(votes, key=lambda k: votes[k])
        out["name"] = best_name
        out["name_confidence"] = max(float(out.get("name_confidence") or 0), 0.96)
        fixes = list(out.get("fixes") or [])
        if "GRAMMAR_NAME" not in fixes:
            fixes.append("GRAMMAR_NAME")
        out["fixes"] = fixes
    else:
        best_name = out.get("name")

    unit = _grammar_unit(best_name, out.get("unit"))
    if unit != out.get("unit"):
        fixes = list(out.get("fixes") or [])
        if "CANONICAL_UNIT" not in fixes:
            fixes.append("CANONICAL_UNIT")
        out["fixes"] = fixes
    out["unit"] = unit

    # If semantic evidence exists, only use raws that support the winning name.
    supporting = []
    if votes:
        supporting = [
            raw for raw in reads
            if _grammar_direct_name(raw, group_id) == best_name
        ]

    # Otherwise use raw with best fuzzy name score.
    if not supporting and best_name:
        supporting = sorted(
            reads,
            key=lambda raw: _name_score(raw, best_name),
            reverse=True
        )

    parsed = []
    for raw in supporting:
        v = _grammar_primary_value(raw, unit)
        if v is not None:
            parsed.append((v, raw))

    # Some OCR variants preserve the NAME, while a different variant preserves
    # the +VALUE. If semantic supporting reads lost the number, fall back to
    # all reads ranked by name similarity.
    if not parsed and best_name:
        for raw in sorted(
            reads,
            key=lambda s: _name_score(s, best_name),
            reverse=True
        ):
            v = _grammar_primary_value(raw, unit)
            if v is not None:
                parsed.append((v, raw))

    if parsed:
        # Mode vote, then first occurrence for deterministic behavior.
        counts = defaultdict(int)
        for v, _ in parsed:
            counts[v] += 1
        winner = max(counts, key=lambda v: counts[v])
        raw_used = next(raw for v, raw in parsed if v == winner)

        out["value"] = winner
        out["value_confidence"] = max(float(out.get("value_confidence") or 0), 0.97)
        out["grammar_value_raw"] = raw_used
        fixes = list(out.get("fixes") or [])
        if "GRAMMAR_VALUE" not in fixes:
            fixes.append("GRAMMAR_VALUE")
        out["fixes"] = fixes

    out["status"] = "READY" if (
        out.get("name") is not None and
        float(out.get("name_confidence") or 0) >= 0.43 and
        out.get("value") is not None and
        float(out.get("value_confidence") or 0) >= 0.70 and
        out.get("unit") is not None
    ) else "UNCERTAIN"

    return out



# ---------------------------------------------------------------------------
# v6.2 FINAL-6 READER RECOVERY
# ---------------------------------------------------------------------------

_CANONICAL_OPTION_UNITS_V62 = {
    "Tốc độ đánh – ngoại công": "%",
    "Tốc độ đánh – nội công": "%",
    "Phục hồi sinh lực mỗi nửa giây": "điểm",
    "Phục hồi nội lực mỗi nửa giây": "điểm",
    "Sinh khí": "điểm",
    # V1.7.5 registry owns Sinh lực tối đa as implicit-percent in Áo scope.
    "Nội lực tối đa": "điểm",
    "Thể lực tối đa": "điểm",
    "Nội công": "điểm",
    "Sức mạnh": "điểm",
    "Thân pháp": "điểm",
    "Kháng hỏa": "%",
    "Kháng băng": "%",
    "Kháng lôi": "%",
    "Kháng độc": "%",
    "Kháng tất cả": "%",
    "Thời gian choáng": "%",
    "Thời gian trúng độc": "%",
    "Chuyển hóa sát thương thành nội lực": "%",
    "Tốc độ di chuyển": "%",
    "Phòng thủ vật lý": "%",
    "Thời gian làm chậm": "%",
}


_CANONICAL_DISPLAY_RANGES_V62 = {
    "Phục hồi sinh lực mỗi nửa giây": (40, 90),
    "Phục hồi nội lực mỗi nửa giây": (40, 90),
    "Sinh khí": (10, 60),
    # V1.7.5: no legacy 400-1000 point-range authority for slot-filtered Sinh lực tối đa.
    "Nội lực tối đa": (400, 1000),
    "Thể lực tối đa": (400, 1000),
    "Nội công": (10, 60),
    "Kháng hỏa": (20, 80),
    "Kháng băng": (20, 80),
    "Kháng lôi": (20, 80),
    "Kháng độc": (20, 80),
    "Thời gian choáng": (20, 100),
    "Thời gian trúng độc": (20, 100),
    "Thời gian phục hồi": (30, 80),
    "Chuyển hóa sát thương thành nội lực": (1, 15),
    "Tốc độ di chuyển": (30, 80),
    "Phòng thủ vật lý": (20, 80),
    "Thời gian làm chậm": (20, 100),
    "Sức mạnh": (10, 50),
    "Thân pháp": (10, 60),
    "Tăng né tránh": (20, 900),
    "Tăng độ chính xác đòn đánh cận chiến": (100, 500),
    "Hỏa sát – nội công": (300, 2500),
    "Hỏa sát – ngoại công": (100, 1500),
}


def _hf_line_reads_v62(pil_line):
    """
    Two stable OCR views for the tiny JX1 bitmap font.
    These are supplemental evidence only; the existing Reader remains primary.
    """
    try:
        p = pil_line.convert("RGB")
        # The normal Reader passes ~5 px vertical padding. Tesseract on the JX1
        # bitmap font becomes much more stable after removing one outer pixel.
        if p.height >= 30:
            p = p.crop((0, 1, p.width, p.height-1))
        arr = np.asarray(p)
        if arr.size == 0:
            return []
        clean, allowed = _blue_gray_clean_rgb(arr)
        gray = cv2.cvtColor(clean, cv2.COLOR_RGB2GRAY)
        # Supplemental views are all derived from the same BLUE/GRAY-only mask.
        out=[]
        for tag, src, scale in (("HF_MASK", allowed, 7), ("HF_GRAY_BG", gray, 6)):
            up=cv2.resize(src,None,fx=scale,fy=scale,interpolation=cv2.INTER_NEAREST)
            reads=safe_ocr_string(Image.fromarray(up), config="--psm 7")
            for lang, txt in reads:
                if txt:
                    out.append((f"{tag}:{lang}",txt))
                    break
        return out
    except Exception:
        return []


def _semantic_common_name_v62(raw, group_id="__all__"):
    """
    Deterministic aliases for recurring JX1 OCR shapes.
    Only returns canonical dictionary names.
    """
    n = norm_text(raw or "")
    candidates = set(_candidate_options(group_id))

    def allowed(name):
        return name if name in candidates else None

    # Common stat families. JX1 bitmap OCR frequently renders "lực" as
    # lve / Ive / Tue / Pie. These aliases are intentionally local to
    # distinctive multi-token patterns, so they do not broaden generic matching.
    luc_like = bool(re.search(r"\b(?:luc|lve|ive|tue|pie|dhic|lye)\b", n))
    toi_like = bool(re.search(r"\b(?:toi|tei|tai|tdi|téi)\b", n))
    nua_like = bool(re.search(r"\b(?:nua|nia|mia|nda|mai)\b", n))
    giay_like = bool(re.search(r"\b(?:giay|ziay|giddy|iay)\b", n))

    if ("sinh" in n and luc_like and nua_like and giay_like):
        return allowed("Phục hồi sinh lực mỗi nửa giây")

    if (re.search(r"\b(?:noi|nei|nai|hei)\b", n) and luc_like and
        nua_like and giay_like and re.search(r"\b(?:phuc|fluc|flic|ephoi|gehoi)\b", n)):
        return allowed("Phục hồi nội lực mỗi nửa giây")

    if "sinh" in n and re.search(r"\b(?:khi|ehi)\b", n):
        return allowed("Sinh khí")

    if ("sinh" in n and luc_like and toi_like and "da" in n):
        return allowed("Sinh lực tối đa")

    # V1.7.5 user-taught slot-only options. Use distinctive multi-token
    # patterns so legacy Reader can agree with the profile-aware Stage17 path.
    if (re.search(r"\b(?:tang|tane)\b", n) and
        re.search(r"\b(?:cong|ceng|cdng|cing|cang|c0ng)\b", n) and
        re.search(r"\b(?:kich|kieh|k1ch)\b", n) and
        re.search(r"\b(?:ky|ey|ke)\b", n) and
        re.search(r"\b(?:nang|mang)\b", n)):
        return allowed("Tăng công kích kỹ năng")

    if (re.search(r"\b(?:muc|mue)\b", n) and
        re.search(r"\b(?:khang|kang)\b", n) and
        re.search(r"\b(?:tinh|t1nh)\b", n) and
        re.search(r"\b(?:toi|tei|tai)\b", n) and
        re.search(r"\b(?:da|d4)\b", n)):
        return allowed("Mức kháng tính tối đa")

    if (re.search(r"\b(?:noi|nei|hai|wai|nai|hei)\b", n) and
        re.search(r"\b(?:luc|lnc|lye|lve|ive)\b", n) and
        ("toi" in n or "tai" in n or "tdi" in n or "tei" in n or "téi" in n)):
        return allowed("Nội lực tối đa")

    if (re.search(r"\b(?:the|thé)\b", n) and
        re.search(r"\b(?:luc|lye)\b", n) and
        ("toi" in n or "tai" in n)):
        return allowed("Thể lực tối đa")

    if (re.search(r"\b(?:noi|nai|nei|hi)\b", n) and
        re.search(r"\b(?:cong|ceng|ceng|céng)\b", n)):
        return allowed("Nội công")

    # Resistances.
    if re.search(r"\b(?:khang|thang|ehang)\b", n):
        if re.search(r"\b(?:hoa|hea)\b", n):
            return allowed("Kháng hỏa")
        if "bang" in n:
            return allowed("Kháng băng")
        if re.search(r"\b(?:loi|lei)\b", n):
            return allowed("Kháng lôi")
        if re.search(r"\b(?:doc|dec)\b", n):
            return allowed("Kháng độc")

    # Time modifiers.
    if re.search(r"\b(?:thoi|thai|thei|thsi)\b", n) and "gian" in n:
        if "choang" in n:
            return allowed("Thời gian choáng")
        if re.search(r"\b(?:trung|trime)\b", n) and re.search(r"\b(?:doc|dec)\b", n):
            return allowed("Thời gian trúng độc")
        if "phuc" in n and re.search(r"\b(?:hoi|hei|hai)\b", n):
            return allowed("Thời gian phục hồi")

    # Conversion.
    if ("sat" in n and "thanh" in n and
        re.search(r"\b(?:noi|nai)\b", n) and "luc" in n and
        re.search(r"\b(?:thuong|thugne|thidne|thu)\b", n)):
        return allowed("Chuyển hóa sát thương thành nội lực")

    # Common random equipment options seen in logs(3).
    if (re.search(r"\b(?:phong|pheng)\b", n) and
        re.search(r"\b(?:thu|thw|thu)\b", n) and
        re.search(r"\b(?:vat|v4t)\b", n) and
        re.search(r"\b(?:ly|1y|ty)\b", n)):
        return allowed("Phòng thủ vật lý")

    if (re.search(r"\b(?:suc|sve|suc)\b", n) and
        re.search(r"\b(?:manh|manh)\b", n)):
        return allowed("Sức mạnh")

    if re.search(r"\b(?:than|th4n)\b", n) and re.search(r"\b(?:phap|ph4p)\b", n):
        return allowed("Thân pháp")

    if (re.search(r"\b(?:thoi|thai|thei|thsi)\b", n) and "gian" in n and
        re.search(r"\b(?:lam|1am)\b", n) and
        re.search(r"\b(?:cham|ch4m)\b", n)):
        return allowed("Thời gian làm chậm")

    if (re.search(r"\b(?:toc|tac|tec)\b", n) and
        re.search(r"\b(?:do|d0)\b", n) and
        re.search(r"\b(?:di|d1)\b", n) and
        re.search(r"\b(?:chuyen|chuyem)\b", n)):
        return allowed("Tốc độ di chuyển")

    return None



def _all_line_raws_v64(line_obj):
    raws=[]
    for x in (line_obj.get("all_name_ocr") or []):
        if isinstance(x,(list,tuple)) and len(x)>=2:
            raws.append(str(x[1]))
        else:
            raws.append(str(x))
    raws.extend(str(x) for x in (line_obj.get("v62_hf_ocr") or []) if x)

    # Do NOT de-duplicate all_name_ocr: each entry comes from a different OCR
    # preprocessing variant. If two independent variants both read -48 while
    # one reads -46, that is meaningful majority evidence.
    if not raws:
        for k in ("raw_name_ocr","raw_value_ocr"):
            if line_obj.get(k):
                raws.append(str(line_obj.get(k)))
    return [x for x in raws if x]


def _observed_range_votes_v64(raws):
    votes=defaultdict(int)
    examples={}
    for raw in raws or []:
        rg=_visible_range_v62(raw)
        if rg is None:
            continue
        rg=(int(rg[0]),int(rg[1]))
        votes[rg]+=1
        examples.setdefault(rg,raw)
    if not votes:
        return None,0,None
    winner=max(votes,key=lambda k:(votes[k], -(k[1]-k[0])))
    return winner,votes[winner],examples.get(winner)


def _range_compatible_v64(canonical, observed):
    if canonical is None or observed is None:
        return True
    ca,cb=map(int,canonical); oa,ob=map(int,observed)
    # Exact ranges are the normal contract. Small OCR drift is tolerated only
    # when both endpoints are very close.
    if (ca,cb)==(oa,ob):
        return True
    return abs(ca-oa)<=2 and abs(cb-ob)<=5


def _repair_name_by_range_v64(line_obj, group_id):
    out=dict(line_obj)
    raws=_all_line_raws_v64(out)
    observed,count,raw_example=_observed_range_votes_v64(raws)
    current=out.get("name")
    current_cr=_CANONICAL_DISPLAY_RANGES_V62.get(current)

    # First preference: deterministic semantic evidence from any raw variant.
    semantic=defaultdict(int)
    for raw in raws:
        name=_semantic_common_name_v62(raw,group_id)
        if name:
            cr=_CANONICAL_DISPLAY_RANGES_V62.get(name)
            if observed is None or cr is None or _range_compatible_v64(cr,observed):
                semantic[name]+=1

    fused=_semantic_fused_name_v65(raws,group_id)
    if fused:
        semantic[fused]+=2

    if semantic:
        best=max(semantic,key=lambda n:(semantic[n], float(max((_name_score(r,n) for r in raws), default=0.0))))
        if current is None or best==current or semantic[best]>=1:
            out["name"]=best
            out["name_confidence"]=max(float(out.get("name_confidence") or 0),0.98)
            current=best
            current_cr=_CANONICAL_DISPLAY_RANGES_V62.get(current)

    # If current canonical range visibly conflicts with the tooltip range,
    # do not allow a plausible numeric value to make the wrong NAME pass.
    if observed is not None and current_cr is not None and not _range_compatible_v64(current_cr,observed):
        candidates=_candidate_options(group_id)
        ranked=[]
        for name in candidates:
            cr=_CANONICAL_DISPLAY_RANGES_V62.get(name)
            if cr is None or not _range_compatible_v64(cr,observed):
                continue
            score=max((_name_score(raw,name) for raw in raws), default=0.0)
            sem=sum(1 for raw in raws if _semantic_common_name_v62(raw,group_id)==name)
            ranked.append((sem,score,name))
        ranked.sort(reverse=True)
        if ranked and (ranked[0][0]>=1 or ranked[0][1]>=0.58):
            out["name"]=ranked[0][2]
            out["name_confidence"]=max(float(out.get("name_confidence") or 0),0.97)
        else:
            # Better UNCERTAIN than false READY.
            out["name"]=None
            out["name_confidence"]=0.0

    out["v64_observed_range"]=None if observed is None else list(observed)
    out["v64_observed_range_votes"]=count
    out["v64_observed_range_raw"]=raw_example
    return out


def _primary_signed_candidates_v64(raw, option_name, unit):
    s=str(raw or "").replace("–","-").replace("—","-").replace("−","-")
    head=re.split(r"[\[\{£]",s,maxsplit=1)[0]
    if ":" in head:
        head=head.split(":",1)[1]
    head=re.sub(r"[†‡#$¢]", "+", head)

    rg=_CANONICAL_DISPLAY_RANGES_V62.get(option_name) or _visible_range_v62(s)
    out=[]
    # First signed-looking numeric token only. It is the primary VALUE by JX1 grammar.
    m=re.search(r'([+\-“”"]?)\s*([0-9Il|OoBbSsZz]{1,5})',head)
    if not m:
        return out
    sign_ch,token=m.group(1),m.group(2)
    if not re.search(r"\d",token):
        return out

    for mag in _numeric_token_variants_v62(token):
        sign=-1 if sign_ch=="-" else 1
        value=sign*mag
        if option_name and option_name.startswith("Thời gian "):
            value=-abs(value)
        repaired=_repair_to_range_v62(value,rg,unit=unit,has_sign=bool(sign_ch))
        if repaired:
            for rv,penalty in repaired:
                out.append((rv,penalty,bool(sign_ch),rg))
        elif rg is None:
            out.append((value,0,bool(sign_ch),rg))
    return out


def _majority_primary_value_v64(line_obj, name, unit):
    raws=_all_line_raws_v64(line_obj)
    value_votes=defaultdict(float)
    family_votes=defaultdict(set)
    evidence=[]

    for raw in raws:
        src="HF" if raw in (line_obj.get("v62_hf_ocr") or []) else "BASE"
        cands=_primary_signed_candidates_v64(raw,name,unit)
        if not cands:
            continue
        # Only the best first-primary candidate from each OCR raw may vote.
        value,penalty,has_sign,rg=sorted(cands,key=lambda x:(x[1],0 if x[2] else 1))[0]
        weight=1.0 + (0.20 if has_sign else 0.0) - 0.15*penalty
        value_votes[value]+=max(0.25,weight)
        family_votes[value].add(src)
        evidence.append({
            "value":value,"source":src,"raw":raw,
            "repair_penalty":penalty,
            "range":None if rg is None else list(rg)
        })

    if not value_votes:
        return line_obj.get("value"), evidence

    winner=max(
        value_votes,
        key=lambda v:(len(family_votes[v]), value_votes[v], -abs(v))
    )
    return winner,evidence


def _semantic_fused_name_v65(raws, group_id="__all__"):
    """Fuse tokens across OCR views of the same option row."""
    norms=[norm_text(x or "") for x in (raws or []) if x]
    blob=" ".join(norms)
    candidates=set(_candidate_options(group_id))

    def allowed(name):
        return name if name in candidates else None

    has_khang=bool(re.search(r"\b(?:khang|kang|hang|thang|ehang)\b", blob))
    has_sat_cong=("sat" in blob and ("cong" in blob or "ceng" in blob))
    if has_khang:
        if re.search(r"\b(?:loi|lei|l0i)\b", blob): return allowed("Kháng lôi")
        if re.search(r"\b(?:hoa|hea)\b", blob): return allowed("Kháng hỏa")
        if re.search(r"\bbang\b", blob): return allowed("Kháng băng")
        if re.search(r"\b(?:doc|dec)\b", blob): return allowed("Kháng độc")

    # Bottom colored rows can preserve only the element word in CHROMA OCR.
    # If "Lôi" survives but no sát/công weapon signature survives, tentatively
    # map to Kháng lôi; the v6.4 displayed-range gate still has final veto.
    if re.search(r"\b(?:loi|lei|l0i)\b", blob) and not has_sat_cong:
        return allowed("Kháng lôi")

    if "phuc" in blob and "sinh" in blob and re.search(r"\b(?:nua|nia|mia|nda)\b", blob):
        return allowed("Phục hồi sinh lực mỗi nửa giây")
    if "phuc" in blob and re.search(r"\b(?:noi|nei|nai|hei)\b", blob) and re.search(r"\b(?:nua|nia|mia|nda)\b", blob):
        return allowed("Phục hồi nội lực mỗi nửa giây")

    if ("chuyen" in blob or "ehuyen" in blob) and "sat" in blob and "thanh" in blob and re.search(r"\b(?:noi|nai|nei)\b", blob):
        return allowed("Chuyển hóa sát thương thành nội lực")

    if re.search(r"\b(?:tang|tane)\b", blob) and "tranh" in blob and re.search(r"\b(?:ne|me)\b", blob):
        return allowed("Tăng né tránh")

    return None


def _canonical_unit_v62(name, fallback=None):
    reg=_grammar_unit(name, None)
    if reg is not None:
        return reg
    return _CANONICAL_OPTION_UNITS_V62.get(name, fallback)


def _numeric_token_variants_v62(token):
    """
    Convert OCR-confused numeric glyphs into plausible integers.
    B is ambiguous in this bitmap font, so retain a few variants and let
    cross-read voting/range evidence decide.
    """
    fixed = {"I":"1", "l":"1", "|":"1", "O":"0", "o":"0",
             "Z":"2", "z":"2", "S":"5", "s":"5"}
    variants = [""]
    for ch in str(token):
        if ch.isdigit():
            opts = [ch]
        elif ch in fixed:
            opts = [fixed[ch]]
        elif ch in ("B", "b"):
            opts = ["8", "5", "6"]
        else:
            continue
        variants = [a+b for a in variants for b in opts]
    out = []
    for x in variants:
        if x and len(x) <= 5:
            try:
                v = int(x)
                if v not in out:
                    out.append(v)
            except Exception:
                pass
    return out


def _visible_range_v62(raw):
    """
    Read the [min-max] range loosely. When OCR inserts a stray digit between
    range ends, use the first and last numeric groups inside the bracket.
    """
    s = str(raw or "").replace("–","-").replace("—","-").replace("−","-")
    m = re.search(r"[\[\{£(]([^\]\}\)]{2,40})", s)
    if not m:
        return None
    inside = m.group(1)
    # A real range must visibly contain a separator; reject merged garbage
    # such as "[102360]".
    if not re.search(r"[-=~>]", inside):
        return None
    toks = re.findall(r"[0-9Il|Oo]{1,4}", inside)
    vals = []
    for t in toks:
        vv = _numeric_token_variants_v62(t)
        if vv:
            vals.append(vv[0])
    if len(vals) < 2:
        return None
    a, b = vals[0], vals[-1]
    if a <= 0 or b <= 0:
        return None
    return (min(a,b), max(a,b))


def _repair_to_range_v62(value, rg, unit=None, has_sign=False):
    if value is None:
        return []
    if rg is None:
        return [(int(value), 0)]

    lo, hi = rg
    sign = -1 if int(value) < 0 else 1
    digits = str(abs(int(value)))

    if lo <= abs(int(value)) <= hi:
        return [(int(value), 0)]

    ordered = []

    # The most common live JX1 failure is a junk percent/sign glyph appended
    # after the value: +14 -> 140, +23% -> 238, -49% -> -498.
    if len(digits) >= 2:
        ordered.append((int(digits[:-1]), 1, "TRAILING_1"))

    # When '+' disappears and becomes a leading 1/4 in an unsigned percent,
    # 123% with [20-80] is usually +23%, and 430% is +30%.
    if (unit == "%" and not has_sign and len(digits) == 3
        and digits[0] in ("1","4")):
        ordered.append((int(digits[1:]), 1, "LEADING_PLUS_GLYPH"))

    if len(digits) >= 3:
        ordered.append((int(digits[:-2]), 2, "TRAILING_2"))

    out = []
    for mag, penalty, why in ordered:
        if lo <= mag <= hi:
            item = (sign * mag, penalty)
            if item not in out:
                out.append(item)
    return out


def _primary_value_candidates_v62(raw, option_name, unit):
    """
    Extract primary value from the text before [min-max].
    Supports missing/garbled +/% glyphs.
    """
    s = str(raw or "").replace("–","-").replace("—","-").replace("−","-")
    head = re.split(r"[\[\{£]", s, maxsplit=1)[0]
    if ":" in head:
        head = head.split(":", 1)[1]

    # OCR often turns + into dagger/hash/currency glyphs.
    head = re.sub(r"[†‡#$¢]", "+", head)
    rg = _visible_range_v62(s)
    canonical_rg = _CANONICAL_DISPLAY_RANGES_V62.get(option_name)
    if canonical_rg is not None:
        # Canonical tooltip ranges are more reliable than garbled bracket OCR
        # such as "[102360]" or "[20.2 80]".
        rg = canonical_rg

    found = []
    for m in re.finditer(r'([+\-“”"]?)\s*([0-9Il|OoBbSsZz]{1,5})', head):
        sign_ch, token = m.group(1), m.group(2)
        # Never turn letters from the option name ("S" in Sinh, "l" in lực)
        # into fake standalone numbers.
        if not re.search(r"\d", token):
            continue
        for mag in _numeric_token_variants_v62(token):
            sign = -1 if sign_ch == "-" else 1
            v = sign * mag

            # Time modifiers are reductions in the JX1 tooltip, and the minus
            # glyph is frequently OCR'd as a quote.
            if option_name and option_name.startswith("Thời gian "):
                v = -abs(v)

            repaired = _repair_to_range_v62(v, rg, unit=unit, has_sign=bool(sign_ch))
            if repaired:
                for rv, penalty in repaired:
                    found.append((rv, penalty, bool(sign_ch), rg, bool(re.fullmatch(r"\d+", token))))
            elif rg is None:
                found.append((v, 0, bool(sign_ch), rg, bool(re.fullmatch(r"\d+", token))))
    return found


def _robust_value_v62(pil_line, name, unit, existing_reads, current_value, hf_reads=None):
    """
    Vote across:
      - existing v5.x OCR variants,
      - two high-fidelity bitmap variants,
      - dedicated numeric whitelist OCR.
    """
    sources = []
    for raw in existing_reads or []:
        if raw:
            sources.append(("BASE", raw, 1.0))

    hf = list(hf_reads) if hf_reads is not None else _hf_line_reads_v62(pil_line)
    for tag, raw in hf:
        sources.append((tag, raw, 1.35))

    # Dedicated numeric OCR is very useful for tiny '+'/'%' glyphs.
    try:
        if unit == "%":
            for raw in _numeric_whitelist_reads(
                pil_line, (0.28,0.30,0.38,0.42,0.50), True
            ):
                sources.append(("NUMERIC", raw, 1.20))
        elif unit in ("điểm", "điểm/lần", "cấp"):
            for raw in _numeric_whitelist_reads(
                pil_line, (0.28,0.34,0.42), False
            ):
                sources.append(("NUMERIC", raw, 0.85))
    except Exception:
        pass

    scores = defaultdict(float)
    evidence = []

    # Current Reader value remains evidence, but never dominates better raw OCR.
    if current_value is not None:
        try:
            cv = int(current_value)
            if name and name.startswith("Thời gian "):
                cv = -abs(cv)
            cr = _CANONICAL_DISPLAY_RANGES_V62.get(name)
            repaired_current = _repair_to_range_v62(
                cv, cr, unit=unit, has_sign=True
            ) if cr is not None else [(cv,0)]
            if repaired_current:
                cv = repaired_current[0][0]
                scores[cv] += 0.70
                evidence.append({"value":cv,"score":0.70,"source":"CURRENT"})
        except Exception:
            pass

    for src, raw, weight in sources:
        for value, penalty, has_sign, rg, token_clean in _primary_value_candidates_v62(raw, name, unit):
            # Broad sanity guard.
            if unit == "%" and abs(value) > 200:
                continue
            if unit in ("điểm", "điểm/lần") and abs(value) > 10000:
                continue

            score = weight
            if has_sign:
                score += 0.18
            score -= 0.18 * penalty

            # A clean high-fidelity signed numeric token (e.g. +437, -49)
            # is stronger than generic whitelist OCR. Do not boost OCR-letter
            # tokens such as "Z5", which are known bitmap confusions.
            if src.startswith("HF_") and token_clean and has_sign and penalty == 0:
                score += 1.00

            # Exact range membership is strong evidence.
            if rg is not None and rg[0] <= abs(value) <= rg[1]:
                score += 0.22

            scores[value] += max(0.05, score)
            evidence.append({
                "value": value,
                "score": round(max(0.05, score), 3),
                "source": src,
                "raw": raw,
                "range": None if rg is None else list(rg),
                "repair_penalty": penalty,
            })

    if not scores:
        return current_value, evidence, hf

    winner = sorted(scores, key=lambda v:(-scores[v], abs(v)))[0]
    return winner, evidence, hf


def _repair_line_v62(pil_line, line_obj, group_id):
    out = dict(line_obj)
    reads = list(out.get("all_name_ocr") or [])

    # High-fidelity evidence helps names without replacing the original Reader.
    hf = _hf_line_reads_v62(pil_line)
    semantic_votes = defaultdict(int)
    for raw in reads + [x[1] for x in hf]:
        name = _semantic_common_name_v62(raw, group_id)
        if name:
            semantic_votes[name] += 1

    if semantic_votes:
        best_name = max(semantic_votes, key=lambda k: semantic_votes[k])
        # Do not override a good name with a single weak contradictory vote.
        current_name = out.get("name")
        if current_name is None or best_name == current_name or semantic_votes[best_name] >= 2:
            out["name"] = best_name
            out["name_confidence"] = max(float(out.get("name_confidence") or 0), 0.97)

    name = out.get("name")
    unit = _canonical_unit_v62(name, out.get("unit"))
    out["unit"] = unit

    value, evidence, hf2 = _robust_value_v62(
        pil_line,
        name,
        unit,
        reads,
        out.get("value"),
        hf_reads=hf
    )

    if value is not None:
        out["value"] = value
        out["value_confidence"] = max(float(out.get("value_confidence") or 0), 0.96)

    out["v62_hf_ocr"] = [x[1] for x in hf2]
    out["v62_value_evidence"] = evidence
    fixes = list(out.get("fixes") or [])
    if semantic_votes and "V62_NAME_VOTE" not in fixes:
        fixes.append("V62_NAME_VOTE")
    if value is not None and "V62_VALUE_VOTE" not in fixes:
        fixes.append("V62_VALUE_VOTE")
    if unit is not None and "V62_CANONICAL_UNIT" not in fixes:
        fixes.append("V62_CANONICAL_UNIT")
    out["fixes"] = fixes

    out["status"] = "READY" if (
        out.get("name") is not None and
        out.get("value") is not None and
        out.get("unit") is not None and
        float(out.get("name_confidence") or 0) >= 0.43 and
        float(out.get("value_confidence") or 0) >= 0.70
    ) else "UNCERTAIN"
    return out


def _quick_row_ocr_v62(pil, y0, y1):
    try:
        crop=pil.crop((0,max(0,int(y0)-5),pil.width,min(pil.height,int(y1)+6))).convert("RGB")
        reads=_hf_line_reads_v62(crop)
        if reads:
            return reads[0][1]

        # v6.4 fallback: the MAX channel is materially better on the real Q3
        # bottom edge where normal HF returned empty.
        arr=np.asarray(crop)
        if arr.size:
            allowed=_blue_gray_mask_rgb(arr)
            up=cv2.resize(allowed,None,fx=6,fy=6,interpolation=cv2.INTER_NEAREST)
            rr=safe_ocr_string(Image.fromarray(up),config="--psm 7")
            if rr:
                return rr[0][1]
        return ""
    except Exception:
        return ""


def _recover_bottom_last6_v62(pil, boxes):
    """
    Fix the real edge case from logs(2):
    current six rows started at 'Giới tính: Nữ' and missed the real bottom OPT.

    Shift down only when:
      - there is room for one more cadence row,
      - the current first row does NOT look like an option range,
      - the predicted bottom row DOES look like an option range.
    """
    if len(boxes) != 6:
        return boxes, {"applied": False}

    centers = [(a+b)/2.0 for a,b in boxes]
    gaps = [centers[i+1]-centers[i] for i in range(5)]
    gap = float(np.median(gaps)) if gaps else 13.0
    heights = [b-a+1 for a,b in boxes]
    h = int(round(float(np.median(heights)))) if heights else 8

    next_center = centers[-1] + gap
    y0 = int(round(next_center - (h-1)/2.0))
    y1 = y0 + h - 1

    if y1 >= pil.height - 1:
        return boxes, {"applied": False, "reason": "NO_ROOM"}

    first_raw = _quick_row_ocr_v62(pil, boxes[0][0], boxes[0][1])
    next_raw = _quick_row_ocr_v62(pil, y0, y1)

    def optionish(raw):
        n = str(raw or "")
        # Every real random option row in this JX1 build carries a displayed
        # [min-max] range. Requirement/gender/fixed-stat rows do not.
        # The primary +VALUE glyph is too small to require here.
        return bool(
            re.search(r"[\[\{£(].{0,28}\d.{0,12}[-=~>—–].{0,12}\d", n)
        )

    first_norm=norm_text(first_raw or "")
    gender_row=("gioi tinh" in first_norm) or ("giai tinh" in first_norm)
    candidate_has_text=bool(re.search(r"[A-Za-zÀ-ỹ]", str(next_raw or "")))

    if (not optionish(first_raw)) and (optionish(next_raw) or (gender_row and candidate_has_text)):
        shifted = list(boxes[1:]) + [(y0,y1)]
        return shifted, {
            "applied": True,
            "old_first": list(boxes[0]),
            "new_last": [y0,y1],
            "first_raw": first_raw,
            "new_last_raw": next_raw,
            "cadence": gap,
            "gender_row_forced_shift": bool(gender_row and not optionish(next_raw)),
        }

    return boxes, {
        "applied": False,
        "first_raw": first_raw,
        "candidate_raw": next_raw,
        "candidate_box": [y0,y1],
    }



# ---------------------------------------------------------------------------
# v6.3 RUNTIME TRUTH GATE
# ---------------------------------------------------------------------------
def _segmentation_truth_gate_v63(boxes, image_height):
    if len(boxes) != 6:
        return {"pass":False,"reasons":["NOT_6_ROWS"]}
    centers=[(float(a)+float(b))/2.0 for a,b in boxes]
    gaps=[centers[i+1]-centers[i] for i in range(5)]
    heights=[int(b)-int(a)+1 for a,b in boxes]
    med=float(np.median(gaps)) if gaps else 0.0
    mad=float(np.median(np.abs(np.asarray(gaps)-med))) if gaps else 999.0
    spread=(max(gaps)-min(gaps)) if gaps else 999.0
    bottom_gap=int(image_height)-1-int(boxes[-1][1])
    reasons=[]

    overlaps=[]
    for i in range(len(boxes)-1):
        ov=max(0, min(int(boxes[i][1]),int(boxes[i+1][1])) - max(int(boxes[i][0]),int(boxes[i+1][0])) + 1)
        if ov>0:
            overlaps.append({"rows":[i+1,i+2],"overlap_px":int(ov)})

    if overlaps:
        reasons.append("OVERLAPPING_PHYSICAL_ROWS")

    med_height=float(np.median(heights)) if heights else 0.0
    if med_height>0 and max(heights) > max(18.0, med_height*1.85):
        reasons.append("FUSED_ROW_HEIGHT_OUTLIER")

    if not (8.0 <= med <= 18.5): reasons.append("BAD_CADENCE_MEDIAN")
    if mad > 2.2: reasons.append("BAD_CADENCE_MAD")
    if spread > 6.5: reasons.append("BAD_CADENCE_SPREAD")
    if not (5 <= int(np.median(heights)) <= 14): reasons.append("BAD_ROW_HEIGHT")
    if bottom_gap > max(36, int(image_height*0.18)): reasons.append("LAST6_NOT_NEAR_BOTTOM")
    return {
        "pass":not reasons,"reasons":reasons,"median_gap":round(med,3),
        "mad":round(mad,3),"spread":round(float(spread),3),
        "bottom_gap":bottom_gap,"heights":heights,
        "overlaps":overlaps,
        "median_row_height":round(med_height,3),
    }


def _truth_gate_line_v63(line_obj, group_id):
    name=line_obj.get("name")
    value=line_obj.get("value")
    unit=line_obj.get("unit")
    reasons=[]
    candidates=set(_candidate_options(group_id))
    if not name or name not in candidates:
        reasons.append("NAME_NOT_CANONICAL")

    canonical_unit=_canonical_unit_v62(name, unit) if name else unit
    if canonical_unit is not None and unit != canonical_unit:
        reasons.append("UNIT_MISMATCH")

    cr=_CANONICAL_DISPLAY_RANGES_V62.get(name)
    if cr is not None:
        try:
            av=abs(int(value))
            if not (int(cr[0]) <= av <= int(cr[1])):
                reasons.append("VALUE_OUTSIDE_CANONICAL_RANGE")
        except Exception:
            reasons.append("VALUE_MISSING")
    elif value is None:
        reasons.append("VALUE_MISSING")

    # v6.4: compare the range printed on the tooltip with the canonical range.
    # This blocks false READY cases such as:
    #   "Sinh lực tối đa +594 [400-1000]" -> misread as "Sinh khí +59 [10-60]".
    observed=line_obj.get("v64_observed_range")
    if cr is not None and observed is not None:
        observed=tuple(int(x) for x in observed)
        if not _range_compatible_v64(cr,observed):
            reasons.append("DISPLAY_RANGE_CONFLICT")

    raws=[]
    for x in (line_obj.get("all_name_ocr") or []):
        if isinstance(x,(list,tuple)) and len(x)>=2: raws.append(str(x[1]))
        else: raws.append(str(x))
    raws.extend(str(x) for x in (line_obj.get("v62_hf_ocr") or []) if x)
    for k in ("raw_name_ocr","raw_value_ocr"):
        if line_obj.get(k): raws.append(str(line_obj.get(k)))

    name_scores=[]
    semantic_support=0
    if name:
        for raw in raws:
            try: name_scores.append(float(_name_score(raw,name)))
            except Exception: pass
            try:
                if _semantic_common_name_v62(raw,group_id)==name:
                    semantic_support += 1
            except Exception: pass
    max_name=max(name_scores) if name_scores else 0.0
    # A line cannot be READY just because the fuzzy matcher picked something.
    if name and max_name < 0.50 and semantic_support < 1:
        reasons.append("WEAK_NAME_EVIDENCE")

    # Count independent evidence families that support the final numeric value.
    srcs=set()
    exact_value_evidence=0
    for ev in (line_obj.get("v62_value_evidence") or []):
        try:
            if int(ev.get("value")) == int(value):
                exact_value_evidence += 1
                src=str(ev.get("source") or "")
                if src.startswith("HF_"): src="HF"
                elif src.startswith("NUMERIC"): src="NUMERIC"
                elif src.startswith("BASE"): src="BASE"
                elif src.startswith("CURRENT"): src="CURRENT"
                srcs.add(src)
        except Exception:
            pass
    self_contained=False
    if value is not None and name:
        for raw in raws:
            rg=_visible_range_v62(raw)
            cands=_primary_signed_candidates_v64(raw,name,unit)
            if rg is not None and cands:
                if cr is None or _range_compatible_v64(cr,rg):
                    if any(int(c[0])==int(value) for c in cands):
                        self_contained=True
                        break
    if value is not None and len(srcs) < 2 and exact_value_evidence < 2 and not self_contained:
        reasons.append("WEAK_VALUE_EVIDENCE")

    passed=not reasons
    return {
        "pass":passed,"reasons":reasons,"max_name_score":round(max_name,4),
        "semantic_support":semantic_support,"value_sources":sorted(srcs),
        "value_evidence_count":exact_value_evidence,"canonical_range":cr,
        "observed_range":line_obj.get("v64_observed_range"),
        "self_contained_value_evidence":self_contained,
    }


def _ocr_reads_strings_v170(reads):
    out=[]
    for x in reads or []:
        if isinstance(x,(list,tuple)) and len(x)>=2: out.append(str(x[1]))
        elif x is not None: out.append(str(x))
    return out

def _paddle_option_candidate_v170(raw,group_id):
    best=(0.0,None)
    for option in _candidate_options(group_id):
        try: sc=float(_name_score(raw,option))
        except Exception: sc=0.0
        if sc>best[0]: best=(sc,option)
    return best[1],best[0]

def _paddle_value_v170(raw,name,unit):
    try:
        vals=_primary_signed_candidates_v64(raw,name,unit)
        if vals: return int(vals[0][0])
    except Exception: pass
    try:
        vals=_numeric_candidates(raw)
        if vals: return int(vals[0])
    except Exception: pass
    return None

def _paddle_geometry_v170(rows,image_h):
    if len(rows)!=6: return {"pass":False,"reason":"COUNT_NE_6"}
    centers=[(float(x["box"][1])+float(x["box"][3]))/2.0 for x in rows]
    gaps=np.diff(np.asarray(centers,dtype=float))
    if len(gaps)!=5 or np.any(gaps<4):
        return {"pass":False,"reason":"BAD_ORDER","centers":centers}
    med=float(np.median(gaps)); mad=float(np.median(np.abs(gaps-med)))
    lower=centers[-1]/max(1.0,float(image_h))
    ok=bool(med>=7 and mad<=max(7.0,med*0.48) and lower>=0.38)
    return {"pass":ok,"reason":None if ok else "CADENCE_FAIL",
            "centers":[round(x,3) for x in centers],"median_gap":round(med,3),
            "mad":round(mad,3),"lower_ratio":round(lower,4)}

def _read_single_tooltip_paddle_hybrid_v170(image_path,group_id):
    if paddleocr_recognize is None:
        return {"status":"UNAVAILABLE","reason":"PADDLE_IMPORT_MISSING","lines":[]}
    image_path=Path(image_path)
    img=_cv_imread_unicode(image_path)
    if img is None:
        return {"status":"UNAVAILABLE","reason":"IMAGE_READ_FAILED","lines":[]}
    paddle=paddleocr_recognize(img,min_score=0.34)
    if not paddle.get("ok"):
        return {"status":"UNAVAILABLE","reason":paddle.get("reason") or "PADDLE_UNAVAILABLE",
                "lines":[],"paddle":paddle}

    cand=[]
    for det in paddle.get("lines",[]) or []:
        raw=str(det.get("text") or "").strip()
        name,score=_paddle_option_candidate_v170(raw,group_id)
        box=list(det.get("box") or [])
        if name and score>=0.45 and len(box)==4:
            cand.append({**det,"canonical_candidate":name,"canonical_score":float(score)})
    cand.sort(key=lambda x:((x["box"][1]+x["box"][3])/2.0,x["box"][0]))
    if len(cand)<6:
        return {"status":"UNCERTAIN","reason":"PADDLE_OPTION_ROWS_LT_6","lines":[],
                "candidate_count":len(cand),"paddle":paddle}
    rows=cand[-6:]
    geom=_paddle_geometry_v170(rows,img.shape[0])
    if not geom.get("pass"):
        return {"status":"UNCERTAIN","reason":"PADDLE_GEOMETRY_UNCERTAIN","lines":[],
                "paddle_geometry":geom,"paddle_final6_rows":rows,"paddle":paddle}

    pil=Image.open(image_path).convert("RGB")
    final=[]
    for idx,det in enumerate(rows,1):
        x0,y0,x1,y1=[int(v) for v in det["box"]]
        padx=max(8,int((x1-x0)*0.025)); pady=max(5,int((y1-y0)*0.40))
        crop=pil.crop((max(0,x0-padx),max(0,y0-pady),
                       min(pil.width,x1+padx+1),min(pil.height,y1+pady+1)))
        tess=recognize_line(crop,group_id)
        raw=str(det.get("text") or "")
        pname=det.get("canonical_candidate"); pscore=float(det.get("canonical_score") or 0.0)
        pconf=float(det.get("score") or 0.0)

        reads=_ocr_reads_strings_v170(tess.get("ocr_reads")); reads.append(raw)
        name=tess.get("name"); nconf=float(tess.get("name_confidence") or 0.0)
        if name==pname and name is not None:
            nconf=max(nconf,min(0.995,0.70+0.30*pconf))
        elif (name is None or nconf<0.55) and pscore>=0.64 and pconf>=0.52:
            name=pname; nconf=max(nconf,min(0.985,0.55+0.40*pscore))

        unit=_canonical_unit_v62(name,infer_unit(group_id,name,raw,tess.get("raw_ocr") or ""))
        pvalue=_paddle_value_v170(raw,name,unit)
        value=tess.get("value"); vconf=float(tess.get("value_confidence") or 0.0)
        if pvalue is not None:
            plaus=_value_plausibility(group_id,name,unit,pvalue)
            if value is not None and int(value)==int(pvalue): vconf=max(vconf,0.985)
            elif (value is None or vconf<0.70) and plaus>=0.80:
                value=int(pvalue); vconf=max(vconf,0.90)

        ve=list(tess.get("v62_value_evidence") or [])
        if pvalue is not None:
            ve.append({"source":"PADDLE","value":int(pvalue),"raw":raw,"confidence":pconf})

        line={"line":idx,"name":name,"value":value,"unit":unit,
              "name_confidence":nconf,"value_confidence":vconf,
              "status":"READY" if (name is not None and nconf>=0.43 and value is not None and vconf>=0.70 and unit is not None) else "UNCERTAIN",
              "fixes":list(tess.get("fixes") or [])+["PADDLE_FULL_TOOLTIP_BOX"],
              "raw_name_ocr":raw,"raw_value_ocr":raw,"all_name_ocr":reads,
              "numeric_candidates":list(tess.get("numeric_candidates") or []),
              "attack_speed_percent_authority":tess.get("attack_speed_percent_authority"),
              "box":[y0,y1],"paddle_box":[x0,y0,x1,y1],"paddle_text":raw,
              "paddle_confidence":pconf,"paddle_name_candidate":pname,
              "paddle_name_score":round(pscore,4),"tesseract_name":tess.get("name"),
              "tesseract_value":tess.get("value"),"v62_value_evidence":ve}
        line=_grammar_repair_line(line,group_id)
        line=_targeted_hf_rescue(crop,line,group_id)
        line=_repair_line_v62(crop,line,group_id)
        line=_repair_name_by_range_v64(line,group_id)
        line["unit"]=_canonical_unit_v62(line.get("name"),line.get("unit"))
        vv,ev=_majority_primary_value_v64(line,line.get("name"),line.get("unit"))
        if vv is not None:
            line["value"]=vv
            line["value_confidence"]=max(float(line.get("value_confidence") or 0),0.97)
        line["v64_primary_evidence"]=ev
        line["truth_gate"]=_truth_gate_line_v63(line,group_id)
        if not line["truth_gate"]["pass"]: line["status"]="UNCERTAIN"
        final.append(line)

    ready=bool(len(final)==6 and all(x.get("status")=="READY" and x.get("truth_gate",{}).get("pass") for x in final))
    return {"status":"READY" if ready else "UNCERTAIN",
            "reason":None if ready else "PADDLE_HYBRID_TRUTH_UNRESOLVED",
            "group_id":group_id,"image":str(image_path),
            "ocr_pipeline":"PADDLE_VI_FULL_TOOLTIP_PLUS_TESSERACT_VERIFY",
            "paddle_engine_status":paddleocr_engine_status(),
            "paddle_elapsed_ms":paddle.get("elapsed_ms"),"paddle_geometry":geom,
            "paddle_final6_rows":rows,"lines":final,
            "segmentation":{"status":"OK","method":"PADDLEOCR_TEXT_DETECTION",
                            "boxes":[[int(x["box"][1]),int(x["box"][3])] for x in rows],
                            "v63_truth_gate":geom}}

def _read_single_tooltip_legacy(image_path, group_id):
    image_path = Path(image_path)
    pil = Image.open(image_path).convert("RGB")
    boxes, seg = extract_last6_boxes(image_path, return_debug=True)
    if len(boxes) != 6:
        return {"status":"UNCERTAIN","reason":"LAST6_NOT_FOUND","lines":[],"segmentation":seg}

    boxes, bottom_recovery = _recover_bottom_last6_v62(pil, boxes)
    seg["v62_bottom_recovery"] = bottom_recovery
    seg["boxes"] = [[int(a),int(b)] for a,b in boxes]
    seg["centers"] = [round((a+b)/2.0, 3) for a,b in boxes]
    seg["v63_truth_gate"] = _segmentation_truth_gate_v63(boxes, pil.height)

    seg["option_range"]={
        "first_option_y":int(boxes[0][0]),
        "last_option_y":int(boxes[-1][1]),
        "rule":"FINAL_6_OPTION_ROWS"
    }
    seg["overlay_file"]=_save_last6_overlay(image_path,boxes)

    lines = []
    for idx, (y0, y1) in enumerate(boxes, 1):
        pad_y = max(5, int(pil.height * 0.018))
        crop = pil.crop((0, max(0, y0-pad_y), pil.width, min(pil.height, y1+pad_y+1)))
        x = recognize_line(crop, group_id)
        line_status = "READY" if (
            x["name"] is not None and
            x["name_confidence"] >= 0.43 and
            x["value"] is not None and
            x["value_confidence"] >= 0.70 and
            x["unit"] is not None
        ) else "UNCERTAIN"
        line_obj = {
            "line": idx,
            "name": x["name"],
            "value": x["value"],
            "unit": x["unit"],
            "name_confidence": x["name_confidence"],
            "value_confidence": x["value_confidence"],
            "status": line_status,
            "fixes": x["fixes"],
            "raw_name_ocr": x["raw_ocr"],
            "raw_value_ocr": x["raw_ocr"],
            "all_name_ocr": x["ocr_reads"],
            "numeric_candidates": x["numeric_candidates"],
            "attack_speed_percent_authority": x.get("attack_speed_percent_authority"),
            "box": [int(y0), int(y1)],
        }
        line_obj = _grammar_repair_line(line_obj, group_id)
        line_obj = _targeted_hf_rescue(crop, line_obj, group_id)
        line_obj = _repair_line_v62(crop, line_obj, group_id)

        # v6.4: the visible [min-max] range is independent evidence about the
        # option family. Use it to repair/deny false names before READY.
        line_obj = _repair_name_by_range_v64(line_obj, group_id)
        line_obj["unit"] = _canonical_unit_v62(line_obj.get("name"), line_obj.get("unit"))

        v64_value, v64_evidence = _majority_primary_value_v64(
            line_obj, line_obj.get("name"), line_obj.get("unit")
        )
        if v64_value is not None:
            line_obj["value"] = v64_value
            line_obj["value_confidence"] = max(float(line_obj.get("value_confidence") or 0),0.97)
        line_obj["v64_primary_evidence"] = v64_evidence

        line_obj["truth_gate"] = _truth_gate_line_v63(line_obj, group_id)
        if not line_obj["truth_gate"]["pass"]:
            line_obj["status"] = "UNCERTAIN"
        lines.append(line_obj)

    all_empty = all(not x.get("all_name_ocr") for x in lines)
    return {
        "status": (
            "READY" if (
                seg.get("v63_truth_gate",{}).get("pass") and
                all(x["status"] == "READY" and x.get("truth_gate",{}).get("pass") for x in lines)
            ) else ("OCR_ENGINE_EMPTY" if all_empty else "UNCERTAIN")
        ),
        "group_id": group_id,
        "image": str(image_path),
        "segmentation": seg,
        "lines": lines,
    }


def _reader_quality_score_v170(result):
    if not isinstance(result,dict): return -999
    lines=list(result.get("lines") or [])
    ready=sum(1 for x in lines if x.get("status")=="READY" and x.get("truth_gate",{}).get("pass"))
    geom=1 if result.get("segmentation",{}).get("v63_truth_gate",{}).get("pass") else 0
    return ready*10+geom*4+(3 if result.get("status")=="READY" else 0)

def read_single_tooltip(image_path,group_id):
    hybrid=_read_single_tooltip_paddle_hybrid_v170(image_path,group_id)
    if hybrid.get("status")=="READY":
        hybrid["reader_selection"]="PADDLE_HYBRID_READY"
        return hybrid
    legacy=_read_single_tooltip_legacy(image_path,group_id)
    if _reader_quality_score_v170(hybrid)>_reader_quality_score_v170(legacy):
        hybrid["reader_selection"]="PADDLE_HYBRID_BEST_AVAILABLE"
        hybrid["legacy_fallback_status"]=legacy.get("status")
        return hybrid
    legacy["reader_selection"]="LEGACY_STAGE16_FALLBACK"
    legacy["paddle_hybrid_status"]={"status":hybrid.get("status"),"reason":hybrid.get("reason"),
                                    "engine":hybrid.get("paddle_engine_status") or paddleocr_engine_status()}
    return legacy


def consensus(results):
    if not results:
        return {"status":"UNCERTAIN","lines":[],"truth_gate":{"pass":False,"reason":"NO_FRAMES"}}
    if all(r.get("segmentation",{}).get("status")=="IMAGE_READ_FAILED" for r in results):
        return {"status":"IMAGE_READ_FAILED","lines":[],"frame_statuses":[r.get("status") for r in results]}
    if all(r.get("status")=="OCR_ENGINE_EMPTY" for r in results):
        return {"status":"OCR_ENGINE_EMPTY","lines":[],"frame_statuses":[r.get("status") for r in results]}
    if len(results)==1:
        return results[0]

    good_geometry=sum(1 for r in results if r.get("segmentation",{}).get("v63_truth_gate",{}).get("pass"))
    out=[]
    for i in range(6):
        votes=defaultdict(int); exemplars={}; eligible=0
        for r in results:
            if not r.get("segmentation",{}).get("v63_truth_gate",{}).get("pass"):
                continue
            if len(r.get("lines",[]))!=6: continue
            x=r["lines"][i]
            if not x.get("truth_gate",{}).get("pass"):
                continue
            eligible += 1
            key=(x.get("name"),x.get("value"),x.get("unit"))
            votes[key]+=1; exemplars[key]=x
        if not votes:
            out.append({"line":i+1,"status":"UNCERTAIN","votes":0,"truth_gate":{"pass":False,"reason":"NO_TRUTH_GATED_VOTE"}})
            continue
        winner=max(votes,key=votes.get)
        need=2 if len(results)>=3 else len(results)
        x=dict(exemplars[winner]); x["votes"]=votes[winner]
        x["eligible_frames"]=eligible
        x["status"]="READY" if votes[winner]>=need and None not in winner else "UNCERTAIN"
        if x["status"]!="READY":
            x["truth_gate"]={**x.get("truth_gate",{}),"pass":False,"consensus_reason":"INSUFFICIENT_TRUTH_VOTES"}
        out.append(x)
    ready=(good_geometry>=2 and len(out)==6 and all(x.get("status")=="READY" for x in out))
    return {
        "status":"READY" if ready else "UNCERTAIN",
        "lines":out,
        "frame_statuses":[r.get("status") for r in results],
        "truth_gate":{"pass":ready,"good_geometry_frames":good_geometry,"required_geometry_frames":2},
    }


def evaluate_filter(read_result, filter_config):
    if read_result.get("status") != "READY":
        return {"decision":"UNCERTAIN","reason":"READER_NOT_READY","rule_results":[]}
    observed = {x["name"]: x for x in read_result["lines"]}
    passed = 0; enabled = 0; mandatory_failed = False; rule_results = []
    for rule in filter_config.get("rules", []):
        if not rule.get("enabled", True):
            continue
        enabled += 1
        hit = observed.get(rule["option_name"])
        ok = False
        if hit is not None and hit.get("value") is not None:
            v = float(hit["value"]); target = float(rule["value"]); op = rule.get("op", ">=")
            ok = {">=":v>=target,"<=":v<=target,">":v>target,"<":v<target,"==":v==target}[op]
        passed += int(ok)
        if rule.get("mandatory", False) and not ok:
            mandatory_failed = True
        rule_results.append({
            "option_name":rule["option_name"], "found_value":None if hit is None else hit.get("value"),
            "operator":rule.get("op", ">="), "target":rule["value"], "passed":ok,
            "mandatory":bool(rule.get("mandatory", False)),
        })
    if mandatory_failed:
        decision = "FAIL"
    elif enabled == 0:
        decision = "PASS"
    elif filter_config.get("mode", "ALL") == "ALL":
        decision = "PASS" if passed == enabled else "FAIL"
    else:
        need = int(filter_config.get("at_least_n", 1))
        decision = "PASS" if passed >= need else "FAIL"
    return {"decision":decision,"rule_results":rule_results}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--group", required=True)
    ap.add_argument("--image", action="append", required=True)
    ap.add_argument("--filter")
    ap.add_argument("--out", default="dryrun_result.json")
    args = ap.parse_args()
    results = [read_single_tooltip(x, args.group) for x in args.image[:3]]
    final = consensus(results)
    payload = {"reader":final,"frames":results,"live_actions_enabled":False}
    if args.filter:
        cfg = json.loads(Path(args.filter).read_text(encoding="utf-8"))
        payload["filter"] = evaluate_filter(final, cfg)
    Path(args.out).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
