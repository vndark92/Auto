
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
import numpy as np

def build_ocr_views(img: Image.Image):
    """Return OCR-friendly views for translucent JX1 tooltip/inventory overlays."""
    rgb = img.convert("RGB")
    out = [("original", rgb)]

    gray = ImageOps.grayscale(rgb)
    gray = ImageOps.autocontrast(gray, cutoff=1)
    gray = ImageEnhance.Contrast(gray).enhance(1.8)
    gray = ImageEnhance.Sharpness(gray).enhance(1.35)
    out.append(("gray_contrast", gray.convert("RGB")))

    a = np.asarray(rgb, dtype=np.uint8)
    mx = a.max(axis=2).astype(np.int16)
    mn = a.min(axis=2).astype(np.int16)
    sat = mx - mn
    lum = a.mean(axis=2)
    mask = ((lum >= 118) | ((sat >= 38) & (lum >= 82)))
    cleaned = np.zeros_like(a)
    cleaned[mask] = a[mask]
    fg = Image.fromarray(cleaned, "RGB")
    fg = ImageEnhance.Contrast(fg).enhance(1.65)
    fg = ImageEnhance.Sharpness(fg).enhance(1.4)
    out.append(("fg_suppress", fg))

    g = np.asarray(ImageOps.grayscale(rgb), dtype=np.uint8)
    th = int(max(92, min(168, float(np.percentile(g, 71)))))
    bw = np.where(g >= th, 255, 0).astype(np.uint8)
    b = Image.fromarray(bw, "L").filter(ImageFilter.MedianFilter(3)).convert("RGB")
    out.append(("binary", b))

    scaled = []
    for name, im in out:
        scaled.append((name+"_2x", im.resize((im.width*2, im.height*2))))
    return out + scaled
