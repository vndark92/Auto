from __future__ import annotations
from pathlib import Path
from difflib import SequenceMatcher
import re
import unicodedata

import cv2
import numpy as np
import pytesseract
from PIL import Image


# ONLY user-confirmed unique anchors live here.
# "Kỹ năng Võ công vốn có" is intentionally absent because it is shared.
ANCHORS = {
    # Vũ khí
    "Tăng độ chính xác đòn đánh cận chiến": "vukhi",
    "Hỏa sát – ngoại công": "vukhi",
    "Hỏa sát – nội công": "vukhi",
    "Sát thương vật lý – ngoại công": "vukhi",
    "Sát thương vật lý – nội công": "vukhi",
    "Tốc độ đánh – ngoại công": "vukhi",
    "Tốc độ đánh – nội công": "vukhi",
    "Độc sát – nội công": "vukhi",
    "Độc sát – ngoại công": "vukhi",
    "Lôi sát – nội công": "vukhi",
    "Lôi sát – ngoại công": "vukhi",
    "Băng sát – nội công": "vukhi",
    "Băng sát – ngoại công": "vukhi",

    # Giày
    "Tốc độ di chuyển": "giay",

    # Áo
    "Thời gian phục hồi": "ao",

    # Dây chuyền / Ngọc bội family
    "Kháng tất cả": "jewelry",
    "Tăng công kích kỹ năng": "baotay",
    "Mức kháng tính tối đa": "daychuyen",
}


def _norm(text):
    s = unicodedata.normalize("NFD", str(text or ""))
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    s = s.lower().replace("đ", "d")
    s = s.replace("–", "-").replace("—", "-")
    s = re.sub(r"[^a-z0-9%+\-\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _name_part(raw):
    # Only the label before ':' participates in anchor matching.
    s = str(raw or "")
    if ":" in s:
        s = s.split(":", 1)[0]

    n = _norm(s)

    # Strip leading OCR debris such as an isolated number.
    n = re.sub(r"^(?:\d+\s+)+", "", n)

    # Real JX1 bitmap OCR confusions observed on the current client.
    aliases = (
        (r"\bthai\s+gian\b", "thoi gian"),
        (r"\bphuc\s+hai\b", "phuc hoi"),
        (r"\bphuc\s+haii\b", "phuc hoi"),
    )
    for pat, rep in aliases:
        n = re.sub(pat, rep, n)

    return re.sub(r"\s+", " ", n).strip()


_QUALIFIER_CONG = r"(?:cong|ceng|cdng|cing|cang|c0ng)"
_QUALIFIER_NOI = r"(?:noi|nei|n0i|ni)"
_QUALIFIER_NGOAI = r"(?:ngoai|ng0ai|ngo4|ngoa1|ngoal|ngoair|ngogi|ngos|nzoai)"

def _expected_qualifier(canonical):
    n=_norm(canonical)
    if re.search(r"\bngoai\s+cong\b",n): return 'NGOAI'
    if re.search(r"\bnoi\s+cong\b",n): return 'NOI'
    return None

def _observed_qualifier(raw_name):
    n=_name_part(raw_name)
    noi=bool(re.search(rf"\b{_QUALIFIER_NOI}\s+{_QUALIFIER_CONG}\b",n))
    ngoai=bool(re.search(rf"\b{_QUALIFIER_NGOAI}\s+{_QUALIFIER_CONG}\b",n))
    if noi and ngoai: return 'CONFLICT'
    if noi: return 'NOI'
    if ngoai: return 'NGOAI'
    return None

def _qualifier_compatible(raw_name,canonical):
    expected=_expected_qualifier(canonical)
    if expected is None: return True
    return _observed_qualifier(raw_name)==expected

def _similarity(raw_name, canonical):
    if not _qualifier_compatible(raw_name,canonical):
        return 0.0
    a = _name_part(raw_name)
    b = _norm(canonical)
    if not a or not b:
        return 0.0

    # Exact/substring evidence.
    if a == b:
        return 1.0
    if b in a or a in b:
        return min(0.99, 0.90 + 0.09 * min(len(a), len(b)) / max(len(a), len(b)))

    ratio = SequenceMatcher(None, a, b).ratio()

    # Token overlap makes bitmap OCR distortions less fragile.
    ta, tb = set(a.split()), set(b.split())
    token_score = len(ta & tb) / max(1, len(tb))

    return max(ratio, 0.55 * ratio + 0.45 * token_score)


def _match_anchor(raw_line):
    best = None
    for canonical, group_id in ANCHORS.items():
        score = _similarity(raw_line, canonical)
        # Long exclusive names can survive substantial bitmap OCR noise.
        threshold = 0.76 if len(_norm(canonical)) >= 15 else 0.80
        if score >= threshold:
            if best is None or score > best["score"]:
                best = {
                    "canonical": canonical,
                    "group_id": group_id,
                    "score": round(float(score), 4),
                    "raw": str(raw_line or ""),
                }
    return best


def _load_image(image_or_path):
    if isinstance(image_or_path, Image.Image):
        return image_or_path.convert("RGB")
    p = Path(image_or_path)
    try:
        buf = np.fromfile(str(p), dtype=np.uint8)
        arr = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        if arr is None:
            return None
        arr = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
        return Image.fromarray(arr)
    except Exception:
        return None


def _option_color_mask_rgb(arr):
    """v7.0 scanner mask: blue/cyan + dark gray only; white + halo forbidden."""
    if arr is None or getattr(arr, "size", 0) == 0:
        return np.zeros((0,0), dtype=np.uint8)
    r=arr[:,:,0].astype(np.int16); g=arr[:,:,1].astype(np.int16); b=arr[:,:,2].astype(np.int16)
    mx=np.maximum.reduce([r,g,b]); mn=np.minimum.reduce([r,g,b]); chroma=mx-mn
    blue=(b>=76)&((b-r)>=18)&(b+12>=g)&(mx>=88)
    gray=(chroma<=20)&(mx>=76)&(mx<=172)
    white_core=(mn>=205)&(chroma<=30)
    halo=cv2.dilate((white_core.astype(np.uint8)*255),np.ones((3,3),np.uint8),iterations=1)>0
    return (((blue|gray)&(~halo)).astype(np.uint8)*255)


def _text_line_bands(pil_image):
    """
    Detect all visible text rows in the complete tooltip.
    This is independent from LAST-6 segmentation.
    """
    arr = np.asarray(pil_image.convert("RGB"))
    if arr.size == 0:
        return []

    # v7.0: detect candidate rows from option colors only. White labels and
    # white bracket ranges must not create OCR rows.
    mask = (_option_color_mask_rgb(arr) > 0).astype(np.uint8)

    proj = mask.sum(axis=1)
    runs = []
    start = None

    for y, count in enumerate(proj):
        if count > 5:
            if start is None:
                start = y
        else:
            if start is not None:
                if y - start >= 5:
                    runs.append((start, y - 1))
                start = None

    if start is not None and len(proj) - start >= 5:
        runs.append((start, len(proj) - 1))

    return runs


def _ocr_line(pil_image, y0, y1):
    arr = np.asarray(pil_image.convert("RGB"))
    y0 = max(0, int(y0) - 2)
    y1 = min(arr.shape[0], int(y1) + 3)

    crop = arr[y0:y1, :, :]
    if crop.size == 0:
        return ""

    # v7.0: OCR only the allowed option-color mask; original white text is gone.
    allowed = _option_color_mask_rgb(crop)
    up = cv2.resize(
        allowed, None, fx=6, fy=6,
        interpolation=cv2.INTER_NEAREST
    )

    # vie+eng is best for the Vietnamese labels; eng fallback is handled below.
    for lang in ("vie+eng", "eng"):
        try:
            txt = pytesseract.image_to_string(
                Image.fromarray(up),
                lang=lang,
                config="--psm 7",
                timeout=1.8
            ).strip()
            if txt:
                return txt
        except Exception:
            pass
    return ""


def scan_full_tooltip_anchors(image_or_path, final6_names=None):
    """
    Scan the ENTIRE tooltip only for user-confirmed unique group anchors.

    final6_names are merged as high-confidence evidence because the normal
    Reader may already have recognized an anchor inside the final six rows.
    """
    hits = []

    # Merge canonical final-6 names first.
    for name in final6_names or []:
        if name in ANCHORS:
            hits.append({
                "canonical": name,
                "group_id": ANCHORS[name],
                "score": 1.0,
                "raw": name,
                "source": "FINAL6_READER",
            })

    img = _load_image(image_or_path)
    lines = []
    if img is not None:
        for idx, (y0, y1) in enumerate(_text_line_bands(img), start=1):
            raw = _ocr_line(img, y0, y1)
            if not raw:
                continue
            lines.append({
                "line_index": idx,
                "box": [int(y0), int(y1)],
                "raw": raw,
            })

            match = _match_anchor(raw)
            if match:
                match = dict(match)
                match["source"] = "FULL_TOOLTIP_OCR"
                match["box"] = [int(y0), int(y1)]
                hits.append(match)

    # De-duplicate canonical anchors, keep strongest evidence.
    by_name = {}
    for hit in hits:
        name = hit["canonical"]
        if name not in by_name or hit["score"] > by_name[name]["score"]:
            by_name[name] = hit

    canonical_hits = sorted(by_name.keys())
    groups = sorted(set(by_name[n]["group_id"] for n in canonical_hits))

    return {
        "ok": img is not None,
        "canonical_hits": canonical_hits,
        "groups": groups,
        "hits": [by_name[n] for n in canonical_hits],
        "ocr_lines": lines,
        "line_count": len(lines),
        "conflict": len(groups) > 1,
        "policy": "FULL_TOOLTIP_UNIQUE_ANCHORS_ONLY",
    }
