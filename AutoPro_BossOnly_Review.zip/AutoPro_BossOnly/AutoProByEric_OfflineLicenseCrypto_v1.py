from __future__ import annotations
import hashlib

P = 2**255 - 19
L = 2**252 + 27742317777372353535851937790883648493
D = (-121665 * pow(121666, P-2, P)) % P
SQRT_M1 = pow(2, (P-1)//4, P)

def _inv(x: int) -> int:
    return pow(x, P-2, P)

def _xrecover(y: int) -> int:
    xx = ((y*y - 1) * _inv(D*y*y + 1)) % P
    x = pow(xx, (P+3)//8, P)
    if (x*x - xx) % P != 0:
        x = (x * SQRT_M1) % P
    if x & 1:
        x = P - x
    return x

BY = (4 * _inv(5)) % P
BX = _xrecover(BY)
B = (BX, BY, 1, (BX*BY) % P)
IDENTITY = (0, 1, 1, 0)

def _point_add(a, b):
    x1,y1,z1,t1 = a; x2,y2,z2,t2 = b
    aa = ((y1-x1)*(y2-x2)) % P
    bb = ((y1+x1)*(y2+x2)) % P
    cc = (2*D*t1*t2) % P
    dd = (2*z1*z2) % P
    e = (bb-aa) % P; f = (dd-cc) % P; g = (dd+cc) % P; h = (bb+aa) % P
    return ((e*f)%P, (g*h)%P, (f*g)%P, (e*h)%P)

def _point_double(a):
    x,y,z,t = a
    aa=(x*x)%P; bb=(y*y)%P; cc=(2*z*z)%P; dd=(-aa)%P
    e=((x+y)*(x+y)-aa-bb)%P; g=(dd+bb)%P; f=(g-cc)%P; h=(dd-bb)%P
    return ((e*f)%P, (g*h)%P, (f*g)%P, (e*h)%P)

def _scalar_mult(point, scalar: int):
    q=IDENTITY; p=point; n=int(scalar)
    while n>0:
        if n & 1: q=_point_add(q,p)
        p=_point_double(p); n >>= 1
    return q

def _encode_point(point) -> bytes:
    x,y,z,t=point; zi=_inv(z); x=(x*zi)%P; y=(y*zi)%P
    return (y | ((x & 1)<<255)).to_bytes(32,'little')

def _decode_point(buf: bytes):
    if len(buf)!=32: raise ValueError('bad point length')
    n=int.from_bytes(buf,'little'); sign=(n>>255)&1; y=n&((1<<255)-1)
    if y>=P: raise ValueError('bad y')
    x=_xrecover(y)
    if (x&1)!=sign: x=P-x
    if (y*y-x*x-1-D*x*x*y*y)%P!=0: raise ValueError('point not on curve')
    return (x,y,1,(x*y)%P)

def verify(public_key: bytes, message: bytes, signature: bytes) -> bool:
    try:
        if len(public_key)!=32 or len(signature)!=64: return False
        a=_decode_point(public_key); rb=signature[:32]; r=_decode_point(rb)
        s=int.from_bytes(signature[32:],'little')
        if s>=L: return False
        k=int.from_bytes(hashlib.sha512(rb+public_key+message).digest(),'little')%L
        return _encode_point(_scalar_mult(B,s)) == _encode_point(_point_add(r,_scalar_mult(a,k)))
    except Exception:
        return False
