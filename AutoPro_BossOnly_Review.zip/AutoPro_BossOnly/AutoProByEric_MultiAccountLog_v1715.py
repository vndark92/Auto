"""V1.7.15 concurrent per-window runtime event log, additive to legacy logs.

Each app process/session and each JX1 hwnd writes to a distinct bounded JSONL file.
Readers merge a bounded tail across all sessions. This supports concurrent app
instances, but does not claim multiple independent automation owners in one PID.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, os, re, threading, time
from AutoProByEric_ConfigStore_v1715 import save_json, load_json


def account_id(game_pid, hwnd):
    return f'{int(game_pid or 0)}:{int(hwnd or 0)}'


class MultiAccountLog:
    def __init__(self, root, session_pid=None, session_nonce=None, max_bytes=2_000_000, shared=False):
        # Use one per-user folder on Windows so separate installed/copy folders
        # still appear in the same account log viewer. Tests can remain local.
        shared_base = os.environ.get('LOCALAPPDATA') if shared else None
        self.root = (Path(shared_base) / 'AutoProByEric' / 'logs' / 'accounts') if shared_base else (Path(root) / 'accounts')
        self.root.mkdir(parents=True, exist_ok=True)
        self.session_pid = int(session_pid or os.getpid())
        self.session_nonce = str(session_nonce or __import__('uuid').uuid4().hex[:16])
        self.max_bytes = max(4096, int(max_bytes))
        self._lock = threading.RLock()
        self._seq = 0

    def _path(self, hwnd):
        return self.root / f'events_{self.session_pid}_{self.session_nonce}_hwnd_{int(hwnd or 0)}.jsonl'

    def append(self, hwnd, game_pid=0, title='', category='INFO', message='', details=None):
        hwnd = int(hwnd or 0)
        if hwnd < 0:
            raise ValueError('INVALID_HWND')
        with self._lock:
            self._seq += 1
            entry = {
                'id': f'{self.session_pid}:{self.session_nonce}:{self._seq}',
                'timestamp': datetime.now(timezone.utc).isoformat(timespec='milliseconds'),
                'session_pid': self.session_pid, 'hwnd': hwnd,
                'game_pid': int(game_pid or 0),
                'account_id': account_id(game_pid, hwnd),
                'title': str(title or '')[:128],
                'category': str(category or 'INFO')[:24],
                'message': str(message or '')[:600],
                'details': details if isinstance(details, (dict, list)) else {},
            }
            encoded = json.dumps(entry, ensure_ascii=False, default=str)
            if len(encoded) > 12000:
                entry['details'] = {'note': 'DETAILS_TRUNCATED'}
                encoded = json.dumps(entry, ensure_ascii=False)
            path = self._path(hwnd)
            if path.exists() and path.stat().st_size + len(encoded.encode('utf-8')) > self.max_bytes:
                # Three bounded rotated segments per unique app session. Never
                # overwrite a still-live file without recording previous data.
                for index in range(3, 0, -1):
                    old = path.with_name(path.name + ('.' + str(index - 1) if index > 1 else ''))
                    dest = path.with_name(path.name + '.' + str(index))
                    if old.exists():
                        os.replace(old, dest)
            with path.open('a', encoding='utf-8') as f:
                f.write(encoded + '\n')
            return entry


    def publish_presence(self, hwnd, game_pid, title='', active_modes=None, input_tool_running=False, window_alive=True):
        """Bounded process presence, kept separate from the event timeline.

        Presence expires after 90 seconds on crash, no permanent ONLINE claims.
        """
        hwnd = int(hwnd or 0)
        pid = int(game_pid or 0)
        if hwnd <= 0 or pid <= 0:
            return {'ok': False, 'reason': 'INVALID_CLIENT_IDENTITY'}
        item = {'account_id': account_id(pid, hwnd), 'hwnd': hwnd, 'game_pid': pid,
                'session_pid': self.session_pid, 'session_nonce': self.session_nonce,
                'title': str(title or '')[:128], 'window_alive': bool(window_alive),
                'active_modes': [str(x)[:24] for x in (active_modes or [])][:4],
                'input_tool_running': bool(input_tool_running),
                'last_seen_epoch': time.time()}
        directory = self.root / 'presence'
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f'instance_{self.session_pid}_{self.session_nonce}.json'
        save_json(path, item)
        return {'ok': True, 'account_id': item['account_id']}

    def presence_snapshot(self, ttl_seconds=90):
        directory = self.root / 'presence'
        if not directory.exists():
            return []
        now = time.time()
        results = []
        candidates = []
        for path in directory.glob('instance_*.json'):
            try:
                if path.is_file() and not path.is_symlink():
                    candidates.append((path.stat().st_mtime, path))
            except OSError:
                continue
        files = [p for _, p in sorted(candidates, reverse=True)[:200]]
        for path in files:
            try:
                info = json.loads(path.read_text(encoding='utf-8'))
                stamp = float(info.get('last_seen_epoch') or 0)
                if stamp > now + 30 or (now - stamp) > ttl_seconds:
                    continue
                aid = str(info.get('account_id') or '')
                if not re.fullmatch(r'\d+:\d+', aid):
                    continue
                info['alias'] = self.get_alias(aid)
                results.append(info)
            except (OSError, ValueError, TypeError):
                continue
        return results

    def _alias_path(self, aid):
        valid = re.fullmatch(r'(\d+):(\d+)', str(aid or ''))
        if not valid:
            raise ValueError('INVALID_ACCOUNT_ID')
        return self.root / 'aliases' / (valid.group(1) + '_' + valid.group(2) + '.json')

    def get_alias(self, aid):
        try:
            data = load_json(self._alias_path(aid), default={})
            return str(data.get('alias') or '')[:40] if isinstance(data, dict) else ''
        except (ValueError, OSError):
            return ''

    def set_alias(self, aid, alias):
        path = self._alias_path(aid)
        alias = str(alias or '').strip()[:40]
        # Only the user-defined presentation label is retained; no credentials.
        save_json(path, {'account_id': aid, 'alias': alias})
        return {'ok': True, 'account_id': aid, 'alias': alias}

    def recent(self, *, selected_account='ALL', limit=200):
        limit = min(500, max(1, int(limit)))
        selected_account = str(selected_account or 'ALL')
        events = []
        # Bounded I/O: latest 250 files. Ignore symlinks/nonfiles to avoid
        # following a user-controlled path outside the account log directory.
        candidates = []
        for path in self.root.glob('events_*.jsonl*'):
            try:
                if path.is_file() and not path.is_symlink():
                    candidates.append((path.stat().st_mtime, path))
            except OSError:
                continue  # a different instance rotated this file
        files = [p for _, p in sorted(candidates, reverse=True)[:250]]
        for path in files:
            try:
                # Read at most 256 KiB from the end of each rotated segment,
                # not the full multi-megabyte log on every UI refresh.
                with path.open('rb') as stream:
                    size = stream.seek(0, os.SEEK_END)
                    start = max(0, size - 262144)
                    stream.seek(start)
                    raw = stream.read(262144)
                tail = raw.splitlines()
                if start and tail: tail = tail[1:]  # first line may be partial
                for raw_line in tail[-min(250, limit):]:
                    line = raw_line.decode('utf-8', errors='replace')
                    try:
                        item = json.loads(line)
                    except (ValueError, TypeError):
                        continue
                    if selected_account != 'ALL' and item.get('account_id') != selected_account:
                        continue
                    events.append(item)
            except OSError:
                continue
        events.sort(key=lambda x: (str(x.get('timestamp') or ''), str(x.get('id') or '')))
        # Build account selector before trimming events to the page limit;
        # otherwise quiet accounts disappear when other clients are busy.
        seen = {}
        for event in events:
            aid = event.get('account_id') or '0:0'
            if aid not in seen:
                seen[aid] = {'id': aid, 'title': event.get('title') or 'Không rõ cửa sổ', 'hwnd': event.get('hwnd'), 'game_pid': event.get('game_pid')}
        presence = self.presence_snapshot()
        for state in presence:
            aid = state['account_id']
            if aid not in seen:
                seen[aid] = {'id': aid, 'title': state.get('title') or 'Cửa sổ game',
                             'hwnd': state.get('hwnd'), 'game_pid': state.get('game_pid')}
        for identity in seen.values():
            identity['alias'] = self.get_alias(identity['id'])
        return {'ok': True, 'events': events[-limit:], 'presence': presence,
                'accounts': sorted(seen.values(), key=lambda x: x['id'])}
