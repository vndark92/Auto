@echo off
setlocal
cd /d "%~dp0"
echo Auto Pro By Eric V1.7.16 - Offline Regression
py -3.12 -m unittest discover -s tests -p "test_v17*.py" -v
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Test fail hoac chua cai du thu vien. Xem README_V1716.md.
pause
exit /b %RC%
