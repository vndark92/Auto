"""Boss-only orchestration. No routes, storage transfers or Ctrl+F toggle."""
class BossOnlyFlow:
    def _validate_start(self, hwnd):
        if not hwnd or not self.core.window_exists(int(hwnd)):
            return {'ok': False, 'reason': 'GAME_CLIENT_NOT_FOUND'}
        if not self.config.get('ingame_auto_setup_confirmed'):
            return {'ok': False, 'reason': 'ENABLE_INGAME_COMBAT_AND_LOOT_FIRST'}
        if self.config.get('mode') != 'KEEP':
            return {'ok': False, 'reason': 'ONLY_KEEP_OR_REJECT_SUPPORTED'}
        if self._other_automation_busy():
            return {'ok': False, 'reason': 'OTHER_AUTOMATION_RUNNING'}
        return self.api.filter_runtime_guard('AUTO_BOSS', selected_profile_ids=self.config.get('filter_profile_ids') or [1], require_enabled_rules=True)

    def _run_one_cycle(self, hwnd):
        cycle = self._new_cycle()
        if self._cancelled(): return {'ok': False, 'reason': 'USER_STOP'}
        cap = self._ensure_player_bag_open_live(hwnd, 'BEFORE_KEY1')
        if not cap.get('ok'): return cap
        if self._capacity_status(cap['snapshot'])['status'] != 'NOT_FULL':
            return {'ok': False, 'reason': 'BAG_SPACE_NOT_CONFIRMED'}
        self._bag_snapshot, self._bag_grid = cap['snapshot'], cap['grid']
        before = cap['snapshot']
        empty_before = {(int(c['row']),int(c['col'])) for c in before.get('cells',[]) if c.get('occupied') is False}
        if not empty_before: return {'ok':False,'reason':'BAG_BASELINE_UNCERTAIN'}
        self.bag_registry.commit_baseline(before)
        if self._cancelled(): return {'ok': False, 'reason': 'USER_STOP'}
        sent = self._dispatch_key1_once(hwnd, cycle)
        if not sent.get('ok'): return sent
        loot = self._wait_boss_and_autoloot_live_bag(hwnd)
        if not loot.get('ok'): return loot
        if self._cancelled(): return {'ok': False, 'reason': 'USER_STOP'}
        cap = self._ensure_player_bag_open_live(hwnd, 'FILTER_NEW_LOOT')
        if not cap.get('ok'): return cap
        candidates = loot.get('candidates') or []
        if not candidates: return {'ok': False, 'reason': 'NO_NEW_LOOT_CONFIRMED'}
        candidates = self._autoboss_demerge_suspicious_candidates(hwnd, candidates, cap['grid'])
        for candidate in candidates:
            cells = candidate.get('geometric_cells') or candidate.get('cells') or []
            if not cells or not all(tuple(c) in empty_before for c in cells):
                return {'ok':False,'reason':'NEW_ITEM_OVERLAPS_OLD_OR_UNCERTAIN_CELLS'}
        items = self._build_loot_queue(candidates, cap['snapshot'], cap['grid'])
        if not items: return {'ok': False, 'reason': 'NO_NEW_LOOT_CONFIRMED'}
        result = self._process_loot(hwnd, items, cap['grid'])
        if not result.get('ok'): return result
        result = self._postprocess_checkpoint(hwnd)
        if not result.get('ok'): return result
        cycle.completed = True
        self.counters['cycles'] += 1
        self._set_state('BOSS_CYCLE_COMPLETE')
        return {'ok': True}

    def _run(self, hwnd, test_one_cycle):
        try:
            focus = self._focus_client(hwnd)
            if not focus.get('ok'):
                self._error(focus.get('reason', 'CLIENT_NOT_READY'), 'BossOnly', focus)
                return
            # Combat and pickup are already enabled by the user in the game.
            # Never toggle Ctrl+F: doing so could disable their existing Auto.
            while not self._cancelled():
                result = self._run_one_cycle(hwnd)
                if not result.get('ok'):
                    if self._cancelled(): break
                    self._error(result.get('reason', 'UNCONFIRMED_RESULT'), 'BossOnly', result)
                    return
                if test_one_cycle:
                    self._set_state('SESSION_COMPLETE')
                    return
            self._set_state('STOPPED')
        except Exception as exc:
            self._error('BOSS_ONLY_EXCEPTION', 'BossOnly', {'error': str(exc)})
        finally:
            self.running = False
            self._set_running_flag(False)
            self.log_writer.flush()
