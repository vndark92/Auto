"""Conservative reservation policy for independent hotkey sequencers."""

def reserve_inventory_hotkey(key, inventory_hotkey, active_modes):
    """True: do not send key while an automation owns a potentially conflicting UI.

    The policy intentionally does NOT claim to serialize every input path across
    threads/processes; that requires a shared input coordinator in a later build.
    """
    return bool(str(key or '').upper() == str(inventory_hotkey or '').upper()
                and any(str(mode).upper() in ('CHEST','ROLL','BOSS') for mode in (active_modes or [])))
