from __future__ import annotations
import ctypes
from ctypes import wintypes
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple
import time

import mss
from PIL import Image

user32 = ctypes.windll.user32

kernel32 = ctypes.windll.kernel32

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

def _window_pid(hwnd: int) -> int:
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
    return int(pid.value)

def _process_name(pid: int) -> str:
    if not pid:
        return ""
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return ""
    try:
        size = wintypes.DWORD(32768)
        buf = ctypes.create_unicode_buffer(size.value)
        # BOOL QueryFullProcessImageNameW(HANDLE,DWORD,LPWSTR,PDWORD)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            from pathlib import Path
            return Path(buf.value).name.lower()
    except Exception:
        return ""
    finally:
        kernel32.CloseHandle(handle)
    return ""

@dataclass
class WindowInfo:
    hwnd: int
    title: str
    client_width: int
    client_height: int
    left: int
    top: int
    pid: int = 0
    process_name: str = ""

def _client_rect_screen(hwnd: int) -> Optional[Tuple[int,int,int,int]]:
    rect = wintypes.RECT()
    if not user32.GetClientRect(wintypes.HWND(hwnd), ctypes.byref(rect)):
        return None

    pt = wintypes.POINT(0,0)
    if not user32.ClientToScreen(wintypes.HWND(hwnd), ctypes.byref(pt)):
        return None

    w = int(rect.right - rect.left)
    h = int(rect.bottom - rect.top)
    if w <= 0 or h <= 0:
        return None
    return int(pt.x), int(pt.y), w, h

def enumerate_windows() -> List[WindowInfo]:
    out = []
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value.strip()
        if not title:
            return True

        r = _client_rect_screen(int(hwnd))
        if not r:
            return True
        left, top, w, h = r
        if w < 320 or h < 240:
            return True

        pid = _window_pid(int(hwnd))
        pname = _process_name(pid)
        out.append(WindowInfo(
            hwnd=int(hwnd), title=title,
            client_width=w, client_height=h,
            left=left, top=top,
            pid=pid, process_name=pname
        ))
        return True

    user32.EnumWindows(EnumWindowsProc(cb), 0)
    out.sort(key=lambda x: (0 if any(k in x.title.lower() for k in
             ("võ lâm","vo lam","jx","game")) else 1, x.title.lower()))
    return out

def get_cursor_screen() -> Tuple[int,int]:
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return int(pt.x), int(pt.y)

def get_cursor_client(hwnd: int) -> Optional[Tuple[int,int]]:
    pt = wintypes.POINT(*get_cursor_screen())
    if not user32.ScreenToClient(wintypes.HWND(hwnd), ctypes.byref(pt)):
        return None
    return int(pt.x), int(pt.y)

def capture_client(hwnd: int) -> Optional[Image.Image]:
    r = _client_rect_screen(hwnd)
    if not r:
        return None
    left, top, w, h = r

    # Visible-screen capture only. This intentionally does not inject into JX1.
    with mss.mss() as sct:
        shot = sct.grab({"left":left,"top":top,"width":w,"height":h})
        return Image.frombytes("RGB", shot.size, shot.rgb)

def window_exists(hwnd: int) -> bool:
    return bool(user32.IsWindow(wintypes.HWND(hwnd)))

def is_minimized(hwnd: int) -> bool:
    return bool(user32.IsIconic(wintypes.HWND(hwnd)))
