@echo off
setlocal
cd /d "%~dp0"
echo -----------------------------------------
echo Auto Pro By Eric V1.7.16 - Acc Instance
 echo Tao thu muc rieng de khong trung config.
echo -----------------------------------------
py -3.12 tools\create_instance.py
if errorlevel 1 (
    echo Khong tao duoc. Kiem tra ten thu muc va quyen ghi.
)
pause
