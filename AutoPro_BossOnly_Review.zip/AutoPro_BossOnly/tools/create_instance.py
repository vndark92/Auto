"""Create isolated application copies for separate game clients.

Runs locally without network or admin privileges. Does not start game or automation.
Usage: py -3.12 tools/create_instance.py --name Acc_02
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import shutil

EXCLUDE_NAMES = {'instances', '__pycache__', '.git', '.pytest_cache', 'logs'}
EXCLUDE_SUFFIXES = {'.pyc', '.pyo', '.tmp'}


def create_instance(source_dir, name):
    source = Path(source_dir).resolve()
    name = str(name or '').strip()
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,32}', name):
        raise ValueError('Tên acc chỉ dùng a-z, A-Z, 0-9, gạch dưới và gạch nối (1–32 ký tự).')
    if not (source / 'AutoProByEric_Stage17_LockedUI_v1_8.py').is_file():
        raise ValueError('Không tìm thấy mã nguồn AutoPro cần nhân bản.')
    instances = source / 'instances'
    destination = instances / name
    if destination.exists() or destination.is_symlink():
        raise FileExistsError('Thư mục này đã tồn tại. Không ghi đè cấu hình acc: ' + str(destination))
    instances.mkdir(parents=True, exist_ok=True)

    def ignore(directory, names):
        return [part for part in names if part in EXCLUDE_NAMES or
                Path(part).suffix.lower() in EXCLUDE_SUFFIXES or
                (Path(directory) / part).is_symlink()]

    shutil.copytree(source, destination, ignore=ignore, symlinks=False)
    # Do not attach a new instance to an old/stale HWND on its first launch.
    runtime_path = destination / 'autopro_runtime_config.json'
    if runtime_path.is_file():
        try:
            state = json.loads(runtime_path.read_text(encoding='utf-8-sig'))
            if isinstance(state, dict):
                state['locked_client'] = None
                runtime = state.get('runtime')
                if isinstance(runtime, dict):
                    runtime['module_running'] = {}
                runtime_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
        except (ValueError, OSError):
            # Malformed config is intentionally not silently replaced; the
            # application ConfigStore/diagnostics will handle its recovery.
            pass
    readme = destination / 'INSTANCE_INFO.txt'
    readme.write_text(
        'AUTO PRO BY ERIC V1.7.16 - INSTANCE RIENG\n'
        f'Ten hien thi thu muc: {name}\n'
        'Cau hinh va ho so game trong thu muc nay KHONG dung chung voi app goc.\n'
        'Log va khoa dieu khien duoc dong bo trong LOCALAPPDATA/AutoProByEric.\n'
        'KHONG chay hai AutoPro tren cung mot cua so game.\n', encoding='utf-8')
    return destination


def main():
    parser = argparse.ArgumentParser(description='Tạo thư mục riêng cho mỗi acc AutoPro.')
    parser.add_argument('--name', default=None, help='Tên thư mục acc (ví dụ Acc_01)')
    args = parser.parse_args()
    name = args.name if args.name is not None else input('Tên thư mục cho acc mới (ví dụ Acc_02): ')
    try:
        destination = create_instance(Path(__file__).resolve().parents[1], name)
    except (ValueError, OSError) as exc:
        print('[THẤT BẠI]', exc)
        return 1
    print('[ĐÃ TẠO]', destination)
    print('Mở RUN_AUTOPRO.bat trong thư mục mới và chọn đúng cửa sổ game.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
