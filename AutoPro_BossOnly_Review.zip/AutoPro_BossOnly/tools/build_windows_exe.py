"""Windows-only PyInstaller build of frozen V1.7.16-dev. No feature changes."""
import os
import sys
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NAME = 'AutoProByEric_V1.7.16'


def build():
    if os.name != 'nt':
        raise SystemExit('ERROR: Build must run on Windows x64 (not Linux).')
    resources = []
    for entry in ROOT.iterdir():
        if entry.is_file() and entry.suffix.lower() in ('.html', '.css', '.js', '.json', '.png', '.ico'):
            resources.append(entry)
    for folder in ('Data', 'assets', 'runtime'):
        if (ROOT / folder).is_dir():
            resources.append(ROOT / folder)
    cmd = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean',
           '--onedir', '--windowed', '--contents-directory', '.',
           '--name', NAME, '--distpath', str(ROOT / 'dist'),
           '--workpath', str(ROOT / 'build'),
           '--specpath', str(ROOT),
           '--collect-all', 'webview',
           '--collect-all', 'paddleocr',
           '--collect-all', 'paddle',
           '--collect-all', 'cv2',
           '--hidden-import', 'pythonnet',
           '--hidden-import', 'clr',
           '--hidden-import', 'win32api',
           '--hidden-import', 'win32con',
           '--hidden-import', 'win32gui',
           '--hidden-import', 'win32process',
           '--hidden-import', 'win32com.client',
           '--hidden-import', 'pytesseract',
           '--hidden-import', 'mss',
           '--hidden-import', 'PIL',
           '--icon', str(ROOT / 'AutoProByEric.ico')]
    for path in resources:
        cmd += ['--add-data', f'{path}{os.pathsep}.']
    cmd.append(str(ROOT / 'AutoProByEric_Stage17_LockedUI_v1_8.py'))
    print('Building V1.7.16 Windows EXE using PyInstaller...', flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)
    target = ROOT / 'dist' / NAME
    exe = target / f'{NAME}.exe'
    if not exe.is_file() or exe.read_bytes()[:2] != b'MZ':
        raise SystemExit('Build output is missing or not a Windows PE executable.')
    for required in ('ui_locked.html','AutoProByEric_UserOptionFilter.json','Data'):
        if not (target / required).exists():
            raise SystemExit(f'Missing required resource in build: {required}')
    (target / 'README_TEST.txt').write_text(
        'Auto Pro By Eric V1.7.16 — Windows x64 TEST BUILD\\n'
        'This executable is not validated on a live game.\\n'
        'Requires WebView2 Runtime and separately installed Tesseract for OCR.\\n'
        'Do not use valuable game items for the first test.\\n'
        'For multiple accounts copy the entire folder into separate writable locations.\\n',
        encoding='utf-8')
    print(f'BUILD OK: {exe}')

if __name__ == '__main__':
    build()
