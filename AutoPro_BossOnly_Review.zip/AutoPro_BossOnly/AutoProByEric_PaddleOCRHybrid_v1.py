
from __future__ import annotations
import threading, time, traceback, zlib
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

ENGINE_VERSION="PADDLEOCR_HYBRID_V1_7_6_ONEDNN_SAFE"
PADDLE_LANG="vi"
PADDLE_OCR_VERSION="PP-OCRv5"

_ENGINE=None
_ENGINE_ERROR=None
_ENGINE_API=None
_ENGINE_INIT_KW=None
_ENGINE_RUNTIME_RECOVERY_COUNT=0
_LOCK=threading.RLock()
_CACHE_KEY=None
_CACHE_VALUE=None

@dataclass
class OCRLine:
    text:str
    score:float
    box:List[int]
    polygon:List[List[int]]
    engine:str="PADDLEOCR"
    def to_dict(self): return asdict(self)

def _cache_key(image):
    if image is None or getattr(image,"size",0)==0: return None
    a=np.ascontiguousarray(image[::4,::4])
    return (tuple(image.shape),int(zlib.crc32(a.tobytes()) & 0xffffffff))

def engine_status():
    try:
        import paddleocr
        po=True; pov=getattr(paddleocr,"__version__",None)
    except Exception:
        po=False; pov=None
    try:
        import paddle
        pp=True; ppv=getattr(paddle,"__version__",None)
    except Exception:
        pp=False; ppv=None
    return {
        "engine_version":ENGINE_VERSION,"available":bool(po and pp),
        "initialized":_ENGINE is not None,"api":_ENGINE_API,
        "init_kwargs":dict(_ENGINE_INIT_KW or {}),
        "mkldnn_disabled":bool((_ENGINE_INIT_KW or {}).get("enable_mkldnn") is False),
        "runtime_recovery_count":int(_ENGINE_RUNTIME_RECOVERY_COUNT),
        "lang":PADDLE_LANG,"ocr_version":PADDLE_OCR_VERSION,
        "paddleocr_installed":po,"paddleocr_version":pov,
        "paddle_installed":pp,"paddle_version":ppv,
        "last_error":_ENGINE_ERROR,
    }

def _init():
    global _ENGINE,_ENGINE_ERROR,_ENGINE_API,_ENGINE_INIT_KW
    if _ENGINE is not None: return _ENGINE
    with _LOCK:
        if _ENGINE is not None: return _ENGINE
        try:
            from paddleocr import PaddleOCR
        except Exception as exc:
            _ENGINE_ERROR=f"IMPORT_FAILED:{type(exc).__name__}:{exc}"
            return None
        # PaddlePaddle 3.3.x + PaddleOCR 3.x on CPU can enter a broken
        # oneDNN/PIR conversion path.  Prefer the documented PaddleOCR
        # enable_mkldnn=False switch so inference stays on the safe CPU path.
        attempts=[
            dict(lang="vi",ocr_version="PP-OCRv5",
                 use_doc_orientation_classify=False,use_doc_unwarping=False,
                 use_textline_orientation=False,device="cpu",
                 enable_mkldnn=False,enable_hpi=False),
            dict(lang="vi",ocr_version="PP-OCRv5",
                 use_doc_orientation_classify=False,use_doc_unwarping=False,
                 use_textline_orientation=False,
                 enable_mkldnn=False,enable_hpi=False),
            # Compatibility fallbacks only if this installed PaddleOCR does not
            # accept the v3 inference knobs.  Runtime still remains fail-closed.
            dict(lang="vi",ocr_version="PP-OCRv5",
                 use_doc_orientation_classify=False,use_doc_unwarping=False,
                 use_textline_orientation=False,device="cpu"),
            dict(lang="vi",use_angle_cls=False,show_log=False),
        ]
        errors=[]
        for kw in attempts:
            try:
                eng=PaddleOCR(**kw)
                _ENGINE=eng
                _ENGINE_INIT_KW=dict(kw)
                _ENGINE_API="V3_PREDICT" if hasattr(eng,"predict") else "V2_OCR"
                _ENGINE_ERROR=None
                return eng
            except Exception as exc:
                errors.append(f"{type(exc).__name__}:{exc}")
        _ENGINE_ERROR="INIT_FAILED:"+" | ".join(errors[-3:])
        return None

def _box_from_poly(poly):
    p=np.asarray(poly,dtype=float).reshape(-1,2)
    return [int(round(p[:,0].min())),int(round(p[:,1].min())),
            int(round(p[:,0].max())),int(round(p[:,1].max()))]

def _parse_v3(obj):
    try:
        d=obj.json
        if callable(d): d=d()
    except Exception:
        d=None
    if not isinstance(d,dict):
        try: d=dict(obj)
        except Exception: return []
    d=d.get("res",d)
    texts=list(d.get("rec_texts") or [])
    scores=list(d.get("rec_scores") or [])
    polys=list(d.get("rec_polys") or d.get("dt_polys") or [])
    boxes=list(d.get("rec_boxes") or [])
    out=[]
    for i in range(min(len(texts),len(scores))):
        text=str(texts[i] or "").strip()
        if not text: continue
        try: score=float(scores[i])
        except Exception: score=0.0
        poly=None
        if i<len(polys):
            try: poly=np.asarray(polys[i],dtype=float).reshape(-1,2).tolist()
            except Exception: poly=None
        box=None
        if i<len(boxes):
            try: box=[int(round(float(x))) for x in list(boxes[i])[:4]]
            except Exception: box=None
        if (not box or len(box)!=4) and poly: box=_box_from_poly(poly)
        if not box or len(box)!=4: continue
        if poly is None:
            x0,y0,x1,y1=box
            poly=[[x0,y0],[x1,y0],[x1,y1],[x0,y1]]
        out.append(OCRLine(text,score,box,poly))
    return out

def _parse_v2(raw):
    rows=raw
    if isinstance(rows,list) and len(rows)==1 and isinstance(rows[0],list):
        rows=rows[0]
    out=[]
    for item in rows or []:
        try:
            poly=item[0]; text=str(item[1][0] or "").strip(); score=float(item[1][1])
            if not text: continue
            out.append(OCRLine(text,score,_box_from_poly(poly),
                               np.asarray(poly,dtype=float).reshape(-1,2).astype(int).tolist()))
        except Exception:
            continue
    return out

def _dedupe(lines):
    ranked=sorted(lines,key=lambda x:(-x.score,x.box[1],x.box[0]))
    kept=[]
    for ln in ranked:
        x0,y0,x1,y1=ln.box
        duplicate=False
        for k in kept:
            a0,b0,a1,b1=k.box
            ix0,iy0=max(x0,a0),max(y0,b0); ix1,iy1=min(x1,a1),min(y1,b1)
            inter=max(0,ix1-ix0)*max(0,iy1-iy0)
            area=max(1,(x1-x0)*(y1-y0)); area2=max(1,(a1-a0)*(b1-b0))
            if inter/min(area,area2)>=0.75:
                duplicate=True; break
        if not duplicate: kept.append(ln)
    return sorted(kept,key=lambda x:((x.box[1]+x.box[3])/2.0,x.box[0]))

def recognize(image,min_score=0.34):
    global _CACHE_KEY,_CACHE_VALUE,_ENGINE_ERROR
    if image is None or getattr(image,"size",0)==0:
        return {"ok":False,"reason":"EMPTY_IMAGE","lines":[]}
    key=_cache_key(image)
    with _LOCK:
        if key is not None and key==_CACHE_KEY and _CACHE_VALUE is not None:
            return dict(_CACHE_VALUE)
    eng=_init()
    if eng is None:
        return {"ok":False,"reason":"PADDLEOCR_UNAVAILABLE","lines":[],"status":engine_status()}
    t0=time.perf_counter()

    def _infer_once(engine):
        lines=[]
        if hasattr(engine,"predict"):
            for obj in engine.predict(image) or []:
                lines.extend(_parse_v3(obj))
            api="V3_PREDICT"
        else:
            lines=_parse_v2(engine.ocr(image,cls=False))
            api="V2_OCR"
        return lines,api

    try:
        lines,api=_infer_once(eng)
        recovery=None
    except Exception as exc:
        msg=f"{type(exc).__name__}:{exc}"
        # Exact failure observed in the 2026-10-14 live READER_TEST log.
        # Retry once with a freshly-created engine whose first-choice init
        # explicitly disables MKL-DNN/oneDNN.  Never loop and never promote
        # failed Paddle evidence into Filter authority.
        if ("ConvertPirAttribute2RuntimeAttribute" in msg or "onednn_instruction" in msg):
            global _ENGINE,_ENGINE_API,_ENGINE_INIT_KW,_ENGINE_RUNTIME_RECOVERY_COUNT
            with _LOCK:
                _ENGINE=None; _ENGINE_API=None; _ENGINE_INIT_KW=None
                _ENGINE_RUNTIME_RECOVERY_COUNT += 1
            eng2=_init()
            if eng2 is not None and bool((_ENGINE_INIT_KW or {}).get("enable_mkldnn") is False):
                try:
                    lines,api=_infer_once(eng2)
                    recovery="ONEDNN_RUNTIME_REINIT_MKLDNN_DISABLED"
                except Exception as exc2:
                    _ENGINE_ERROR=f"RUNTIME_FAILED:{type(exc2).__name__}:{exc2}"
                    return {"ok":False,"reason":"PADDLEOCR_RUNTIME_FAILED","error":_ENGINE_ERROR,
                            "recovery":"ONEDNN_RETRY_FAILED",
                            "traceback":traceback.format_exc(limit=3),"lines":[]}
            else:
                _ENGINE_ERROR=f"RUNTIME_FAILED:{msg}"
                return {"ok":False,"reason":"PADDLEOCR_RUNTIME_FAILED","error":_ENGINE_ERROR,
                        "recovery":"ONEDNN_SAFE_REINIT_UNAVAILABLE",
                        "traceback":traceback.format_exc(limit=3),"lines":[]}
        else:
            _ENGINE_ERROR=f"RUNTIME_FAILED:{msg}"
            return {"ok":False,"reason":"PADDLEOCR_RUNTIME_FAILED","error":_ENGINE_ERROR,
                    "traceback":traceback.format_exc(limit=3),"lines":[]}

    lines=[x for x in _dedupe(lines) if float(x.score)>=float(min_score)]
    out={"ok":bool(lines),"reason":None if lines else "NO_TEXT",
         "engine":ENGINE_VERSION,"api":api,"lang":"vi","ocr_version":"PP-OCRv5",
         "mkldnn_disabled":bool((_ENGINE_INIT_KW or {}).get("enable_mkldnn") is False),
         "runtime_recovery":recovery,
         "elapsed_ms":round((time.perf_counter()-t0)*1000.0,3),
         "lines":[x.to_dict() for x in lines]}
    with _LOCK:
        _CACHE_KEY=key; _CACHE_VALUE=dict(out)
    return out

def warmup():
    eng=_init()
    return {"ok":eng is not None,"status":engine_status(),
            "note":"First initialization may download official PaddleOCR models."}

if __name__=="__main__":
    import json
    print(json.dumps(warmup(),ensure_ascii=False,indent=2))
