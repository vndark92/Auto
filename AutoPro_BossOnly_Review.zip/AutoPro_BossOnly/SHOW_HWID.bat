@echo off
setlocal
cd /d "%~dp0"
title Auto Pro By Eric - HWID
py -3.12 AutoProByEric_LicenseGuard_v1.py --show-hwid
pause
