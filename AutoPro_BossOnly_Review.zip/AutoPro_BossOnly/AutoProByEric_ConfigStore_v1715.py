"""V1.7.15 crash-resistant, cross-process serialized JSON persistence.

Keep all backups beside their original file. Never silently reset corrupt critical
configuration: restore from a validated backup or log a warning for diagnostics.
"""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import json, os, shutil, tempfile, threading, time

_PROCESS_LOCK = threading.RLock()


@contextmanager
def _file_lock(path: Path, timeout: float = 8.0):
    path.parent.mkdir(parents=True, exist_ok=True)
    lockpath = path.with_name(path.name + '.lock')
    with _PROCESS_LOCK, lockpath.open('a+b') as f:
        f.seek(0, 2)
        if f.tell() == 0:
            f.write(b'\0'); f.flush()
        f.seek(0)
        started = time.monotonic()
        while True:
            try:
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.lockf(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB, 1)
                break
            except (OSError, BlockingIOError):
                if time.monotonic() - started > timeout:
                    raise TimeoutError('CONFIG_LOCK_TIMEOUT: ' + str(path))
                time.sleep(0.05)
        try:
            yield
        finally:
            f.seek(0)
            if os.name == 'nt':
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.lockf(f.fileno(), fcntl.LOCK_UN, 1)


def _atomic_bytes(path: Path, raw: bytes):
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def save_json(path: Path, payload) -> None:
    path = Path(path)
    raw = (json.dumps(payload, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with _file_lock(path):
        backup = path.with_name(path.name + '.bak')
        if path.exists():
            # Only preserve valid previous data; a corrupt primary must not
            # overwrite the one useful backup.
            previous = path.read_bytes()
            try:
                json.loads(previous.decode('utf-8-sig'))
                _atomic_bytes(backup, previous)
            except (ValueError, UnicodeError):
                pass
        _atomic_bytes(path, raw)


def load_json(path: Path, default=None, *, on_recovery=None):
    path = Path(path)
    with _file_lock(path):
        if not path.exists():
            return default
        try:
            return json.loads(path.read_text(encoding='utf-8-sig'))
        except (ValueError, UnicodeError) as err:
            backup = path.with_name(path.name + '.bak')
            if backup.exists():
                try:
                    previous = backup.read_bytes()
                    obj = json.loads(previous.decode('utf-8-sig'))
                    _atomic_bytes(path, previous)
                    if on_recovery:
                        on_recovery('RESTORED_BACKUP', str(path), str(err))
                    return obj
                except (ValueError, UnicodeError, OSError):
                    pass
            if on_recovery:
                on_recovery('CONFIG_CORRUPT_NO_BACKUP', str(path), str(err))
            return default
