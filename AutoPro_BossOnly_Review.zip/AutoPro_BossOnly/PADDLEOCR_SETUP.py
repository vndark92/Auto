import json,sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from AutoProByEric_PaddleOCRHybrid_v1 import warmup,engine_status,recognize

warm=warmup()
# Runtime smoke must execute inference, not only import/initialize.  This catches
# the PaddlePaddle 3.3.x oneDNN/PIR failure that import tests cannot detect.
img=Image.new("RGB",(360,96),"white")
d=ImageDraw.Draw(img)
d.text((12,28),"AUTO PRO OCR 123",fill="black")
arr=np.asarray(img)
smoke=recognize(arr,min_score=0.0) if warm.get("ok") else {"ok":False,"reason":"WARMUP_FAILED"}
runtime_ok=bool(warm.get("ok")) and smoke.get("reason") not in {
    "PADDLEOCR_RUNTIME_FAILED","PADDLEOCR_UNAVAILABLE","EMPTY_IMAGE","WARMUP_FAILED"
}
payload={"warmup":warm,"runtime_smoke":smoke,"runtime_ok":runtime_ok,"status":engine_status()}
print(json.dumps(payload,ensure_ascii=False,indent=2))
(ROOT/"PADDLEOCR_ENGINE_STATUS.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
raise SystemExit(0 if runtime_ok else 2)
