# Báo cáo phát triển Auto Pro By Eric V1.7.16-dev

**Ngày:** 27/10/2026 (Asia/Bangkok)  
**Đầu vào:** ZIP nguồn V1.7.15-dev của dự án  
**Đầu ra:** ZIP nguồn V1.7.16-dev, có test tự động, tiện ích tạo instance riêng, log trạng thái đa phiên và tài liệu.  
**Mức nghiệm thu:** kiểm thử ngoại tuyến, **chưa nghiệm thu Windows/game**.

## 1. Những thay đổi có mã nguồn và test

| Ưu tiên | Nội dung | File ảnh hưởng | Kết quả / giới hạn |
|---|---|---|---|
| P1 | Khóa client OS-level theo PID/HWND, cấm hai AutoPro cùng giữ client | `AutoProByEric_ClientOwnership_v1716.py`, `AutoProByEric_Stage17_LockedUI_v1_8.py` | Có test hai instance nội tiến trình và subprocess; chỉ ràng buộc bản tuân thủ giao thức |
| P1 | Khóa độc quyền chuột vật lý giữa các tiến trình | File như trên | Cấm hai foreground Auto tranh SendInput; khóa chỉ nhả lúc app exit, cần mở rộng quản lý lifetime |
| P1 | START gate Cast/Chest/Roll/Boss, F10 không đi vòng khóa | `AutoProByEric_InputTool_v1.py`, UI Adapter, `AutoProByEric_RunSafety_v1716.py` | Test hook F10, policy Background, chặn start chồng chéo; các legacy diagnostics chưa được điều phối hoàn toàn |
| P1 | Chặn Chest/Roll/Boss ở chế độ Background khi chưa có ACK xác nhận | UI Adapter, RunSafety | Trả `BACKGROUND_ENGINE_UNVERIFIED`; không nhận sai việc gửi thành công thành game đã thực hiện |
| P2 | Tách cấu hình theo acc bằng thư mục riêng | `tools/create_instance.py`, `CREATE_ACCOUNT_INSTANCE.bat` | Test clone/không ghi đè, không chép log, xóa HWND/runtime_running cũ; chưa có scheduler đa-client trong cùng process |
| P2 | Log đa acc có alias, presence TTL, đọc tail giới hạn, xoay 3 đoạn | `AutoProByEric_MultiAccountLog_v1715.py`, JS/CSS/HTML | Test alias, quiet accounts, rotate, presence expire; chưa stress test I/O nhiều process trên Windows |
| P2 | Giao diện trung tính và tăng tính rõ ràng ở Logs | `autopro_minimal_v1716.css`, `autopro_multi_account_ui_v1716.js`, `ui_locked.html` | Giữ nguyên UI cũ, thêm alias+trạng thái; chưa QA WebView2 DPI trên Windows |

## 2. Kiểm thử

- Bộ unit test kế thừa V1.7.15 + mới V1.7.16: **23 test PASS / 0 FAIL** ở môi trường Python phát triển.
- Test owner dùng subprocess thật để chứng minh OS file-lock ngăn một tiến trình thứ hai chiếm cùng client.
- Test không chiếm chuột được định nghĩa như **chính sách fail-closed**, không tuyên bố ACK PostMessage từ game.
- Corpus OCR kế thừa không sửa: kết quả replay cũ **40/49 confirmed đúng, 0 false-confirmed, 9 unknown/ambiguous**. Số liệu này không phải benchmark in-game và không mới được thu thập từ game.

## 3. Vướng mắc chưa thể tự giải quyết từ nguồn hiện có

### Blocker A — Không thể cam kết Auto Chest/Roll/Boss chạy không chiếm chuột

Phụ thuộc vào game trên Windows: DirectInput/RawInput, việc xử lý `WM_MOUSEMOVE`, `WM_LBUTTONDOWN`, `WM_LBUTTONUP`, điều kiện mất focus, `PrintWindow`/capture của cửa sổ bị che/minimize, và tooltip có tạo khi con trỏ hệ thống không di chuyển hay không. Nhiều đường input trong backend còn dùng `SetCursorPos`, `SendInput`, `SetForegroundWindow`. Chỉ thay thành PostMessage là không đủ; cần sensor sau từng giao dịch và rollback/pause trước DROP/STORE. **Hiện chỉ Cast Bùa có đường gửi phím nền giới hạn, chưa xác nhận game chấp nhận.**

**Đầu vào cần cung cấp:** 1–2 máy Windows 10/11 chạy game thật, cho thử nghiệm hai cửa sổ (nên dùng acc thử), ghi màn hình có con trỏ, DPI/độ phân giải, các thao tác PostMessage khi cửa sổ không focus và khi che/minimize. Không cần mật khẩu tài khoản.

### Blocker B — Chưa thể chạy hai Auto Chest/Roll/Boss song song không chiếm chuột

Một máy chỉ có một con trỏ vật lý. Engine không có transport nền đầy đủ nên bản dev dùng khóa toàn cục `global_physical_input`, an toàn hơn nhưng chỉ một engine Foreground/Auto được chạy trong nhóm AutoPro hợp tác. Chưa có InputCoordinator bao trùm 100% tác vụ legacy; các chức năng test thủ công vẫn cần audit chi tiết.

**Cần:** nghiệm thu đường click/drag nền, cảm biến inventory và tooltip từng HWND; tiêu chí timeout/phản hồi khi mất focus/đứt frame. Nếu game không nhận PostMessage, cần lựa chọn kỹ thuật khác (hoặc chấp nhận điều khiển foreground tuần tự), không thể tự suy ra từ code.

### Blocker C — Thiếu ảnh OCR có nhãn độc lập

Cần ảnh tooltip gốc/ảnh hàng thuộc tính của 7 loại chưa có prototype, đa DPI/ngôn ngữ/nền, ít nhất vài mẫu *độc lập* mỗi loại. Bộ holdout cũ bị trùng train; không nên dùng làm căn cứ chốt DROP/STORE cho item quý.

### Blocker D — Công cụ build EXE và installer chưa nghiệm thu Windows

Chưa có Windows SDK/PyInstaller/WebView2/VC++ thực tế để ký và chạy EXE mới. Installer kế thừa có tải từ Internet nhưng chưa có SHA-256 được xác thực để ghim; không nên tự bịa hash hoặc bỏ chặn security. Thử cài nên trên máy ảo Windows rồi nghiệm thu chữ ký/checksum từ nguồn chính thức.

### Blocker E — Thiếu profile thật/đặt tên acc và tiêu chí sản phẩm

Không thể tự đoán acc nào là nhân vật nào hoặc tọa độ/đường đi của từng game client. V1.7.16 dùng alias hiển thị tự đặt và tạo thư mục config riêng; muốn import/migration profile có kiểm soát cần người dùng chỉ rõ profile nào dùng cho acc nào. Không lưu thông tin đăng nhập.

## 4. Quy trình nghiệm thu đề xuất

1. Máy Windows: chạy `CHECK_V1716.bat` và xác nhận tất cả test PASS; mở UI kiểm tra Logs, CSS, WebView2 và DPI 100/125/150%.
2. Mở hai cửa sổ game khác nhau. Chạy AutoPro từ hai **thư mục instance khác nhau** và xác minh log tự xuất hiện ở cùng tab Logs (alias và trạng thái).
3. Cố chọn **cùng một HWND** từ hai app: phiên thứ hai phải báo `OWNED_BY_ANOTHER_AUTOPRO_INSTANCE`.
4. Chạy Cast Bùa Background hai cửa sổ, không sử dụng vật phẩm có giá trị; quan sát con trỏ không di chuyển/focus không đổi, xác minh game có/không nhận phím. Nếu không nhận, đánh dấu transport không hỗ trợ.
5. Thử foreground Auto ở app A và app B: app B phải bị từ chối quyền chuột; đóng app A mới được chuyển quyền. Lưu ý giới hạn này là cố ý ở dev build.
6. Thử mode Background với Chest/Roll/Boss: phải bị chặn trước khi có bất kỳ Start/destructive action nào.
7. Sau khi những điểm trên đạt, mới xem xét triển khai hoàn chỉnh per-HWND sensor ACK và InputCoordinator; không thực hiện DROP/STORE cho tới khi cả read + commit được xác thực.

**Kết luận:** Bản V1.7.16-dev cải thiện khả năng quan sát, cô lập cấu hình và giới hạn tranh chấp input ở các luồng Start chính. Chưa chứng minh chạy nền trọn vẹn hoặc nhiều Auto gameplay đồng thời; chưa có EXE đã được kiểm thử game.
