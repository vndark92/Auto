from __future__ import annotations

"""V12.0 closed-world visual option recognition for Auto Pro By Eric.

The active JX1 option domain contains canonical + user-taught slot options. This module treats
option identity as image classification over real captured JX1 glyphs. OCR text
is retained only as a secondary vote/diagnostic signal.

Safety properties:
- no prototype => visual authority is unavailable, never fabricated;
- top score requires margin over second-best;
- family/qualifier evidence can support or veto but OCR cannot single-handedly
  override a strong visual contradiction;
- target exclusion can be proven by low visual compatibility with the wanted
  option even when exact non-target identity is unknown.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import json, math, re, unicodedata

import cv2
import numpy as np
from PIL import Image

from AutoProByEric_OptionRegistry_v1 import REGISTRY as OPTION_REGISTRY, BY_ID, BY_NAME

VISION_VERSION = "CLOSED_WORLD_OPTION_VISION_V12_4_MULTIMODAL_EVIDENCE_ROOTFIX"
NORMALIZED_HEIGHT = 24
# Conservative release thresholds. They are calibrated by holdout corpus, not
# used to force a decision when evidence is weak.
VISUAL_CONFIRM_MIN = 0.66
VISUAL_EXCLUDE_MAX = 0.43
VISUAL_MIN_MARGIN = 0.075
OCR_SECONDARY_WEIGHT = 0.18
VISUAL_WEIGHT = 0.64
FAMILY_WEIGHT = 0.10
QUALIFIER_WEIGHT = 0.08


def _norm_text(s: str) -> str:
    # Vietnamese đ/Đ does not decompose under NFKD. Replace it before ASCII
    # folding so critical tokens such as "đánh" and "độ" do not become
    # "anh" / "o". This is especially important for mandatory ATTACK_SPEED.
    s = str(s or "").replace("Đ", "D").replace("đ", "d")
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("ascii").lower()
    s = s.replace("–", "-").replace("—", "-")
    return " ".join(re.findall(r"[a-z0-9]+", s))


def _token_ratio(a: str, b: str) -> float:
    a, b = _norm_text(a), _norm_text(b)
    if not a or not b:
        return 0.0
    # SequenceMatcher is intentionally secondary evidence only.
    import difflib
    seq = difflib.SequenceMatcher(None, a, b).ratio()
    ta, tb = set(a.split()), set(b.split())
    jac = len(ta & tb) / max(1, len(ta | tb))
    return float(0.68 * seq + 0.32 * jac)

def _ocr_secondary_qualifier(text: str) -> Optional[str]:
    """Strict qualifier micro-vote. It narrows visual candidates; never final authority."""
    n = _norm_text(text)
    if re.search(r"\b(?:ngoai|ngoar|ngoal|ngoa|nzoal|nzoar|ngzoas|ngzoal|ngeal)\w*\b", n): return "NGOAI"
    if re.search(r"\b(?:noi|nei|ndi|ngi|nii|n0i)\w*\b", n): return "NOI"
    return None


def _edit_distance_at_most_one(a: str, b: str) -> bool:
    """Small deterministic token comparator; no broad fuzzy phrase matching."""
    a=str(a or ''); b=str(b or '')
    if a==b: return True
    if abs(len(a)-len(b))>1: return False
    if len(a)>len(b): a,b=b,a
    if len(a)==len(b):
        return sum(x!=y for x,y in zip(a,b))<=1
    # b is exactly one character longer than a.
    i=j=errors=0
    while i<len(a) and j<len(b):
        if a[i]==b[j]: i+=1; j+=1; continue
        errors+=1; j+=1
        if errors>1: return False
    return True


def _near_specific_token(n: str, target: str) -> bool:
    """Near-match one high-specificity token only (edit distance <= 1).

    A longer OCR token may have adjacent glyphs fused onto the canonical token;
    comparing its canonical-length prefix handles that without creating typo
    alias lists. Short tokens such as `vo` remain exact-only.
    """
    toks=str(n or '').split()
    target=str(target or '')
    for tok in toks:
        if tok==target: return True
        if len(target)<=2: continue
        if _edit_distance_at_most_one(tok,target): return True
        if len(tok)>len(target) and _edit_distance_at_most_one(tok[:len(target)],target): return True
    return False


def _skill_family_micro_vote(n: str) -> bool:
    # Distinctive four-token conjunction. Each long token may lose/alter one
    # glyph (nang->nng, cong->cng, von->vn); `vo` must survive exactly.
    return (
        _near_specific_token(n,'nang') and
        any(tok=='vo' for tok in str(n or '').split()) and
        _near_specific_token(n,'cong') and
        _near_specific_token(n,'von')
    )


def _ocr_secondary_family(text: str) -> Optional[str]:
    """Conservative multi-token family vote used only to narrow visual search."""
    n = _norm_text(text)
    if not n: return None
    q = _ocr_secondary_qualifier(n)
    has=lambda *xs:any(x in n for x in xs)
    if _skill_family_micro_vote(n): return 'SKILL_LEVEL'
    if has('toc','tec','tic') and has('danh','dank','daenh'): return 'ATTACK_SPEED'
    if has('chuyen','chay') and has('sat') and has('thuong','thudng','thudne','thidng') and has('thanh') and has('noi','nei'): return 'DAMAGE_TO_MANA'
    # Closed-world exclusion groups for KNOWN_IGNORE rows. They are not used to
    # assign a canonical Option ID; they only prove incompatibility with a
    # filterable target family such as SKILL_LEVEL.
    if has('luc','luce','lic','lie') and has('toi','tei','te1','tai','ti') and has('da'): return 'RESOURCE_MAX'
    if has('tang') and has('chinh') and has('xac','xeac','x4ac') and has('danh'): return 'ACCURACY'
    # V12.2: closed-world family exclusion must survive a clipped/corrupted first
    # token. Real corpus 01:26:43 reads `oat thudng vat ly ...`: `sat` is lost,
    # while the distinctive multi-token pair `thương vật lý` remains. This vote
    # is only family-level negative evidence; visual identity still owns canonical ID.
    if has('thuong','thudng','thudnzg','thudngzg','thing') and has('vat','wat') and has('ly','lv','1y'): return 'PHYSICAL_DAMAGE'
    if has('sat','s4t') and has('bang','rang'): return 'ICE_DAMAGE'
    if has('sat','s4t') and has('loi','lei','lsi'): return 'LIGHTNING_DAMAGE'
    if has('sat','s4t') and has('hoa','hia','hea'): return 'FIRE_DAMAGE'
    if has('sat','s4t') and has('doc','dec','hdec','hde'): return 'POISON_DAMAGE'
    if has('khang','kang'):
        if has('bang'): return 'ICE_RESIST'
        if has('doc','dec','dic','diec'): return 'POISON_RESIST'
        if has('loi','lei','ler'): return 'LIGHTNING_RESIST'
        if has('hoa','hia','hea'): return 'FIRE_RESIST'
        if has('tat') and has('ca'): return 'ALL_RESIST'
    if has('thoi','tho1','thei','thde1','the1') and has('gian'):
        if has('trung','tring','trimg','trang') and has('doc','dec','dic','diec'): return 'POISON_DURATION'
        if has('lam') and has('cham'): return 'SLOW_DURATION'
        if has('choang','choanz','chodng'): return 'STUN_DURATION'
        if has('phuc') and has('hoi'): return 'RECOVERY_TIME'
    if has('phuc') and has('hoi') and (has('sinh') or (has('noi') and has('luc'))): return 'RESOURCE_RECOVERY'
    if has('tang') and has('cong','ceng') and has('kich') and has('ky','ey') and has('nang'): return 'SKILL_ATTACK_BONUS'
    if has('muc') and has('khang','kang') and has('tinh') and has('toi','tei','tai') and has('da'): return 'MAX_RESIST_CAP'
    if has('sinh') and has('luc','lve','lue') and has('toi','tei','tai') and has('da'): return 'RESOURCE_MAX'
    if has('toc') and has('di') and has('chuyen'): return 'MOVE_SPEED'
    if has('bo') and has('qua') and has('ne') and has('tranh'): return 'IGNORE_DODGE'
    if has('phong') and has('thu') and has('vat') and has('ly'): return 'PHYSICAL_DEFENSE'
    return None


def _ocr_secondary_canonical_hint(text: str) -> Optional[str]:
    """Strict multi-token canonical hint. Visual evidence must still confirm it."""
    n=_norm_text(text); q=_ocr_secondary_qualifier(n); fam=_ocr_secondary_family(n)
    if not n: return None
    # family/qualifier pairs with a single canonical target
    pair={
      ('ATTACK_SPEED','NOI'):'toc_o_anh_noi_cong',('ATTACK_SPEED','NGOAI'):'toc_o_anh_ngoai_cong',
      ('PHYSICAL_DAMAGE','NOI'):'sat_thuong_vat_ly_noi_cong',('PHYSICAL_DAMAGE','NGOAI'):'sat_thuong_vat_ly_ngoai_cong',
      ('FIRE_DAMAGE','NOI'):'hoa_sat_noi_cong',('FIRE_DAMAGE','NGOAI'):'hoa_sat_ngoai_cong',
      ('ICE_DAMAGE','NOI'):'bang_sat_noi_cong',('ICE_DAMAGE','NGOAI'):'bang_sat_ngoai_cong',
      ('LIGHTNING_DAMAGE','NOI'):'loi_sat_noi_cong',('LIGHTNING_DAMAGE','NGOAI'):'loi_sat_ngoai_cong',
      ('POISON_DAMAGE','NOI'):'oc_sat_noi_cong',('POISON_DAMAGE','NGOAI'):'oc_sat_ngoai_cong',
    }
    if (fam,q) in pair: return pair[(fam,q)]
    # V1.7.15: explicit, mutually-exclusive FULL tokens only.  A family vote
    # alone ("lực tối đa") is not proof of Sinh vs Nội vs Thể.  No fuzzy
    # resource-name identity: "Néi luc téi da" must stay ambiguous.
    if fam == 'RESOURCE_MAX':
        tokens = set(n.split())
        if not {'luc', 'toi', 'da'}.issubset(tokens):
            return None
        names = {'sinh': 'sinh_luc_toi_a', 'noi':'noi_luc_toi_a', 'the':'the_luc_toi_a'}
        matches = [id_ for token, id_ in names.items() if token in tokens]
        return matches[0] if len(matches) == 1 else None
    single={'SKILL_LEVEL':'ky_nang_vo_cong_von_co','ICE_RESIST':'khang_bang','POISON_RESIST':'khang_oc','LIGHTNING_RESIST':'khang_loi','FIRE_RESIST':'khang_hoa','ALL_RESIST':'khang_tat_ca','POISON_DURATION':'thoi_gian_trung_oc','SLOW_DURATION':'thoi_gian_lam_cham','STUN_DURATION':'thoi_gian_choang','RECOVERY_TIME':'thoi_gian_phuc_hoi','DAMAGE_TO_MANA':'chuyen_hoa_sat_thuong_thanh_noi_luc','MOVE_SPEED':'toc_o_di_chuyen','IGNORE_DODGE':'bo_qua_ne_tranh','PHYSICAL_DEFENSE':'phong_thu_vat_ly','SKILL_ATTACK_BONUS':'tang_cong_kich_ky_nang','MAX_RESIST_CAP':'muc_khang_tinh_toi_a'}
    if fam in single:return single[fam]
    has=lambda *xs:any(x in n for x in xs)
    if has('tang') and has('chinh') and has('xac','xeac','x4ac') and has('danh'): return 'tang_o_chinh_xac_on_anh_can_chien'
    return None


def _binary_from_rgb(img: Image.Image) -> np.ndarray:
    arr = np.asarray(img.convert("RGB"), dtype=np.uint8)
    # Foreground proof has black background and preserves accepted glyph color.
    mx = arr.max(axis=2)
    mask = (mx >= 24).astype(np.uint8) * 255
    # Remove isolated single-pixel noise only.
    n, labels, stats, _ = cv2.connectedComponentsWithStats((mask > 0).astype(np.uint8), 8)
    out = np.zeros_like(mask)
    for i in range(1, n):
        x, y, w, h, area = [int(v) for v in stats[i]]
        if area <= 1:
            continue
        out[labels == i] = 255

    # Translucent-tooltip cleanup can still leave tiny distant islands. Keep the
    # dominant horizontal text cluster and discard islands separated by >20 px.
    # Real JX1 word/value gaps in the captured corpus stay below this boundary.
    runs = _component_runs(out)
    if len(runs) >= 2:
        clusters=[]; cur=[runs[0]]
        for rr in runs[1:]:
            if rr[0]-cur[-1][1]-1 > 20:
                clusters.append(cur); cur=[rr]
            else:
                cur.append(rr)
        clusters.append(cur)
        scored=[]
        for cl in clusters:
            x0,x1=cl[0][0],cl[-1][1]
            ink=int((out[:,x0:x1+1]>0).sum())
            span=x1-x0+1
            scored.append((ink,span,x0,x1))
        if scored:
            _,_,kx0,kx1=max(scored,key=lambda t:(t[0],t[1]))
            cleaned=np.zeros_like(out); cleaned[:,kx0:kx1+1]=out[:,kx0:kx1+1]
            out=cleaned
    return out


def _component_runs(mask: np.ndarray) -> List[Tuple[int, int]]:
    if mask is None or mask.size == 0:
        return []
    cols = np.where((mask > 0).any(axis=0))[0]
    if len(cols) == 0:
        return []
    runs: List[Tuple[int, int]] = []
    s = p = int(cols[0])
    for x0 in cols[1:]:
        x = int(x0)
        if x > p + 1:
            runs.append((s, p)); s = x
        p = x
    runs.append((s, p))
    return runs


def _orange_mask(img: Image.Image) -> np.ndarray:
    arr = np.asarray(img.convert("RGB"), dtype=np.uint8)
    hsv = cv2.cvtColor(arr, cv2.COLOR_RGB2HSV)
    h, s, v = cv2.split(hsv)
    return (((h >= 3) & (h <= 38) & (s >= 70) & (v >= 95)).astype(np.uint8) * 255)


def _find_value_suffix_cut(img: Image.Image, mask: np.ndarray) -> Optional[int]:
    """Find the start x of the right-side value suffix using visual geometry.

    This is deliberately not numeric OCR. Skill orange is the strongest cue.
    For gray/blue rows, a large inter-glyph gap after the midpoint is used. If
    geometry is not convincing we keep the whole row rather than invent a cut.
    """
    if mask is None or mask.size == 0:
        return None
    h, w = mask.shape[:2]
    orange = _orange_mask(img)
    ys, xs = np.where(orange > 0)
    if len(xs) >= 3:
        ox0 = int(xs.min())
        if ox0 >= int(w * 0.35):
            return max(0, ox0 - 3)

    runs = _component_runs(mask)
    if len(runs) < 3:
        return None
    ink0, ink1 = runs[0][0], runs[-1][1]
    span = max(1, ink1 - ink0 + 1)
    candidates = []
    for i in range(len(runs) - 1):
        gap = runs[i + 1][0] - runs[i][1] - 1
        xright = runs[i + 1][0]
        rel = (xright - ink0) / span
        # Word gaps in JX1 are commonly 6-9 px. A >=11 px gap after ~45% of
        # the ink span is much more likely to be the value suffix boundary.
        if gap >= 11 and rel >= 0.45:
            candidates.append((gap, xright, rel))
    if not candidates:
        return None
    # Prefer the earliest sufficiently-large suffix gap, avoiding trailing
    # translucent noise islands far to the right.
    candidates.sort(key=lambda x: (x[1], -x[0]))
    return max(0, int(candidates[0][1]) - 2)


def normalize_name_mask(img_or_path: Any, *, return_meta: bool = False):
    img = Image.open(img_or_path).convert("RGB") if isinstance(img_or_path, (str, Path)) else img_or_path.convert("RGB")
    mask = _binary_from_rgb(img)
    cut = _find_value_suffix_cut(img, mask)
    if cut is not None and cut >= 8:
        mask = mask[:, :cut]
    ys, xs = np.where(mask > 0)
    if len(xs) == 0:
        out = np.zeros((NORMALIZED_HEIGHT, 1), dtype=np.uint8)
        meta = {"ok": False, "reason": "NO_FOREGROUND", "value_suffix_cut": cut}
        return (out, meta) if return_meta else out
    x0, x1, y0, y1 = int(xs.min()), int(xs.max()) + 1, int(ys.min()), int(ys.max()) + 1
    crop = mask[y0:y1, x0:x1]
    scale = NORMALIZED_HEIGHT / max(1, crop.shape[0])
    nw = max(1, int(round(crop.shape[1] * scale)))
    norm = cv2.resize(crop, (nw, NORMALIZED_HEIGHT), interpolation=cv2.INTER_NEAREST)
    # One pixel horizontal safety padding stabilizes translation scoring.
    norm = np.pad(norm, ((0, 0), (2, 2)), mode="constant", constant_values=0)
    meta = {
        "ok": True,
        "source_size": list(img.size),
        "foreground_bbox": [x0, y0, x1, y1],
        "value_suffix_cut": cut,
        "normalized_size": [int(norm.shape[1]), int(norm.shape[0])],
    }
    return (norm, meta) if return_meta else norm


def save_normalized_mask(mask: np.ndarray, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(mask.astype(np.uint8), "L").save(path)


def _pad_to(a: np.ndarray, width: int, shift: int = 0) -> np.ndarray:
    out = np.zeros((NORMALIZED_HEIGHT, width), dtype=np.uint8)
    x = max(0, shift)
    src0 = max(0, -shift)
    n = min(a.shape[1] - src0, width - x)
    if n > 0:
        out[:, x:x+n] = a[:, src0:src0+n]
    return out


def _score_pair(a: np.ndarray, b: np.ndarray) -> Dict[str, float]:
    """Translation-tolerant multi-metric score in [0,1].

    Bitmap glyphs can move by one native pixel between captures. Exact IoU is
    therefore supporting evidence, not the sole authority. A 1px tolerant IoU
    and bidirectional chamfer-like distance make the comparison stable while
    preserving discriminative glyph shape.
    """
    if a.size == 0 or b.size == 0:
        return {"score": 0.0, "iou": 0.0, "tolerant_iou": 0.0, "ncc": 0.0, "projection": 0.0, "shape": 0.0}
    width = max(a.shape[1], b.shape[1]) + 10
    best = {"score": -1.0, "iou": 0.0, "tolerant_iou": 0.0, "ncc": 0.0, "projection": 0.0, "shape": 0.0}
    aa0 = (a > 0).astype(np.uint8)
    kernel = np.ones((3,3), np.uint8)
    for shift in range(-4, 5):
        aa = (_pad_to((aa0 * 255).astype(np.uint8), width, shift) > 0).astype(np.uint8)
        bb = (_pad_to(b, width, 0) > 0).astype(np.uint8)
        inter = float(np.logical_and(aa, bb).sum())
        union = float(np.logical_or(aa, bb).sum())
        iou = inter / union if union else 0.0

        ad = cv2.dilate(aa, kernel, iterations=1) > 0
        bd = cv2.dilate(bb, kernel, iterations=1) > 0
        # Tolerant overlap: every glyph pixel gets one-pixel capture jitter.
        tinter = 0.5 * (float(np.logical_and(aa > 0, bd).sum()) + float(np.logical_and(bb > 0, ad).sum()))
        tden = 0.5 * (float((aa > 0).sum()) + float((bb > 0).sum()))
        tiou = tinter / tden if tden else 0.0

        af, bf = aa.astype(np.float32).ravel(), bb.astype(np.float32).ravel()
        if af.std() > 1e-6 and bf.std() > 1e-6:
            ncc_raw = float(np.corrcoef(af, bf)[0, 1])
            if math.isnan(ncc_raw): ncc_raw = 0.0
        else:
            ncc_raw = 0.0
        ncc = max(0.0, min(1.0, (ncc_raw + 1.0) / 2.0))
        pa = aa.sum(axis=0).astype(np.float32); pb = bb.sum(axis=0).astype(np.float32)
        den = float(np.linalg.norm(pa) * np.linalg.norm(pb))
        projection = float(np.dot(pa, pb) / den) if den > 1e-9 else 0.0

        # Bidirectional nearest-foreground distance. Distance transform returns
        # distance to zero, so invert the binary foreground maps.
        dist_to_b = cv2.distanceTransform((1-bb).astype(np.uint8), cv2.DIST_L2, 3)
        dist_to_a = cv2.distanceTransform((1-aa).astype(np.uint8), cv2.DIST_L2, 3)
        da = float(dist_to_b[aa > 0].mean()) if (aa > 0).any() else 9.0
        db = float(dist_to_a[bb > 0].mean()) if (bb > 0).any() else 9.0
        mean_d = 0.5 * (da + db)
        shape = float(math.exp(-mean_d / 1.35))

        score = 0.16 * iou + 0.28 * tiou + 0.17 * ncc + 0.20 * projection + 0.19 * shape
        if score > best["score"]:
            best = {"score": float(score), "iou": float(iou), "tolerant_iou": float(tiou), "ncc": float(ncc), "projection": float(projection), "shape": float(shape), "shift": int(shift)}
    return best


@dataclass
class VisualCandidate:
    option_id: str
    option_name: str
    family: Optional[str]
    qualifier: Optional[str]
    unit: Optional[str]
    visual_score: float
    ocr_score: float
    family_score: float
    qualifier_score: float
    ensemble_score: float
    best_prototype: Optional[str]
    prototype_count: int


class GoldenOptionVisualRegistry:
    def __init__(self, root: Path, registry_json: Optional[Path] = None):
        self.root = Path(root)
        self.registry_json = Path(registry_json) if registry_json else self.root / "Data" / "golden_option_visual_registry.json"
        self.data: Dict[str, Any] = {"entries": []}
        self.entries: Dict[str, Dict[str, Any]] = {}
        self.prototype_cache: Dict[str, np.ndarray] = {}
        self.reload()

    def reload(self):
        try:
            self.data = json.loads(self.registry_json.read_text(encoding="utf-8")) if self.registry_json.exists() else {"entries": []}
        except Exception:
            self.data = {"entries": []}
        self.entries = {str(x.get("option_id")): x for x in self.data.get("entries", []) if isinstance(x, dict) and x.get("option_id")}
        self.prototype_cache.clear()

    def get(self, option_id: str) -> Dict[str, Any]:
        return self.entries.get(str(option_id), {})

    def prototypes(self, option_id: str, split: str = "train") -> List[Tuple[str, np.ndarray]]:
        entry = self.get(option_id)
        out = []
        for p in entry.get("visual_prototypes", []) or []:
            if str(p.get("split") or "train") != split:
                continue
            rel = str(p.get("mask_path") or "")
            if not rel:
                continue
            path = (self.root / rel).resolve()
            key = str(path)
            if key not in self.prototype_cache:
                try:
                    self.prototype_cache[key] = np.asarray(Image.open(path).convert("L"), dtype=np.uint8)
                except Exception:
                    continue
            out.append((rel, self.prototype_cache[key]))
        return out


class ClosedWorldOptionVisionEngine:
    VERSION = VISION_VERSION

    def __init__(self, root: Path):
        self.root = Path(root)
        self.registry = GoldenOptionVisualRegistry(self.root)
        self.option_rows = {str(x.get("id")): x for x in OPTION_REGISTRY}

    def _visual_qualifier_vote_from_mask(self, mask: np.ndarray, family: Optional[str]) -> Dict[str, Any]:
        """Dedicated NỘI/NGOẠI visual micro-recognizer.

        It compares the current real JX1 name mask only against real captured
        prototypes from the already compatible option family. It is deliberately
        conservative: no prototype/weak margin => UNKNOWN. OCR is not used here.
        """
        if not family or family in ("UNKNOWN", "CONFLICT", "RESOURCE_MAX", "ACCURACY"):
            return {"state": "UNKNOWN", "family": family, "noi_score": 0.0, "ngoai_score": 0.0, "margin": 0.0, "prototype_count": 0}
        def _suffix_region(m: np.ndarray, frac: float = 0.60) -> np.ndarray:
            if m is None or m.size == 0:
                return m
            xs = np.where((m > 0).any(axis=0))[0]
            if len(xs) == 0:
                return m
            x0, x1 = int(xs.min()), int(xs.max()) + 1
            span = max(1, x1 - x0)
            sx = max(x0, int(round(x1 - span * frac)))
            return m[:, sx:x1]

        # Compare the localized right-side name suffix rather than the full name.
        # This prevents the shared family prefix (e.g. "Băng sát") from
        # overpowering the critical "nội công" / "ngoại công" distinction.
        suffix_mask = _suffix_region(mask)
        scores = {"NOI": [], "NGOAI": []}
        proto_count = 0
        for oid, meta in self.option_rows.items():
            if meta.get("option_family") != family:
                continue
            q = meta.get("qualifier")
            if q not in scores:
                continue
            for _rel, proto in self.registry.prototypes(oid, "train"):
                proto_count += 1
                scores[q].append(float(_score_pair(suffix_mask, _suffix_region(proto))["score"]))
        noi = max(scores["NOI"]) if scores["NOI"] else 0.0
        ngoai = max(scores["NGOAI"]) if scores["NGOAI"] else 0.0
        best_q = "NOI" if noi >= ngoai else "NGOAI"
        best = max(noi, ngoai); second = min(noi, ngoai); margin = best-second
        # A qualifier is authority only when actual paired real-game prototypes
        # exist and the visual separation is meaningful. Otherwise stay UNKNOWN.
        state = best_q if best >= 0.50 and margin >= 0.055 and scores[best_q] and scores["NGOAI" if best_q=="NOI" else "NOI"] else "UNKNOWN"
        return {"state": state, "family": family, "noi_score": round(noi,6), "ngoai_score": round(ngoai,6), "margin": round(margin,6), "prototype_count": proto_count}

    def _candidate(self, option_id: str, mask: np.ndarray, ocr_text: str, observed_family: Optional[str], observed_qualifier: Optional[str]) -> VisualCandidate:
        meta = self.option_rows.get(option_id) or {}
        protos = self.registry.prototypes(option_id, "train")
        best_score = 0.0; best_path = None
        if protos:
            for rel, proto in protos:
                s = _score_pair(mask, proto)["score"]
                if s > best_score:
                    best_score, best_path = float(s), rel
        ocr = _token_ratio(ocr_text, meta.get("display_name") or "")
        fam = meta.get("option_family")
        qual = meta.get("qualifier")
        family_score = 0.5 if not observed_family or observed_family in ("UNKNOWN", "CONFLICT") else (1.0 if observed_family == fam else 0.0)
        qualifier_score = 0.5 if not qual else (1.0 if observed_qualifier == qual else (0.5 if not observed_qualifier else 0.0))
        # No visual prototype => OCR may support diagnostics but cannot become
        # single-source canonical authority. Keep its ensemble deliberately low.
        if protos:
            # When family/qualifier evidence is available, it is a structural
            # closed-world gate: an ICE_DAMAGE row should not lose to SKILL_LEVEL
            # merely because a noisy shape score is slightly higher. Visual still
            # owns the largest single weight; OCR remains secondary.
            if observed_family not in (None, "", "UNKNOWN", "CONFLICT"):
                ensemble = 0.48 * best_score + 0.18 * ocr + 0.22 * family_score + 0.12 * qualifier_score
            else:
                ensemble = VISUAL_WEIGHT * best_score + OCR_SECONDARY_WEIGHT * ocr + FAMILY_WEIGHT * family_score + QUALIFIER_WEIGHT * qualifier_score
        else:
            ensemble = 0.22 * ocr + 0.08 * family_score + 0.05 * qualifier_score
        return VisualCandidate(
            option_id=option_id, option_name=str(meta.get("display_name") or option_id),
            family=fam, qualifier=qual, unit=meta.get("unit_type"),
            visual_score=round(best_score, 6), ocr_score=round(ocr, 6),
            family_score=round(family_score, 6), qualifier_score=round(qualifier_score, 6),
            ensemble_score=round(float(ensemble), 6), best_prototype=best_path,
            prototype_count=len(protos),
        )

    def classify_row(self, row_img: Image.Image, *, ocr_text: str = "", observed_family: Optional[str] = None, observed_qualifier: Optional[str] = None, allowed_option_ids: Optional[Sequence[str]] = None) -> Dict[str, Any]:
        mask, norm_meta = normalize_name_mask(row_img, return_meta=True)
        # Existing semantic family/qualifier may come from row geometry/OCR. If
        # absent, use a conservative OCR secondary vote; neither path can by
        # itself establish canonical identity.
        effective_family = observed_family if observed_family not in (None, "", "UNKNOWN", "CONFLICT") else _ocr_secondary_family(ocr_text)
        qualifier_visual = self._visual_qualifier_vote_from_mask(mask, effective_family)
        if qualifier_visual.get("state") in ("NOI", "NGOAI"):
            effective_qualifier = qualifier_visual["state"]
        else:
            effective_qualifier = observed_qualifier if observed_qualifier not in (None, "", "UNKNOWN") else _ocr_secondary_qualifier(ocr_text)
        canonical_hint = _ocr_secondary_canonical_hint(ocr_text)
        if allowed_option_ids is None:
            candidate_ids=list(self.option_rows.keys())
        else:
            allowed_set={str(x) for x in allowed_option_ids if str(x) in self.option_rows}
            candidate_ids=[oid for oid in self.option_rows.keys() if oid in allowed_set]

        # Stage-1 profile gate.  A strict family/canonical hint outside the active
        # registry is exclusion evidence.  Do NOT force the row to the nearest
        # in-profile visual prototype.
        allowed_families={self.option_rows[oid].get('option_family') for oid in candidate_ids if self.option_rows[oid].get('option_family')}
        if allowed_option_ids is not None and canonical_hint and canonical_hint in self.option_rows and canonical_hint not in candidate_ids:
            return {
                "vision_version": self.VERSION, "identity_state": "OUT_OF_PROFILE", "identity_authoritative": False,
                "canonical_option_id": None, "canonical_option_name": None, "family": effective_family, "qualifier": effective_qualifier, "unit": None,
                "best_id": None, "best_score": 0.0, "best_visual_score": 0.0, "second_id": None, "second_score": 0.0, "margin": 0.0,
                "normalization": norm_meta, "secondary_family_vote": effective_family, "secondary_qualifier_vote": effective_qualifier,
                "visual_qualifier_vote": qualifier_visual, "secondary_canonical_hint": canonical_hint,
                "candidate_pool_size": 0, "allowed_candidate_count": len(candidate_ids), "out_of_profile": True,
                "out_of_profile_reason": "STRICT_CANONICAL_HINT_OUTSIDE_ACTIVE_REGISTRY", "candidates": [],
            }
        if allowed_option_ids is not None and effective_family not in (None,"","UNKNOWN","CONFLICT") and effective_family not in allowed_families:
            return {
                "vision_version": self.VERSION, "identity_state": "OUT_OF_PROFILE", "identity_authoritative": False,
                "canonical_option_id": None, "canonical_option_name": None, "family": effective_family, "qualifier": effective_qualifier, "unit": None,
                "best_id": None, "best_score": 0.0, "best_visual_score": 0.0, "second_id": None, "second_score": 0.0, "margin": 0.0,
                "normalization": norm_meta, "secondary_family_vote": effective_family, "secondary_qualifier_vote": effective_qualifier,
                "visual_qualifier_vote": qualifier_visual, "secondary_canonical_hint": canonical_hint,
                "candidate_pool_size": 0, "allowed_candidate_count": len(candidate_ids), "out_of_profile": True,
                "out_of_profile_reason": "STRICT_FAMILY_OUTSIDE_ACTIVE_REGISTRY", "candidates": [],
            }
        # Candidate narrowing is safe only from strict multi-token evidence. The
        # final identity still requires a real JX1 visual prototype score/margin.
        if canonical_hint and canonical_hint in self.option_rows:
            hinted=self.option_rows[canonical_hint]; hf=hinted.get('option_family')
            if hf:
                candidate_ids=[oid for oid in candidate_ids if self.option_rows[oid].get('option_family')==hf]
            else:
                candidate_ids=[canonical_hint]
        elif effective_family == 'RESOURCE_MAX':
            candidate_ids=[oid for oid in candidate_ids if oid in ('sinh_luc_toi_a','noi_luc_toi_a','the_luc_toi_a')]
        elif effective_family not in (None,"","UNKNOWN","CONFLICT"):
            narrowed=[oid for oid in candidate_ids if self.option_rows[oid].get('option_family')==effective_family]
            if narrowed: candidate_ids=narrowed
        if effective_qualifier in ('NOI','NGOAI'):
            qn=[oid for oid in candidate_ids if self.option_rows[oid].get('qualifier') in (None,effective_qualifier)]
            if qn: candidate_ids=qn
        # Options with no prototype cannot become visual authority; retaining them
        # only burns CPU. They remain represented in the 34-option registry and
        # target compatibility reports as prototype-unavailable UNKNOWN.
        visual_ids=[oid for oid in candidate_ids if self.registry.prototypes(oid,'train')]
        if visual_ids: candidate_ids=visual_ids
        candidates = [self._candidate(oid, mask, ocr_text, effective_family, effective_qualifier) for oid in candidate_ids]
        candidates.sort(key=lambda c: c.ensemble_score, reverse=True)
        top = candidates[0] if candidates else None
        second = candidates[1] if len(candidates) > 1 else None
        margin = (top.ensemble_score - second.ensemble_score) if top and second else (top.ensemble_score if top else 0.0)
        visual_available = bool(top and top.prototype_count > 0)
        state = "OPTION_UNKNOWN"; authority = False
        # RESOURCE_MAX is a safe exclusion-family only. Historical OCR cannot
        # reliably distinguish Nội/Thể/Sinh in every tiny row, so V12 refuses
        # to fabricate a canonical ID from shape alone. It may still prove that
        # the row is NOT a filter target such as SKILL_LEVEL.
        if effective_family == 'RESOURCE_MAX' and (not canonical_hint or not top or top.option_id != canonical_hint):
            # A good visual score cannot override a missing or contradictory
            # exact OCR identity for these three lookalike attributes.
            state = 'OPTION_AMBIGUOUS' if top and visual_available else 'OPTION_UNKNOWN'
        elif top and visual_available and top.visual_score >= VISUAL_CONFIRM_MIN and margin >= VISUAL_MIN_MARGIN:
            state = "OPTION_CONFIRMED"; authority = True
        elif top and visual_available:
            # Secondary-vote confirmation: visual evidence must still be present,
            # while OCR/family/qualifier only resolve a visual tie. OCR alone can
            # never satisfy this gate.
            secondary_ok = (
                (top.visual_score >= 0.28
                 and top.ocr_score >= 0.42
                 and top.family_score >= 0.90
                 and (top.qualifier is None or top.qualifier_score >= 0.95)
                 and margin >= 0.065)
                or
                (top.visual_score >= 0.55
                 and top.ocr_score >= 0.34
                 and top.family_score >= 0.90
                 and top.qualifier_score >= 0.50
                 and margin >= 0.08)
            )
            if secondary_ok:
                state = "OPTION_CONFIRMED"; authority = True
            elif top.visual_score > VISUAL_EXCLUDE_MAX or top.ocr_score >= 0.58:
                state = "OPTION_AMBIGUOUS"

        return {
            "vision_version": self.VERSION,
            "identity_state": state,
            "identity_authoritative": authority,
            "canonical_option_id": top.option_id if authority and top else None,
            "canonical_option_name": top.option_name if authority and top else None,
            "family": top.family if authority and top else observed_family,
            "qualifier": top.qualifier if authority and top else observed_qualifier,
            "unit": top.unit if authority and top else None,
            "best_id": top.option_id if top else None,
            "best_score": top.ensemble_score if top else 0.0,
            "best_visual_score": top.visual_score if top else 0.0,
            "second_id": second.option_id if second else None,
            "second_score": second.ensemble_score if second else 0.0,
            "margin": round(float(margin), 6),
            "normalization": norm_meta,
            "secondary_family_vote": effective_family,
            "secondary_qualifier_vote": effective_qualifier,
            "visual_qualifier_vote": qualifier_visual,
            "secondary_canonical_hint": canonical_hint,
            "candidate_pool_size": len(candidate_ids),
            "allowed_candidate_count": (len(allowed_option_ids) if allowed_option_ids is not None else len(self.option_rows)),
            "out_of_profile": False,
            "candidates": [asdict(c) for c in candidates[:8]],
        }

    def target_compatibility(self, row_img: Image.Image, target_option_id: str, *, ocr_text: str = "", observed_family: Optional[str] = None, observed_qualifier: Optional[str] = None) -> Dict[str, Any]:
        mask, norm_meta = normalize_name_mask(row_img, return_meta=True)
        target_meta=self.option_rows.get(str(target_option_id)) or {}
        effective_family = observed_family if observed_family not in (None,"","UNKNOWN","CONFLICT") else _ocr_secondary_family(ocr_text)
        effective_qualifier = observed_qualifier if observed_qualifier not in (None,"","UNKNOWN") else _ocr_secondary_qualifier(ocr_text)
        target = self._candidate(str(target_option_id), mask, ocr_text, effective_family, effective_qualifier)
        if target.prototype_count <= 0:
            return {"state": "ROW_UNKNOWN", "reason": "TARGET_HAS_NO_VISUAL_PROTOTYPE", "target": asdict(target), "normalization": norm_meta}
        tf=target_meta.get('option_family'); tq=target_meta.get('qualifier')
        # A strict family/qualifier contradiction is exclusion evidence, not an
        # OCR identity decision. This implements family-before-fuzzy safely.
        if effective_family not in (None,"","UNKNOWN","CONFLICT") and tf and effective_family!=tf:
            return {"state":"TARGET_EXCLUDED","reason":"STRICT_FAMILY_CONTRADICTION","target":asdict(target),"normalization":norm_meta,"observed_family":effective_family}
        if tq in ('NOI','NGOAI') and effective_qualifier in ('NOI','NGOAI') and tq!=effective_qualifier:
            return {"state":"TARGET_EXCLUDED","reason":"STRICT_QUALIFIER_CONTRADICTION","target":asdict(target),"normalization":norm_meta,"observed_qualifier":effective_qualifier}
        if target.visual_score >= VISUAL_CONFIRM_MIN:
            return {"state": "TARGET_COMPATIBLE", "reason": "TARGET_VISUAL_COMPATIBLE", "target": asdict(target), "normalization": norm_meta}
        if target.visual_score <= VISUAL_EXCLUDE_MAX:
            return {"state": "TARGET_EXCLUDED", "reason": "TARGET_VISUAL_EXCLUDED", "target": asdict(target), "normalization": norm_meta}
        return {"state": "ROW_UNKNOWN", "reason": "TARGET_VISUAL_AMBIGUITY_BAND", "target": asdict(target), "normalization": norm_meta}

    def classify_rows(self, row_images: Sequence[Image.Image], row_evidence: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
        out = []
        for i, img in enumerate(row_images):
            ev = row_evidence[i] if i < len(row_evidence) else {}
            rid = ev.get("row_identity_authority") or {}
            sem = rid.get("semantic_identity") or {}
            out.append(self.classify_row(
                img, ocr_text=str(ev.get("text") or ""),
                observed_family=sem.get("observed_family"), observed_qualifier=sem.get("observed_qualifier")
            ))
        return out
