@echo off
setlocal
cd /d "%~dp0"
echo [1/3] Python 3.12 + pip
py -3.12 --version
if errorlevel 1 goto fail
py -3.12 -m pip install --upgrade pip
if errorlevel 1 goto fail
echo [2/3] Install pinned PaddlePaddle CPU + PaddleOCR
py -3.12 -m pip install --upgrade "paddlepaddle==3.3.1" "paddleocr==3.7.0"
if errorlevel 1 goto fail
echo [3/3] Warm up Vietnamese OCR model
py -3.12 PADDLEOCR_SETUP.py
if errorlevel 1 goto fail
echo PaddleOCR READY
pause
exit /b 0
:fail
echo Setup failed. Run SETUP_AUTOPRO\INSTALL_ALL.bat for full environment repair.
pause
exit /b 1
