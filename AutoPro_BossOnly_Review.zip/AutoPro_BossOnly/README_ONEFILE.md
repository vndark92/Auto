# Auto Pro By Eric V1.7.16 — đóng gói một EXE

**Mục tiêu phân phối:** đúng một file `AutoProByEric_V1.7.16.exe`. Người kiểm thử chỉ cần mở EXE trên Windows x64; **không phải đặt HTML/JSON/Python/Data cạnh EXE**, cũng không cần cài Python để chạy bản EXE đã build.

**Tình trạng của gói hiện tại:** đây là mã nguồn + bộ tạo một EXE cho **Windows 64-bit**. Chưa có bản EXE được biên dịch và chạy thử trên Windows trong môi trường cung cấp gói này. Không dùng ZIP này như thể nó đã là ứng dụng Windows phát hành.

## Dành cho máy Windows dùng để build (một lần)

1. Máy build có Windows 10/11 x64, Python 3.12 x64, Internet để cài dependencies, và Tesseract OCR x64 đã cài tại `C:\Program Files\Tesseract-OCR` (hoặc chép cả thư mục OCR vào `vendor\Tesseract-OCR`).
2. Giải nén ZIP, nhấn đúp `TAO_1_FILE_EXE.bat`. Chương trình tự tạo môi trường build và cài thư viện.
3. Nếu thành công, **chỉ lấy file** `dist\AutoProByEric_V1.7.16.exe` để phát cho người thử. Không sao chép folder source/build.

Không cần chạy các batch file khác. Nếu lệnh build lỗi, lưu ảnh hoặc nội dung lỗi (không cần gửi dữ liệu game riêng tư).

## Dành cho người kiểm thử (sau khi đã nhận EXE thành công)

- Mở `AutoProByEric_V1.7.16.exe` trên Windows 10/11 x64, chấp nhận UAC nếu ứng dụng yêu cầu. Không cần Python hay thư mục dữ liệu cạnh EXE.
- EXE tự giải nén thư viện tạm thời bằng PyInstaller và tạo cấu hình bền vững trong `%LOCALAPPDATA%\AutoProByEric\V1.7.16\instances\...`. **Đừng xóa AppData nếu cần giữ cấu hình/tọa độ.**
- Để có cấu hình riêng cho acc khác, sao chép EXE thành tên khác (ví dụ `AutoPro_Acc02.exe`), ứng dụng tạo profile độc lập. Log nhiều acc được lưu chung tại `%LOCALAPPDATA%\AutoProByEric\logs\accounts` và có bộ lọc trong giao diện.
- Kiểm tra lần lượt giao diện, chọn HWND, log nhiều acc, quyền sở hữu cửa sổ. Chưa bật Auto xử lý vật phẩm có giá trị trước khi thử an toàn.

## Giới hạn chưa giải quyết

- **Chưa biên dịch được EXE Windows ở đây** vì môi trường hiện tại không phải Windows, không có Windows PyInstaller / thư viện DLL Win. Không có phép kiểm tra một lần chạy game thật.
- Windows vẫn có thể cần **Microsoft Edge WebView2 Runtime**. Đây là thành phần hệ thống có thể không có trên một số máy, chưa được nhúng cố định.
- PaddleOCR có thể tải model OCR ở lần dùng đầu nếu máy chưa có model cache. Bản single-EXE không đồng nghĩa với bảo đảm offline tuyệt đối.
- Tesseract.exe chỉ được nhúng nếu tìm thấy Windows OCR trên máy build. **Build sẽ dừng** khi thiếu Tesseract, thay vì xuất EXE thiếu OCR.
- PyInstaller chứa Python runtime/vision libraries trong EXE, vì vậy file cuối có thể lớn và mỗi lần mở cần giải nén thư viện vào thư mục tạm; cửa sổ và log vẫn thuộc profile bền vững.
- 23/23 bài test logic của V1.7.16 và 4/4 bài kiểm thử launcher một file đạt trên Linux. Đây **không phải** kiểm thử chạy EXE Windows.

**Phiên bản ứng dụng không thay đổi:** V1.7.16. Auto Chest/Roll/Boss chạy nền chưa xác minh vẫn được khóa như trước; không phát triển tính năng V1.7.17.
