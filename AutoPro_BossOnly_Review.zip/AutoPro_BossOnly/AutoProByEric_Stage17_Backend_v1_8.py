from __future__ import annotations
from pathlib import Path
from AutoProByEric_ConfigStore_v1715 import save_json as _safe_save_json, load_json as _safe_load_json
from dataclasses import dataclass
from ctypes import wintypes
import json, os, time, traceback, shutil, ctypes, sys, re, difflib, unicodedata, zipfile, functools, threading, hashlib
import pytesseract
import webview

from AutoProByEric_WinCapture_v1_7 import (
    enumerate_windows, capture_client, get_cursor_client,
    window_exists, is_minimized
)
from AutoProByEric_TooltipDetector_v1_7 import detect_tooltip_near_cursor
from AutoProByEric_Stage16_Reader_v1_6 import (
    OPTION_DB, read_single_tooltip, consensus, evaluate_filter,
    extract_last6_boxes, _blue_gray_mask_rgb, _numeric_candidates, normalize_numeric_ocr,
    _primary_value_token, read_attack_speed_percent_authority, parse_attack_speed_percent_evidence
)

try:
    from AutoProByEric_PaddleOCRHybrid_v1 import (
        recognize as paddleocr_recognize,
        engine_status as paddleocr_engine_status,
    )
except Exception:
    paddleocr_recognize = None
    def paddleocr_engine_status():
        return {
            "available": False,
            "initialized": False,
            "last_error": "PADDLE_RUNTIME_BRIDGE_IMPORT_FAILED",
        }
from AutoProByEric_InventorySensor_v3_5 import (
    detect_inventory_grid, detect_personal_storage_grid, detect_jx1_panel_identities, resolve_jx1_containers, GridOwner,
    validate_known_grid, snapshot_inventory, diff_snapshots,
    canonical_inventory_grid_snapshot, CANONICAL_X, CANONICAL_Y
)
from AutoProByEric_NewItemQueue_v4_0 import (
    GROUP_LABELS, possible_groups_for_footprint, hover_points_for_candidate,
    choose_best_group, public_queue_item, classify_group_from_options
)
from AutoProByEric_FullTooltipAnchorScanner_v6_0 import scan_full_tooltip_anchors
from AutoProByEric_OptionRegistry_v1 import (
    FILTERABLE_OPTIONS, REGISTRY as OPTION_REGISTRY, registry_payload, validate_registry, option_semantics, option_unit_type,
    PROFILE_REGISTRY_VERSION, profile_registry_payload, profile_key_for_scope, profile_options, profile_option_ids, option_allowed_for_scope,
    USER_TAUGHT_IMPLICIT_PERCENT_OPTIONS, implicit_percent_number_only
)
from AutoProByEric_ItemFilterEngine_v1 import (
    CONFIG_SCHEMA_VERSION as FILTER_CONFIG_SCHEMA_VERSION, migrate_config as migrate_filter_config,
    enabled_profiles as filter_enabled_profiles, wanted_option_set, union_scan_rules, compose_profile_result
)
from AutoProByEric_AutoResumeAfterLagController_v1 import (
    AutoResumeAfterLagController, classify_pause_reason, AUTO_RESUME_DELAY_SECONDS
)
from AutoProByEric_TooltipForegroundExtractor_v1 import (
    TooltipForegroundExtractor, EXTRACTOR_VERSION as V110_FOREGROUND_EXTRACTOR_VERSION
)
from AutoProByEric_ClosedWorldOptionVision_v1 import (
    ClosedWorldOptionVisionEngine, VISION_VERSION as V120_VISION_VERSION
)
from AutoProByEric_ResumeCoordinator_v1 import (
    ResumeCoordinator, RESUME_COORDINATOR_VERSION as V120_RESUME_COORDINATOR_VERSION
)
from AutoProByEric_LogLifecycleManager_v1 import LogLifecycleManager
from AutoProByEric_LicenseGuard_v1 import license_runtime_allowed, license_status
from AutoProByEric_ProofArtifactManager_v1 import (
    ProofArtifactManager, PROOF_ARTIFACT_MANAGER_VERSION as V121_PROOF_MANAGER_VERSION
)
from AutoProByEric_StorageTruthHarness_v12_4 import (
    HARNESS_VERSION as STORAGE_TRUTH_HARNESS_VERSION,
    write_pre_store_truth, write_post_store_truth,
)
from AutoProByEric_PaddleEscalationPolicy_v1 import (
    evaluate as adaptive_paddle_escalation_policy,
    POLICY_VERSION as ADAPTIVE_PADDLE_POLICY_VERSION,
)

ROOT = Path(__file__).resolve().parent
LOGDIR = ROOT / 'logs'
LOGDIR.mkdir(exist_ok=True)
LOG_LIFECYCLE = LogLifecycleManager(LOGDIR)
# Ultra Cleanroom V1: canonical diagnostic tree only. Version identity stays in metadata.
LOG_RUNTIME_DIR = LOGDIR / 'runtime'
LOG_ACTIONS_DIR = LOGDIR / 'actions'
LOG_PROOF_RESUME_DIR = LOGDIR / 'proof' / 'resume'
LOG_PROOF_STORAGE_DIR = LOGDIR / 'proof' / 'storage'
for _log_dir in (LOG_RUNTIME_DIR, LOG_ACTIONS_DIR, LOG_PROOF_RESUME_DIR, LOG_PROOF_STORAGE_DIR):
    _log_dir.mkdir(parents=True, exist_ok=True)
FILTER_PATH = ROOT / 'AutoProByEric_Stage16_FilterSample_v1.6.json'
USER_FILTER_PATH = ROOT / 'AutoProByEric_UserOptionFilter.json'
OCR_CONFIG_PATH = ROOT / 'ocr_path.json'
APP_CONFIG_PATH = ROOT / 'autopro_runtime_config.json'
SHOP_GUARD_PATH = ROOT / 'shop_open_guard_v8_8.json'
SHOP_GUARD_REFERENCE_PATH = ROOT / 'shop_open_reference_v8_8.png'
SHOP_RUNTIME_LOG_PATH = LOGDIR / 'shop_guard_runtime_v8_8.jsonl'
SHOP_LATEST_DIAG_PATH = LOGDIR / 'shop_guard_latest_v8_8.json'
SHOP_LATEST_SCREEN_PATH = LOGDIR / 'shop_guard_latest_screen_v8_8.png'
AUTO_RESUME_LOG_PATH = LOGDIR / 'auto_resume_after_lag.jsonl'
RUNTIME_LIFECYCLE_LOG_PATH = LOGDIR / 'RUNTIME_LIFECYCLE.jsonl'


# V12.5 child build from the exact V12.4 runtime that produced the StorageTruth
# artifacts used by the 2026-10-04 10:05:38 regression report. OCR / Vision /
# Filter / Drop / Resume / Storage geometry / occupancy / planner stay frozen.
# This child fixes ONLY physical Store execution after a valid destination exists.
V125_BUILD_ID = 'AutoProByEric_V12.11_AutoChest_KEEP_DROP_Master'
V124_BUILD_ID = V125_BUILD_ID
V122_BUILD_ID = V125_BUILD_ID
V122_READER_VERSION = 'CLOSED_WORLD_OPTION_VISION_V12_2_FILTER_TRUTH'
V122_FILTER_VERSION = 'OBSERVED_OPTION_FILTER_V12_2_RULE_TRUTH'
V121_BUILD_ID = V122_BUILD_ID
V121_READER_VERSION = V122_READER_VERSION
V121_FILTER_VERSION = V122_FILTER_VERSION
V120_BUILD_ID = V121_BUILD_ID
V120_READER_VERSION = V121_READER_VERSION
V120_FILTER_VERSION = V121_FILTER_VERSION
V116_BUILD_ID = V120_BUILD_ID
V115_BUILD_ID = V116_BUILD_ID
V114_BUILD_ID = V115_BUILD_ID
V113_BUILD_ID = V114_BUILD_ID
V112_BUILD_ID = V113_BUILD_ID
V112_READER_VERSION = V120_READER_VERSION
V112_FILTER_VERSION = V120_FILTER_VERSION
V111_BUILD_ID = V112_BUILD_ID
V111_READER_VERSION = V112_READER_VERSION
V111_FILTER_VERSION = V112_FILTER_VERSION
PROOF_ARTIFACTS = ProofArtifactManager(
    LOGDIR,
    build_id=V121_BUILD_ID,
    subsystem_revisions={
        'foreground': V110_FOREGROUND_EXTRACTOR_VERSION,
        'skill_value': 'SKILL_LEVEL_READER_V2_PHYSICAL_ROW_BAND',
        'option_vision': V120_VISION_VERSION,
        'resume_drop': 'PHYSICAL_DROP_TRUTH_V11_5_PRESERVED',
        'filter': V121_FILTER_VERSION,
        'storage': 'STORE_TRANSACTION_V10_8_PLUS',
    },
)
V110_FOREGROUND_PROOF_DIR = PROOF_ARTIFACTS.subdir('foreground')
V110_FOREGROUND_EXTRACTOR = TooltipForegroundExtractor(zoom_scale=4)
V120_VISION_ENGINE = ClosedWorldOptionVisionEngine(ROOT)
V120_VISION_PROOF_DIR = PROOF_ARTIFACTS.subdir('option_vision')

# Compatibility names are retained because older helper/function names are stable
# runtime contracts. Their values identify the active V12.2 child build.
V110_BUILD_ID = V111_BUILD_ID
V110_READER_VERSION = V111_READER_VERSION
V110_FILTER_VERSION = V111_FILTER_VERSION
V109_BUILD_ID = V111_BUILD_ID
V109_READER_VERSION = V111_READER_VERSION
V109_FILTER_VERSION = V111_FILTER_VERSION
V107_BUILD_ID = V111_BUILD_ID
V107_READER_VERSION = V111_READER_VERSION
V107_FILTER_VERSION = V111_FILTER_VERSION
V108_BUILD_ID = V111_BUILD_ID
V108_READER_VERSION = V111_READER_VERSION
V109_FINAL6_PROOF_DIR = V110_FOREGROUND_PROOF_DIR
V109_FILTER_RECOVERY_DELAY_SEC = AUTO_RESUME_DELAY_SECONDS
V109_PENDING_RECHECK_INTERVAL_SEC = AUTO_RESUME_DELAY_SECONDS
V113_RESUME_DROP_PROOF_DIR = PROOF_ARTIFACTS.subdir('resume_drop')
V113_SAME_ITEM_MAX_MAE = 32.0
V113_SAME_ITEM_MIN_MARGIN = 1.25
# V11.5 keeps the proven V11.3 metric calibration. _sig_mae is a distance:
# LOWER is a closer visual match. We do not retune thresholds in this build.
V115_POSTDROP_PRESENT_MAX_MAE = V113_SAME_ITEM_MAX_MAE
V115_POSTDROP_AMBIGUOUS_SCORE_MARGIN = V113_SAME_ITEM_MIN_MARGIN
V115_POSTDROP_EXCLUDED_MIN_MAE = V113_SAME_ITEM_MAX_MAE
V116_SKILL_VALUE_PROOF_DIR = PROOF_ARTIFACTS.subdir('skill_value')
V116_SKILL_DOMAIN = (1, 2, 3)


def _v107_sha256_path(path):
    try:
        h=hashlib.sha256()
        with Path(path).open('rb') as f:
            for chunk in iter(lambda:f.read(1024*1024),b''):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None

def _v107_canonical_filter_snapshot(cfg):
    c=migrate_filter_config(cfg or {})
    profiles=[]
    for p in filter_enabled_profiles(c) if isinstance(c,dict) else []:
        rules=[]
        for r in (p.get('rules') or []):
            if not r.get('enabled',True):
                continue
            rules.append({
                'option_name':r.get('option_name'),'operator':r.get('operator') or r.get('op') or '>=',
                'target':r.get('target') if r.get('target') is not None else r.get('value'),'enabled':True,
            })
        profiles.append({'profile_id':int(p.get('profile_id') or 0),'enabled':True,'rules':rules})
    return {
        'schema_version':c.get('schema_version',FILTER_CONFIG_SCHEMA_VERSION),
        'scope':c.get('scope','GLOBAL'),'scope_value':c.get('scope_value','GLOBAL'),
        'group_id':c.get('group_id'),'family':c.get('family'),'profiles':profiles,
    }

def _v107_json_hash(value):
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()

def _v107_runtime_provenance():
    files={
        'entrypoint':ROOT/'AutoProByEric_Stage17_LockedUI_v1_8.py',
        'backend':Path(__file__).resolve(),
        'reader':ROOT/'AutoProByEric_Stage16_Reader_v1_6.py',
        'filter_engine':ROOT/'AutoProByEric_ItemFilterEngine_v1.py',
        'option_registry':ROOT/'AutoProByEric_OptionRegistry_v1.py',
    }
    return {
        'build_id':V107_BUILD_ID,
        'executable_path':str(Path(sys.executable).resolve()),
        'argv0':str(sys.argv[0]) if sys.argv else None,
        'entrypoint':str(files['entrypoint'].resolve()),
        'reader_module_path':str(files['reader'].resolve()),
        'reader_module_sha256':_v107_sha256_path(files['reader']),
        'reader_class':'backend Final6 direct-row fast stage + adaptive PaddleOCR V1.7.10 rescue + Stage16 primitives',
        'reader_function':'Api._read_queue_item_internal/_fast_scan_one_crop',
        'paddle_runtime_bridge':{
            'enabled':True,
            'status':paddleocr_engine_status(),
            'policy':'ADAPTIVE_PADDLE_FINAL6_NAME_ROI_RESCUE_V1_7_10',
        },
        'filter_module_path':str(files['backend']),
        'filter_module_sha256':_v107_sha256_path(files['backend']),
        'filter_class':'backend shared-evidence evaluator',
        'filter_function':'_fast_evaluate_profiles/_fast_evaluate_filter',
        'profile_registry_version':PROFILE_REGISTRY_VERSION,
        'profile_registry':profile_registry_payload(),
        'config_engine_path':str(files['filter_engine'].resolve()),
        'config_engine_sha256':_v107_sha256_path(files['filter_engine']),
        'dispatcher_module_path':str(files['backend']),
        'dispatcher_module_sha256':_v107_sha256_path(files['backend']),
        'reader_version':V107_READER_VERSION,'filter_version':V107_FILTER_VERSION,
    }

# Stage 22.1 / v8.4: give JX1 a little more time to latch the picked item
# before the ground click. Keep EXACTLY-ONCE semantics: these are delays only,
# never retries.
DROP_PICK_SETTLE_BACKGROUND_SEC = 0.120
DROP_PICK_SETTLE_FOREGROUND_SEC = 0.115
DROP_AFTER_GROUND_SETTLE_SEC = 0.090
DROP_CONFIRM_TIMEOUT_SEC = 1.85
DROP_CONFIRM_POLL_SEC = 0.070

# Filter v10.5 child patch — Drop world-occlusion transaction recovery.
# The first input pair is still one logical Drop transaction. Recovery is
# bounded and state-driven: max two recovery attempts, never blind retries.
DROP_RECOVERY_MAX_ATTEMPTS = 2
DROP_GROUND_MOTION_SAMPLE_SEC = 0.035
DROP_GROUND_ROI_RADIUS = 22
DROP_GROUND_OCCLUSION_MAE = 14.0
DROP_CURSOR_REPROBE_SAMPLES = 2

# Stage 24 / v8.8: personal HÀNH TRANG storage timings retained from the approved v8.6 path.
# Exactly-once mouse semantics; delays are only for JX1 UI settle/confirmation.
STORE_ICON_SETTLE_SEC = 0.34
STORE_PICK_SETTLE_BACKGROUND_SEC = 0.120
STORE_PICK_SETTLE_FOREGROUND_SEC = 0.120
STORE_PLACE_SETTLE_SEC = 0.110
STORE_CONFIRM_TIMEOUT_SEC = 2.10
STORE_CONFIRM_POLL_SEC = 0.075

# Stage 24 / v8.8 — shared real-time consumable scheduler.
COMMON_WHITE_INTERVAL_SEC = 62 * 60   # Thiên Sơn Bảo Lộ: 60m duration, use every 62m
COMMON_GREEN_INTERVAL_SEC = 32 * 60   # Quế Hoa Tửu: 30m duration, use every 32m
COMMON_FAILED_RETRY_SEC = 60          # never spam a failed key/click attempt
COMMON_POPUP_SETTLE_SEC = 0.18

# Stage 25 / v9.4 — continuous Shop cycle.
# KEEP path: close Shop exactly once -> store in personal bag -> close bag ->
# reopen the saved Shop NPC exactly once -> Guard must pass before continuing.
SHOP_CLOSE_SETTLE_SEC = 0.14
SHOP_CLOSE_CONFIRM_TIMEOUT_SEC = 1.25
SHOP_REOPEN_CONFIRM_TIMEOUT_SEC = 2.20
SHOP_REOPEN_POLL_SEC = 0.085
SHOP_NPC_CAPTURE_DELAY_MS = 2600
SHOP_CLOSE_CANONICAL = (218.0 / 800.0, 426.0 / 600.0)
SHOP_CHARACTER_CLOSE_CANONICAL = (323.0 / 800.0, 426.0 / 600.0)
SHOP_DIALOG_TRADE_CANONICAL = (249.0 / 800.0, 299.0 / 600.0)
SHOP_TWO_PANEL_SETTLE_SEC = 0.18
SHOP_DIALOG_SETTLE_SEC = 0.24

# Stage 24.6 / v9.3 — skill-level orange-value fast KEEP fix; v9.2 personal-bag/store retained.
# The right-side JX1 source inventory is a fixed 6x10 geometry in an 800x600 client.
# We use canonical geometry only after its actual grid borders validate on the live frame.
SOURCE_CANONICAL_MIN_X_BORDER = 1.80
SOURCE_CANONICAL_MIN_Y_BORDER = 1.80
SOURCE_GRID_QUICK_RECAPTURE_SEC = 0.045

# Inventory source-grid self-recovery — PRE-ACTION ONLY.
# These waits are intentionally short/bounded. Recovery may use only the
# user-selected canonical source-inventory hotkey (F4 or Q).
SOURCE_GRID_RECOVERY_POLL_SEC = 0.055
VERIFIED_GRID_LEASE_MAX_AGE_SEC = 0.90
VERIFIED_GRID_LEASE_STABILITY_FRAMES = 2
SOURCE_GRID_RECOVERY_PRIMARY_TIMEOUT_SEC = 0.72
SOURCE_GRID_RECOVERY_REOPEN_TIMEOUT_SEC = 0.95

# Chest Master Self-Healing Core V10.6
CHEST_SAFE_PAUSE_REASON_REGISTRY_V2 = frozenset({
    'DESTRUCTIVE_TRANSACTION_TRUE_UNKNOWN',
    'CURSOR_TRUE_UNKNOWN_AFTER_BOUNDED_REPROBE',
    'SOURCE_AND_CURSOR_BOTH_UNRESOLVED_AFTER_ACTION',
    'STORE_SOURCE_DESTINATION_CURSOR_ALL_UNRESOLVED',
    'STORE_TRANSACTION_TRUE_UNKNOWN',
    'LOST_HWND_DURING_UNRESOLVED_DESTRUCTIVE_TRANSACTION',
    'TRANSACTION_LEDGER_CORRUPTION_WITH_ITEM_LOCATION_UNKNOWN',
    'DROP_TRANSACTION_TRULY_UNKNOWN',
})
PENDING_DISPOSITION_MAX = 12
RECOVERY_FILTER_REREAD_MAX = 1
FINAL6_DIRECT_ZOOM_SCALE = 4

class ItemRecoveryLedger(dict):
    """In-memory known-item ledger for the current chest session only."""
    def __init__(self):
        super().__init__()
        self.pending=[]


def _safe_pause_v2_allowed(reason):
    return str(reason or '').upper() in CHEST_SAFE_PAUSE_REASON_REGISTRY_V2

def _logical_item_id(item):
    """Stable physical-item identity; Q01 is never a global key in V11.2."""
    item=item or {}
    existing=str(item.get('logical_item_id') or '')
    if existing.startswith('ITEM-'):
        return existing
    session=item.get('session_generation')
    cycle=item.get('originating_cycle_id')
    if cycle is None:
        cycle=item.get('recovery_origin_cycle_id')
    if cycle is None:
        cycle=item.get('cycle_id')
    if session is not None and cycle is not None:
        anchor=list(item.get('original_anchor') or item.get('anchor') or [0,0])
        footprint=list(item.get('footprint') or [1,1])
        fp=str(item.get('fingerprint') or item.get('item_id') or item.get('candidate_id') or item.get('queue_id') or 'ITEM')
        payload={
            'session_generation':int(session),
            'originating_cycle_id':int(cycle),
            'fingerprint':fp,
            'anchor':anchor,
            'footprint':footprint,
        }
        digest=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')).hexdigest()[:14]
        return f"ITEM-{int(session):04d}-{int(cycle):06d}-{digest}"
    # Compatibility fallback for historical artifacts only. New live items are
    # stamped with session+cycle before entering any pending/recovery map.
    fp=str(item.get('queue_id') or item.get('item_id') or item.get('candidate_id') or 'ITEM')
    a=item.get('anchor') or [0,0]; f=item.get('footprint') or [1,1]
    return f"LEGACY-{fp}@{a[0]},{a[1]}:{f[0]}x{f[1]}"


def _v113_source_signature_hash(signatures):
    """Canonical hash of pending-item source signatures for instance binding."""
    try:
        payload=[]
        for sg in (signatures or []):
            payload.append({
                'offset':list(sg.get('offset') or [0,0]),
                'occupied':bool(sg.get('occupied')),
                'sig':list(sg.get('sig') or []),
            })
        raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')
        return hashlib.sha256(raw).hexdigest() if payload else None
    except Exception:
        return None


def _v113_read_option_signature(read):
    """Return the authoritative Final6 foreground hash attached to a Filter read."""
    try:
        r=read if isinstance(read,dict) else {}
        ff=r.get('fast_filter') if isinstance(r.get('fast_filter'),dict) else {}
        frames=ff.get('frames') if isinstance(ff.get('frames'),list) else []
        f0=frames[0] if frames and isinstance(frames[0],dict) else {}
        return f0.get('foreground_zoom4x_sha256') or f0.get('ocr_input_sha256') or f0.get('foreground_final6_sha256')
    except Exception:
        return None


def _v110_item_decision_fingerprint(item, cycle_id=None):
    """Deterministic current-item fingerprint used only for decision authorization.

    Historical queue records often did not carry a dedicated fingerprint.  V11.0
    therefore derives one from the current logical queue identity + anchor +
    footprint + cycle.  It is not an OCR identity claim; it prevents a decision
    envelope from authorizing input for a different queue/cycle instance.
    """
    item=item or {}
    payload={
        'cycle_id':cycle_id,
        'logical_item_id':_logical_item_id(item),
        'queue_id':item.get('queue_id'),
        'anchor':list(item.get('anchor') or [0,0]),
        'footprint':list(item.get('footprint') or [1,1]),
    }
    raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def _canonical_source_grid_candidate(image):
    """Build/validate the fixed right-side source grid directly from canonical geometry.

    This is intentionally stricter than blindly trusting coordinates: the candidate is
    accepted only when validate_known_grid() sees real 28px grid borders in the live
    frame. It fixes SOURCE_GRID_NOT_VISIBLE_NO_HOTKEY when the generic edge finder is
    pulled off cadence by consumables, item art, hover state, or other bright pixels.
    """
    try:
        if image is None:
            return {"ok": False, "reason": "NO_IMAGE"}
        w, h = int(image.width), int(image.height)
        if w < 600 or h < 450:
            return {"ok": False, "reason": "CLIENT_SIZE_UNSUPPORTED"}
        sx, sy = w / 800.0, h / 600.0
        xs = [int(round(float(x) * sx)) for x in CANONICAL_X]
        ys = [int(round(float(y) * sy)) for y in CANONICAL_Y]
        if len(xs) != 7 or len(ys) != 11 or xs[-1] >= w or ys[-1] >= h:
            return {"ok": False, "reason": "CANONICAL_OUT_OF_BOUNDS"}
        # Source grid must live on the right side; never reinterpret the center personal bag.
        if xs[0] < int(w * 0.68):
            return {"ok": False, "reason": "CANONICAL_NOT_RIGHT_SIDE"}
        grid = {
            "ok": True,
            "confidence": 0.84,
            "x_lines": xs,
            "y_lines": ys,
            "cols": 6,
            "rows": 10,
            "roi": [xs[0], ys[0], xs[-1], ys[-1]],
            "kind": GridOwner.PLAYER_INVENTORY.value,
            "coordinate_space": "CLIENT",
            "canonical_runtime": True,
        }
        v = validate_known_grid(image, grid)
        if not v.get("ok"):
            return {"ok": False, "reason": "CANONICAL_BORDER_NOT_VISIBLE", "validation": v, "grid": grid}
        # Keep the public threshold explicit in diagnostics even though validate_known_grid
        # currently applies the same 1.8/1.8 safety floor.
        if float(v.get("x_border_ratio") or 0) < SOURCE_CANONICAL_MIN_X_BORDER or float(v.get("y_border_ratio") or 0) < SOURCE_CANONICAL_MIN_Y_BORDER:
            return {"ok": False, "reason": "CANONICAL_BORDER_TOO_WEAK", "validation": v, "grid": grid}
        grid["known_grid_validation"] = v
        grid["confidence"] = max(0.84, min(0.96, 0.72 + 0.04 * min(float(v.get("x_border_ratio") or 0), float(v.get("y_border_ratio") or 0))))
        return {"ok": True, "grid": grid, "validation": v}
    except Exception as e:
        return {"ok": False, "reason": "CANONICAL_PROBE_EXCEPTION", "error": str(e)}


def _auto_resume_log(event, payload=None):
    try:
        row={
            'ts_epoch':time.time(),
            'ts_monotonic':time.monotonic(),
            'event':str(event or 'AUTO_RESUME_EVENT'),
        }
        if isinstance(payload,dict):
            row.update(_public_json_safe(payload) if '_public_json_safe' in globals() else payload)
        with LOG_LIFECYCLE.locked_writer():
            with AUTO_RESUME_LOG_PATH.open('a',encoding='utf-8') as f:
                f.write(json.dumps(row,ensure_ascii=False,default=str)+'\n')
    except Exception:
        pass


def _runtime_lifecycle_log(payload=None):
    """Best-effort canonical runtime lifecycle transition log."""
    try:
        row={'timestamp':time.time()}
        if isinstance(payload,dict):
            row.update(_public_json_safe(payload) if '_public_json_safe' in globals() else payload)
        with LOG_LIFECYCLE.locked_writer():
            with RUNTIME_LIFECYCLE_LOG_PATH.open('a',encoding='utf-8') as f:
                f.write(json.dumps(row,ensure_ascii=False,default=str)+'\n')
    except Exception:
        pass


def _shop_diag_write(event, payload=None, hwnd=None):
    """Always-on Shop diagnostics. Best-effort and never blocks automation."""
    try:
        rec = {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'event': str(event),
            'hwnd': int(hwnd or 0),
            'payload': payload if isinstance(payload, dict) else {'value': payload},
        }
        line = json.dumps(rec, ensure_ascii=False, default=str)
        with LOG_LIFECYCLE.locked_writer():
            with SHOP_RUNTIME_LOG_PATH.open('a', encoding='utf-8') as f:
                f.write(line + '\n')
            SHOP_LATEST_DIAG_PATH.write_text(
                json.dumps(rec, ensure_ascii=False, indent=2, default=str), encoding='utf-8'
            )
        return rec
    except Exception:
        return None


def _shop_diag_capture(hwnd):
    """Save the latest client frame whenever the user ARM/TESTs Shop Guard."""
    try:
        img = capture_client(int(hwnd))
        if img is None:
            return {'ok': False, 'reason': 'CAPTURE_NONE'}
        img.save(SHOP_LATEST_SCREEN_PATH)
        return {'ok': True, 'size': [img.width, img.height], 'file': SHOP_LATEST_SCREEN_PATH.name}
    except Exception as e:
        return {'ok': False, 'reason': 'CAPTURE_EXCEPTION', 'error': str(e)}


def _all_filter_options(scope_value='GLOBAL'):
    # V1.7.5 two-stage + slot filter: UI candidate space is selected BEFORE OCR.
    # The canonical 34-option vocabulary remains available for audit/exclusion,
    # but the user can only configure options in the active closed registry.
    return profile_options(scope_value)


def _profile_rule_validation(cfg):
    c=migrate_filter_config(cfg or {})
    scope_value=c.get('scope_value','GLOBAL')
    allowed=set(profile_options(scope_value))
    invalid=[]
    for prof in filter_enabled_profiles(c):
        for rule in prof.get('rules') or []:
            name=str(rule.get('option_name') or '').strip()
            if name and name not in allowed:
                invalid.append({'profile_id':prof.get('profile_id'),'option_name':name})
    return {
        'ok':not invalid,'scope_value':scope_value,'profile_key':profile_key_for_scope(scope_value),
        'allowed_options':list(profile_options(scope_value)),'allowed_option_ids':list(profile_option_ids(scope_value)),
        'invalid_rules':invalid,'registry_version':PROFILE_REGISTRY_VERSION,
    }


def _default_option_filter():
    return migrate_filter_config({
        "name": "Auto Pro By Eric - Multi Filter Profiles",
        "scope": "GLOBAL", "scope_value": "GLOBAL",
        "group_id": None, "family": None, "rules": []
    })


def _load_option_filter():
    for path in (USER_FILTER_PATH, FILTER_PATH):
        if not path.exists():
            continue
        try:
            raw=_safe_load_json(path)
            if not isinstance(raw,dict):
                continue
            cfg=migrate_filter_config(raw)
            # V1.7.5 migration: Áo/Bao tay are now explicit slot scopes because
            # each has a user-taught slot-only option. Legacy Nón/Đai/Giày/Nhẫn
            # selectors still collapse into the broad Đồ Chung Base-10 scope.
            if str(cfg.get('scope_value') or '').lower() in ('giay','non','dailung','dai','nhan'):
                cfg['scope']='PROFILE'; cfg['scope_value']='common'; cfg['group_id']=None; cfg['family']='ĐỒ CHUNG'
            # Persist only the user config migration; sample fallback remains read-only.
            if path == USER_FILTER_PATH and raw != cfg:
                _safe_save_json(USER_FILTER_PATH, cfg)
            return cfg
        except Exception:
            pass
    return _default_option_filter()


def _filter_has_enabled_rules(cfg):
    return bool(filter_enabled_profiles(migrate_filter_config(cfg or {})))


def _search_filter_applies(cfg, group_pick):
    scope = str((cfg or {}).get("scope", "GLOBAL")).upper()

    if scope == "GLOBAL":
        return True

    if scope == "GROUP":
        return (
            bool(group_pick)
            and not bool(group_pick.get("ambiguous"))
            and cfg.get("group_id") == group_pick.get("group_id")
        )

    if scope == "FAMILY":
        return (
            bool(group_pick)
            and bool(group_pick.get("identity_known"))
            and cfg.get("family") == group_pick.get("family")
        )

    if scope == "PROFILE" and str((cfg or {}).get('scope_value') or '').lower() == 'common':
        # Existing group classifier calls generic armor/ring/glove/belt rows
        # CHUNG when no exclusive hard anchor exists.  Explicit weapon/jewelry
        # hard anchors still veto this profile.
        if not group_pick or str(group_pick.get('family') or '').upper() == 'CONFLICT':
            return False
        gid=str(group_pick.get('group_id') or '').lower()
        fam=str(group_pick.get('family') or '').upper()
        return gid in {'non','ao','baotay','dailung','giay','nhan'} or fam in {'CHUNG','GIÀY','ÁO'}

    return False


def _wanted_rule_ok(rule, hit):
    """Evaluate one already-recognized canonical option hit."""
    if hit is None:
        return False
    op = str(rule.get("op", "EXISTS")).upper()
    if op == "EXISTS":
        return True
    if hit.get("value") is None:
        return False
    try:
        value = float(hit.get("value"))
        target = float(rule.get("value", 0))
    except Exception:
        return False
    return {
        ">=": value >= target,
        "<=": value <= target,
        ">": value > target,
        "<": value < target,
        "==": value == target,
    }.get(op, False)


def _wanted_norm_text(text):
    """Loose OCR normalization used only for direct wanted-option matching."""
    s = str(text or "").lower()
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    s = s.replace("đ", "d")
    s = s.replace("–", " ").replace("—", " ").replace("-", " ")
    # Remove values/ranges/units: wanted-name matching must compare the text name.
    # v7.2 root fix: strip numeric-like OCR TOKENS only. The old pattern also
    # deleted letters s/o/i/l/b inside normal words (e.g. "sinh luc"), which
    # damaged fuzzy matching and generated false review evidence.
    s = re.sub(r"(?<![a-z])[+\-]?\s*[0-9soIlB]{1,5}\s*%?(?![a-z])", " ", s, flags=re.I)
    for junk in ("diem", "didm", "dvem", "dem", "cap"):
        s = s.replace(junk, " ")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


# Stage 29.3 / v10.1 — semantic qualifier veto.
# NỘI CÔNG and NGOẠI CÔNG are mutually exclusive meaning, not fuzzy suffixes.
_QUALIFIER_CONG_TOKENS = r"(?:cong|ceng|cdng|cing|cang|c0ng)"
_QUALIFIER_NOI_TOKENS = r"(?:noi|nei|n0i|ni)"
_QUALIFIER_NGOAI_TOKENS = r"(?:ngoai|ng0ai|ngo4|ngoa1|ngoal|ngoair|ngogi|ngos|nzoai)"

def _expected_semantic_qualifier(option_name):
    n=_wanted_norm_text(option_name)
    if re.search(r"\bngoai\s+cong\b", n):
        return 'NGOAI'
    if re.search(r"\bnoi\s+cong\b", n):
        return 'NOI'
    return None

def _observed_semantic_qualifier(raw):
    n=_wanted_norm_text(raw)
    if not n:
        return None
    # v10.5.2 Row-ROI: qualifier word itself is authoritative when its
    # high-specificity token survives but the trailing 'công' glyph is clipped
    # or corrupted by the tight NAME ROI.  Keep the short OCR fallback 'ni'
    # coupled to a recognized công token so it cannot become a broad match.
    noi_pair=bool(re.search(rf"\b{_QUALIFIER_NOI_TOKENS}\s+{_QUALIFIER_CONG_TOKENS}\b", n))
    ngoai_pair=bool(re.search(rf"\b{_QUALIFIER_NGOAI_TOKENS}\s+{_QUALIFIER_CONG_TOKENS}\b", n))
    noi_word=bool(re.search(r"\b(?:noi|nei|n0i)\b", n))
    ngoai_word=bool(re.search(rf"\b{_QUALIFIER_NGOAI_TOKENS}\b", n))
    noi=noi_pair or noi_word
    ngoai=ngoai_pair or ngoai_word
    if noi and ngoai:
        return 'CONFLICT'
    if noi:
        return 'NOI'
    if ngoai:
        return 'NGOAI'
    return None

def _semantic_qualifier_check(raw, option_name):
    expected=_expected_semantic_qualifier(option_name)
    if expected is None:
        return {'required':False,'expected':None,'observed':None,'status':'NOT_APPLICABLE','compatible':True}
    observed=_observed_semantic_qualifier(raw)
    if observed == expected:
        status='MATCH'
        compatible=True
    elif observed in ('NOI','NGOAI','CONFLICT'):
        status='SEMANTIC_CONTRADICTION'
        compatible=False
    else:
        status='QUALIFIER_UNKNOWN'
        compatible=False
    return {'required':True,'expected':expected,'observed':observed,'status':status,'compatible':compatible}




# v10.5 — semantic option-family authority ---------------------------------
def _semantic_norm_text(text):
    """Accent-insensitive text normalization that PRESERVES family tokens.

    Unlike `_wanted_norm_text`, this must not treat OCR-like alphabetic tokens
    such as ``loi`` as numbers.  Only true decimal value/range tokens are
    removed; alphanumeric family variants such as ``1oi`` remain visible.
    """
    s=str(text or '').lower()
    s=unicodedata.normalize('NFD',s)
    s=''.join(ch for ch in s if unicodedata.category(ch)!='Mn')
    s=s.replace('đ','d').replace('–',' ').replace('—',' ').replace('−',' ').replace('-',' ')
    s=re.sub(r'(?<![a-z0-9])[+]?\s*\d{1,5}\s*%?(?![a-z0-9])',' ',s,flags=re.I)
    for junk in ('diem','didm','dvem','dem','cap'):
        s=re.sub(rf'\b{junk}\b',' ',s)
    s=re.sub(r'[^a-z0-9]+',' ',s)
    return re.sub(r'\s+',' ',s).strip()


# Whole-line fuzzy similarity is diagnostic only until this structural identity
# gate passes.  Family-defining tokens carry authority; generic suffixes such as
# "sát", "nội công" and "ngoại công" never establish a family by themselves.

def _has_all_tokens(n, patterns):
    return all(re.search(p, n) for p in patterns)


def _edit_distance_at_most_one(a, b):
    """Deterministic token distance <=1; deliberately not phrase fuzzy."""
    a=str(a or ''); b=str(b or '')
    if a==b: return True
    if abs(len(a)-len(b))>1: return False
    if len(a)>len(b): a,b=b,a
    if len(a)==len(b):
        return sum(x!=y for x,y in zip(a,b))<=1
    i=j=errors=0
    while i<len(a) and j<len(b):
        if a[i]==b[j]: i+=1; j+=1; continue
        errors+=1; j+=1
        if errors>1: return False
    return True

def _near_specific_token(n, target):
    toks=str(n or '').split(); target=str(target or '')
    for tok in toks:
        if tok==target: return True
        if len(target)<=2: continue
        if _edit_distance_at_most_one(tok,target): return True
        if len(tok)>len(target) and _edit_distance_at_most_one(tok[:len(target)],target): return True
    return False

def _skill_family_micro_vote(n):
    """High-specificity skill-family vote resilient to one dropped glyph/token."""
    toks=str(n or '').split()
    return (
        _near_specific_token(n,'nang') and
        any(tok=='vo' for tok in toks) and
        _near_specific_token(n,'cong') and
        _near_specific_token(n,'von')
    )


def _observed_option_family(raw):
    """Classify a raw OCR row by discriminative semantic family tokens.

    Returns UNKNOWN instead of guessing from generic shared suffixes.  The
    patterns intentionally mirror known JX1 OCR variants but remain conservative
    enough that PHYSICAL_DAMAGE cannot become LIGHTNING_DAMAGE merely because
    both end in "... nội công".
    """
    n=_semantic_norm_text(raw)
    if not n:
        return {'family':'UNKNOWN','confidence':0.0,'source':'NO_TEXT'}

    # Multi-token families first; order prevents shared words from stealing a
    # more specific identity (e.g. DAMAGE_TO_MANA contains "sát thương").
    # V1.7.8: skill text commonly loses one glyph per high-specificity token in
    # Paddle/Tesseract. Use a four-token micro-vote instead of accumulating
    # literal typo aliases; this remains family evidence, never numeric truth.
    if _skill_family_micro_vote(n):
        return {'family':'SKILL_LEVEL','confidence':0.98,'source':'RAW_SKILL_FAMILY_NEAR_TOKENS'}
    rules=[
        ('DAMAGE_TO_MANA', 0.99, [r'\b(?:chuyen|chuyenh|chuyenhoa)\b', r'\b(?:hoa|h0a)\b', r'\bsat\b', r'\b(?:thuong|thisng|thueng)\b', r'\b(?:thanh|thanhh)\b', r'\b(?:noi|nei)\b', r'\b(?:luc|lue)\b']),
        ('PHYSICAL_DAMAGE',0.99,[r'\b(?:sat|saf)\b',r'\b(?:thuong|thisng|thueng)\b',r'\b(?:vat|v4t)\b',r'\b(?:ly|1y|ty)\b']),
        ('PHYSICAL_DEFENSE',0.99,[r'\b(?:phong|pheng)\b',r'\b(?:thu|thv)\b',r'\b(?:vat|v4t)\b',r'\b(?:ly|1y|ty)\b']),
        ('ATTACK_SPEED',0.98,[r'\b(?:toc|tac|taec|tec|tic|tee|tect)\b',r'\b(?:danh|damh|dank|danhy|dgndanhy)\b']),
        ('SKILL_ATTACK_BONUS',0.99,[r'\b(?:tang|tane)\b',r'\b(?:cong|ceng|cdng|cing|cang|c0ng)\b',r'\b(?:kich|kieh|k1ch)\b',r'\b(?:ky|ey|ke)\b',r'\b(?:nang|mang)\b']),
        ('MAX_RESIST_CAP',0.99,[r'\b(?:muc|mue)\b',r'\b(?:khang|kang)\b',r'\b(?:tinh|t1nh)\b',r'\b(?:toi|tei|tai)\b',r'\b(?:da|d4)\b']),
        ('RESOURCE_MAX',0.99,[r'\b(?:sinh|s1nh)\b',r'\b(?:luc|lue|lve)\b',r'\b(?:toi|tei|tai)\b',r'\b(?:da|d4)\b']),
        ('MOVE_SPEED',0.98,[r'\b(?:toc|tac|tec)\b',r'\bdo\b',r'\bdi\b',r'\b(?:chuyen|chuyenh)\b']),
        ('RECOVERY_TIME',0.98,[r'\b(?:thoi|thei)\b',r'\b(?:gian|cian)\b',r'\b(?:phuc|phue)\b',r'\b(?:hoi|hei)\b']),
        ('ALL_RESIST',0.98,[r'\b(?:khang|kang)\b',r'\b(?:tat|t4t)\b',r'\bca\b']),
        ('IGNORE_DODGE',0.98,[r'\bbo\b',r'\bqua\b',r'\b(?:ne|nep)\b',r'\b(?:tranh|trank)\b']),
        ('POISON_DURATION',0.98,[r'\b(?:thoi|thei)\b',r'\b(?:gian|cian)\b',r'\b(?:trung|trvng)\b',r'\b(?:doc|d0c|pec)\b']),
        ('SLOW_DURATION',0.98,[r'\b(?:thoi|thei)\b',r'\b(?:gian|cian)\b',r'\b(?:lam|l4m)\b',r'\b(?:cham|ch4m)\b']),
        ('STUN_DURATION',0.98,[r'\b(?:thoi|thei)\b',r'\b(?:gian|cian)\b',r'\b(?:choang|cho4ng)\b']),
    ]
    for fam,conf,pats in rules:
        if _has_all_tokens(n,pats):
            return {'family':fam,'confidence':conf,'source':'RAW_FAMILY_TOKENS'}

    # Resistance families require KHÁNG, so they cannot collide with elemental
    # damage families that require SÁT.
    if re.search(r'\b(?:khang|kang)\b',n):
        elemental_res=[
            ('FIRE_RESIST',r'\b(?:hoa|h0a|hqa)\b'),
            ('ICE_RESIST',r'\b(?:bang|b4ng|beng)\b'),
            ('LIGHTNING_RESIST',r'\b(?:loi|lei|l0i|l6i|1oi|116i|l1)\b'),
            ('POISON_RESIST',r'\b(?:doc|d0c|pec)\b'),
        ]
        for fam,pat in elemental_res:
            if re.search(pat,n):
                return {'family':fam,'confidence':0.97,'source':'RAW_RESIST_FAMILY_TOKEN'}

    # Elemental damage requires BOTH the element discriminator and "sát".
    if re.search(r'\bsat\b',n):
        elemental=[
            ('FIRE_DAMAGE',r'\b(?:hoa|h0a|hqa)\b'),
            ('ICE_DAMAGE',r'\b(?:bang|b4ng|beng)\b'),
            ('LIGHTNING_DAMAGE',r'\b(?:loi|lei|l0i|l6i|1oi|116i|l1)\b'),
            ('POISON_DAMAGE',r'\b(?:doc|d0c|pec|hee)\b'),
        ]
        found=[]
        for fam,pat in elemental:
            if re.search(pat,n):
                found.append(fam)
        if len(found)==1:
            return {'family':found[0],'confidence':0.97,'source':'RAW_ELEMENT_FAMILY_TOKEN'}
        if len(found)>1:
            return {'family':'CONFLICT','confidence':1.0,'source':'MULTIPLE_ELEMENT_FAMILY_TOKENS'}

    return {'family':'UNKNOWN','confidence':0.0,'source':'NO_DISCRIMINATIVE_FAMILY_TOKEN'}


def _observed_unit_type(raw):
    """Explicit unit evidence from one physical option row."""
    text=str(raw or '')
    n=_wanted_norm_text(text)
    if '%' in text or re.search(r'\bphan\s*tram\b',n):
        return 'PERCENT'
    if re.search(r'\b(?:diem|didm|dvem|dem)\b',n):
        return 'POINT'
    if re.search(r'\bcap\b',n):
        return 'LEVEL'
    return 'UNKNOWN'


def _unit_contract_check(raw, option_name):
    expected=option_unit_type(option_name) or (option_semantics(option_name) or {}).get('unit_type')
    observed=_observed_unit_type(raw)
    if expected is None:
        return {'expected_unit':None,'observed_unit':observed,'unit_status':'NOT_APPLICABLE','unit_compatible':True}
    if expected=='NONE':
        compatible=(observed=='UNKNOWN')
        status='UNIT_MATCH_NONE' if compatible else 'UNIT_MISMATCH'
    elif observed=='UNKNOWN':
        # Missing glyph is not a contradiction. The authoritative parser is still
        # routed by expected unit; explicit contradictory units are rejected.
        compatible=True; status='EXPECTED_UNIT_CONTEXT'
    else:
        compatible=(observed==expected); status='UNIT_MATCH' if compatible else 'UNIT_MISMATCH'
    return {'expected_unit':expected,'observed_unit':observed,'unit_status':status,'unit_compatible':bool(compatible)}


def _semantic_identity_check(raw, option_name):
    expected=option_semantics(option_name)
    expected_family=expected.get('option_family')
    expected_qualifier=expected.get('qualifier')
    expected_unit=expected.get('unit_type')
    unit_check=_unit_contract_check(raw,option_name)
    observed=_observed_option_family(raw)
    observed_family=observed.get('family')

    if expected_family is None:
        family_status='NOT_APPLICABLE'; family_compatible=True
    elif observed_family==expected_family:
        family_status='FAMILY_MATCH'; family_compatible=True
    elif observed_family in (None,'UNKNOWN'):
        family_status='FAMILY_UNKNOWN'; family_compatible=False
    else:
        family_status='SEMANTIC_FAMILY_CONTRADICTION'; family_compatible=False

    qcheck=_semantic_qualifier_check(raw, option_name)
    qualifier_compatible=bool(qcheck.get('compatible'))
    unit_compatible=bool(unit_check.get('unit_compatible'))
    identity_compatible=bool(family_compatible and qualifier_compatible and unit_compatible)
    if family_status=='SEMANTIC_FAMILY_CONTRADICTION':
        reason='SEMANTIC_FAMILY_CONTRADICTION'
    elif family_status=='FAMILY_UNKNOWN':
        reason='FAMILY_UNKNOWN'
    elif not qualifier_compatible:
        reason=('SEMANTIC_QUALIFIER_CONTRADICTION' if qcheck.get('status')=='SEMANTIC_CONTRADICTION' else 'QUALIFIER_UNKNOWN')
    elif not unit_compatible:
        reason='UNIT_MISMATCH'
    else:
        reason='FAMILY_MATCH' if expected_family else 'IDENTITY_MATCH'
    return {
        'canonical_option_id':expected.get('canonical_option_id'),
        'expected_family':expected_family,
        'observed_family':observed_family,
        'option_family':observed_family,
        'family_confidence':float(observed.get('confidence') or 0.0),
        'family_source':observed.get('source'),
        'family_status':family_status,
        'family_compatible':family_compatible,
        'expected_qualifier':expected_qualifier,
        'observed_qualifier':qcheck.get('observed'),
        'qualifier_status':qcheck.get('status'),
        'qualifier_compatible':qualifier_compatible,
        'expected_unit':expected_unit,
        'observed_unit':unit_check.get('observed_unit'),
        'unit_status':unit_check.get('unit_status'),
        'unit_compatible':unit_compatible,
        'identity_compatible':identity_compatible,
        'identity_reason':reason,
    }


def _wanted_lexical_score(raw, option_name):
    """Legacy fuzzy score retained as diagnostic/candidate ranking only."""
    qcheck=_semantic_qualifier_check(raw, option_name)
    # A hard NỘI/NGOẠI contradiction may not rank as the intended option. An
    # unknown qualifier can still rank for a bounded targeted reread.
    if qcheck.get('status')=='SEMANTIC_CONTRADICTION':
        return 0.0
    a=_wanted_norm_text(raw); b=_wanted_norm_text(option_name)
    if not a or not b:
        return 0.0
    seq=difflib.SequenceMatcher(None,a,b).ratio()
    ac,bc=a.replace(' ',''),b.replace(' ','')
    partial=0.0
    if ac and bc:
        if len(ac)<=len(bc):
            partial=difflib.SequenceMatcher(None,ac,bc).ratio()
        else:
            span=len(bc)
            for i in range(max(1,len(ac)-span+1)):
                partial=max(partial,difflib.SequenceMatcher(None,ac[i:i+span],bc).ratio())
    at=set(a.split()); bt=set(b.split())
    token_recall=len(at & bt)/max(1,len(bt))
    return max(seq,0.88*partial+0.12*token_recall,0.72*seq+0.28*token_recall)


def _v110_skill_lexical_signature(raw):
    """High-specificity fallback for the JX1 skill-level row.

    Bitmap OCR often renders "Kỹ" as K¥ and "Võ" as V6, which defeats the
    semantic token recognizer even though the phrase remains visually unique.
    This fallback never supplies a numeric value; it can establish only row
    identity, after which the specialized LEVEL reader must prove {1,2,3}.
    """
    n=_semantic_norm_text(raw)
    if not n:
        return False
    has_nang=bool(re.search(r'\b(?:nang|ning|mang)\b',n))
    has_cong=bool(re.search(r'\b(?:cong|ceng|cdng|cing|cang|c0ng)\b',n))
    has_von=bool(re.search(r'\b(?:von|vin|v0n)\b',n))
    # "ky"/"vo" are frequently corrupted, so require the three discriminative
    # tokens above plus a good whole-phrase lexical score instead.
    score=_wanted_lexical_score(raw,'Kỹ năng Võ công vốn có')
    return bool(has_nang and has_cong and has_von and score>=0.68)


def _v110_classify_row_identity(raw):
    """Classify ONE physical row against the full 34-option registry.

    This is used only to establish whether absence can be authoritative.  The
    classifier is deliberately conservative: ambiguity returns UNKNOWN instead
    of inventing an option.  Numeric values are never part of identity.
    """
    raw=str(raw or '')
    ranked=[]
    for entry in OPTION_REGISTRY:
        name=str(entry.get('display_name') or '')
        if not name:
            continue
        score=float(_wanted_lexical_score(raw,name))
        sem=_semantic_identity_check(raw,name)
        special_skill=(name=='Kỹ năng Võ công vốn có' and _v110_skill_lexical_signature(raw))
        semantic_ok=bool(sem.get('identity_compatible') or special_skill)
        # Long option names tolerate slightly more bitmap corruption.  Short
        # names require a higher score to avoid cross-option aliasing.
        token_count=max(1,len(_wanted_norm_text(name).split()))
        threshold=0.72 if token_count>=4 else 0.76
        if special_skill:
            threshold=0.68
        authoritative=bool(semantic_ok and score>=threshold)
        ranked.append({
            'canonical_option_id':entry.get('id'),
            'canonical_option_name':name,
            'category':entry.get('category'),
            'score':round(score,4),
            'threshold':threshold,
            'authoritative':authoritative,
            'semantic_identity':sem,
            'special_skill_signature':special_skill,
        })
    ranked.sort(key=lambda x:(1 if x['authoritative'] else 0,x['score']),reverse=True)
    if not ranked:
        return {'status':'UNKNOWN_IDENTITY','authoritative':False,'raw':raw,'candidates':[]}
    top=ranked[0]; second=ranked[1] if len(ranked)>1 else None
    # Two simultaneously-authoritative close candidates are an identity
    # conflict, never absence evidence.
    if top['authoritative'] and second and second['authoritative'] and (top['score']-second['score'])<0.035:
        return {
            'status':'UNKNOWN_IDENTITY','authoritative':False,'reason':'ROW_IDENTITY_AMBIGUOUS',
            'raw':raw,'candidates':ranked[:4],
        }
    if top['authoritative']:
        return {
            'status':'AUTHORITATIVE_IDENTITY','authoritative':True,'raw':raw,
            'canonical_option_id':top['canonical_option_id'],
            'canonical_option_name':top['canonical_option_name'],
            'category':top['category'],'score':top['score'],'threshold':top['threshold'],
            'semantic_identity':top['semantic_identity'],
            'source':('SKILL_LEXICAL_SIGNATURE' if top.get('special_skill_signature') else 'FOREGROUND_ROW_IDENTITY'),
            'candidates':ranked[:4],
        }
    return {
        'status':'UNKNOWN_IDENTITY','authoritative':False,'reason':'NO_AUTHORITATIVE_ROW_IDENTITY',
        'raw':raw,'best_score':top['score'],'best_candidate':top['canonical_option_name'],
        'candidates':ranked[:4],
    }


def _v110_classify_all_rows(raw_lines):
    rows=[_v110_classify_row_identity(x) for x in (raw_lines or [])]
    all_authoritative=(len(rows)==6 and all(bool(x.get('authoritative')) for x in rows))
    return {
        'rows':rows,
        'row_count':len(rows),
        'all_six_identity_authoritative':bool(all_authoritative),
        'authoritative_option_names':[x.get('canonical_option_name') for x in rows if x.get('authoritative')],
        'unknown_row_indices':[i for i,x in enumerate(rows) if not x.get('authoritative')],
    }


def _v110_absence_authority(scan, wanted_name):
    """Return ABSENT_CONFIRMED only from six authoritative row identities."""
    ids=(scan or {}).get('row_identity_set') or {}
    if not ids.get('all_six_identity_authoritative'):
        return {'state':'UNKNOWN_IDENTITY','authoritative':False,
                'unknown_row_indices':ids.get('unknown_row_indices') or []}
    names=list(ids.get('authoritative_option_names') or [])
    if str(wanted_name) in names:
        return {'state':'PRESENT_CONFIRMED','authoritative':True,'present':True}
    return {'state':'ABSENT_CONFIRMED','authoritative':True,'present':False,
            'observed_option_names':names}


# V11.2 closed-world target-exclusion authority -----------------------------
def _v111_coarse_row_domain(raw):
    """Return a conservative semantic domain even when exact OCR identity is noisy.

    This is used only to EXCLUDE incompatible wanted options.  It never promotes
    a row to the wanted option and never supplies numeric authority.
    """
    n=_semantic_norm_text(raw)
    if not n:
        return {'domain':'UNKNOWN','confidence':0.0,'source':'NO_TEXT'}
    fam=_observed_option_family(raw)
    if fam.get('family') not in (None,'UNKNOWN','CONFLICT'):
        return {'domain':fam.get('family'),'confidence':float(fam.get('confidence') or 0.0),'source':fam.get('source') or 'FAMILY'}
    # Known-ignore/resource rows are still useful negative evidence against all
    # filterable families.  Exact canonical identity is not required.
    if re.search(r'\b(?:sinh|noi|the|hei|h[eé]i)\b',n) and re.search(r'\b(?:luc|lue)\b',n) and re.search(r'\b(?:toi|tei|t0i)\s+(?:da|d4)\b',n):
        return {'domain':'MAX_RESOURCE','confidence':0.92,'source':'COARSE_RESOURCE_TOKENS'}
    if re.search(r'\b(?:chinh|chinhx|chinhxac|xac)\b',n) and re.search(r'\b(?:danh|don|can|chien)\b',n):
        return {'domain':'KNOWN_IGNORE_ACCURACY','confidence':0.90,'source':'COARSE_ACCURACY_TOKENS'}
    if re.search(r'\b(?:khang|kang)\b',n):
        return {'domain':'RESISTANCE_DOMAIN','confidence':0.90,'source':'COARSE_KHANG_TOKEN'}
    if re.search(r'\b(?:sat|saf|rang)\b',n):
        return {'domain':'DAMAGE_DOMAIN','confidence':0.88,'source':'COARSE_SAT_TOKEN'}
    if re.search(r'\b(?:thoi|tho1|thei)\b',n) and re.search(r'\b(?:gian|cian)\b',n):
        return {'domain':'TIME_STATUS_DOMAIN','confidence':0.88,'source':'COARSE_TIME_TOKENS'}
    if re.search(r'\b(?:phuc|phue)\s+(?:hoi|hei)\b',n):
        return {'domain':'RECOVERY_DOMAIN','confidence':0.86,'source':'COARSE_RECOVERY_TOKENS'}
    if _v110_skill_lexical_signature(raw):
        return {'domain':'SKILL_LEVEL','confidence':0.98,'source':'SKILL_SIGNATURE'}
    return {'domain':'UNKNOWN','confidence':0.0,'source':'NO_CLOSED_WORLD_DOMAIN'}


def _v111_domain_compatible(domain, expected_family):
    domain=str(domain or 'UNKNOWN'); expected=str(expected_family or '')
    if domain=='UNKNOWN':
        return None
    if domain==expected:
        return True
    if domain in {'MAX_RESOURCE','KNOWN_IGNORE_ACCURACY','RECOVERY_DOMAIN'}:
        return False
    if domain=='RESISTANCE_DOMAIN':
        return expected in {'ALL_RESIST','FIRE_RESIST','ICE_RESIST','LIGHTNING_RESIST','POISON_RESIST'}
    if domain=='DAMAGE_DOMAIN':
        return expected in {'PHYSICAL_DAMAGE','FIRE_DAMAGE','ICE_DAMAGE','LIGHTNING_DAMAGE','POISON_DAMAGE','DAMAGE_TO_MANA'}
    if domain=='TIME_STATUS_DOMAIN':
        return expected in {'RECOVERY_TIME','POISON_DURATION','SLOW_DURATION','STUN_DURATION'}
    return False


def _v111_target_exclusion_certificate(raw, row_identity, wanted_name, row_index):
    """Prove TARGET_EXCLUDED without requiring perfect exact-name OCR."""
    wanted_name=str(wanted_name or '')
    meta=option_semantics(wanted_name) or {}
    expected_family=meta.get('option_family')
    rid=row_identity if isinstance(row_identity,dict) else {}
    # Exact canonical row identity is strongest closed-world evidence.
    if rid.get('authoritative'):
        observed=str(rid.get('canonical_option_name') or '')
        if observed==wanted_name:
            return {'row_index':row_index,'state':'TARGET_COMPATIBLE','reason':'AUTHORITATIVE_WANTED_CANONICAL','observed_option':observed,'authoritative':True}
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'AUTHORITATIVE_DIFFERENT_CANONICAL','observed_option':observed,'authoritative':True}
    sem=_semantic_identity_check(raw,wanted_name)
    if sem.get('family_status')=='SEMANTIC_FAMILY_CONTRADICTION':
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'SEMANTIC_FAMILY_CONTRADICTION','observed_family':sem.get('observed_family'),'expected_family':expected_family,'authoritative':True}
    if sem.get('qualifier_status')=='SEMANTIC_CONTRADICTION':
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'SEMANTIC_QUALIFIER_CONTRADICTION','observed_qualifier':sem.get('observed_qualifier'),'authoritative':True}
    if sem.get('unit_status')=='UNIT_MISMATCH':
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'UNIT_CONTRADICTION','observed_unit':sem.get('observed_unit'),'expected_unit':sem.get('expected_unit'),'authoritative':True}
    coarse=_v111_coarse_row_domain(raw)
    compatible=_v111_domain_compatible(coarse.get('domain'),expected_family)
    if compatible is False:
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'CLOSED_WORLD_DOMAIN_CONTRADICTION','observed_domain':coarse.get('domain'),'expected_family':expected_family,'domain_evidence':coarse,'authoritative':True}
    if compatible is True:
        return {'row_index':row_index,'state':'TARGET_COMPATIBLE','reason':'CLOSED_WORLD_DOMAIN_COMPATIBLE','observed_domain':coarse.get('domain'),'expected_family':expected_family,'domain_evidence':coarse,'authoritative':False}
    return {'row_index':row_index,'state':'UNKNOWN','reason':'ROW_TARGET_COMPATIBILITY_UNKNOWN','expected_family':expected_family,'domain_evidence':coarse,'authoritative':False}


def _v111_absence_authority(scan, wanted_name):
    """V11.2 ABSENT_CONFIRMED V2: all six rows independently exclude target."""
    scan=scan or {}
    raw_lines=list(scan.get('raw_lines') or [])
    rows=list(((scan.get('row_identity_set') or {}).get('rows') or []))
    if len(raw_lines)!=6:
        return {'state':'UNKNOWN_IDENTITY','authoritative':False,'reason':'FINAL6_ROW_COUNT_NOT_SIX','row_count':len(raw_lines),'target_exclusion_certificates':[]}
    certs=[]
    for i,raw in enumerate(raw_lines):
        rid=rows[i] if i<len(rows) else {}
        certs.append(_v111_target_exclusion_certificate(raw,rid,wanted_name,i+1))
    if any(c.get('state')=='TARGET_COMPATIBLE' and c.get('reason')=='AUTHORITATIVE_WANTED_CANONICAL' for c in certs):
        return {'state':'PRESENT_CONFIRMED','authoritative':True,'present':True,'target_exclusion_certificates':certs}
    if certs and all(c.get('state')=='TARGET_EXCLUDED' for c in certs):
        return {'state':'ABSENT_CONFIRMED','authoritative':True,'present':False,'method':'ALL_SIX_TARGET_EXCLUDED_V2','target_exclusion_certificates':certs}
    return {'state':'UNKNOWN_IDENTITY','authoritative':False,'present':None,'reason':'TARGET_EXCLUSION_INCOMPLETE','target_exclusion_certificates':certs,'compatible_or_unknown_rows':[c.get('row_index') for c in certs if c.get('state')!='TARGET_EXCLUDED']}



# V11.2 closed-world family/candidate truth ----------------------------------
def _v112_closed_world_row_classifier(raw, row_identity=None):
    """Classify one physical Final6 row inside the fixed 34-option registry.

    Exact canonical OCR is preferred but not required for negative authority.
    Candidate families are taken from the registry-ranked row candidates and
    reinforced by family-level lexical signatures. Fuzzy score never crosses
    an incompatible family boundary.
    """
    raw=str(raw or '')
    rid=row_identity if isinstance(row_identity,dict) else {}
    if rid.get('authoritative'):
        sem=rid.get('semantic_identity') or {}
        fam=sem.get('observed_family') or sem.get('expected_family')
        return {
            'authority':'AUTHORITATIVE_CANONICAL',
            'family':fam,
            'family_candidates':[fam] if fam else [],
            'canonical_candidates':[rid.get('canonical_option_name')],
            'source':'AUTHORITATIVE_ROW_IDENTITY',
        }

    ranked=[c for c in (rid.get('candidates') or []) if isinstance(c,dict)]
    best=max([float(c.get('score') or 0.0) for c in ranked] or [0.0])
    # Keep only plausible closed-world candidates near the best lexical score.
    # This is not authority to identify the exact option; it is enough to prove
    # that a target family is impossible when every plausible candidate belongs
    # elsewhere in the closed registry.
    plausible=[]
    for c in ranked:
        score=float(c.get('score') or 0.0)
        if score < max(0.44,best-0.20):
            continue
        sem=c.get('semantic_identity') or {}
        fam=sem.get('expected_family') or sem.get('observed_family')
        if fam:
            plausible.append({'option':c.get('canonical_option_name'),'family':fam,'score':score})
    fams=sorted({x['family'] for x in plausible if x.get('family')})

    n=_semantic_norm_text(raw)
    # Strong family signatures. They are used to narrow the closed-world family
    # set, never to manufacture a canonical option or numeric value.
    signature=None
    if _v110_skill_lexical_signature(raw):
        signature='SKILL_LEVEL'
    elif re.search(r'\b(?:toc|tec)\b',n) and re.search(r'\b(?:do|de)\b',n) and re.search(r'\b(?:danh|daenh|danhh)\b',n):
        signature='ATTACK_SPEED'
    elif re.search(r'\b(?:vat|vaf)\b',n) and re.search(r'\b(?:ly|1y)\b',n) and re.search(r'\b(?:thuong|thudng|thuongzg|thudngzg)\b',n):
        signature='PHYSICAL_DAMAGE'
    elif re.search(r'\b(?:chuyen|chuyen|chuy[eé]n)\b',n) and re.search(r'\b(?:hoa|h[eé]a)\b',n) and re.search(r'\b(?:sat|saf)\b',n) and re.search(r'\b(?:noi|nei)\b',n):
        signature='DAMAGE_TO_MANA'
    elif re.search(r'\b(?:khang|kang)\b',n):
        signature='RESISTANCE_DOMAIN'
    elif re.search(r'\b(?:phong|phongg)\b',n) and re.search(r'\b(?:thu|th[uủ])\b',n) and re.search(r'\b(?:vat|vaf)\b',n):
        signature='PHYSICAL_DEFENSE'
    elif re.search(r'\b(?:toc|tec)\b',n) and re.search(r'\b(?:di|dj)\b',n) and re.search(r'\b(?:chuyen|chuy[eé]n)\b',n):
        signature='MOVE_SPEED'
    elif re.search(r'\b(?:sinh|sink|noi|nei|the|hei|hei)\b',n) and re.search(r'\b(?:luc|lue)\b',n) and re.search(r'\b(?:toi|tei|t0i)\b',n):
        signature='MAX_RESOURCE'
    elif re.search(r'\b(?:thoi|tho1|thei)\b',n) and re.search(r'\b(?:gian|cian)\b',n):
        signature='TIME_STATUS_DOMAIN'
    elif re.search(r'\b(?:sat|saf)\b',n):
        signature='DAMAGE_DOMAIN'

    if signature:
        # A strong signature can collapse noisy registry candidate families to a
        # known domain. For broad domains retain all compatible concrete families.
        broad={
            'RESISTANCE_DOMAIN':{'ALL_RESIST','FIRE_RESIST','ICE_RESIST','LIGHTNING_RESIST','POISON_RESIST'},
            'DAMAGE_DOMAIN':{'PHYSICAL_DAMAGE','FIRE_DAMAGE','ICE_DAMAGE','LIGHTNING_DAMAGE','POISON_DAMAGE','DAMAGE_TO_MANA'},
            'TIME_STATUS_DOMAIN':{'RECOVERY_TIME','POISON_DURATION','SLOW_DURATION','STUN_DURATION'},
            'MAX_RESOURCE':{'MAX_RESOURCE'},
        }
        sfams=broad.get(signature,{signature})
        if fams:
            narrowed=sorted(set(fams).intersection(sfams))
            if narrowed:
                fams=narrowed
            else:
                fams=sorted(sfams)
        else:
            fams=sorted(sfams)
        return {
            'authority':'AUTHORITATIVE_FAMILY_ONLY',
            'family':signature,
            'family_candidates':fams,
            'canonical_candidates':[x['option'] for x in plausible[:4]],
            'source':'CLOSED_WORLD_FAMILY_SIGNATURE',
            'registry_candidates':plausible[:6],
        }

    if fams:
        return {
            'authority':'AMBIGUOUS_WITHIN_FAMILY' if len(fams)==1 else 'CLOSED_WORLD_CANDIDATE_SET',
            'family':fams[0] if len(fams)==1 else None,
            'family_candidates':fams,
            'canonical_candidates':[x['option'] for x in plausible[:4]],
            'source':'CLOSED_WORLD_REGISTRY_CANDIDATES',
            'registry_candidates':plausible[:6],
        }
    return {'authority':'UNKNOWN','family':None,'family_candidates':[],'canonical_candidates':[],'source':'NO_CLOSED_WORLD_FAMILY'}


def _v112_target_family_compatible(candidate_family, expected_family):
    if not candidate_family:
        return None
    # Broad semantic domains from family-only signatures.
    if candidate_family=='RESISTANCE_DOMAIN':
        return expected_family in {'ALL_RESIST','FIRE_RESIST','ICE_RESIST','LIGHTNING_RESIST','POISON_RESIST'}
    if candidate_family=='DAMAGE_DOMAIN':
        return expected_family in {'PHYSICAL_DAMAGE','FIRE_DAMAGE','ICE_DAMAGE','LIGHTNING_DAMAGE','POISON_DAMAGE','DAMAGE_TO_MANA'}
    if candidate_family=='TIME_STATUS_DOMAIN':
        return expected_family in {'RECOVERY_TIME','POISON_DURATION','SLOW_DURATION','STUN_DURATION'}
    if candidate_family=='MAX_RESOURCE':
        return expected_family=='MAX_RESOURCE'
    return str(candidate_family)==str(expected_family)


def _v111_target_exclusion_certificate(raw, row_identity, wanted_name, row_index):
    """V11.2 target certificate: family/candidate truth precedes fuzzy name."""
    wanted_name=str(wanted_name or '')
    meta=option_semantics(wanted_name) or {}
    expected_family=meta.get('option_family')
    rid=row_identity if isinstance(row_identity,dict) else {}
    if rid.get('authoritative'):
        observed=str(rid.get('canonical_option_name') or '')
        if observed==wanted_name:
            return {'row_index':row_index,'state':'TARGET_PRESENT','reason':'AUTHORITATIVE_WANTED_CANONICAL','observed_option':observed,'authoritative':True}
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'AUTHORITATIVE_DIFFERENT_CANONICAL','observed_option':observed,'authoritative':True}

    sem=_semantic_identity_check(raw,wanted_name)
    if sem.get('family_status')=='SEMANTIC_FAMILY_CONTRADICTION':
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'SEMANTIC_FAMILY_CONTRADICTION','observed_family':sem.get('observed_family'),'expected_family':expected_family,'authoritative':True}
    if sem.get('qualifier_status')=='SEMANTIC_CONTRADICTION':
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'SEMANTIC_QUALIFIER_CONTRADICTION','observed_qualifier':sem.get('observed_qualifier'),'authoritative':True}
    if sem.get('unit_status')=='UNIT_MISMATCH':
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'UNIT_CONTRADICTION','observed_unit':sem.get('observed_unit'),'expected_unit':sem.get('expected_unit'),'authoritative':True}

    cw=_v112_closed_world_row_classifier(raw,rid)
    fams=list(cw.get('family_candidates') or [])
    compat=[_v112_target_family_compatible(f,expected_family) for f in fams]
    if fams and not any(x is True for x in compat):
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'CLOSED_WORLD_CANDIDATE_FAMILIES_EXCLUDE_TARGET',
                'expected_family':expected_family,'closed_world':cw,'authoritative':True}
    if fams and any(x is True for x in compat):
        return {'row_index':row_index,'state':'TARGET_COMPATIBLE','reason':'CLOSED_WORLD_TARGET_FAMILY_POSSIBLE',
                'expected_family':expected_family,'closed_world':cw,'authoritative':False}

    coarse=_v111_coarse_row_domain(raw)
    compatible=_v111_domain_compatible(coarse.get('domain'),expected_family)
    if compatible is False:
        return {'row_index':row_index,'state':'TARGET_EXCLUDED','reason':'CLOSED_WORLD_DOMAIN_CONTRADICTION','observed_domain':coarse.get('domain'),'expected_family':expected_family,'domain_evidence':coarse,'closed_world':cw,'authoritative':True}
    if compatible is True:
        return {'row_index':row_index,'state':'TARGET_COMPATIBLE','reason':'CLOSED_WORLD_DOMAIN_COMPATIBLE','observed_domain':coarse.get('domain'),'expected_family':expected_family,'domain_evidence':coarse,'closed_world':cw,'authoritative':False}
    return {'row_index':row_index,'state':'ROW_UNKNOWN','reason':'ROW_TARGET_COMPATIBILITY_UNKNOWN','expected_family':expected_family,'domain_evidence':coarse,'closed_world':cw,'authoritative':False}


def _v111_absence_authority(scan, wanted_name):
    """V11.2 ABSENT_CONFIRMED: exactly six independent TARGET_EXCLUDED rows."""
    scan=scan or {}
    raw_lines=list(scan.get('raw_lines') or [])
    rows=list(((scan.get('row_identity_set') or {}).get('rows') or []))
    if len(raw_lines)!=6:
        return {'state':'UNKNOWN_IDENTITY','authoritative':False,'reason':'FINAL6_SEGMENTATION_UNKNOWN','row_count':len(raw_lines),'target_exclusion_certificates':[]}
    certs=[]
    for i,raw in enumerate(raw_lines):
        rid=rows[i] if i<len(rows) else {}
        certs.append(_v111_target_exclusion_certificate(raw,rid,wanted_name,i+1))
    if any(c.get('state') in ('TARGET_PRESENT','TARGET_COMPATIBLE') and c.get('reason')=='AUTHORITATIVE_WANTED_CANONICAL' for c in certs):
        return {'state':'PRESENT_CONFIRMED','authoritative':True,'present':True,'target_exclusion_certificates':certs}
    if certs and all(c.get('state')=='TARGET_EXCLUDED' for c in certs):
        return {'state':'ABSENT_CONFIRMED','authoritative':True,'present':False,'method':'ALL_SIX_TARGET_EXCLUDED_V11_2','target_exclusion_certificates':certs}
    return {'state':'UNKNOWN_IDENTITY','authoritative':False,'present':None,'reason':'TARGET_EXCLUSION_INCOMPLETE',
            'target_exclusion_certificates':certs,
            'compatible_or_unknown_rows':[c.get('row_index') for c in certs if c.get('state')!='TARGET_EXCLUDED']}


def _v112_precise_unresolved_reason(rule_results, scans):
    """Return one forensic unresolved class; never generic FILTER_UNRESOLVED."""
    rule_results=list(rule_results or [])
    scans=list(scans or [])
    if not scans or not any((x or {}).get('complete') for x in scans):
        return 'FINAL6_SEGMENTATION_UNKNOWN'
    for rr in rule_results:
        st=str((rr or {}).get('state') or '')
        if st in {'NUMERIC_CONFLICT'}:
            return 'FRAME_CONTRADICTION'
        if st in {'UNRESOLVED_NUMERIC','UNKNOWN_VALUE'}:
            return 'TARGET_VALUE_UNKNOWN'
        if st in {'UNRESOLVED_NEAR_NAME'}:
            return 'TARGET_OPTION_POSSIBLY_PRESENT'
        if st in {'UNKNOWN_IDENTITY'}:
            for a in (rr.get('absence_evidence') or []):
                for c in (a.get('target_exclusion_certificates') or []):
                    if c.get('state') in ('ROW_UNKNOWN','UNKNOWN'):
                        cw=c.get('closed_world') or {}
                        if not (cw.get('family_candidates') or []):
                            return 'FAMILY_UNKNOWN'
            return 'ROW_IDENTITY_UNKNOWN'
    return 'TARGET_OPTION_POSSIBLY_PRESENT'

# v7.2 IGNORE LOW-VALUE OPTIONS
# User-confirmed throwaway attributes. These rows are intentionally excluded
# from wanted-option evidence so they can never create KEEP/NEED_REVIEW noise.
_IGNORED_LOW_VALUE_OPTIONS = (
    "Sinh lực tối đa",
    "Thể lực tối đa",
    "Nội lực tối đa",
    "Phục hồi nội lực mỗi nửa giây",
    "Phục hồi sinh lực mỗi nửa giây",
    "Hồi phục sinh lực",
)
_IGNORED_LOW_VALUE_NORMS = {_wanted_norm_text(x): x for x in _IGNORED_LOW_VALUE_OPTIONS}

def _row_is_ignored_low_value(row):
    """Return True only for a strong/exact match to a user-declared trash option.

    Conservative by design: exact canonical name wins immediately; raw OCR is
    ignored only when it is almost the same phrase, preventing overlap with
    useful options such as Chuyển hóa sát thương thành nội lực.
    """
    canonical = str((row or {}).get("name") or "")
    if canonical in _IGNORED_LOW_VALUE_OPTIONS:
        return True

    texts = []
    for x in ((row or {}).get("all_name_ocr") or []):
        if x:
            texts.append(str(x))
    for key in ("raw_name_ocr", "raw_ocr"):
        x = (row or {}).get(key)
        if x:
            texts.append(str(x))

    for raw in texts:
        rn = _wanted_norm_text(raw)
        if not rn:
            continue
        rt = set(rn.split())
        for ign_norm in _IGNORED_LOW_VALUE_NORMS:
            it = set(ign_norm.split())
            if not it:
                continue
            recall = len(rt & it) / len(it)
            precision = len(rt & it) / max(1, len(rt))
            ratio = difflib.SequenceMatcher(None, rn, ign_norm).ratio()
            # Require near-exact phrase identity, not just shared words like
            # "noi luc" or "sinh luc".
            if ratio >= 0.84 and recall >= 0.80 and precision >= 0.72:
                return True
    return False


def _wanted_raw_score(raw, option_name):
    """Authoritative wanted-option score: fuzzy can rank only after semantics pass."""
    ident=_semantic_identity_check(raw, option_name)
    if not ident.get('identity_compatible'):
        return 0.0
    return _wanted_lexical_score(raw, option_name)


def _fast_primary_numeric_candidates(raw, option_name=None):
    """Extract the primary value from ONE strong wanted-option row.

    v10.2 shares the Stage16 VALUE_TOKEN parser so the fast path and general
    reader cannot disagree about ``+VALUE unit [range]`` semantics. In
    particular, ``+114% [100-250]`` cannot become ``1148`` when the printed
    range proves that the trailing OCR ``8`` is the percent glyph.
    """
    text = str(raw or '').replace('–','-').replace('—','-').replace('−','-')
    head = re.split(r'[\[\{£]', text, maxsplit=1)[0]
    head = head.replace('†','+').replace('‡','+').replace('#','+').replace('$','+').replace('¢','+')

    # 1) Shared signed VALUE_TOKEN parser. Range digits are metadata only.
    info=_primary_value_token(text)
    if info.get('value') is not None:
        return [int(info.get('value'))]

    # 2) JX1 '+' is sometimes OCR'd as t/T/f. Require a true token boundary
    # and ACTUAL decimal digits so letters inside Vietnamese words cannot vote.
    pseudo=[]
    for m in re.finditer(r'(?<!\w)[tTf]\s*(\d{1,4})(?!\d)', head, flags=re.UNICODE):
        pseudo.append(int(m.group(1)))
    if pseudo:
        return pseudo[-1:]

    # 3) Unsigned value with an intact unit.
    n=_wanted_norm_text(head)
    unit=[]
    for pat in (r'(\d{1,4})\s*%', r'(\d{1,4})\s*(?:cap|diem|didm|dvem|dem)\b'):
        for m in re.finditer(pat, head if '%' in pat else n, flags=re.I):
            unit.append(int(m.group(1)))
    if unit:
        return unit[-1:]

    # 4) Lost-sign/lost-unit rescue. Because the wanted NAME has already been
    # strongly matched and the printed range was removed, exactly one decimal
    # token in the primary area is safe. Do not infer time-reduction signs.
    if str(option_name or '').startswith('Thời gian '):
        return []
    bare=[int(x) for x in re.findall(r'(?<!\d)(\d{1,4})(?!\d)', head)]
    if len(bare)==1:
        return [bare[0]]
    return []


def _wanted_frame_evidence(frames, option_name):
    """Semantic-safe historical/heavy-reader evidence for one wanted option."""
    hits=[]
    target_norm=_wanted_norm_text(option_name)
    target_tokens=set(target_norm.split())
    target_len=len(target_tokens)
    raw_threshold=0.72 if target_len<=2 else 0.64
    expected_meta=option_semantics(option_name)
    is_attack_speed=(expected_meta.get('option_family')=='ATTACK_SPEED')

    for fi,frame in enumerate(frames or [],1):
        for row in frame.get('lines',[]) or []:
            target_is_low_value=option_name in _IGNORED_LOW_VALUE_OPTIONS
            if (not target_is_low_value) and _row_is_ignored_low_value(row):
                continue
            texts=[]
            for x in (row.get('all_name_ocr') or []):
                if x: texts.append(str(x))
            for key in ('raw_name_ocr','raw_value_ocr','raw_ocr'):
                x=row.get(key)
                if x: texts.append(str(x))
            candidates=[]
            for raw in texts:
                lexical=_wanted_lexical_score(raw,option_name)
                ident=_semantic_identity_check(raw,option_name)
                if ident.get('identity_compatible'): tier=3
                elif ident.get('family_status')=='FAMILY_UNKNOWN' or ident.get('qualifier_status')=='QUALIFIER_UNKNOWN': tier=2
                else: tier=1
                candidates.append((tier,float(lexical),raw,ident))
            if candidates:
                max_tier=max(x[0] for x in candidates)
                tier_pool=[x for x in candidates if x[0]==max_tier]
                _,best_raw,best_text,best_ident=max(tier_pool,key=lambda x:x[1])
            else:
                best_raw=0.0; best_text=''; best_ident=_semantic_identity_check('',option_name)

            canonical_exact=bool(row.get('name')==option_name and best_ident.get('identity_compatible'))
            best_norm=_wanted_norm_text(best_text)
            best_tokens=set(best_norm.split())
            token_recall=len(best_tokens & target_tokens)/max(1,len(target_tokens))
            raw_match=bool(best_ident.get('identity_compatible') and best_raw>=raw_threshold)
            if target_len<=2:
                raw_strong=bool(raw_match and best_raw>=0.82 and token_recall>=0.50)
            else:
                raw_strong=bool(raw_match and ((best_raw>=0.78) or (best_raw>=0.72 and token_recall>=0.50)))
            if not canonical_exact and not raw_match:
                continue

            speed_auth=row.get('attack_speed_percent_authority') or {}
            numeric_authoritative=(bool(speed_auth.get('authoritative')) if is_attack_speed else row.get('value') is not None)
            truth_pass=bool((row.get('truth_gate') or {}).get('pass')) and bool(best_ident.get('identity_compatible'))
            hit={
                'frame':fi,'line':row.get('line'),'name':row.get('name'),
                'value':row.get('value'),'unit':row.get('unit'),
                'name_confidence':float(row.get('name_confidence') or 0.0),
                'value_confidence':float(row.get('value_confidence') or 0.0),
                'truth_pass':truth_pass,'status':row.get('status'),
                'canonical_exact':canonical_exact,'raw_match':raw_match,'raw_strong':raw_strong,
                'raw_score':round(float(best_raw),3),'fuzzy_score':round(float(best_raw),3),
                'token_recall':round(float(token_recall),3),'raw_text':best_text,
                'semantic_identity':best_ident,
                'expected_family':best_ident.get('expected_family'),'observed_family':best_ident.get('observed_family'),
                'family_compatible':best_ident.get('family_compatible'),
                'expected_qualifier':best_ident.get('expected_qualifier'),'observed_qualifier':best_ident.get('observed_qualifier'),
                'expected_unit':best_ident.get('expected_unit'),
                'numeric_authoritative':numeric_authoritative,
                'attack_speed_percent_authority':speed_auth if is_attack_speed else None,
            }
            hits.append(hit)

    if not hits:
        return {'found':False,'safe_name':False,'hits':[],'raw_threshold':raw_threshold}

    truth_hits=[h for h in hits if h['truth_pass'] and h.get('family_compatible')]
    canonical_normal=[h for h in hits if h['canonical_exact'] and h['name_confidence']>=0.43 and h.get('family_compatible')]
    raw_candidates=[h for h in hits if h['raw_match'] and h.get('family_compatible')]
    strong_raw=[h for h in hits if h.get('raw_strong') and h.get('family_compatible')]
    raw_frames={h['frame'] for h in raw_candidates}
    strong_raw_frames={h['frame'] for h in strong_raw}
    safe_name=bool(truth_hits or canonical_normal or strong_raw)

    value_votes={}; truth_values=set(); strong_single_values=set()
    for h in hits:
        if not h.get('family_compatible') or not h.get('numeric_authoritative'):
            continue
        if h.get('value') is None:
            continue
        try: key=float(h['value'])
        except Exception: continue
        value_votes.setdefault(key,set()).add(h['frame'])
        if h['truth_pass']: truth_values.add(key)
        if (h['truth_pass'] or
            (h.get('raw_strong') and h['value_confidence']>=0.62) or
            (h['canonical_exact'] and h['name_confidence']>=0.60 and h['value_confidence']>=0.70)):
            strong_single_values.add(key)
    safe_values={v for v,frame_ids in value_votes.items() if len(frame_ids)>=2 or v in truth_values or v in strong_single_values}

    return {
        'found':True,'safe_name':safe_name,'safe_values':sorted(safe_values),
        'hits':hits,'raw_threshold':raw_threshold,
        'raw_match_frames':sorted(raw_frames),'strong_raw_frames':sorted(strong_raw_frames),
        'expected_family':expected_meta.get('option_family'),
        'expected_qualifier':expected_meta.get('qualifier'),
        'expected_unit':expected_meta.get('unit_type'),
    }


def _evaluate_search_filter(read_result, filter_config, frames=None):
    """
    v7.3 Config-Driven Short-Circuit Filter.

    Search/evaluate ONLY options present in the user's active filter. Unrelated
    low-value rows do not participate in KEEP/NO_MATCH/NEED_REVIEW. A full
    six-line READY result is not required to KEEP an item.

    Safety contract:
      - Positive wanted-option evidence may KEEP immediately.
      - Missing/weak evidence while the reader is uncertain stays UNCERTAIN.
      - FAIL is emitted only when the six-line reader is fully READY and the
        enabled wanted rules are conclusively absent/not satisfied.
    """
    # v7.3 CONFIG-DRIVEN CONTRACT:
    # Every enabled user rule is authoritative, including Sinh/Nội/Thể lực if
    # the user explicitly selected it.  "Ignore low value" applies only to
    # unrelated rows that are NOT part of the active filter.
    rules = [
        r for r in (filter_config or {}).get("rules", [])
        if bool(r.get("enabled", True)) and str(r.get("option_name") or "").strip()
    ]
    if not rules:
        return {
            "decision": "NO_FILTER",
            "reason": "NO_ENABLED_SEARCH_RULES",
            "rule_results": []
        }

    # Consensus READY rows are still valuable, but are no longer mandatory.
    consensus_observed = {
        row.get("name"): row
        for row in read_result.get("lines", [])
        if row.get("name")
    }

    passed = 0
    results = []
    mode = "ALL"  # v7.5 all enabled conditions are mandatory

    for rule in rules:
        option_name = rule.get("option_name")
        op = str(rule.get("op", "EXISTS")).upper()
        evidence = _wanted_frame_evidence(frames or [], option_name)
        consensus_hit = consensus_observed.get(option_name)

        # v10.5: a canonical label emitted by the general reader is not enough
        # to establish semantics. Revalidate FAMILY + QUALIFIER against raw OCR
        # before a consensus row may satisfy a configured rule.
        consensus_identity=None
        consensus_safe=None
        if consensus_hit is not None:
            raw_consensus=' | '.join(str(x) for x in (consensus_hit.get('all_name_ocr') or []) if x)
            raw_consensus=raw_consensus or str(consensus_hit.get('raw_name_ocr') or consensus_hit.get('raw_ocr') or '')
            consensus_identity=_semantic_identity_check(raw_consensus,option_name)
            if consensus_identity.get('identity_compatible'):
                consensus_safe=consensus_hit
                if option_semantics(option_name).get('option_family')=='ATTACK_SPEED':
                    auth=consensus_hit.get('attack_speed_percent_authority') or {}
                    if not auth.get('authoritative'):
                        consensus_safe=None

        # Prefer conclusive consensus only after semantic/unit authority.
        ok = _wanted_rule_ok(rule, consensus_safe)
        source = "CONSENSUS_SEMANTIC" if ok else None
        found_value = None if consensus_safe is None else consensus_safe.get("value")

        if not ok and evidence.get("safe_name"):
            if op == "EXISTS":
                ok = True
                source = "FRAME_WANTED_NAME"
            else:
                # Evaluate only values independently supported by >=2 frames or
                # by a truth-gated frame. This prevents one bad digit from KEEP.
                for value in evidence.get("safe_values", []):
                    pseudo = {"value": value}
                    if _wanted_rule_ok(rule, pseudo):
                        ok = True
                        source = "FRAME_WANTED_VALUE"
                        found_value = value
                        break

        passed += int(ok)
        results.append({
            "option_name": option_name,
            "found": bool(consensus_safe is not None or evidence.get("found")),
            "found_value": found_value,
            "operator": op,
            "target": rule.get("value"),
            "passed": ok,
            "mandatory": (mode == "ALL"),
            "match_source": source,
            "wanted_evidence": evidence,
            "consensus_identity": consensus_identity,
        })

        # Logical short-circuit.  This does not trust unrelated OCR rows:
        # ANY can KEEP as soon as one configured rule passes. ALL still requires
        # every configured rule, but already-passed rules never need re-analysis.
        if mode == "ANY" and ok:
            break

    if mode == "ALL":
        positive = passed == len(rules)
    else:
        positive = passed >= 1

    # v7.1 STRICT TRASH REJECT.
    # Root fix: weak fuzzy hits are NOT partial wanted evidence. NEED_REVIEW is
    # reserved for a strong wanted NAME whose numeric condition cannot yet be
    # resolved. A geometrically complete final-6 scan with no strong wanted
    # name is conclusive NO_MATCH even when the whole-reader status is not READY.
    strong_scan_frames = 0
    medium_scan_frames = 0
    for frame in (frames or []):
        lines = frame.get("lines") or []
        seg = frame.get("segmentation") or {}
        seg_status = str(seg.get("status") or "").upper()
        if len(lines) == 6 and seg_status not in {"IMAGE_READ_FAILED", "FAILED", "NO_TOOLTIP"}:
            strong_scan_frames += 1
        elif len(lines) >= 4 and seg_status not in {"IMAGE_READ_FAILED", "FAILED", "NO_TOOLTIP"}:
            medium_scan_frames += 1

    scan_complete = bool(
        strong_scan_frames >= 1 or
        medium_scan_frames >= 2 or
        read_result.get("status") == "READY"
    )

    # Only a STRONG name hit with unresolved numeric value deserves review.
    partial_numeric = False
    for rr, rule in zip(results, rules):
        ev = rr.get("wanted_evidence", {}) or {}
        op = str(rule.get("op", "EXISTS")).upper()
        if op != "EXISTS" and ev.get("safe_name") and not ev.get("safe_values"):
            partial_numeric = True
            break

    if positive:
        decision = "PASS"
        reason = "WANTED_OPTION_MATCH"
    elif partial_numeric:
        decision = "UNCERTAIN"
        reason = "STRONG_WANTED_NAME_NUMERIC_UNRESOLVED"
    elif scan_complete:
        decision = "FAIL"
        reason = "NO_STRONG_WANTED_MATCH_AFTER_FINAL6_SCAN"
    else:
        decision = "UNCERTAIN"
        reason = "TOOLTIP_SCAN_INCOMPLETE"

    return {
        "decision": decision,
        "reason": reason,
        "mode": mode,
        "matched": passed,
        "enabled": len(rules),
        "reader_status": read_result.get("status"),
        "good_search_frames": strong_scan_frames,
        "strong_scan_frames": strong_scan_frames,
        "medium_scan_frames": medium_scan_frames,
        "scan_complete": scan_complete,
        "partial_numeric": partial_numeric,
        "configured_rule_count": len(rules),
        "evaluated_rule_count": len(results),
        "unrelated_low_value_policy": "SKIP_UNLESS_EXPLICITLY_CONFIGURED",
        "short_circuit": bool((mode == "ANY" and positive) or (mode == "ALL" and positive)),
        "rule_results": results,
    }



# ---------------------------------------------------------------------------
# v7.4 FAST WANTED SCANNER -> VALUE ON DEMAND
# ---------------------------------------------------------------------------
_FAST_OCR_LANG_CACHE = None

def _fast_ocr_lang():
    """Pick OCR language once per process (v7.7 cached).

    pytesseract.get_languages() launches Tesseract. Doing that once for every
    item wastes a measurable part of a 5-item batch, so cache the result.
    """
    global _FAST_OCR_LANG_CACHE
    if _FAST_OCR_LANG_CACHE:
        return _FAST_OCR_LANG_CACHE
    try:
        langs=set(pytesseract.get_languages(config=''))
    except Exception:
        langs=set()
    if 'vie' in langs and 'eng' in langs:
        _FAST_OCR_LANG_CACHE = 'vie+eng'
    elif 'vie' in langs:
        _FAST_OCR_LANG_CACHE = 'vie'
    else:
        _FAST_OCR_LANG_CACHE = 'eng'
    return _FAST_OCR_LANG_CACHE


def _fast_blue_gray_ocr(pil_image, psm=6, timeout=1.05):
    """Exactly ONE Tesseract call over BLUE/GRAY pixels only.

    This intentionally skips the Stage-20 general-reader rescue matrix. It is
    used only to locate user-configured wanted options quickly.
    """
    try:
        import numpy as np
        import cv2
        arr=np.asarray(pil_image.convert('RGB'))
        mask=_blue_gray_mask_rgb(arr)
        if mask is None or getattr(mask,'size',0)==0 or int((mask>0).sum()) < 8:
            return ''
        # Black glyphs on white background are fastest/stablest for Tesseract.
        bw=np.full(mask.shape,255,dtype=np.uint8)
        bw[mask>0]=0
        # 2x is enough for the JX1 bitmap font and substantially cheaper than
        # the heavy reader's many 3x/variant rescue passes.
        bw=cv2.resize(bw,None,fx=2.0,fy=2.0,interpolation=cv2.INTER_NEAREST)
        cfg=f'--psm {int(psm)}'
        # v9.1 speed path: English-only OCR is ~25-40% faster on the JX1 bitmap
        # font and still preserves enough Latin glyph structure for the accent-insensitive
        # wanted-name matcher. The heavy/general reader remains unchanged.
        return pytesseract.image_to_string(
            bw, lang='eng', config=cfg, timeout=timeout
        ).strip()
    except Exception:
        return ''


def _fast_blue_gray_ocr_with_geometry(pil_image, block_y0=0, psm=6, timeout=1.8):
    """One OCR pass that preserves line geometry for row/value association."""
    try:
        import numpy as np, cv2
        from collections import defaultdict
        arr=np.asarray(pil_image.convert('RGB'))
        mask=_blue_gray_mask_rgb(arr)
        if mask is None or getattr(mask,'size',0)==0 or int((mask>0).sum()) < 8:
            return '', []
        bw=np.full(mask.shape,255,dtype=np.uint8); bw[mask>0]=0
        bw=cv2.resize(bw,None,fx=2.0,fy=2.0,interpolation=cv2.INTER_NEAREST)
        data=pytesseract.image_to_data(
            bw,lang='eng',config=f'--psm {int(psm)}',timeout=float(timeout),
            output_type=pytesseract.Output.DICT
        )
        groups=defaultdict(list)
        for i,t in enumerate(data.get('text') or []):
            if str(t or '').strip():
                groups[(data['block_num'][i],data['par_num'][i],data['line_num'][i])].append(i)
        evidence=[]
        for inds in groups.values():
            text=' '.join(str(data['text'][i]) for i in inds).strip()
            left=min(data['left'][i] for i in inds)/2.0
            top=min(data['top'][i] for i in inds)/2.0
            right=max(data['left'][i]+data['width'][i] for i in inds)/2.0
            bottom=max(data['top'][i]+data['height'][i] for i in inds)/2.0
            abs_top=float(block_y0)+top; abs_bottom=float(block_y0)+bottom
            evidence.append({
                'text':text,'bbox':[left,abs_top,right,abs_bottom],
                'center_y':(abs_top+abs_bottom)/2.0,
            })
        evidence.sort(key=lambda x:x['center_y'])
        return '\n'.join(x['text'] for x in evidence), evidence
    except Exception:
        return '', []


def _v109_zoom_row_context(image_path, scan, row_index, pad_px=4):
    """Return one V11.0 RAW-FIRST foreground-clean physical row.

    Geometry still comes from Final6, but the pixels passed to targeted OCR are
    extracted from the native row BEFORE 4x enlargement.  This prevents white
    inventory stack-count halos (999/558/etc.) from becoming gray OCR glyphs.
    """
    from PIL import Image
    pil=Image.open(Path(image_path)).convert('RGB')
    boxes=(scan or {}).get('boxes') or []
    idx=int(row_index)
    if len(boxes)!=6 or not (0 <= idx < 6):
        return None, None
    rect=(scan or {}).get('final6_rect')
    if isinstance(rect,(list,tuple)) and len(rect)==4:
        fx0,fy0,fx1,fy1=[int(v) for v in rect]
    else:
        fy0=max(0,int(boxes[0][0])-5); fy1=min(pil.height,int(boxes[-1][1])+6)
        fx0,fx1=0,pil.width

    y0,y1=[int(v) for v in boxes[idx]]
    # Native row crop.  pad_px is specified in historical 4x-space; convert to
    # a small native margin rather than enlarging contaminated pixels first.
    native_pad=max(1,int(round(float(pad_px)/2.0)))
    cy0=max(fy0,y0-native_pad)
    cy1=min(fy1,y1+native_pad+1)
    raw_row=pil.crop((fx0,cy0,fx1,cy1))
    fg=V110_FOREGROUND_EXTRACTOR.extract_single_row(raw_row,idx)
    row=fg.clean_row_zoom4x
    return row, {
        'scale':FINAL6_DIRECT_ZOOM_SCALE,
        'final6_raw':pil.crop((fx0,fy0,fx1,fy1)),
        'row_raw':raw_row,
        'row_clean_rgb':fg.clean_row_rgb,
        'row_foreground_sha256':fg.foreground_sha256,
        'row_raw_sha256':fg.raw_sha256,
        'fy0':fy0,'fy1':fy1,
        'row_native_bbox':[fx0,cy0,fx1,cy1],
        'row_zoom_bbox':[0,0,row.width,row.height],
        'source':'FINAL6_FOREGROUND_ROW_ZOOM4X',
        'extractor_version':V110_FOREGROUND_EXTRACTOR_VERSION,
    }


def _fast_numeric_ocr(pil_image, timeout=0.55):
    """Tiny on-demand numeric OCR for ONE already-matched option row.

    It never runs on unrelated rows. Blue/gray masking is preserved and the
    character set is restricted to numeric symbols, so this is much cheaper
    than re-OCRing the whole six-row block.
    """
    try:
        import numpy as np
        import cv2
        arr=np.asarray(pil_image.convert('RGB'))
        mask=_blue_gray_mask_rgb(arr)
        if mask is None or getattr(mask,'size',0)==0 or int((mask>0).sum()) < 4:
            return ''
        bw=np.full(mask.shape,255,dtype=np.uint8)
        bw[mask>0]=0
        bw=cv2.resize(bw,None,fx=2.0,fy=2.0,interpolation=cv2.INTER_NEAREST)
        cfg='--psm 7 -c tessedit_char_whitelist=+0123456789%.-'
        return pytesseract.image_to_string(
            bw, lang='eng', config=cfg, timeout=float(timeout)
        ).strip()
    except Exception:
        return ''

def _fast_family_identity_rescue(image_path, scan, rule_name):
    """Bounded same-row family/qualifier reread for an ambiguous candidate.

    This rereads only the already associated physical row; it never reruns the
    whole tooltip.  A known cross-family contradiction is not rescued.
    """
    try:
        hit=((scan or {}).get('rule_hits') or {}).get(rule_name) or {}
        idx=hit.get('physical_row_index')
        boxes=(scan or {}).get('boxes') or []
        if idx is None or len(boxes)!=6:
            return None
        idx=int(idx)
        if not (0 <= idx < 6):
            return None
        ident0=hit.get('semantic_identity') or _semantic_identity_check(hit.get('raw',''), rule_name)
        if ident0.get('family_status')=='SEMANTIC_FAMILY_CONTRADICTION':
            return {'attempted':False,'reason':'KNOWN_FAMILY_CONTRADICTION','row_index':idx}
        row,zoom_ctx=_v109_zoom_row_context(image_path,scan,idx,pad_px=4)
        if row is None:
            return {'attempted':True,'reason':'FINAL6_ZOOM_ROW_UNAVAILABLE','row_index':idx}
        name_roi=row.crop((0,0,max(1,int(row.width*0.78)),row.height))
        raw=_fast_blue_gray_ocr(name_roi, psm=7, timeout=.70)
        ident=_semantic_identity_check(raw,rule_name)
        lexical=_wanted_lexical_score(raw,rule_name)
        # v10.5.2: this is NAME-ROI identity rescue only.  Numeric authority
        # belongs exclusively to the row VALUE ROI after identity + unit are accepted.
        return {
            'attempted':True,'raw':raw,'row_index':idx,
            'score':float(lexical),'semantic_identity':ident,
            'value':None,
            'reason':ident.get('identity_reason'),
        }
    except Exception as e:
        return {'attempted':True,'reason':'FAMILY_RESCUE_ERROR','error':type(e).__name__}


def _v116_skill_physical_row_band(image_path, scan, row_index, margin_px=None):
    """Return one stable native physical option row from the ORIGINAL hover frame.

    V11.5 used a tight glyph-derived row via _v109_zoom_row_context. Real failed
    +1/+2 fixtures were only 10 px tall and clipped the orange value/cap glyphs.
    This band is derived from neighboring row baselines / measured line pitch,
    never from tight glyph bounds, and is therefore stable across 10/14 px OCR
    boxes.
    """
    try:
        from PIL import Image
        import numpy as np
        pil=Image.open(Path(image_path)).convert('RGB')
        boxes=(scan or {}).get('boxes') or []
        idx=int(row_index)
        if len(boxes)!=6 or not (0 <= idx < 6):
            return None, {'ok':False,'reason':'SKILL_PHYSICAL_BAND_REQUIRES_SIX_ROWS'}
        centers=[(float(a)+float(b))/2.0 for a,b in boxes]
        gaps=[centers[i+1]-centers[i] for i in range(5) if centers[i+1]>centers[i]]
        if not gaps:
            return None, {'ok':False,'reason':'SKILL_PHYSICAL_BAND_NO_LINE_PITCH'}
        gs=sorted(gaps); pitch=float(gs[len(gs)//2])
        rect=(scan or {}).get('final6_rect')
        if isinstance(rect,(list,tuple)) and len(rect)==4:
            fx0,fy0,fx1,fy1=[int(v) for v in rect]
        else:
            fx0,fx1=0,pil.width
            fy0=max(0,int(min(a for a,b in boxes))-6); fy1=min(pil.height,int(max(b for a,b in boxes))+7)
        c=centers[idx]
        top=((centers[idx-1]+c)/2.0) if idx>0 else (c-pitch/2.0)
        bottom=((c+centers[idx+1])/2.0) if idx<5 else (c+pitch/2.0)
        safe_margin=int(margin_px if margin_px is not None else max(2,round(pitch*0.15)))
        y0=max(fy0,int(np.floor(top))-safe_margin)
        y1=min(fy1,int(np.ceil(bottom))+safe_margin+1)
        if y1-y0 < max(12,int(round(pitch))):
            need=max(0,max(12,int(round(pitch)))-(y1-y0))
            y0=max(fy0,y0-(need+1)//2); y1=min(fy1,y1+need//2+1)
        raw=pil.crop((fx0,y0,fx1,y1))
        fg=V110_FOREGROUND_EXTRACTOR.extract_single_row(raw,idx)
        return fg.clean_row_rgb, {
            'ok':True,'logical_row_bbox':[int(boxes[idx][0]),int(boxes[idx][1])],
            'numeric_source_bbox':[fx0,y0,fx1,y1],'row_band_bbox':[fx0,y0,fx1,y1],
            'raw_row_size':[raw.width,raw.height],'line_pitch':round(pitch,3),
            'safe_margin':safe_margin,'row_raw_sha256':fg.raw_sha256,
            'row_foreground_sha256':fg.foreground_sha256,
            'final6_rect':[fx0,fy0,fx1,fy1],
        }
    except Exception as e:
        return None, {'ok':False,'reason':'SKILL_PHYSICAL_BAND_EXCEPTION','error':type(e).__name__}


def _v116_skill_orange_mask(row_img):
    import numpy as np, cv2
    arr=np.asarray(row_img.convert('RGB'))
    hsv=cv2.cvtColor(arr,cv2.COLOR_RGB2HSV)
    return cv2.inRange(hsv,np.array((8,90,110),dtype=np.uint8),np.array((32,255,255),dtype=np.uint8))


def _v116_skill_token_groups(orange):
    """Return compact orange token groups. Gap<=4 joins '+' to digit; 'cấp'
    starts after the larger real inter-token gap in the JX1 fixtures."""
    import cv2
    n, labels, stats, cents=cv2.connectedComponentsWithStats(orange,8)
    value_roi_x=max(0,int(round(orange.shape[1]*0.48)))
    comps=[]
    for ci in range(1,int(n)):
        x,y,w,h,area=[int(v) for v in stats[ci]]
        if area>=2 and h>=2 and x>=value_roi_x:
            comps.append([x,y,w,h,area])
    comps.sort(key=lambda c:(c[0],c[1]))
    groups=[]
    for x,y,w,h,area in comps:
        if (not groups) or x-(groups[-1][0]+groups[-1][2])>4:
            groups.append([x,y,w,h,area])
        else:
            g=groups[-1]
            x0=min(g[0],x); y0=min(g[1],y)
            x1=max(g[0]+g[2],x+w); y1=max(g[1]+g[3],y+h)
            g[:]=[x0,y0,x1-x0,y1-y0,g[4]+area]
    return groups,value_roi_x,comps


def _fast_skill_level_orange_rescue(image_path, scan, rule_name):
    """V11.6 stable-row SkillLevelReader for the closed {1,2,3} domain.

    Exact V11.5 failure: 10px tight rows clipped the orange '+N cấp' token.
    Tesseract then returned '+14' / '+24'; the domain regex correctly rejected
    those strings because the valid 1/2 was followed by another digit. V11.6
    reads a baseline-derived physical row band from the original Final6 frame,
    isolates only the '+N' orange token, and records explicit border/crop proof.
    """
    try:
        if _wanted_norm_text(rule_name) != _wanted_norm_text('Kỹ năng Võ công vốn có'):
            return None
        hit=((scan or {}).get('rule_hits') or {}).get(rule_name) or {}
        idx=hit.get('physical_row_index'); boxes=(scan or {}).get('boxes') or []
        if idx is None or len(boxes)!=6: return None
        idx=int(idx)
        if not (0 <= idx < 6): return None
        import numpy as np, cv2

        # Diagnostic old/tight source: proves whether expansion was required.
        old_img,old_ctx=_v109_zoom_row_context(image_path,scan,idx,pad_px=4)
        old_native=(old_ctx or {}).get('row_clean_rgb') if isinstance(old_ctx,dict) else None
        old_orange=_v116_skill_orange_mask(old_native) if old_native is not None else None
        old_ys,old_xs=(np.where(old_orange>0) if old_orange is not None and old_orange.size else (np.array([]),np.array([])))
        old_touch_top=bool(old_ys.size and int(old_ys.min())==0)
        old_touch_bottom=bool(old_ys.size and int(old_ys.max())==int(old_orange.shape[0]-1)) if old_orange is not None and old_orange.size else False

        skill_row_img,band=_v116_skill_physical_row_band(image_path,scan,idx)
        if skill_row_img is None:
            return {'raw':'','value':None,'row_index':idx,'source':'SKILL_LEVEL_READER_V2',
                    'rejection_reason':(band or {}).get('reason','PHYSICAL_ROW_BAND_UNAVAILABLE')}
        orange=_v116_skill_orange_mask(skill_row_img)
        ys,xs=np.where(orange>0)
        orange_pixel_count=int(xs.size)
        touches_top=bool(ys.size and int(ys.min())==0)
        touches_bottom=bool(ys.size and int(ys.max())==int(orange.shape[0]-1))
        expansion_used=bool(old_touch_top or old_touch_bottom)
        expanded_bbox=None

        # Border-touch guard: re-expand from ORIGINAL image, never from clipped row.
        if touches_top or touches_bottom:
            skill_row_img2,band2=_v116_skill_physical_row_band(image_path,scan,idx,margin_px=max(3,int((band or {}).get('safe_margin',2))+2))
            if skill_row_img2 is not None:
                orange2=_v116_skill_orange_mask(skill_row_img2)
                ys2,xs2=np.where(orange2>0)
                if xs2.size:
                    skill_row_img=skill_row_img2; orange=orange2; ys=ys2; xs=xs2
                    orange_pixel_count=int(xs.size); expansion_used=True
                    expanded_bbox=(band2 or {}).get('row_band_bbox')
                    band=band2
                    touches_top=bool(ys.size and int(ys.min())==0)
                    touches_bottom=bool(ys.size and int(ys.max())==int(orange.shape[0]-1))

        groups,value_roi_x,components=_v116_skill_token_groups(orange)
        candidate_groups=[g for g in groups if g[0]>=value_roi_x and g[4]>=12 and g[2]<=48 and g[3]<=max(18,orange.shape[0])]
        attempts=[]; specialized_candidates=[]; geometry_candidates=[]
        # The first compact group in the right-side value ROI is '+N'. A later
        # group is the orange word 'cấp' and has no numeric authority.
        token_group=candidate_groups[0] if candidate_groups else None
        if token_group is not None:
            x,y,w,h,area=token_group
            token_components=[c for c in components if c[0]>=x and c[0]<(x+w)]
            token_components.sort(key=lambda c:c[0])
            if len(token_components)>=2:
                digit_w=int(token_components[1][2])
                geometry_candidates=[1] if digit_w<=3 else [2,3]
            pad=2
            x0=max(0,x-pad); y0=max(0,y-pad)
            x1=min(orange.shape[1],x+w+pad); y1=min(orange.shape[0],y+h+pad)
            token=orange[y0:y1,x0:x1]
            bw=np.full(token.shape,255,dtype=np.uint8); bw[token>0]=0
            bw=cv2.resize(bw,None,fx=3.0,fy=3.0,interpolation=cv2.INTER_NEAREST)
            raw=pytesseract.image_to_string(
                bw,lang='eng',config='--psm 10 -c tessedit_char_whitelist=+123',timeout=.45
            ).strip()
            compact=re.sub(r'\s+','',str(raw or ''))
            m=re.fullmatch(r'\+?([123])',compact)
            attempts.append({'raw':raw,'compact':compact,'bbox':[x,y,w,h],'area':area,'kind':'ISOLATED_PLUS_DIGIT'})
            if m:
                specialized_candidates.append(int(m.group(1)))

        value=None; authority_reason=None
        if specialized_candidates:
            ocr_value=int(specialized_candidates[0])
            if not geometry_candidates or ocr_value in geometry_candidates:
                value=ocr_value; authority_reason='OCR_DOMAIN_WITH_COMPONENT_GEOMETRY'
        elif geometry_candidates==[1]:
            value=1; authority_reason='UNAMBIGUOUS_COMPONENT_GEOMETRY'

        rejection_reason=None
        if value is None:
            if orange_pixel_count<=0: rejection_reason='NO_ORANGE_VALUE_PIXELS'
            elif token_group is None: rejection_reason='NO_COMPACT_PLUS_DIGIT_TOKEN'
            elif touches_top or touches_bottom: rejection_reason='ORANGE_COMPONENT_STILL_TOUCHES_PHYSICAL_BAND'
            elif attempts: rejection_reason='ISOLATED_TOKEN_OCR_OUTSIDE_SKILL_DOMAIN'
            else: rejection_reason='SKILL_VALUE_UNRESOLVED_AFTER_STABLE_BAND'

        proof_paths={}
        try:
            V116_SKILL_VALUE_PROOF_DIR.mkdir(parents=True,exist_ok=True)
            stem=Path(image_path).stem+f'_row{idx+1}'
            rowp=V116_SKILL_VALUE_PROOF_DIR/f'{stem}_physical_row.png'
            maskp=V116_SKILL_VALUE_PROOF_DIR/f'{stem}_orange_mask.png'
            skill_row_img.save(rowp)
            from PIL import Image
            Image.fromarray(orange,'L').save(maskp)
            PROOF_ARTIFACTS.record_artifact(rowp,'skill_value',extra={'source_image':str(image_path),'row_index':int(idx),'artifact_role':'physical_row'})
            PROOF_ARTIFACTS.record_artifact(maskp,'skill_value',extra={'source_image':str(image_path),'row_index':int(idx),'artifact_role':'orange_mask'})
            proof_paths={'physical_row_path':str(rowp),'orange_mask_path':str(maskp)}
        except Exception:
            pass

        return {
            'raw':(attempts[-1].get('raw') if attempts else ''),'value':value,'row_index':idx,
            'source':'SKILL_LEVEL_READER_V2_PHYSICAL_ROW_BAND',
            'numeric_authoritative':bool(value in V116_SKILL_DOMAIN),
            'authority_reason':authority_reason,
            'logical_row_bbox':(band or {}).get('logical_row_bbox'),
            'numeric_source_bbox':(band or {}).get('numeric_source_bbox'),
            'row_band_bbox':(band or {}).get('row_band_bbox'),
            'raw_row_size':(band or {}).get('raw_row_size'),
            'expanded_value_bbox':expanded_bbox,
            'final_numeric_crop_size':([int(token.shape[1]),int(token.shape[0])] if token_group is not None else None),
            'orange_pixel_count':orange_pixel_count,'orange_component_count':len(components),
            'orange_component_bboxes':[c[:4] for c in components],
            'touches_top':touches_top,'touches_bottom':touches_bottom,
            'old_tight_source_size':(list(old_native.size) if old_native is not None else None),
            'old_touches_top':old_touch_top,'old_touches_bottom':old_touch_bottom,
            'expansion_used':expansion_used,'specialized_candidates':specialized_candidates,
            'geometry_candidates':geometry_candidates,'final_skill_value':value,
            'rejection_reason':rejection_reason,'value_roi_x':value_roi_x,'attempts':attempts,
            **proof_paths,
        }
    except Exception as e:
        return {'raw':'','value':None,'source':'SKILL_LEVEL_READER_V2_PHYSICAL_ROW_BAND',
                'rejection_reason':'SKILL_LEVEL_READER_V2_EXCEPTION','error':type(e).__name__}


def _percent_glyph_anchor_digits_read(row):
    """V10.6 geometry-first percent reader for the same physical VALUE row.

    The JX1 value glyphs are blue/purple.  We locate the rightmost percent
    glyph visually and use it only as the right boundary; OCR receives digits
    left of that boundary, never the percent sign itself.  This prevents %→8.
    """
    try:
        import numpy as np, cv2
        arr=np.asarray(row.convert('RGB')); h,w=arr.shape[:2]
        hsv=cv2.cvtColor(arr,cv2.COLOR_RGB2HSV)
        # Calibrated to the live blue/purple option-value glyph, not global text.
        mask=cv2.inRange(hsv,np.array((108,45,115),dtype=np.uint8),np.array((134,255,255),dtype=np.uint8))
        x_floor=max(0,int(round(w*0.56)))
        ys,xs=np.where(mask[:,x_floor:]>0)
        if xs.size<8:
            return {'authoritative':False,'reason':'PERCENT_GLYPH_ANCHOR_NOT_FOUND','reads':[]}
        right=int(x_floor+xs.max())
        # A percent glyph occupies the stable right-edge ~5px lobe in 800x600 live
        # frames. Scale this width by row height so higher-DPI clients stay relative.
        unit_w=max(4,min(8,int(round(max(8,h)*0.34))))
        unit_left=max(x_floor,right-unit_w+1)
        unit_pixels=int((mask[:,unit_left:right+1]>0).sum())
        if unit_pixels < max(6,int(h*0.35)):
            return {'authoritative':False,'reason':'PERCENT_GLYPH_ANCHOR_WEAK','reads':[],
                    'percent_anchor_x':right,'percent_unit_pixels':unit_pixels}
        # Read only sign+digits immediately left of the visual percent boundary.
        digit_width=max(22,min(42,int(round(w*0.10))))
        x0=max(x_floor,unit_left-digit_width)
        digits=mask[:,x0:unit_left]
        if int((digits>0).sum())<5:
            return {'authoritative':False,'reason':'PERCENT_DIGITS_VISUALLY_EMPTY','reads':[],
                    'percent_anchor_x':right,'digits_roi':[x0,0,unit_left,h]}
        bw=np.full(digits.shape,255,dtype=np.uint8); bw[digits>0]=0
        reads=[]; vals=[]
        for scale,psm in ((6,8),(6,13),(8,8),(8,13)):
            up=cv2.resize(bw,None,fx=scale,fy=scale,interpolation=cv2.INTER_NEAREST)
            try:
                raw=pytesseract.image_to_string(up,lang='eng',config=f'--psm {psm} -c tessedit_char_whitelist=+0123456789',timeout=.45).strip()
            except Exception:
                raw=''
            reads.append({'raw':raw,'scale':scale,'psm':psm})
            m=re.search(r'\+?\s*(\d{1,3})(?!\d)',str(raw or ''))
            if m:
                try:
                    v=int(m.group(1))
                    if 0<=v<=999: vals.append(v)
                except Exception: pass
        if not vals:
            return {'authoritative':False,'reason':'PERCENT_DIGITS_UNRESOLVED','reads':reads,
                    'percent_anchor_x':right,'digits_roi':[x0,0,unit_left,h]}
        counts={v:vals.count(v) for v in set(vals)}
        winner=max(sorted(counts),key=lambda v:(counts[v],-v)); votes=counts[winner]
        # Geometry already proves the unit; require at least two agreeing digit reads.
        authoritative=bool(votes>=2)
        return {'authoritative':authoritative,'value':winner if authoritative else None,
                'reason':'PERCENT_GLYPH_ANCHOR_DIGITS_CONSENSUS' if authoritative else 'PERCENT_DIGITS_CONFLICT',
                'reads':reads,'candidates':vals,'winner_votes':votes,'percent_anchor_x':right,
                'percent_unit_pixels':unit_pixels,'digits_roi':[x0,0,unit_left,h],
                'unit_source':'VISUAL_PERCENT_GLYPH_ANCHOR','numeric_source':'PERCENT_DIGITS_ONLY_V10_6'}
    except Exception as e:
        return {'authoritative':False,'reason':'PERCENT_GLYPH_ANCHOR_EXCEPTION','error':type(e).__name__,'reads':[]}


def _fast_percent_value_roi_consensus(row):
    """Bounded percent-only reread of the SAME physical row VALUE ROI.

    Used only after option identity is already authoritative and the specialized
    AttackSpeed reader remains unresolved.  It never reads another row and never
    supplies option identity.  Authority requires an explicit percent glyph from
    at least one tight ROI read; agreeing reads are preferred.
    """
    try:
        from PIL import Image, ImageOps
        candidates=[]
        reads=[]
        # Tight right-side crops: broad enough for sign+digits+%, narrow enough
        # to exclude most option-name glyphs. Multiple starts handle JX1 scaling.
        for frac in (0.50,0.56,0.62):
            x0=max(0,min(row.width-1,int(row.width*frac)))
            roi=row.crop((x0,0,row.width,row.height))
            for scale,inv in ((4,False),(6,True)):
                z=roi.resize((max(1,roi.width*scale),max(1,roi.height*scale)),Image.Resampling.LANCZOS)
                g=ImageOps.grayscale(z)
                if inv: g=ImageOps.invert(g)
                try:
                    raw=pytesseract.image_to_string(
                        g,config='--psm 7 -c tessedit_char_whitelist=+0123456789%',
                        timeout=.35
                    ).strip()
                except Exception:
                    raw=''
                reads.append({'raw':raw,'x0':x0,'scale':scale,'inverted':inv})
                if '%' not in raw:
                    continue
                # Bind only the signed/unsigned numeric token immediately before %.
                m=re.search(r'([+]?\s*\d{1,3})\s*%',raw)
                if not m:
                    continue
                try: v=int(re.sub(r'\D','',m.group(1)))
                except Exception: continue
                if 0 <= v <= 999:
                    candidates.append(v)
        if not candidates:
            return {'authoritative':False,'value':None,'reads':reads,'reason':'NO_EXPLICIT_PERCENT_TOKEN'}
        counts={v:candidates.count(v) for v in set(candidates)}
        value=max(sorted(counts),key=lambda v:(counts[v],-v))
        votes=counts[value]
        # One explicit-percent read is allowed when every other explicit token,
        # if any, agrees. This remains same-row, same-frame, unit-gated evidence.
        conflicting=sorted(v for v in counts if v!=value)
        authoritative=(votes>=2 or (votes>=1 and not conflicting))
        return {
            'authoritative':bool(authoritative),'value':value if authoritative else None,
            'reads':reads,'candidates':candidates,'winner_votes':votes,
            'conflicts':conflicting,'reason':'TIGHT_VALUE_ROI_PERCENT_CONSENSUS' if authoritative else 'PERCENT_CANDIDATE_CONFLICT'
        }
    except Exception as e:
        return {'authoritative':False,'value':None,'reads':[],'reason':'VALUE_ROI_EXCEPTION','error':type(e).__name__}


def _fast_attack_speed_rgb_rescue(image_path, scan, rule_name):
    """v10.5 shared AttackSpeedPercentReader for NỘI and NGOẠI.

    Unlike v9.9, this never repairs a value by deleting a trailing ``8``.
    Authority requires an actual percent glyph on the same physical row.  A
    generic integer such as ``448`` is retained only as diagnostic evidence.
    """
    try:
        meta=option_semantics(rule_name)
        if meta.get('option_family')!='ATTACK_SPEED' or meta.get('unit_type')!='PERCENT':
            return None
        hit=((scan or {}).get('rule_hits') or {}).get(rule_name) or {}
        idx=hit.get('physical_row_index')
        boxes=(scan or {}).get('boxes') or []
        if idx is None or len(boxes)!=6:
            return None
        idx=int(idx)
        if not (0 <= idx < 6):
            return None
        row,zoom_ctx=_v109_zoom_row_context(image_path,scan,idx,pad_px=4)
        if row is None:
            return None
        # Specialized percent authority owns its own tight same-row VALUE ROI bands.
        # Identity is already accepted before this targeted reread, so one same-row
        # OCR string may corroborate glyph shapes such as ``8o%`` => 80%.
        direct_row_raw=_fast_blue_gray_ocr(row,psm=7,timeout=.70)
        result=read_attack_speed_percent_authority(
            row,
            rule_name,
            generic_value=hit.get('value'),
            raw_text=direct_row_raw,
        )
        if isinstance(result,dict):
            result['direct_row_raw']=direct_row_raw

        # Bounded same-master-frame fallback: if the targeted row OCR loses a
        # percent glyph shape (e.g. 80% -> 898), OCR the FINAL6 block only and
        # recover the text line geometrically associated with THIS physical row.
        # This is not a primary whole-tooltip reader and never changes identity.
        if not (result or {}).get('authoritative'):
            try:
                block=(zoom_ctx or {}).get('final6_zoom')
                fy0=int((zoom_ctx or {}).get('fy0') or 0)
                if block is None:
                    raise RuntimeError('FINAL6_ZOOM_CONTEXT_MISSING')
                _,evs=_fast_blue_gray_ocr_with_geometry(block,block_y0=0,psm=6,timeout=1.15)
                target_c=(((float(boxes[idx][0])+float(boxes[idx][1]))/2.0)-fy0)*FINAL6_DIRECT_ZOOM_SCALE
                near=[e for e in evs if abs(float(e.get('center_y',-9999))-target_c)<=32.0]
                if near:
                    fallback_raw=min(near,key=lambda e:abs(float(e.get('center_y',-9999))-target_c)).get('text','')
                    fallback=read_attack_speed_percent_authority(
                        row,rule_name,generic_value=hit.get('value'),raw_text=fallback_raw
                    )
                    if isinstance(fallback,dict):
                        fallback['direct_row_raw']=direct_row_raw
                        fallback['final6_row_fallback_raw']=fallback_raw
                        fallback['authority_path']='TIGHT_ROW_PLUS_FINAL6_GEOMETRY_FALLBACK'
                    if fallback and fallback.get('authoritative'):
                        result=fallback
            except Exception:
                pass

        # V10.6 PercentReaderV2: do not OCR '%' as a number. Detect the
        # percent glyph visually and OCR only the sign+digits to its left.
        if not (result or {}).get('authoritative'):
            anchor_read=_percent_glyph_anchor_digits_read(row)
            if anchor_read.get('authoritative'):
                result={
                    **dict(result or {}),'value':int(anchor_read.get('value')),
                    'numeric_unit':'PERCENT','authoritative':True,'percent_glyph_evidence':True,
                    'reason':'PERCENT_GLYPH_ANCHOR_DIGITS_CONSENSUS',
                    'numeric_source':'PERCENT_DIGITS_ONLY_V10_6',
                    'percent_glyph_anchor':anchor_read,'authority_path':'PERCENT_GLYPH_ANCHOR_V2',
                }
            elif isinstance(result,dict):
                result['percent_glyph_anchor']=anchor_read

        # v10.5.2 bounded same-row grayscale rescue. Some real JX1 captures
        # render the tiny percent glyph with too little blue/gray chroma, so the
        # color mask sees ``+478`` while luminance still clearly shows ``+47%``.
        # This runs only after ATTACK_SPEED identity is strong and the proven
        # percent reader remains unresolved. Two overlapping VALUE bands must
        # agree on an explicit percent token; no whole-tooltip OCR is used.
        if not (result or {}).get('authoritative'):
            try:
                import numpy as np, cv2
                arr=np.asarray(row.convert('RGB')); h,w=arr.shape[:2]
                extra=[]
                for fa,fb in ((0.67,0.94),(0.69,0.94)):
                    x0=max(0,min(w-1,int(round(w*fa)))); x1=max(x0+1,min(w,int(round(w*fb))))
                    cut=arr[:,x0:x1]
                    gray=cv2.cvtColor(cut,cv2.COLOR_RGB2GRAY)
                    bw=cv2.threshold(gray,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]
                    up=cv2.resize(bw,None,fx=8,fy=8,interpolation=cv2.INTER_CUBIC)
                    raw=pytesseract.image_to_string(
                        up,lang='eng',config='--psm 7 -c tessedit_char_whitelist=+0123456789%TtOoIlSs',timeout=.65
                    ).strip()
                    if raw:
                        extra.append({'raw':raw,'kind':'MASK_CUBIC','bbox':[x0,0,x1,h]})
                if extra:
                    gray_res=parse_attack_speed_percent_evidence(extra,generic_value=hit.get('value'),contextual=True)
                    if isinstance(gray_res,dict):
                        gray_res['authority_path']='ROW_VALUE_GRAY_OTSU_CONSENSUS'
                        gray_res['percent_value_roi_reads']=extra
                        gray_res['direct_row_raw']=direct_row_raw
                    if gray_res and gray_res.get('authoritative'):
                        result=gray_res
            except Exception:
                pass
        # Final bounded VALUE-ROI rescue on the same physical row. This is
        # unit-gated and cannot create identity; it only resolves a PERCENT value
        # when an explicit '%' glyph is recovered from tight right-side crops.
        if not (result or {}).get('authoritative'):
            tight=_fast_percent_value_roi_consensus(row)
            if tight.get('authoritative'):
                result={
                    **dict(result or {}),
                    'value':int(tight.get('value')),
                    'numeric_unit':'PERCENT',
                    'authoritative':True,
                    'percent_glyph_evidence':True,
                    'reason':'TIGHT_VALUE_ROI_PERCENT_CONSENSUS',
                    'numeric_source':'VALUE_ROI_PERCENT_CONSENSUS_V10_5_2',
                    'value_roi_consensus':tight,
                    'authority_path':'TIGHT_VALUE_ROI_PERCENT_CONSENSUS',
                }
            elif isinstance(result,dict):
                result['value_roi_consensus']=tight
        return {
            **dict(result or {}),
            'row_index':idx,
            'source':'ATTACK_SPEED_PERCENT_AUTHORITY',
            'rescue_kind':'SAME_ROW_PERCENT_AUTHORITY',
        }
    except Exception:
        return None


def _implicit_percent_value_from_raw(raw, option_name):
    """V1.7.5 user-taught numeric contract.

    For exactly three taught slot options, the option identity supplies the unit.
    VALUE ROI therefore reads only one signed/bare integer and treats it as %.
    The '%' glyph, '+', and ':' are non-authoritative decoration.
    """
    if not implicit_percent_number_only(option_name):
        return None
    text=str(raw or '')
    # Reuse primary parser first; if it cannot recover a number, allow exactly
    # one standalone integer token. Multiple numbers stay unresolved.
    token=_primary_value_token(text)
    value=token.get('value') if isinstance(token,dict) else None
    if value is None:
        vals=[]
        for m in re.finditer(r'(?<!\d)([+\-]?\d{1,4})(?!\d)', text):
            try: vals.append(int(m.group(1)))
            except Exception: pass
        vals=list(dict.fromkeys(vals))
        if len(vals)==1:
            value=vals[0]
    return value


def _v1713_blue_gray_percent_modal(row):
    """Same-row percent reader using modal agreement across overlapping VALUE starts.

    This is intentionally numeric-only and runs only after NAME/FAMILY identity is
    already strong.  The old single 42% crop could turn label glyphs into digits
    (e.g. real ``+6%`` => ``11``).  Seven overlapping starts make a stable value
    win by repetition; an explicit percent glyph is mandatory.
    """
    try:
        import numpy as np, cv2
        values=[]; reads=[]
        for frac in (0.38,0.40,0.42,0.44,0.46,0.48,0.50):
            x0=max(0,min(row.width-1,int(round(row.width*frac))))
            roi=row.crop((x0,0,row.width,row.height))
            arr=np.asarray(roi.convert('RGB'))
            mask=_blue_gray_mask_rgb(arr)
            if mask is None or getattr(mask,'size',0)==0 or int((mask>0).sum())<4:
                reads.append({'x0':x0,'raw':'','value':None}); continue
            bw=np.full(mask.shape,255,dtype=np.uint8); bw[mask>0]=0
            bw=cv2.resize(bw,None,fx=2.0,fy=2.0,interpolation=cv2.INTER_NEAREST)
            try:
                raw=pytesseract.image_to_string(
                    bw,lang='eng',config='--psm 7 -c tessedit_char_whitelist=+0123456789%.-',timeout=.45
                ).strip()
            except Exception:
                raw=''
            m=re.search(r'([+\-]?\d{1,4})\s*%',str(raw or '')) if '%' in str(raw or '') else None
            value=None
            if m:
                try: value=int(m.group(1))
                except Exception: value=None
            reads.append({'x0':x0,'raw':raw,'value':value})
            if value is not None: values.append(value)
        if not values:
            return {'authoritative':False,'value':None,'reason':'NO_EXPLICIT_PERCENT_MODAL_CANDIDATE','reads':reads}
        counts={v:values.count(v) for v in set(values)}
        winner=max(sorted(counts),key=lambda v:(counts[v],-abs(v)))
        votes=int(counts[winner]); runner=max([n for v,n in counts.items() if v!=winner] or [0])
        # Require a real modal majority, not a lucky single crop.
        authoritative=bool(votes>=2 and votes>runner)
        return {
            'authoritative':authoritative,'value':int(winner) if authoritative else None,
            'winner_votes':votes,'runner_votes':runner,'counts':counts,'reads':reads,
            'reason':'BLUE_GRAY_PERCENT_MODAL_CONSENSUS' if authoritative else 'PERCENT_MODAL_CONFLICT',
        }
    except Exception as e:
        return {'authoritative':False,'value':None,'reason':'PERCENT_MODAL_EXCEPTION','error':type(e).__name__,'reads':[]}


def _v1713_percent_value_authority(row, implicit_percent=False):
    """Resolve one percent value without letting label glyphs become digits.

    First use the existing grayscale explicit-percent reader.  If it conflicts,
    use the independent blue/gray modal reader.  An implicit-percent option may
    omit the glyph only in the registry-owned V1.7.5 contract; otherwise percent
    authority always requires a recovered ``%``.  Two native readers that return
    different authoritative values yield UNKNOWN rather than a guessed number.
    """
    tight=_fast_percent_value_roi_consensus(row)
    modal=_v1713_blue_gray_percent_modal(row)
    tv=tight.get('value') if isinstance(tight,dict) and tight.get('authoritative') else None
    mv=modal.get('value') if isinstance(modal,dict) and modal.get('authoritative') else None
    if tv is not None and mv is not None and int(tv)!=int(mv):
        return {'authoritative':False,'value':None,'reason':'INDEPENDENT_PERCENT_READERS_CONFLICT','tight':tight,'modal':modal}
    if tv is not None:
        return {'authoritative':True,'value':int(tv),'reason':'EXPLICIT_PERCENT_TIGHT_ROI','tight':tight,'modal':modal}
    if mv is not None:
        return {'authoritative':True,'value':int(mv),'reason':'EXPLICIT_PERCENT_MODAL_ROI','tight':tight,'modal':modal}
    # For the three registry-owned implicit-percent options, do NOT fall back to
    # a broad number-only crop here.  The old broad crop is the exact source of
    # the 6 -> 11 corruption.  No explicit/native consensus => unresolved.
    return {'authoritative':False,'value':None,
            'reason':'IMPLICIT_PERCENT_NATIVE_VALUE_UNRESOLVED' if implicit_percent else 'PERCENT_NATIVE_VALUE_UNRESOLVED',
            'tight':tight,'modal':modal}


def _fast_same_frame_numeric_rescue(image_path, scan, rule_name):
    """Targeted VALUE-ROI numeric read after semantic identity is already strong.

    OPTION_UNIT_REGISTRY_V1 routes authority: percent normally requires an explicit percent
    glyph; the three V1.7.5 user-taught slot options are the narrow exception and
    read NUMBER ONLY with implicit %. POINT rejects explicit percent, LEVEL stays
    owned by the specialized Skill reader, and NONE reads the associated token.
    """
    try:
        hit=((scan or {}).get('rule_hits') or {}).get(rule_name) or {}
        idx=hit.get('physical_row_index'); boxes=(scan or {}).get('boxes') or []
        if idx is None or len(boxes)!=6: return None
        idx=int(idx)
        if not (0 <= idx < 6): return None
        expected=option_unit_type(rule_name) or (option_semantics(rule_name) or {}).get('unit_type')
        if expected=='LEVEL':
            return {'raw':'','value':None,'row_index':idx,'source':'VALUE_ROI_V10_5_2',
                    'reason':'LEVEL_OWNED_BY_SPECIALIZED_SKILL_READER','expected_unit':'LEVEL'}
        row,zoom_ctx=_v109_zoom_row_context(image_path,scan,idx,pad_px=3)
        if row is None:
            return None
        x0=max(0,int(row.width*0.42)); value_roi=row.crop((x0,0,row.width,row.height))
        ocr_parent_source='FINAL6_DIRECT_CROP_ZOOM4X'
        foreground_value_sha256=None
        # V11.0 POINT/NONE authority must come from the same clean foreground
        # row family as NAME OCR.  Re-extract the native physical row instead
        # of allowing translucent background stack counts into VALUE OCR.
        if expected in ('POINT','NONE'):
            try:
                from PIL import Image
                master=Image.open(image_path).convert('RGB')
                by0,by1=(scan.get('boxes') or [])[idx]
                py=max(2,int((float(by1)-float(by0))*0.18))
                ny0=max(0,int(by0)-py); ny1=min(master.height,int(by1)+py+1)
                native=master.crop((0,ny0,master.width,ny1))
                fr=V110_FOREGROUND_EXTRACTOR.extract_single_row(native,idx)
                clean=fr.clean_row_rgb
                # Local value token lives in the right half after identity is
                # known; use a tighter 60% start to exclude name digits/noise.
                fx0=max(0,int(clean.width*0.60))
                value_roi=clean.crop((fx0,0,clean.width,clean.height)).resize(
                    (max(1,(clean.width-fx0)*FINAL6_DIRECT_ZOOM_SCALE),
                     max(1,clean.height*FINAL6_DIRECT_ZOOM_SCALE)),
                    Image.Resampling.NEAREST)
                foreground_value_sha256=hashlib.sha256(value_roi.convert('RGB').tobytes()).hexdigest()
                x0=fx0*FINAL6_DIRECT_ZOOM_SCALE
                ocr_parent_source='FINAL6_FOREGROUND_LOCAL_VALUE_ZOOM4X'
            except Exception:
                pass
        implicit_percent=bool(implicit_percent_number_only(rule_name))
        percent_authority=None
        if expected=='PERCENT':
            percent_authority=_v1713_percent_value_authority(row,implicit_percent=implicit_percent)
            value=(int(percent_authority.get('value')) if percent_authority.get('authoritative') and percent_authority.get('value') is not None else None)
            raw=''
            reason=str(percent_authority.get('reason') or 'PERCENT_NATIVE_VALUE_UNRESOLVED')
            explicit_percent=bool(value is not None)  # native percent readers require/locate the glyph
        else:
            raw=_fast_numeric_ocr(value_roi, timeout=.55)
            token=_primary_value_token(raw)
            value=token.get('value')
            reason='VALUE_TOKEN'
            if value is None:
                bare=[int(x) for x in re.findall(r'(?<!\d)(\d{1,4})(?!\d)', str(raw or ''))]
                if len(bare)==1:
                    value=bare[0]; reason='TARGETED_SINGLE_BARE_INTEGER'
            explicit_percent=bool('%' in str(raw or ''))
            if expected=='POINT' and explicit_percent:
                value=None; reason='UNIT_MISMATCH_PERCENT_ON_POINT'
        return {
            'raw':raw,'value':value,'row_index':idx,'source':'VALUE_ROI_V1_7_13_NATIVE_CONSENSUS',
            'rescue_kind':reason,'expected_unit':expected,'explicit_percent':explicit_percent,
            'implicit_percent_by_registry':implicit_percent,
            'percent_authority':percent_authority,
            'value_roi_bbox_zoom4x':[x0,0,row.width,row.height],
            'ocr_parent_source':ocr_parent_source,
            'actual_value_ocr_input_sha256':foreground_value_sha256,
        }
    except Exception:
        return None

def _fast_general_value_token_rescue(image_path, scan, rule_name):
    """One targeted row read for a suspicious malformed primary token.

    This is not an option-specific OCR pipeline. It is only invoked when an
    already strong matched row exposes the real JX1 ``% -> 8`` failure shape.
    The shared VALUE_TOKEN parser then recovers the number if the row OCR
    supplies '%' and/or a bracketed legal range.
    """
    try:
        hit=((scan or {}).get('rule_hits') or {}).get(rule_name) or {}
        idx=hit.get('physical_row_index')
        boxes=(scan or {}).get('boxes') or []
        if idx is None or len(boxes)!=6:
            return None
        idx=int(idx)
        if not (0 <= idx < 6):
            return None
        row,zoom_ctx=_v109_zoom_row_context(image_path,scan,idx,pad_px=4)
        if row is None:
            return None
        value_roi=row.crop((max(0,int(row.width*0.42)),0,row.width,row.height))
        # Reuse the existing blue/gray numeric-only OCR owner on VALUE ROI only.
        raw=_fast_numeric_ocr(value_roi, timeout=.55)
        token=_primary_value_token(raw)
        return {
            'raw':raw,'value':token.get('value'),'row_index':idx,
            'source':'VALUE_TOKEN_RGB_V10_2','token':token,
        }
    except Exception:
        return None


def _skill_authority_resolution(hit):
    """Resolve specialized skill +1/+2/+3 evidence without generic veto.

    A specialized orange value is authoritative only inside the real JX1 skill
    domain 1..3. Any prior/generic value outside that domain is OCR noise; a
    different in-domain value is a genuine numeric conflict.
    """
    hit=hit or {}
    source=str(hit.get('value_source') or '')
    if source not in ('SKILL_ORANGE_VALUE_V11_2_NATIVE_FOREGROUND','SKILL_ORANGE_VALUE_V10_4_2','SKILL_ORANGE_VALUE_V9_9','SKILL_ORANGE_VALUE_V9_3'):
        return None
    try:
        value=int(hit.get('value'))
    except Exception:
        return None
    if value not in (1,2,3):
        return None
    valid_conflicts=[]
    discarded=[]
    for label,cand in (
        ('PRE_SPECIALIZED',hit.get('pre_skill_value')),
        ('GENERIC_CONFIRM',((hit.get('same_frame_numeric_confirm') or {}).get('value'))),
    ):
        if cand is None:
            continue
        try:
            cand=int(cand)
        except Exception:
            continue
        if cand not in (1,2,3):
            discarded.append({'source':label,'value':cand,'reason':'OUT_OF_SKILL_DOMAIN'})
        elif cand != value:
            valid_conflicts.append({'source':label,'value':cand})
    return {
        'authoritative':True,'value':value,'source':source,
        'valid_domain_conflicts':valid_conflicts,
        'discarded_generic_noise':discarded,
        'status':('VALID_DOMAIN_CONFLICT' if valid_conflicts else 'AUTHORITATIVE_SPECIALIZED_SOURCE'),
    }



def _v120_build_stable_visual_rows(pil, boxes, image_stem):
    """Build six stable physical row bands from the original tooltip frame.

    Unlike historical tight foreground rows, the visual recognizer is fed bands
    derived from neighboring baselines / measured line pitch. This preserves
    complete JX1 glyph geometry and prevents 10px-vs-14px crop drift from
    becoming identity evidence.
    """
    centers=[(float(a)+float(b))/2.0 for a,b in (boxes or [])]
    if len(centers)!=6:
        return [],[]
    gaps=[centers[i+1]-centers[i] for i in range(5) if centers[i+1]>centers[i]]
    if not gaps:
        return [],[]
    gs=sorted(gaps); pitch=float(gs[len(gs)//2])
    save=os.environ.get('AUTOPRO_V120_SAVE_VISION_PROOF','1')=='1'
    images=[]; provenance=[]
    for idx,c in enumerate(centers):
        top=((centers[idx-1]+c)/2.0) if idx>0 else c-pitch/2.0
        bot=((c+centers[idx+1])/2.0) if idx<5 else c+pitch/2.0
        margin=max(2,int(round(pitch*0.18)))
        y0=max(0,int(round(top))-margin); y1=min(pil.height,int(round(bot))+margin+1)
        raw=pil.crop((0,y0,pil.width,y1))
        rf=V110_FOREGROUND_EXTRACTOR.extract_single_row(
            raw,idx,proof_dir=(V120_VISION_PROOF_DIR if save else None),
            stem=(f'{image_stem}_vision' if save else None),
        )
        images.append(rf.clean_row_rgb)
        if rf.row_raw_path:
            PROOF_ARTIFACTS.record_artifact(rf.row_raw_path,'option_vision',extra={'image_stem':image_stem,'row_index':idx,'artifact_role':'vision_row_raw'})
        if rf.row_foreground_path:
            PROOF_ARTIFACTS.record_artifact(rf.row_foreground_path,'option_vision',extra={'image_stem':image_stem,'row_index':idx,'artifact_role':'vision_row_foreground'})
        provenance.append({
            'physical_row_index':idx,'physical_band_bbox':[0,y0,pil.width,y1],
            'line_pitch':pitch,'row_raw_sha256':rf.raw_sha256,
            'row_foreground_sha256':rf.foreground_sha256,
            'row_raw_path':rf.row_raw_path,'row_foreground_path':rf.row_foreground_path,
        })
    return images,provenance


def _v120_visual_row_identity(vis, legacy_rid, target_compat):
    """Convert visual-engine output to the stable row-identity contract.

    Legacy OCR identity is retained only as diagnostic evidence. Canonical
    authority belongs to the V12 visual engine.
    """
    vis=vis if isinstance(vis,dict) else {}
    legacy_rid=legacy_rid if isinstance(legacy_rid,dict) else {}
    oid=vis.get('canonical_option_id'); oname=vis.get('canonical_option_name')
    if vis.get('identity_authoritative') and oid and oname:
        meta=option_semantics(oname) or {}
        sem={
            'canonical_option_id':oid,
            'expected_family':meta.get('option_family'),'observed_family':meta.get('option_family'),
            'option_family':meta.get('option_family'),'family_confidence':float(vis.get('best_visual_score') or 0.0),
            'family_source':'CLOSED_WORLD_VISUAL_OPTION','family_status':'FAMILY_MATCH','family_compatible':True,
            'expected_qualifier':meta.get('qualifier'),'observed_qualifier':meta.get('qualifier'),
            'qualifier_status':('NOT_APPLICABLE' if meta.get('qualifier') is None else 'QUALIFIER_MATCH'),
            'qualifier_compatible':True,'expected_unit':meta.get('unit_type'),'observed_unit':meta.get('unit_type'),
            'unit_status':'EXPECTED_UNIT_CONTEXT','unit_compatible':True,'identity_compatible':True,
            'identity_reason':'CLOSED_WORLD_VISUAL_CONFIRMED',
        }
        return {
            'status':'AUTHORITATIVE_IDENTITY','authoritative':True,
            'canonical_option_id':oid,'canonical_option_name':oname,
            'category':next((x.get('category') for x in OPTION_REGISTRY if x.get('id')==oid),None),
            'score':float(vis.get('best_score') or 0.0),'threshold':'V120_VISUAL_ENSEMBLE',
            'semantic_identity':sem,'source':'CLOSED_WORLD_OPTION_VISION_V12_0',
            'candidates':vis.get('candidates') or [],'v120_visual':vis,
            'v120_target_compatibility':target_compat or {},
            'legacy_ocr_identity':legacy_rid,
        }
    # Do not promote legacy OCR to canonical authority when V12 is active.
    return {
        'status':'UNKNOWN_IDENTITY','authoritative':False,
        'reason':vis.get('identity_state') or 'OPTION_UNKNOWN','score':float(vis.get('best_score') or 0.0),
        'best_candidate':vis.get('best_id'),'source':'CLOSED_WORLD_OPTION_VISION_V12_0',
        'candidates':vis.get('candidates') or [],'v120_visual':vis,
        'v120_target_compatibility':target_compat or {},
        'legacy_ocr_identity':legacy_rid,
        'semantic_identity':{
            'observed_family':vis.get('secondary_family_vote'),'observed_qualifier':vis.get('secondary_qualifier_vote'),
            'identity_compatible':False,'identity_reason':'VISUAL_AUTHORITY_NOT_CONFIRMED',
        },
    }


def _v120_rule_compare(op, observed, target):
    op=str(op or 'EXISTS').upper()
    if op=='EXISTS': return True
    try:
        a=float(observed); b=float(target)
    except Exception:
        return None
    if op in ('>=','GE','GTE'): return a>=b
    if op in ('>','GT'): return a>b
    if op in ('<=','LE','LTE'): return a<=b
    if op in ('<','LT'): return a<b
    if op in ('==','=','EQ'): return a==b
    return None


def _v120_evaluate_filter_from_observed(scans, rules):
    """Pure deterministic Filter V2 over canonical ObservedOption objects only.

    Raw OCR strings/fuzzy scores are intentionally absent from this evaluator.
    Perception belongs to the Reader/Vision engine; Filter owns only boolean
    rule evaluation over canonical IDs, units, values and evidence authority.
    """
    complete=[x for x in (scans or []) if x.get('complete') and x.get('v120_closed_world_active')]
    if not complete:
        return None
    results=[]; passed=0; any_unknown=False
    for rule in rules:
        name=str(rule.get('option_name') or '').strip(); op=str(rule.get('op') or rule.get('operator') or 'EXISTS').upper(); target=rule.get('value') if rule.get('value') is not None else rule.get('target')
        meta=option_semantics(name) or {}; oid=meta.get('canonical_option_id')
        frame_states=[]; frame_details=[]
        for scan in complete:
            rows=list(scan.get('v120_row_observations') or [])
            present=[r for r in rows if r.get('identity_authority') and r.get('option_id')==oid]
            if present:
                # Exactly one physical option row is expected; duplicates are a
                # perception contradiction and therefore UNKNOWN.
                if len(present)!=1:
                    frame_states.append('UNKNOWN'); frame_details.append({'state':'UNKNOWN','reason':'DUPLICATE_CANONICAL_OPTION_ROWS','count':len(present)}); continue
                obs=present[0]
                if op=='EXISTS':
                    frame_states.append('PASS'); frame_details.append({'state':'PASS','reason':'CANONICAL_OPTION_PRESENT','observed':obs}); continue
                if not obs.get('numeric_authority') or obs.get('value') is None:
                    frame_states.append('UNKNOWN'); frame_details.append({'state':'UNKNOWN','reason':'TARGET_VALUE_UNKNOWN','observed':obs}); continue
                verdict=_v120_rule_compare(op,obs.get('value'),target)
                if verdict is True:
                    frame_states.append('PASS'); frame_details.append({'state':'PASS','reason':'VALUE_PASS_CONFIRMED','observed':obs}); continue
                if verdict is False:
                    frame_states.append('FAIL'); frame_details.append({'state':'FAIL','reason':'FAIL_VALUE_CONFIRMED','observed':obs}); continue
                frame_states.append('UNKNOWN'); frame_details.append({'state':'UNKNOWN','reason':'OPERATOR_UNKNOWN','observed':obs}); continue
            # No canonical target row. Absence requires six independent visual
            # exclusion certificates for THIS wanted option.
            certs=[]
            for r in rows:
                tc=(r.get('target_compatibility') or {}).get(oid) or {}
                certs.append(tc.get('state'))
            if len(certs)==6 and all(x=='TARGET_EXCLUDED' for x in certs):
                frame_states.append('FAIL'); frame_details.append({'state':'FAIL','reason':'FAIL_ABSENT_CONFIRMED','target_exclusion_states':certs})
            else:
                frame_states.append('UNKNOWN'); frame_details.append({'state':'UNKNOWN','reason':'TARGET_EXCLUSION_INCOMPLETE','target_exclusion_states':certs})

        # Newer authoritative evidence can resolve an earlier UNKNOWN. Conflicting
        # authoritative PASS vs FAIL remains a frame contradiction.
        decisive=[x for x in frame_states if x in ('PASS','FAIL')]
        if decisive and len(set(decisive))>1:
            state='UNKNOWN'; reason='FRAME_CONTRADICTION'; found=None
        elif decisive:
            state=decisive[-1]; reason=('PASS' if state=='PASS' else frame_details[[i for i,x in enumerate(frame_states) if x==state][-1]].get('reason'))
            found=None
            if state in ('PASS','FAIL'):
                for det in reversed(frame_details):
                    if det.get('state')==state and isinstance(det.get('observed'),dict):
                        found=det['observed'].get('value'); break
        else:
            state='UNKNOWN'; reason=(frame_details[-1].get('reason') if frame_details else 'NO_EVIDENCE'); found=None
        if state=='PASS': passed+=1
        elif state=='UNKNOWN': any_unknown=True
        results.append({
            'option_name':name,'option_id':oid,'operator':op,'target':target,
            'passed':state=='PASS','state':('PASS' if state=='PASS' else ('FAIL_VALUE_CONFIRMED' if state=='FAIL' and reason=='FAIL_VALUE_CONFIRMED' else ('FAIL_ABSENT_CONFIRMED' if state=='FAIL' else 'UNKNOWN'))),
            'found_value':found,'reason':reason,'frame_states':frame_states,'frame_details':frame_details,
            'evidence_owner':'OBSERVED_OPTION_FILTER_V12_0',
        })
        # AND profile: any authoritative fail eliminates immediately.
        if state=='FAIL':
            return {
                'decision':'FAIL','filter_result':'REJECT','reject_authority':'AUTHORITATIVE_REJECT',
                'reason':reason,'matched':passed,'enabled':len(rules),'rule_results':results,
                'failed_rule':name,'frames':scans,'fail_fast':True,'skip_review':True,
                'disposition':'REJECT_NOW','pipeline':'OBSERVED_OPTION_FILTER_V12_0',
            }
    if passed==len(rules):
        return {'decision':'PASS','filter_result':'MATCH','reject_authority':'NOT_APPLICABLE','reason':'ALL_CANONICAL_RULES_PASS','matched':passed,'enabled':len(rules),'rule_results':results,'frames':scans,'fail_fast':False,'skip_review':False,'disposition':'KEEP_NOW','pipeline':'OBSERVED_OPTION_FILTER_V12_0'}
    return {'decision':'UNCERTAIN','filter_result':'UNRESOLVED','reject_authority':'UNRESOLVED','reason':'CANONICAL_EVIDENCE_UNRESOLVED','unresolved_reason':'ROW_OR_VALUE_VISUAL_UNKNOWN','matched':passed,'enabled':len(rules),'rule_results':results,'frames':scans,'fail_fast':False,'skip_review':False,'disposition':('RECHECK_PENDING' if len(scans)>=2 else 'RETRY_ONCE'),'pipeline':'OBSERVED_OPTION_FILTER_V12_0'}



def _v171_paddle_row_bridge(image_path, boxes):
    """Run PaddleOCR on the ACTUAL tooltip used by Stage17 fast path.

    V1.7.0 only integrated Paddle in Stage16.read_single_tooltip(), while the
    live configured-filter path normally terminates inside
    _fast_scan_one_crop(). That made Paddle invisible during real FAST_SCAN.

    This bridge is evidence-only:
      * Paddle never decides PASS / FAIL.
      * Paddle never supplies numeric authority.
      * Paddle text is aligned to the six already-proven physical Final6 rows.
      * Existing semantic / vision / unit / numeric truth gates remain owners.
    """
    status = paddleocr_engine_status()
    base = {
        'bridge_version':'PADDLE_RUNTIME_BRIDGE_V1_7_8_UNIQUE_ROW_ASSIGNMENT',
        'available':bool(status.get('available')),
        'initialized':bool(status.get('initialized')),
        'engine_status':status,
        'used':False,
        'rows':[],
        'reason':None,
    }
    if paddleocr_recognize is None:
        base['reason']='PADDLE_RUNTIME_BRIDGE_IMPORT_MISSING'
        return base
    if len(boxes or []) != 6:
        base['reason']='FINAL6_BOXES_NOT_READY'
        return base

    try:
        from PIL import Image
        import numpy as np

        pil = Image.open(Path(image_path)).convert('RGB')

        # V1.7.10 exact workload rootfix: Paddle is NAME/FAMILY evidence for
        # Final6 only, therefore OCRing the title/base-stat half of the tooltip
        # was pure latency.  Crop to the already-proven six-row NAME region at
        # native resolution.  Detection coordinates are translated back to the
        # original tooltip coordinate system before row assignment, so every
        # downstream V1.7.8 truth gate sees identical geometry semantics.
        _pad_y=max(4, int(round(np.median([max(1.0,float(b)-float(a)+1.0) for a,b in boxes])*0.55)))
        roi_y0=max(0,int(boxes[0][0])-_pad_y)
        roi_y1=min(pil.height,int(boxes[-1][1])+_pad_y+1)
        roi_x0=0
        roi_x1=max(1,min(pil.width,int(round(pil.width*0.82))))
        paddle_roi=pil.crop((roi_x0,roi_y0,roi_x1,roi_y1))
        arr = np.asarray(paddle_roi)

        result = paddleocr_recognize(arr, min_score=0.34)
        base['input_policy']='FINAL6_NAME_ROI_NATIVE_V1_7_10'
        base['input_rect']=[int(roi_x0),int(roi_y0),int(roi_x1),int(roi_y1)]
        base['input_size']=[int(paddle_roi.width),int(paddle_roi.height)]
        base['source_tooltip_size']=[int(pil.width),int(pil.height)]
        base['input_area_ratio']=round((float(paddle_roi.width*paddle_roi.height)/max(1.0,float(pil.width*pil.height))),4)
        base['engine_result'] = {
            'ok':bool(result.get('ok')),
            'reason':result.get('reason'),
            'api':result.get('api'),
            'lang':result.get('lang'),
            'ocr_version':result.get('ocr_version'),
            'elapsed_ms':result.get('elapsed_ms'),
        }
        if not result.get('ok'):
            base['reason']=result.get('reason') or 'PADDLEOCR_NO_TEXT'
            return base

        dets=[]
        for d in (result.get('lines') or []):
            box=list(d.get('box') or [])
            text=str(d.get('text') or '').strip()
            if len(box)!=4 or not text:
                continue
            try:
                x0,y0,x1,y1=[float(v) for v in box]
                # Paddle coordinates are ROI-local in V1.7.10.  Restore the
                # original tooltip coordinate frame before unique Final6 align.
                x0+=float(roi_x0); x1+=float(roi_x0)
                y0+=float(roi_y0); y1+=float(roi_y0)
                conf=float(d.get('score') or 0.0)
            except Exception:
                continue
            dets.append({
                'text':text,
                'confidence':conf,
                'box':[x0,y0,x1,y1],
                'center_y':(y0+y1)/2.0,
                'center_x':(x0+x1)/2.0,
            })

        # V1.7.8 unique alignment: one Paddle detection may belong to exactly
        # one physical Final6 row. The previous independent per-row tolerance
        # scan reused the same box in adjacent rows and contaminated semantics.
        aligned=[]
        heights=[max(1.0,float(b)-float(a)+1.0) for a,b in boxes]
        med_h=float(np.median(np.asarray(heights,dtype=float))) if heights else 10.0
        tolerance=max(10.0, med_h*1.20)
        centers=[(float(a)+float(b))/2.0 for a,b in boxes]
        assignments=[[] for _ in boxes]
        unassigned=[]
        for det_index,d in enumerate(dets):
            valid=[]
            dy0,dy1=float(d['box'][1]),float(d['box'][3])
            for row_index,(ry0,ry1) in enumerate(boxes):
                center=centers[row_index]
                dist=abs(float(d['center_y'])-center)
                overlap=max(0.0,min(dy1,float(ry1))-max(dy0,float(ry0)))
                # Center proximity is primary; real vertical overlap is a
                # bounded rescue for a slightly tall Paddle box.
                if dist <= tolerance or overlap > 0.0:
                    valid.append((dist,-overlap,row_index))
            if not valid:
                unassigned.append(det_index)
                continue
            _,_,best_row=min(valid,key=lambda x:(x[0],x[1],x[2]))
            assignments[int(best_row)].append((det_index,d))

        for row_index,(ry0,ry1) in enumerate(boxes):
            center=centers[row_index]
            nearby=[d for _,d in assignments[row_index]]
            nearby.sort(key=lambda d:(d['center_x'], -d['confidence']))

            # Paddle can split one option row into name and numeric boxes. Join
            # left-to-right, but never reuse a physical detection in another row.
            texts=[]; confs=[]; used_boxes=[]
            for d in nearby:
                if d['text'] not in texts:
                    texts.append(d['text'])
                    confs.append(float(d['confidence']))
                    used_boxes.append([round(v,2) for v in d['box']])

            joined=' '.join(texts).strip()
            avg_conf=(sum(confs)/len(confs)) if confs else 0.0
            aligned.append({
                'physical_row_index':int(row_index),
                'text':joined,
                'confidence':round(float(avg_conf),4),
                'boxes':used_boxes,
                'matched_detection_count':len(nearby),
                'row_center_y':round(center,3),
                'tolerance_px':round(tolerance,3),
                'alignment_policy':'UNIQUE_NEAREST_PHYSICAL_ROW_V1_7_8',
            })
        base['alignment_diagnostics']={
            'policy':'UNIQUE_NEAREST_PHYSICAL_ROW_V1_7_8',
            'input_detection_count':len(dets),
            'assigned_detection_count':sum(len(x) for x in assignments),
            'unassigned_detection_count':len(unassigned),
            'duplicate_assignment_count':0,
        }
        base['rows']=aligned
        base['used']=bool(any(r.get('text') for r in aligned))
        base['reason']=None if base['used'] else 'PADDLE_NO_FINAL6_ROW_ALIGNMENT'
        return base
    except Exception as exc:
        base['reason']='PADDLE_RUNTIME_BRIDGE_EXCEPTION'
        base['error']=f'{type(exc).__name__}:{exc}'
        return base


def _v171_best_text_evidence(tesseract_text, paddle_row, option_name):
    """Choose OCR text evidence for NAME/FAMILY matching only.

    Visual row authority remains higher than either OCR engine.
    Numeric extraction remains in the existing VALUE-ROI pipeline.
    """
    tess=str(tesseract_text or '').strip()
    padd=str((paddle_row or {}).get('text') or '').strip()
    pconf=float((paddle_row or {}).get('confidence') or 0.0)

    variants=[]
    if tess:
        ident=_semantic_identity_check(tess,option_name)
        variants.append({
            'source':'TESSERACT_FOREGROUND',
            'raw':tess,
            'score':float(_wanted_lexical_score(tess,option_name)),
            'semantic_identity':ident,
            'confidence':1.0,
        })
    if padd and pconf >= 0.50:
        ident=_semantic_identity_check(padd,option_name)
        variants.append({
            'source':'PADDLE_VI_FULL_TOOLTIP',
            'raw':padd,
            'score':float(_wanted_lexical_score(padd,option_name)),
            'semantic_identity':ident,
            'confidence':pconf,
        })

    if not variants:
        ident=_semantic_identity_check('',option_name)
        return {
            'source':'NO_OCR_TEXT',
            'raw':'',
            'score':0.0,
            'semantic_identity':ident,
            'confidence':0.0,
            'variants':[],
        }

    def _tier(v):
        ident=v.get('semantic_identity') or {}
        if ident.get('identity_compatible'):
            return 3
        if ident.get('family_status')=='FAMILY_UNKNOWN' or ident.get('qualifier_status')=='QUALIFIER_UNKNOWN':
            return 2
        return 1

    best=max(variants,key=lambda v:(_tier(v),float(v.get('score') or 0.0),float(v.get('confidence') or 0.0)))
    return {**best,'variants':variants}

def _v178_canonical_row_text(tesseract_text, paddle_row):
    """Choose family/name text for row perception only, never numeric truth.

    Preserve Tesseract by default. Paddle replaces it only when Paddle is
    high-confidence and supplies a discriminative family that Tesseract lacks.
    This keeps the fusion conservative and target-independent.
    """
    tess=str(tesseract_text or '').strip()
    padd=str((paddle_row or {}).get('text') or '').strip()
    pconf=float((paddle_row or {}).get('confidence') or 0.0)
    tf=_observed_option_family(tess)
    pf=_observed_option_family(padd) if padd else {'family':'UNKNOWN','confidence':0.0}
    tfam=tf.get('family'); pfam=pf.get('family')
    tknown=tfam not in (None,'','UNKNOWN','CONFLICT')
    pknown=pfam not in (None,'','UNKNOWN','CONFLICT')
    if padd and pconf>=0.75 and tknown and pknown and tfam!=pfam:
        # Two independent OCR engines disagree on a discriminative family. Do
        # not silently privilege either one in canonical perception; let visual
        # evidence decide and keep target-specific text as an anti-exclusion
        # safety signal below.
        return {
            'text':'','source':'OCR_FAMILY_CONFLICT','confidence':0.0,
            'family':{'family':'UNKNOWN','confidence':0.0,'source':'MULTIMODAL_FAMILY_CONFLICT'},
            'tesseract_family':tf,'paddle_family':pf,'paddle_confidence':pconf,
        }
    if padd and pconf>=0.75 and pknown and not tknown:
        return {'text':padd,'source':'PADDLE_VI_FAMILY_RESCUE','confidence':pconf,'family':pf}
    if tess:
        return {'text':tess,'source':'TESSERACT_FOREGROUND','confidence':1.0,'family':tf}
    if padd and pconf>=0.75:
        return {'text':padd,'source':'PADDLE_VI_ONLY_TEXT','confidence':pconf,'family':pf}
    return {'text':'','source':'NO_OCR_TEXT','confidence':0.0,'family':{'family':'UNKNOWN','confidence':0.0}}

def _v178_target_compatibility_with_text_veto(row_img, option_name, option_id, tesseract_text, paddle_row):
    """V1.7.13 canonical row-family fusion for target exclusion/compatibility.

    Root cause fixed from logs(20261014-151548): target-specific evidence ranking
    preferred an UNKNOWN Tesseract family over a high-confidence Paddle reading
    of a *different known family*.  That left one row as ROW_UNKNOWN forever,
    so an actually absent mandatory option could never become ABSENT_CONFIRMED.

    The row now gets ONE target-independent canonical family first.  That family
    may prove a cross-family exclusion, but it still cannot create numeric truth.
    Separately, strong target-compatible Paddle evidence retains the V1.7.8
    anti-false-absence veto.  Therefore negative and positive evidence are
    symmetric without granting Paddle PASS/FAIL or numeric authority by itself.
    """
    canonical=_v178_canonical_row_text(tesseract_text,paddle_row)
    cfam=(canonical.get('family') or {}) if isinstance(canonical,dict) else {}
    canonical_raw=str((canonical or {}).get('text') or '')
    best=_v171_best_text_evidence(tesseract_text,paddle_row,option_name)
    ident=best.get('semantic_identity') or {}

    tc=V120_VISION_ENGINE.target_compatibility(
        row_img,option_id,ocr_text=canonical_raw,
        observed_family=cfam.get('family'),
        observed_qualifier=cfam.get('qualifier')
    )
    evidence={
        'source':best.get('source'),'raw':str(best.get('raw') or ''),
        'lexical_score':round(float(best.get('score') or 0.0),4),
        'confidence':round(float(best.get('confidence') or 0.0),4),
        'identity_compatible':bool(ident.get('identity_compatible')),
        'family_status':ident.get('family_status'),'qualifier_status':ident.get('qualifier_status'),
    }
    tc=dict(tc or {})
    tc['target_text_evidence']=evidence
    tc['canonical_row_text_evidence']={
        'source':(canonical or {}).get('source'),'raw':canonical_raw,
        'confidence':round(float((canonical or {}).get('confidence') or 0.0),4),
        'family':cfam.get('family'),'family_confidence':cfam.get('confidence'),
    }

    # Preserve V1.7.8 anti-false-absence behavior.  A strong target-compatible
    # Paddle reading may veto only a visual-only exclusion; it never manufactures
    # canonical identity or numeric value.
    if (
        tc.get('state')=='TARGET_EXCLUDED' and
        tc.get('reason')=='TARGET_VISUAL_EXCLUDED' and
        best.get('source')=='PADDLE_VI_FULL_TOOLTIP' and
        float(best.get('confidence') or 0.0)>=0.75 and
        float(best.get('score') or 0.0)>=0.72 and
        bool(ident.get('identity_compatible'))
    ):
        return {
            **tc,
            'state':'ROW_UNKNOWN',
            'reason':'MULTIMODAL_CONFLICT_PADDLE_TARGET_TEXT_VETO',
            'visual_exclusion_vetoed':True,
            'prior_visual_state':'TARGET_EXCLUDED',
            'prior_visual_reason':'TARGET_VISUAL_EXCLUDED',
            'authority':False,
        }
    return tc


def _fast_scan_one_crop(image_path, rules, profile_scope_value='GLOBAL', paddle_policy='FORCE'):
    """v10.5.2 one-frame Final6 Row-ROI scan with semantic identity before value.

    Six physical option rows are segmented first; per-row NAME ROI drives identity.
    Fuzzy similarity ranks candidates
    only; a rule becomes strong only after FAMILY + QUALIFIER compatibility.
    Targeted rereads are bounded to one already-associated physical row.
    """
    from PIL import Image
    image_path=Path(image_path)
    perf_t0=time.perf_counter()
    _norm_ms=_qual_ms=_numeric_ms=_family_ms=0.0
    _family_rescue_ms=_percent_ms=0.0
    profile_key=profile_key_for_scope(profile_scope_value)
    allowed_profile_options=profile_options(profile_scope_value)
    allowed_profile_ids=profile_option_ids(profile_scope_value)

    seg_t0=time.perf_counter()
    boxes, seg=extract_last6_boxes(image_path, return_debug=True)
    segment_ms=(time.perf_counter()-seg_t0)*1000.0
    if len(boxes)!=6:
        return {
            'complete':False,'reason':'FAST_LAST6_NOT_FOUND','segmentation':seg,
            'raw_block':'','raw_lines':[],'boxes':boxes,'rule_hits':{},
            'timings':{'segment_ms':round(segment_ms,3),'family_eval_ms':0.0,
                       'percent_value_ms':0.0,'targeted_family_rescue_ms':0.0,
                       'targeted_percent_rescue_ms':0.0}
        }

    pil=Image.open(image_path).convert('RGB')
    # V11.0: locate six rows first, then extract accepted foreground glyphs at
    # NATIVE resolution.  Only the clean synthetic buffer is enlarged for OCR.
    fy0=max(0,int(boxes[0][0])-5); fy1=min(pil.height,int(boxes[-1][1])+6)
    name_x1=max(1,int(pil.width*0.78)); value_x0=max(0,int(pil.width*0.42))
    crop_t0=time.perf_counter()
    final6_raw=pil.crop((0,fy0,pil.width,fy1))
    rel_ranges=[[max(0,int(a)-fy0),max(0,int(b)-fy0)] for a,b in boxes]
    save_fg=os.environ.get('AUTOPRO_V110_SAVE_FOREGROUND','1')=='1'
    fg=V110_FOREGROUND_EXTRACTOR.extract_final6(
        final6_raw, rel_ranges,
        proof_dir=(V110_FOREGROUND_PROOF_DIR if save_fg else None),
        stem=(image_path.stem if save_fg else None),
    )
    if not fg.get('ok'):
        return {
            'complete':False,'reason':fg.get('reason') or 'FOREGROUND_EXTRACTION_FAILED',
            'segmentation':seg,'raw_block':'','raw_lines':[],'boxes':boxes,'rule_hits':{},
            'foreground':{'ok':False,'reason':fg.get('reason')},
            'timings':{'segment_ms':round(segment_ms,3),'family_eval_ms':0.0,
                       'percent_value_ms':0.0,'targeted_family_rescue_ms':0.0,
                       'targeted_percent_rescue_ms':0.0}
        }
    final6_foreground=fg['clean_final6_rgb']
    final6_foreground_zoom=fg['clean_final6_zoom4x']
    # Centralized proof ownership: foreground extractor still writes the proven
    # bytes, while V12.1 records build/subsystem metadata in one shared tree.
    for _pp,_role in ((fg.get('final6_raw_path'),'final6_raw'),(fg.get('final6_foreground_path'),'final6_foreground'),(fg.get('final6_foreground_zoom4x_path'),'final6_foreground_zoom4x')):
        if _pp: PROOF_ARTIFACTS.record_artifact(_pp,'foreground',extra={'source_image':str(image_path),'artifact_role':_role})
    for _rp in (fg.get('row_provenance') or []):
        if isinstance(_rp,dict):
            if _rp.get('raw_path'): PROOF_ARTIFACTS.record_artifact(_rp.get('raw_path'),'foreground',extra={'source_image':str(image_path),'row_index':_rp.get('physical_row_index'),'artifact_role':'row_raw'})
            if _rp.get('foreground_path'): PROOF_ARTIFACTS.record_artifact(_rp.get('foreground_path'),'foreground',extra={'source_image':str(image_path),'row_index':_rp.get('physical_row_index'),'artifact_role':'row_foreground'})
    final6_crop_ms=(time.perf_counter()-crop_t0)*1000.0

    # Name OCR is now foreground-clean.  Raw/transparent Final6 is locator and
    # audit evidence only, never the authoritative OCR input.
    name_block=final6_foreground_zoom.crop((
        0,0,min(final6_foreground_zoom.width,name_x1*FINAL6_DIRECT_ZOOM_SCALE),
        final6_foreground_zoom.height
    ))
    actual_name_ocr_input_sha256=hashlib.sha256(name_block.convert('RGB').tobytes()).hexdigest()
    ocr_t0=time.perf_counter()
    _,zoom_name_evidence=_fast_blue_gray_ocr_with_geometry(name_block,block_y0=0,psm=6,timeout=1.35)
    name_line_evidence=[]
    for _e in zoom_name_evidence:
        _bb=_e.get('bbox') or [0,0,0,0]
        name_line_evidence.append({
            'text':_e.get('text',''),
            'bbox':[float(_bb[0])/FINAL6_DIRECT_ZOOM_SCALE,
                    float(fy0)+float(_bb[1])/FINAL6_DIRECT_ZOOM_SCALE,
                    float(_bb[2])/FINAL6_DIRECT_ZOOM_SCALE,
                    float(fy0)+float(_bb[3])/FINAL6_DIRECT_ZOOM_SCALE],
            'center_y':float(fy0)+float(_e.get('center_y',0.0))/FINAL6_DIRECT_ZOOM_SCALE,
        })
    name_ocr_ms=(time.perf_counter()-ocr_t0)*1000.0
    centers=[(float(a)+float(b))/2.0 for a,b in boxes]
    row_evidence=[]; raw_lines=[]
    fg_rows=fg.get('rows') or []
    for idx,(ry0,ry1) in enumerate(boxes):
        py=max(3,int((ry1-ry0)*0.18)); cy0=max(0,int(ry0)-py); cy1=min(pil.height,int(ry1)+py+1)
        near=[e for e in name_line_evidence if abs(float(e.get('center_y',-9999))-centers[idx])<=8.0]
        chosen=min(near,key=lambda e:abs(float(e.get('center_y',-9999))-centers[idx])) if near else None
        raw_name=str((chosen or {}).get('text') or '').strip()
        rp=(fg_rows[idx].public_dict() if idx < len(fg_rows) else {})
        ev={
            'text':raw_name,'raw_name_text':raw_name,
            'bbox':[0.0,float(ry0),float(pil.width),float(ry1)],'center_y':centers[idx],
            'physical_row_index':idx,'source_segment_id':idx,
            'row_bbox':[0,int(cy0),int(pil.width),int(cy1)],'baseline_y':centers[idx],
            'row_height':int(cy1-cy0),'name_roi_bbox':[0,int(cy0),int(name_x1),int(cy1)],
            'value_roi_bbox':[int(value_x0),int(cy0),int(pil.width),int(cy1)],
            'name_ocr_bbox':((chosen or {}).get('bbox')),
            'foreground_provenance':rp,
        }
        row_evidence.append(ev); raw_lines.append(raw_name)
    # V1.7.10 performance ownership: Stage-1 may deliberately defer Paddle.
    # Tesseract + ClosedWorld + numeric readers build a complete preliminary
    # evidence set first.  The profile-level escalation policy decides whether
    # the slow Paddle NAME/FAMILY rescue is actually required.
    _paddle_mode=str(paddle_policy or 'FORCE').upper()
    if _paddle_mode in ('DEFER','SKIP','FAST_ONLY'):
        _paddle_status=paddleocr_engine_status()
        paddle_bridge={
            'bridge_version':'PADDLE_RUNTIME_BRIDGE_V1_7_10_ADAPTIVE',
            'available':bool(_paddle_status.get('available')),
            'initialized':bool(_paddle_status.get('initialized')),
            'engine_status':_paddle_status,
            'used':False,'rows':[],
            'reason':'DEFERRED_BY_ADAPTIVE_PADDLE_POLICY',
            'input_policy':'NOT_RUN_STAGE1_FAST_PATH',
        }
    else:
        paddle_bridge=_v171_paddle_row_bridge(image_path,boxes)
    paddle_rows=list(paddle_bridge.get('rows') or [])
    for idx,ev in enumerate(row_evidence):
        prow=(paddle_rows[idx] if idx < len(paddle_rows) else {})
        ev['tesseract_text']=str(ev.get('text') or '')
        ev['paddle_text']=str(prow.get('text') or '')
        ev['paddle_confidence']=float(prow.get('confidence') or 0.0)
        ev['paddle_runtime_bridge']=prow
        ev['ocr_text_variants']=[
            {'source':'TESSERACT_FOREGROUND','text':ev['tesseract_text'],'confidence':1.0},
            {'source':'PADDLE_VI_FULL_TOOLTIP','text':ev['paddle_text'],'confidence':ev['paddle_confidence']},
        ]
        fused=_v178_canonical_row_text(ev['tesseract_text'],prow)
        ev['canonical_name_text']=str(fused.get('text') or '')
        ev['canonical_name_text_source']=fused.get('source')
        ev['canonical_name_text_confidence']=float(fused.get('confidence') or 0.0)

    ocr_line_evidence=row_evidence
    raw='\n'.join(raw_lines)
    # V12.4 perception: canonical visual authority is unchanged, while
    # high-confidence Paddle may provide NAME/FAMILY secondary evidence.
    semantic_lines=[str(ev.get('canonical_name_text') or ev.get('text') or '') for ev in row_evidence]
    legacy_identity_set=_v110_classify_all_rows(semantic_lines)
    for idx,ev in enumerate(row_evidence):
        ev['row_identity_authority']=((legacy_identity_set.get('rows') or [{}]*6)[idx] if idx < len(legacy_identity_set.get('rows') or []) else {})
    vision_images,vision_prov=_v120_build_stable_visual_rows(pil,boxes,image_path.stem)
    vrows=[]
    wanted_targets=[]
    for rule in rules:
        _name=str(rule.get('option_name') or '').strip(); _meta=option_semantics(_name) or {}
        if _name and _meta.get('canonical_option_id'):
            wanted_targets.append((_name,_meta.get('canonical_option_id')))
    for idx,ev in enumerate(row_evidence):
        legacy=((legacy_identity_set.get('rows') or [{}]*6)[idx] if idx < len(legacy_identity_set.get('rows') or []) else {})
        sem=(legacy.get('semantic_identity') or {}) if isinstance(legacy,dict) else {}
        if idx < len(vision_images):
            canonical_text=str(ev.get('canonical_name_text') or ev.get('text') or '')
            vis=V120_VISION_ENGINE.classify_row(
                vision_images[idx],ocr_text=canonical_text,
                observed_family=sem.get('observed_family'),observed_qualifier=sem.get('observed_qualifier'),
                allowed_option_ids=allowed_profile_ids
            )
            tc={}
            prow=(paddle_rows[idx] if idx < len(paddle_rows) else {})
            for _name,_oid in wanted_targets:
                tc[_oid]=_v178_target_compatibility_with_text_veto(
                    vision_images[idx],_name,_oid,ev.get('tesseract_text') or '',prow
                )
            rid=_v120_visual_row_identity(vis,legacy,tc)

            # V1.7.13 closed-world consistency: once the canonical V12 visual
            # classifier has AUTHORITATIVELY identified this physical row, that
            # single identity owns target compatibility too.  A row cannot be
            # both "Mức kháng tính tối đa" and still remain visually UNKNOWN
            # for whether it is "Kỹ năng Võ công vốn có".  This was the exact
            # deterministic dead-end in logs(20261014-151548).
            #
            # Preserve the V1.7.8 positive-text veto: if strong target-compatible
            # Paddle text explicitly conflicts with the visual identity, keep
            # ROW_UNKNOWN instead of manufacturing a negative certificate.
            if rid.get('authoritative') and rid.get('canonical_option_id'):
                _row_oid=str(rid.get('canonical_option_id'))
                _row_oname=str(rid.get('canonical_option_name') or '')
                for _target_name,_target_oid in wanted_targets:
                    _target_oid=str(_target_oid)
                    _prior=dict(tc.get(_target_oid) or {})
                    if _target_oid == _row_oid:
                        tc[_target_oid]={
                            **_prior,
                            'state':'TARGET_COMPATIBLE',
                            'reason':'CANONICAL_ROW_IDENTITY_MATCH',
                            'authority':True,
                            'canonical_row_option_id':_row_oid,
                            'canonical_row_option_name':_row_oname,
                        }
                    elif not (
                        _prior.get('state')=='ROW_UNKNOWN' and
                        _prior.get('reason')=='MULTIMODAL_CONFLICT_PADDLE_TARGET_TEXT_VETO'
                    ):
                        tc[_target_oid]={
                            **_prior,
                            'state':'TARGET_EXCLUDED',
                            'reason':'CANONICAL_OTHER_OPTION_IDENTITY',
                            'authority':True,
                            'canonical_row_option_id':_row_oid,
                            'canonical_row_option_name':_row_oname,
                            'excluded_target_option_id':_target_oid,
                            'excluded_target_option_name':_target_name,
                        }
                    else:
                        tc[_target_oid]={
                            **_prior,
                            'canonical_row_identity_conflict':True,
                            'canonical_row_option_id':_row_oid,
                            'canonical_row_option_name':_row_oname,
                        }

            ev['v120_visual']=vis; ev['v120_target_compatibility']=tc
            ev['vision_physical_row_provenance']=(vision_prov[idx] if idx < len(vision_prov) else {})
        else:
            rid=_v120_visual_row_identity({},legacy,{})
            ev['v120_visual']={'identity_state':'OPTION_UNKNOWN','reason':'PHYSICAL_ROW_BUILD_FAILED'}
            ev['v120_target_compatibility']={}
        ev['row_identity_authority']=rid; vrows.append(rid)
    row_identity_set={
        'rows':vrows,'row_count':len(vrows),
        'all_six_identity_authoritative':bool(len(vrows)==6 and all(bool(x.get('authoritative')) for x in vrows)),
        'authoritative_option_names':[x.get('canonical_option_name') for x in vrows if x.get('authoritative')],
        'unknown_row_indices':[i for i,x in enumerate(vrows) if not x.get('authoritative')],
        'vision_version':V120_VISION_VERSION,'legacy_ocr_identity_set':legacy_identity_set,
    }

    hits={}
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        if not name:
            continue
        _t=time.perf_counter(); target_tokens=set(_wanted_norm_text(name).split()); _norm_ms+=(time.perf_counter()-_t)*1000.0
        threshold=0.72 if len(target_tokens)<=2 else 0.64
        near_floor=max(0.48,threshold-0.10)
        candidates=[]
        for raw_idx,line in enumerate(raw_lines):
            ev=(ocr_line_evidence[raw_idx] if raw_idx < len(ocr_line_evidence) else {})
            prow=(paddle_rows[raw_idx] if raw_idx < len(paddle_rows) else {})
            _t=time.perf_counter()
            text_ev=_v171_best_text_evidence(line,prow,name)
            lexical=float(text_ev.get('score') or 0.0)
            _norm_ms+=(time.perf_counter()-_t)*1000.0
            _t=time.perf_counter()
            ident=text_ev.get('semantic_identity') or _semantic_identity_check(text_ev.get('raw',''),name)
            _family_ms+=(time.perf_counter()-_t)*1000.0
            effective_line=str(text_ev.get('raw') or line or '')
            # Identity precedes numeric authority in v10.5.2. Paddle/Tesseract
            # NAME evidence may associate a physical row with a wanted option,
            # but numeric authority still comes only from the existing VALUE ROI.
            value=None
            # V11.0 full-row identity is independent evidence.  A row that the
            # 34-option classifier identifies authoritatively as THIS wanted
            # option outranks fuzzy/semantic uncertainty, but still supplies no
            # numeric value by itself.
            row_auth=ev.get('row_identity_authority') or {}
            row_authoritative_match=bool(
                row_auth.get('authoritative')
                and row_auth.get('canonical_option_name')==name
            )
            # Tier 4 = authoritative full-row identity, tier 3 = semantic identity,
            # tier 2 = genuinely unresolved family/qualifier, tier 1 = contradiction.
            if row_authoritative_match:
                tier=4
            elif ident.get('identity_compatible'):
                tier=3
            elif ident.get('family_status')=='FAMILY_UNKNOWN' or ident.get('qualifier_status')=='QUALIFIER_UNKNOWN':
                tier=2
            else:
                tier=1
            candidates.append({
                'tier':tier,'score':float(lexical),'raw':effective_line,'value':value,
                'ocr_text_source':text_ev.get('source'),
                'ocr_text_confidence':text_ev.get('confidence'),
                'ocr_text_variants':text_ev.get('variants') or [],
                'tesseract_raw':str(line or ''),
                'paddle_raw':str(prow.get('text') or ''),
                'paddle_confidence':float(prow.get('confidence') or 0.0),
                'raw_line_index':raw_idx,'physical_row_index':ev.get('physical_row_index'),
                'text_bbox':ev.get('bbox'),'baseline_y':ev.get('center_y'),
                'source_segment_id':ev.get('physical_row_index'),
                'value_source':('PRIMARY_ROW_VALUE' if value is not None else None),
                'row_identity_authority':row_auth,
                'row_authoritative_match':row_authoritative_match,
                'semantic_identity':ident,'qualifier_check':{
                    'required':ident.get('expected_qualifier') is not None,
                    'expected':ident.get('expected_qualifier'),
                    'observed':ident.get('observed_qualifier'),
                    'status':ident.get('qualifier_status'),
                    'compatible':ident.get('qualifier_compatible'),
                },
            })

        # Never let a higher fuzzy score from a wrong family outrank a lower
        # score candidate whose family is structurally correct.
        if candidates:
            max_tier=max(c['tier'] for c in candidates)
            pool=[c for c in candidates if c['tier']==max_tier]
            best=max(pool,key=lambda c:(c['score'], c.get('value') is not None))
        else:
            best={
                'tier':0,'score':0.0,'raw':'','value':None,'raw_line_index':None,
                'physical_row_index':None,'semantic_identity':_semantic_identity_check('',name),
                'qualifier_check':_semantic_qualifier_check('',name),
            }
        ident=best.get('semantic_identity') or _semantic_identity_check(best.get('raw',''),name)
        best['fuzzy_score']=round(float(best.get('score') or 0.0),4)
        best['strong_name']=bool(
            best.get('row_authoritative_match')
            or (float(best.get('score') or 0.0)>=threshold and ident.get('identity_compatible'))
        )
        if best.get('row_authoritative_match'):
            best['strong_name_promoted_by']='V11_FULL_ROW_IDENTITY_AUTHORITY'
        best['threshold']=threshold
        best['family_unknown_near']=any(
            c['tier']==2 and c['score']>=near_floor for c in candidates
        )
        best['family_contradiction_near']=any(
            c['tier']==1 and c['score']>=near_floor and
            (c.get('semantic_identity') or {}).get('family_status')=='SEMANTIC_FAMILY_CONTRADICTION'
            for c in candidates
        )
        best['candidate_semantics']=[{
            'raw':c['raw'],'fuzzy_score':round(c['score'],4),'tier':c['tier'],
            'observed_family':(c.get('semantic_identity') or {}).get('observed_family'),
            'family_status':(c.get('semantic_identity') or {}).get('family_status'),
            'qualifier_status':(c.get('semantic_identity') or {}).get('qualifier_status'),
        } for c in sorted(candidates,key=lambda c:c['score'],reverse=True)[:6]]
        best['option_family']=ident.get('observed_family')
        best['expected_family']=ident.get('expected_family')
        best['observed_family']=ident.get('observed_family')
        best['family_confidence']=ident.get('family_confidence')
        best['family_source']=ident.get('family_source')
        best['family_compatible']=ident.get('family_compatible')
        best['expected_qualifier']=ident.get('expected_qualifier')
        best['observed_qualifier']=ident.get('observed_qualifier')
        best['expected_unit']=ident.get('expected_unit')
        best['observed_unit']=ident.get('observed_unit')
        best['unit_status']=ident.get('unit_status')
        best['unit_compatible']=ident.get('unit_compatible')
        best['numeric_raw']=best.get('value')
        best['numeric_value']=best.get('value')
        best['numeric_source']=best.get('value_source')
        # Non-attack-speed values retain legacy authority. ATTACK_SPEED is
        # resolved below by the shared percent reader.
        best['numeric_authoritative']=(None if ident.get('expected_family')=='ATTACK_SPEED' else bool(best.get('value') is not None and ident.get('unit_compatible')))
        hits[name]=best

    out={
        'complete':True,'reason':'FINAL6_FOREGROUND_ROW_SCANNED_V11_2','segmentation':seg,
        'pipeline':'FINAL6_FOREGROUND_ROW_V11_2','primary_ocr_domain':'FINAL6_PHYSICAL_ROWS',
        'primary_ocr_source':'FINAL6_FOREGROUND_SYNTHETIC_ZOOM4X','full_tooltip_primary_ocr':False,'master_frame_count':1,
        'foreground_extractor_version':V110_FOREGROUND_EXTRACTOR_VERSION,
        'tooltip_locator_rect':[0,0,int(pil.width),int(pil.height)],
        'final6_rect':[0,int(fy0),int(pil.width),int(fy1)],
        'final6_crop_size':[int(pil.width),int(max(0,fy1-fy0))],
        'final6_zoom_scale':FINAL6_DIRECT_ZOOM_SCALE,'row_count':6,
        'raw_final6_sha256':fg.get('raw_final6_sha256'),
        'foreground_final6_sha256':fg.get('clean_final6_sha256'),
        'foreground_zoom4x_sha256':fg.get('clean_final6_zoom4x_sha256'),
        'actual_name_ocr_input_sha256':actual_name_ocr_input_sha256,
        'foreground_proof_paths':{
            'final6_raw':fg.get('final6_raw_path'),
            'final6_foreground':fg.get('final6_foreground_path'),
            'final6_foreground_zoom4x':fg.get('final6_foreground_zoom4x_path'),
        },
        'row_foreground_provenance':fg.get('row_provenance') or [],
        'row_identity_set':row_identity_set,
        'all_six_identity_authoritative':bool(row_identity_set.get('all_six_identity_authoritative')),
        'paddle_runtime_bridge':paddle_bridge,
        'paddle_runtime_used':bool(paddle_bridge.get('used')),
        'paddle_runtime_status':paddle_bridge.get('reason') or ('ACTIVE' if paddle_bridge.get('used') else 'INACTIVE'),
        'profile_registry':{
            'version':PROFILE_REGISTRY_VERSION,'scope_value':profile_scope_value,'profile_key':profile_key,
            'allowed_option_count':len(allowed_profile_options),'allowed_options':allowed_profile_options,
            'allowed_option_ids':allowed_profile_ids,
        },
        'raw_block':raw,'raw_lines':raw_lines,'ocr_line_evidence':ocr_line_evidence,'row_evidence':row_evidence,'boxes':boxes,'rule_hits':hits,
        'timings':{'tooltip_locate_ms':0.0,'final6_crop_ms':round(final6_crop_ms,3),'segmentation_ms':round(segment_ms,3),
                   'segment_ms':round(segment_ms,3),'name_ocr_ms':round(name_ocr_ms,3),'value_ocr_ms':0.0,
                   'blue_ocr_ms':round(name_ocr_ms,3),'gray_ocr_ms':0.0,
                   'normalize_ms':round(_norm_ms,3),'qualifier_ms':round(_qual_ms,3),
                   'family_eval_ms':round(_family_ms,3),'numeric_ms':round(_numeric_ms,3),
                   'targeted_family_rescue_ms':0.0,'percent_value_ms':0.0,
                   'targeted_percent_rescue_ms':0.0,'targeted_rescue_ms':0.0}
    }
    rescue_t0=time.perf_counter()

    # v10.5 bounded family/qualifier rescue. Only UNKNOWN identity may be
    # reread; a known cross-family contradiction is final for that candidate.
    fam_rescue_t0=time.perf_counter()
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        hit=hits.get(name) or {}
        if hit.get('strong_name'):
            continue
        if not hit.get('family_unknown_near'):
            continue
        rescue=_fast_family_identity_rescue(image_path,out,name)
        hit['family_rescue']=rescue
        if not rescue or not rescue.get('attempted'):
            continue
        ident=rescue.get('semantic_identity') or {}
        lexical=float(rescue.get('score') or 0.0)
        if ident.get('identity_compatible') and lexical>=float(hit.get('threshold') or 1.0):
            hit['raw_before_family_rescue']=hit.get('raw')
            hit['raw']=rescue.get('raw') or hit.get('raw')
            hit['score']=lexical; hit['fuzzy_score']=round(lexical,4)
            hit['semantic_identity']=ident
            hit['qualifier_check']={
                'required':ident.get('expected_qualifier') is not None,
                'expected':ident.get('expected_qualifier'),'observed':ident.get('observed_qualifier'),
                'status':ident.get('qualifier_status'),'compatible':ident.get('qualifier_compatible'),
            }
            for key in ('option_family','expected_family','observed_family','family_confidence','family_source','family_compatible','expected_qualifier','observed_qualifier','expected_unit','observed_unit','unit_status','unit_compatible'):
                src_key={'option_family':'observed_family'}.get(key,key)
                hit[key]=ident.get(src_key)
            hit['strong_name']=True
            hit['strong_name_promoted_by']='TARGETED_FAMILY_RESCUE_V10_5'
            # NAME-ROI rescue cannot donate numeric authority. VALUE-ROI
            # processing below remains the sole numeric owner.
    _family_rescue_ms=(time.perf_counter()-fam_rescue_t0)*1000.0

    # OPTION_UNIT_REGISTRY_V1 gate. Numeric evidence is routed only after
    # family/qualifier identity and expected-unit compatibility are known.
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        hit=hits.get(name) or {}
        uc=_unit_contract_check(hit.get('raw',''),name)
        hit.update(uc)
        if uc.get('unit_status')=='UNIT_MISMATCH':
            hit['numeric_authoritative']=False
            hit['numeric_reason']='UNIT_MISMATCH'

    # Preserve proven skill +1/+2/+3 authority.
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        hit=hits.get(name) or {}
        is_skill=(option_semantics(name).get('option_family')=='SKILL_LEVEL')
        if not is_skill:
            continue
        score=float(hit.get('score') or 0.0)
        if not hit.get('strong_name') and score < 0.50:
            continue
        # Never let orange numerics repair a known wrong family.
        ident=hit.get('semantic_identity') or _semantic_identity_check(hit.get('raw',''),name)
        if ident.get('family_status')=='SEMANTIC_FAMILY_CONTRADICTION':
            continue
        skill_value=_fast_skill_level_orange_rescue(image_path,out,name)
        if skill_value and skill_value.get('value') is not None:
            hit['pre_skill_value']=hit.get('value')
            hit['pre_skill_value_source']=hit.get('value_source')
            hit['value']=skill_value.get('value')
            hit['value_source']=skill_value.get('source') or 'SKILL_ORANGE_VALUE_V10_4_2'
            hit['numeric_value']=hit['value']; hit['numeric_source']=hit['value_source']; hit['numeric_authoritative']=True
            hit['skill_color_rescue']=skill_value
            hit['skill_numeric_authority']=_skill_authority_resolution(hit)
            if not hit.get('strong_name') and ident.get('family_compatible') and ident.get('qualifier_compatible'):
                hit['strong_name']=True
                hit['strong_name_promoted_by']='SKILL_NAME_NEAR_PLUS_ORANGE_VALUE_V9_9'

    # v10.5 ATTACK_SPEED authority ALWAYS runs on a strong semantically valid
    # row, even when generic OCR already appears to pass the threshold. This is
    # what prevents +44% => 448 from becoming an early PASS.
    pct_t0=time.perf_counter()
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        hit=hits.get(name) or {}
        if not hit.get('strong_name'):
            continue
        meta=option_semantics(name)
        if meta.get('option_family')!='ATTACK_SPEED':
            continue
        if hit.get('unit_status')=='UNIT_MISMATCH':
            hit['value']=None; hit['numeric_value']=None; hit['numeric_authoritative']=False
            hit['numeric_reason']='UNIT_MISMATCH'
            continue
        generic=hit.get('value')
        hit['generic_numeric_value']=generic
        hit['generic_numeric_source']=hit.get('value_source')
        percent=_fast_attack_speed_rgb_rescue(image_path,out,name)
        hit['attack_speed_percent_authority']=percent
        if percent and percent.get('authoritative') and percent.get('value') is not None:
            hit['value']=int(percent.get('value'))
            hit['value_source']='ATTACK_SPEED_PERCENT_AUTHORITY'
            hit['numeric_value']=hit['value']
            hit['numeric_source']='ATTACK_SPEED_PERCENT_AUTHORITY'
            hit['numeric_authoritative']=True
            hit['observed_unit']='PERCENT'
            hit['numeric_reason']='PERCENT_VALUE_AUTHORITATIVE'
            if percent.get('generic_conflict'):
                hit['generic_percent_glyph_corruption_rejected']=True
                hit['generic_reject_reason']='GENERIC_PERCENT_GLYPH_CORRUPTION_REJECTED'
        else:
            # Never leave generic 448 (or any unsigned integer) in the value
            # slot where normal threshold logic could accidentally PASS it.
            hit['value']=None
            hit['value_source']='NON_AUTHORITATIVE_GENERIC_VALUE'
            hit['numeric_value']=None
            hit['numeric_source']='NON_AUTHORITATIVE_GENERIC_VALUE'
            hit['numeric_authoritative']=False
            hit['numeric_reason']='VALUE_UNRESOLVED'
    _percent_ms=(time.perf_counter()-pct_t0)*1000.0

    # V1.7.5 user-taught NUMBER-ONLY percent authority. This is deliberately
    # narrower than the generic percent parser: only three explicitly taught
    # options may omit the '%' glyph, and only after NAME/FAMILY identity is strong.
    taught_pct_t0=time.perf_counter()
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        if not implicit_percent_number_only(name):
            continue
        hit=hits.get(name) or {}
        if not hit.get('strong_name'):
            continue
        if hit.get('unit_status')=='UNIT_MISMATCH':
            hit['value']=None; hit['numeric_value']=None; hit['numeric_authoritative']=False
            hit['numeric_reason']='UNIT_MISMATCH'
            continue
        rescue=_fast_same_frame_numeric_rescue(image_path,out,name)
        hit['implicit_percent_number_rescue']=rescue
        if rescue and rescue.get('value') is not None:
            hit['value']=int(rescue.get('value'))
            hit['value_source']='IMPLICIT_PERCENT_NATIVE_CONSENSUS_V1_7_13'
            hit['numeric_value']=hit['value']
            hit['numeric_source']=hit['value_source']
            hit['numeric_authoritative']=True
            hit['observed_unit']='PERCENT'
            hit['numeric_reason']='IMPLICIT_PERCENT_NATIVE_CONSENSUS_AUTHORITATIVE'
        else:
            hit['value']=None; hit['numeric_value']=None; hit['numeric_authoritative']=False
            hit['numeric_reason']='USER_TAUGHT_PERCENT_VALUE_UNRESOLVED'
    _percent_ms+=(time.perf_counter()-taught_pct_t0)*1000.0

    # V1.7.13 canonical numeric authority for every other strongly identified
    # configured row. V12 closed-world Filter returns before the historical
    # v9 rescue below, so generic PERCENT/POINT rules such as ``Kháng tất cả``
    # previously reached Filter with identity but no numeric value forever.
    # Run the same-row VALUE reader here, before ObservedOption is frozen.
    general_numeric_t0=time.perf_counter()
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        hit=hits.get(name) or {}
        if not hit.get('strong_name') or hit.get('numeric_authoritative'):
            continue
        op=str(rule.get('op') or rule.get('operator') or 'EXISTS').upper()
        if op=='EXISTS':
            continue
        fam=(option_semantics(name) or {}).get('option_family')
        if fam in ('ATTACK_SPEED','SKILL_LEVEL'):
            continue
        rescue=_fast_same_frame_numeric_rescue(image_path,out,name)
        hit['v1713_general_numeric_rescue']=rescue
        if rescue and rescue.get('value') is not None:
            hit['value']=int(rescue.get('value'))
            hit['value_source']='VALUE_ROI_NATIVE_CONSENSUS_V1_7_13'
            hit['numeric_value']=hit['value']
            hit['numeric_source']=hit['value_source']
            hit['numeric_authoritative']=True
            hit['observed_unit']=rescue.get('expected_unit') or hit.get('observed_unit')
            hit['numeric_reason']='CANONICAL_SAME_ROW_VALUE_AUTHORITY'
    _percent_ms+=(time.perf_counter()-general_numeric_t0)*1000.0

    # Retain v10.2 shared VALUE_TOKEN repair for NON-attack-speed families only.
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        hit=hits.get(name) or {}
        if option_semantics(name).get('option_family')=='ATTACK_SPEED':
            continue
        if not hit.get('strong_name') or hit.get('value') is None:
            continue
        try:
            iv=abs(int(hit.get('value')))
        except Exception:
            continue
        if iv < 1000 or not str(iv).endswith('8'):
            continue
        rescue=_fast_general_value_token_rescue(image_path,out,name)
        if rescue and rescue.get('value') is not None:
            newv=int(rescue.get('value'))
            if abs(newv) < iv:
                hit['pre_value_token_rescue']=hit.get('value')
                hit['value']=newv
                hit['value_source']='VALUE_TOKEN_RGB_V10_2'
                hit['value_token_rescue']=rescue
                hit['numeric_value']=newv; hit['numeric_source']='VALUE_TOKEN_RGB_V10_2'; hit['numeric_authoritative']=True

    # Same-frame failing numeric confirmation stays unchanged for non-speed
    # options. ATTACK_SPEED may only use percent-authoritative evidence.
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        hit=hits.get(name) or {}
        if not hit.get('strong_name') or hit.get('value') is None:
            continue
        op=str(rule.get('op','EXISTS')).upper()
        if op=='EXISTS' or _wanted_rule_ok(rule, {'value':hit.get('value')}):
            continue
        if option_semantics(name).get('option_family')=='ATTACK_SPEED':
            hit['same_frame_numeric_confirm_skipped']='ATTACK_SPEED_PERCENT_AUTHORITY_V10_5'
            continue
        skill_auth=_skill_authority_resolution(hit)
        if skill_auth and skill_auth.get('status')=='AUTHORITATIVE_SPECIALIZED_SOURCE':
            hit['same_frame_numeric_confirm_skipped']='AUTHORITATIVE_SKILL_VALUE_V10_2'
            hit['skill_numeric_authority']=skill_auth
            continue
        confirm=_fast_same_frame_numeric_rescue(image_path,out,name)
        if confirm and confirm.get('value') is not None:
            hit['same_frame_numeric_confirm']=confirm
            hit['same_frame_numeric_confirmed']=bool(int(confirm.get('value'))==int(hit.get('value')))

    # Final per-row trace.  Every row keeps its full-registry identity authority,
    # while numeric fields are attached only from a wanted rule whose local value
    # reader became authoritative.
    for ev in out.get('row_evidence') or []:
        idx=ev.get('physical_row_index')
        rid=ev.get('row_identity_authority') or {}
        cand=[]
        for opt,hit in hits.items():
            if hit.get('physical_row_index')==idx and hit.get('strong_name'):
                cand.append((float(hit.get('score') or 0.0),opt,hit))
        if cand:
            _,opt,hit=max(cand,key=lambda x:x[0]); ident=hit.get('semantic_identity') or {}
            ev.update({
                'canonical_option_id':(rid.get('canonical_option_id') or ident.get('canonical_option_id')),
                'canonical_option_name':opt,
                'family':ident.get('observed_family'),
                'qualifier':ident.get('observed_qualifier'),
                'expected_unit':hit.get('expected_unit'),
                'identity_confidence':max(round(float(hit.get('score') or 0.0),4),float(rid.get('score') or 0.0)),
                'identity_authoritative':True,
                'raw_value_candidates':((hit.get('attack_speed_percent_authority') or {}).get('reads') or ([str((hit.get('numeric_rescue') or {}).get('raw') or '')] if hit.get('numeric_rescue') else [])),
                'canonical_value':hit.get('value'),
                'numeric_authoritative':bool(hit.get('numeric_authoritative')),
                'numeric_source':hit.get('numeric_source') or hit.get('value_source'),
                'final_row_status':('AUTHORITATIVE' if hit.get('numeric_authoritative') else 'IDENTITY_ONLY'),
            })
        elif rid.get('authoritative'):
            sem=rid.get('semantic_identity') or {}
            ev.update({
                'canonical_option_id':rid.get('canonical_option_id'),
                'canonical_option_name':rid.get('canonical_option_name'),
                'family':sem.get('observed_family') or sem.get('expected_family'),
                'qualifier':sem.get('observed_qualifier') or sem.get('expected_qualifier'),
                'expected_unit':sem.get('expected_unit'),
                'identity_confidence':float(rid.get('score') or 0.0),
                'identity_authoritative':True,
                'raw_value_candidates':[],
                'canonical_value':None,'numeric_authoritative':False,'numeric_source':None,
                'final_row_status':'IDENTITY_ONLY',
            })
        else:
            ev.update({'canonical_option_id':None,'canonical_option_name':None,'family':None,'qualifier':None,
                       'expected_unit':None,'identity_confidence':0.0,'identity_authoritative':False,
                       'raw_value_candidates':[],'canonical_value':None,'numeric_authoritative':False,
                       'numeric_source':None,'final_row_status':'UNKNOWN_IDENTITY'})

    # Canonical six-row perception object consumed by Filter V2. Raw OCR text
    # is deliberately excluded from the Filter contract.
    v120_obs=[]
    for ev in out.get('row_evidence') or []:
        rid=ev.get('row_identity_authority') or {}
        sem=rid.get('semantic_identity') or {}
        v120_obs.append({
            'physical_row_index':ev.get('physical_row_index'),
            'option_id':ev.get('canonical_option_id') if ev.get('identity_authoritative') else None,
            'option_name':ev.get('canonical_option_name') if ev.get('identity_authoritative') else None,
            'family':ev.get('family') or sem.get('observed_family'),
            'qualifier':ev.get('qualifier') or sem.get('observed_qualifier'),
            'unit':ev.get('expected_unit') or sem.get('expected_unit'),
            'value':ev.get('canonical_value'),
            'identity_authority':bool(ev.get('identity_authoritative')),
            'numeric_authority':bool(ev.get('numeric_authoritative')),
            'identity_source':rid.get('source'),
            'numeric_source':ev.get('numeric_source'),
            'evidence_id':(ev.get('vision_physical_row_provenance') or {}).get('row_foreground_sha256') or (ev.get('foreground_provenance') or {}).get('row_foreground_sha256'),
            'vision':ev.get('v120_visual') or {},
            'target_compatibility':ev.get('v120_target_compatibility') or {},
        })
    out['v120_row_observations']=v120_obs
    out['v120_closed_world_active']=bool(len(v120_obs)==6)
    out['v120_vision_version']=V120_VISION_VERSION
    out['pipeline']='CLOSED_WORLD_OPTION_VISION_V12_0'

    out['timings']['targeted_family_rescue_ms']=round(_family_rescue_ms,3)
    out['timings']['percent_value_ms']=round(_percent_ms,3)
    out['timings']['targeted_percent_rescue_ms']=round(_percent_ms,3)
    out['timings']['targeted_rescue_ms']=round((time.perf_counter()-rescue_t0)*1000.0,3)
    out['timings']['value_ocr_ms']=round(_percent_ms,3)
    out['timings']['total_scan_ms']=round((time.perf_counter()-perf_t0)*1000.0,3)
    try:
        # V11.0 proof is created by the same extractor that produced the actual
        # OCR buffer.  Raw transparent pixels are saved only for comparison.
        out['final6_raw_path']=fg.get('final6_raw_path')
        out['final6_foreground_path']=fg.get('final6_foreground_path')
        out['final6_foreground_zoom4x_path']=fg.get('final6_foreground_zoom4x_path')
        out['ocr_input_sha256']=fg.get('clean_final6_zoom4x_sha256')
        out['ocr_input_width']=int(final6_foreground_zoom.width)
        out['ocr_input_height']=int(final6_foreground_zoom.height)
        out['ocr_input_stage']='FINAL6_FOREGROUND_SYNTHETIC_ZOOM4X'
        out['primary_ocr_source']='FINAL6_FOREGROUND_SYNTHETIC_ZOOM4X'
        out['final6_row_count']=6
        out['debug_artifacts']={
            'final6_raw':fg.get('final6_raw_path'),
            'final6_foreground':fg.get('final6_foreground_path'),
            'final6_foreground_zoom4x':fg.get('final6_foreground_zoom4x_path'),
            'pre_normalization_stage':'FINAL6_RAW_NATIVE',
            'actual_ocr_input_stage':'FINAL6_FOREGROUND_SYNTHETIC_ZOOM4X',
            'row_proofs':fg.get('row_provenance') or [],
        }
    except Exception as _v110_dbg_e:
        out['final6_debug_error']=str(_v110_dbg_e)
    return out


def _fast_evaluate_filter(image_paths, filter_config, precomputed_scans=None):
    """v8.0 fail-fast evaluator for ACTIVE configured rules.

    ALL-CONDITIONS remains the filter contract: every enabled configured rule
    must pass, but each wanted option may appear in ANY of the six final rows.

    v8.8 adds value-safe behavior:
      * one confident passing numeric read is enough to preserve a wanted item;
      * a single failing numeric read never sells immediately -- it earns frame 2;
      * after frame 2, numeric FAIL is conclusive only when failing evidence agrees;
      * strong wanted-name + unresolved/conflicting numeric evidence is NEED_REVIEW,
        never automatic SELL/DROP.

    Obvious items with absent wanted names still use the fast-reject path.
    """
    rules=[
        r for r in (filter_config or {}).get('rules',[])
        if bool(r.get('enabled',True)) and str(r.get('option_name') or '').strip()
    ]
    if not rules:
        return {'decision':'NO_FILTER','reason':'NO_ENABLED_SEARCH_RULES','frames':[]}

    # Canonical contract stays ALL. We intentionally do not weaken the user's
    # existing filter semantics while accelerating negative decisions.
    mode='ALL'
    scans=list(precomputed_scans) if precomputed_scans is not None else [_fast_scan_one_crop(p,rules,(filter_config or {}).get('scope_value','GLOBAL')) for p in image_paths]
    complete=[x for x in scans if x.get('complete')]
    if not complete:
        # V11.0 three-state truth: failure to obtain six authoritative rows is
        # UNKNOWN, never evidence that the wanted option is absent.
        return {
            'decision':'UNCERTAIN','filter_result':'UNRESOLVED',
            'reject_authority':'UNRESOLVED',
            'reason':('FINAL6_NOT_FOUND_AFTER_RETRY' if len(scans)>=2 else 'FAST_TOOLTIP_SCAN_INCOMPLETE'),
            'frames':scans,'mode':mode,'matched':0,'enabled':len(rules),
            'rule_results':[], 'fail_fast':False,'skip_review':False,
            'disposition':('RECHECK_PENDING' if len(scans)>=2 else 'RETRY_ONCE'),
            'pipeline':'FINAL6_FOREGROUND_ROW_V11_2'
        }

    # V12.0 production Filter authority: canonical ObservedOption only.
    # If closed-world perception is active, legacy OCR/fuzzy evaluation below
    # is intentionally bypassed. Raw OCR remains diagnostic evidence only.
    v120_result=_v120_evaluate_filter_from_observed(scans,rules)
    if v120_result is not None:
        return v120_result

    # v9.0 WANT-VALUE RESCUE -------------------------------------------------
    # Run targeted numeric OCR on EVERY complete frame whose wanted NAME is
    # already strong but whose whole-block OCR lost the value. v8.8 only did
    # this on the first frame; once a second frame existed the rescue was
    # skipped entirely, which could strand a valid +1/+2 item in NEED_REVIEW.
    # This remains cheap: it runs only on strongly matched configured rows.
    for src_i,(image_path,scan) in enumerate(zip(image_paths,scans),1):
        if not scan.get('complete'):
            continue
        for rule in rules:
            name=str(rule.get('option_name') or '').strip()
            hit=((scan.get('rule_hits') or {}).get(name) or {})
            if not hit.get('strong_name') or hit.get('value') is not None:
                continue
            if option_semantics(name).get('option_family')=='ATTACK_SPEED':
                # The shared percent-authority reader already owns this row.
                # Never fall back to generic integer OCR for attack speed.
                continue
            rescue=_fast_same_frame_numeric_rescue(image_path,scan,name)
            if rescue and rescue.get('value') is not None:
                hit['value']=rescue.get('value')
                hit['value_source']='VALUE_ROI_V10_5_2'
                hit['numeric_value']=hit['value']; hit['numeric_source']='VALUE_ROI_V10_5_2'
                hit['numeric_authoritative']=True
                hit['observed_unit']=rescue.get('expected_unit') or hit.get('observed_unit')
                hit['numeric_rescue']=rescue
                hit['rescue_frame']=src_i

    # Phase A: lexical impossibility gate. This runs before broad numeric work,
    # so obvious missing mandatory options still reject without heavy OCR.
    lexical={}
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        strong=[]
        near=False
        best_score=0.0
        best_threshold=1.0
        for si,scan in enumerate(complete,1):
            hit=(scan.get('rule_hits') or {}).get(name) or {}
            score=float(hit.get('score') or 0.0)
            threshold=float(hit.get('threshold') or 1.0)
            best_score=max(best_score,score)
            best_threshold=min(best_threshold,threshold)
            if hit.get('strong_name'):
                strong.append({'frame':si,**hit})
            near_floor=max(0.48, threshold-0.10)
            # Known wrong-family evidence is NOT a reason to retry and can
            # never become partial wanted evidence. Retry is reserved for a
            # semantically compatible-but-weak or genuinely UNKNOWN identity.
            if (hit.get('family_compatible') and (hit.get('qualifier_check') or {}).get('compatible') and score>=near_floor):
                near=True
            elif hit.get('family_unknown_near'):
                near=True
        semantic_contradiction=any(
            ((scan.get('rule_hits') or {}).get(name) or {}).get('family_contradiction_near')
            for scan in complete
        )
        lexical[name]={
            'strong':strong,'near':near,'semantic_contradiction':bool(semantic_contradiction),
            'best_score':best_score,'threshold':best_threshold,
        }

    # V11.0 ABSENCE AUTHORITY -------------------------------------------------
    # OCR miss is not Option absent.  A wanted option can FAIL by absence only
    # when every one of the six physical rows is authoritatively identified and
    # none is the wanted option.  If two frames disagree, evidence is UNKNOWN.
    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        lx=lexical[name]
        if lx['strong']:
            continue
        absence=[_v111_absence_authority(scan,name) for scan in complete]
        states=[x.get('state') for x in absence]
        if states and all(s=='ABSENT_CONFIRMED' for s in states):
            rr={
                'option_name':name,
                'operator':str(rule.get('op','EXISTS')).upper(),
                'target':rule.get('value'),
                'passed':False,
                'state':'FAIL_ABSENT_CONFIRMED',
                'found_value':None,
                'match_source':'ALL_SIX_ROW_IDENTITY_AUTHORITY',
                'strong_hits':[],
                'best_score':lx['best_score'],
                'threshold':lx['threshold'],
                'expected_family':option_semantics(name).get('option_family'),
                'absence_evidence':absence,
                'reject_authority':'AUTHORITATIVE_REJECT',
            }
            return {
                'decision':'FAIL','filter_result':'REJECT',
                'reject_authority':'AUTHORITATIVE_REJECT',
                'reason':'FAST_MANDATORY_OPTION_ABSENT_CONFIRMED',
                'mode':mode,'matched':0,'enabled':len(rules),
                'frames':scans,'rule_results':[rr],'failed_rule':name,
                'fail_fast':True,'skip_review':True,'disposition':'REJECT_NOW',
                'pipeline':'THREE_STATE_CLOSED_WORLD_V11_2'
            }
        # PRESENT/ABSENT disagreement or any unresolved row must remain UNKNOWN.
        lexical[name]['absence_evidence']=absence

    # Phase B: only strong/near-surviving rules reach value evaluation.
    results=[]
    passed=0
    unresolved=False
    unresolved_reason=None

    for rule in rules:
        name=str(rule.get('option_name') or '').strip()
        op=str(rule.get('op','EXISTS')).upper()
        strong=list(lexical[name]['strong'])

        if not strong:
            # V11.2: near-name is diagnostic only after semantic compatibility.
            # If no compatible near candidate exists, keep the condition UNKNOWN
            # rather than falsely labeling an unrelated row as near evidence.
            near=bool(lexical[name].get('near'))
            state='UNRESOLVED_NEAR_NAME' if near else 'UNKNOWN_IDENTITY'
            reason='FAST_NEAR_WANTED_EVIDENCE_NEEDS_SECOND_FRAME' if near else 'TARGET_EXCLUSION_INCOMPLETE'
            results.append({
                'option_name':name,'operator':op,'target':rule.get('value'),
                'passed':False,'state':state,
                'found_value':None,'match_source':None,'strong_hits':[],
                'best_score':lexical[name]['best_score'],
                'threshold':lexical[name]['threshold'],
                'absence_evidence':lexical[name].get('absence_evidence') or [],
            })
            unresolved=True
            unresolved_reason=unresolved_reason or reason
            continue

        if op=='EXISTS':
            passed += 1
            results.append({
                'option_name':name,'operator':op,'target':rule.get('value'),
                'passed':True,'state':'PASS','found_value':None,
                'match_source':'FAST_WANTED_NAME','strong_hits':strong,
            })
            continue

        meta=option_semantics(name)
        if meta.get('option_family')=='ATTACK_SPEED':
            authoritative=[h for h in strong if h.get('numeric_authoritative') and h.get('value') is not None]
            auth_values=[int(h.get('value')) for h in authoritative]
            if authoritative:
                from collections import Counter
                counts=Counter(auth_values)
                chosen=counts.most_common(1)[0][0]
                # If multiple authoritative frames disagree, do not guess.
                if len(set(auth_values))>1 and counts[chosen] < 2:
                    results.append({
                        'option_name':name,'operator':op,'target':rule.get('value'),
                        'passed':False,'state':'NUMERIC_CONFLICT','found_value':None,
                        'match_source':'ATTACK_SPEED_PERCENT_AUTHORITY',
                        'strong_hits':strong,'all_observed_values':auth_values,
                        'expected_unit':'PERCENT','numeric_authoritative':False,
                    })
                    unresolved=True
                    unresolved_reason=unresolved_reason or 'ATTACK_SPEED_PERCENT_AUTHORITY_CONFLICT'
                    continue
                if _wanted_rule_ok(rule,{'value':chosen}):
                    passed += 1
                    results.append({
                        'option_name':name,'operator':op,'target':rule.get('value'),
                        'passed':True,'state':'PASS','found_value':chosen,
                        'match_source':'ATTACK_SPEED_PERCENT_AUTHORITY',
                        'strong_hits':strong,'all_observed_values':auth_values,
                        'expected_unit':'PERCENT','observed_unit':'PERCENT',
                        'numeric_authoritative':True,'reason':'PERCENT_VALUE_AUTHORITATIVE',
                    })
                    continue
                rr={
                    'option_name':name,'operator':op,'target':rule.get('value'),
                    'passed':False,'state':'FAIL_VALUE_CONFIRMED','found_value':chosen,
                    'match_source':'ATTACK_SPEED_PERCENT_AUTHORITY',
                    'strong_hits':strong,'all_observed_values':auth_values,
                    'expected_unit':'PERCENT','observed_unit':'PERCENT',
                    'numeric_authoritative':True,'reason':'PERCENT_VALUE_AUTHORITATIVE',
                    'reject_authority':'AUTHORITATIVE_REJECT',
                }
                results.append(rr)
                return {
                    'decision':'FAIL','filter_result':'REJECT','reason':'FAST_MANDATORY_VALUE_FAILED_PERCENT_AUTHORITY',
                    'reject_authority':'AUTHORITATIVE_REJECT',
                    'mode':mode,'matched':passed,'enabled':len(rules),
                    'frames':scans,'rule_results':results,'failed_rule':name,
                    'fail_fast':True,'skip_review':True,'disposition':'REJECT_NOW',
                    'pipeline':'FINAL6_FOREGROUND_ROW_V11_2'
                }
            # Generic integers (e.g. 448 from +44%) are diagnostic only.
            # Without percent authority this rule remains bounded-unresolved.
            results.append({
                'option_name':name,'operator':op,'target':rule.get('value'),
                'passed':False,'state':'UNRESOLVED_NUMERIC','found_value':None,
                'match_source':None,'strong_hits':strong,
                'expected_unit':'PERCENT','numeric_authoritative':False,
                'reason':'VALUE_UNRESOLVED',
                'generic_values':[h.get('generic_numeric_value') for h in strong if h.get('generic_numeric_value') is not None],
            })
            unresolved=True
            unresolved_reason=unresolved_reason or 'ATTACK_SPEED_PERCENT_AUTHORITY_UNRESOLVED'
            continue

        vals=[h.get('value') for h in strong if h.get('value') is not None]
        candidates=[]
        numeric_conflict=False
        numeric_unconfirmed=False

        # v10.2 NUMERIC AUTHORITY: a valid orange +1/+2/+3 is authoritative
        # for Kỹ năng Võ công vốn có. Invalid-domain generic noise cannot veto
        # it, and a confirmed below-threshold value can FAIL immediately.
        skill_resolutions=[r for r in (_skill_authority_resolution(h) for h in strong) if r]
        if skill_resolutions:
            skill_conflicts=[r for r in skill_resolutions if r.get('valid_domain_conflicts')]
            skill_values=[int(r.get('value')) for r in skill_resolutions]
            if skill_conflicts or len(set(skill_values))>1:
                results.append({
                    'option_name':name,'operator':op,'target':rule.get('value'),
                    'passed':False,'state':'NUMERIC_CONFLICT',
                    'found_value':None,'match_source':'AUTHORITATIVE_SPECIALIZED_SOURCE',
                    'strong_hits':strong,'skill_authority':skill_resolutions,
                    'all_observed_values':skill_values,
                })
                unresolved=True
                unresolved_reason=unresolved_reason or 'SKILL_VALID_DOMAIN_NUMERIC_CONFLICT'
                continue
            chosen=skill_values[0]
            if _wanted_rule_ok(rule,{'value':chosen}):
                passed += 1
                results.append({
                    'option_name':name,'operator':op,'target':rule.get('value'),
                    'passed':True,'state':'PASS','found_value':chosen,
                    'match_source':'AUTHORITATIVE_SPECIALIZED_SOURCE',
                    'strong_hits':strong,'skill_authority':skill_resolutions,
                    'all_observed_values':skill_values,
                })
                continue
            rr={
                'option_name':name,'operator':op,'target':rule.get('value'),
                'passed':False,'state':'FAIL_VALUE_CONFIRMED','found_value':chosen,
                'match_source':'AUTHORITATIVE_SPECIALIZED_SOURCE',
                'strong_hits':strong,'skill_authority':skill_resolutions,
                'all_observed_values':skill_values,
                'reject_authority':'AUTHORITATIVE_REJECT',
            }
            results.append(rr)
            return {
                'decision':'FAIL','filter_result':'REJECT','reason':'FAST_MANDATORY_VALUE_FAILED_AUTHORITATIVE',
                'reject_authority':'AUTHORITATIVE_REJECT',
                'mode':mode,'matched':passed,'enabled':len(rules),
                'frames':scans,'rule_results':results,'failed_rule':name,
                'fail_fast':True,'skip_review':True,'disposition':'REJECT_NOW',
                'pipeline':'FINAL6_FOREGROUND_ROW_V11_2'
            }

        # KEEP-SAFE precedence: if ANY strong read sees a value that satisfies
        # the configured condition, never let a second noisy OCR frame turn it
        # into SELL/DROP. This is especially important for +1/+2 skill levels.
        passing_vals=[v for v in vals if _wanted_rule_ok(rule,{'value':v})]
        if passing_vals:
            from collections import Counter
            chosen=Counter(passing_vals).most_common(1)[0][0]
            passed += 1
            results.append({
                'option_name':name,'operator':op,'target':rule.get('value'),
                'passed':True,'state':'PASS','found_value':chosen,
                'match_source':'FAST_WANTED_VALUE_ANY_STRONG_PASS','strong_hits':strong,
                'all_observed_values':vals,
            })
            continue

        if len(complete)>=2:
            from collections import Counter
            counts=Counter(vals)
            repeated=[v for v,c in counts.items() if c>=2]
            if repeated:
                candidates=repeated
            elif len(set(vals))>1:
                numeric_conflict=True
            else:
                # Only one frame supplied a number while multiple frames were
                # scanned: do not sell on a singleton failing OCR value.
                numeric_unconfirmed=True
        else:
            # v9.1: if the whole-block OCR and a dedicated numeric-only OCR on
            # the SAME already-matched row agree on the same failing value, the
            # value is sufficiently confirmed to reject without paying for a
            # second full six-row OCR frame. Any disagreement still requests
            # frame 2, preserving the v8.8 safety behavior.
            same_frame_confirmed=[
                h.get('value') for h in strong
                if h.get('same_frame_numeric_confirmed') and h.get('value') is not None
            ]
            if same_frame_confirmed:
                candidates=[same_frame_confirmed[0]]
            else:
                numeric_unconfirmed=bool(vals)

        if candidates:
            # Two agreeing values and none pass => numeric FAIL is conclusive.
            rr={
                'option_name':name,'operator':op,'target':rule.get('value'),
                'passed':False,'state':'FAIL_VALUE_CONFIRMED','found_value':candidates[0],
                'match_source':'FAST_WANTED_VALUE_CONFIRMED','strong_hits':strong,
                'all_observed_values':vals,
                'reject_authority':'AUTHORITATIVE_REJECT',
            }
            results.append(rr)
            return {
                'decision':'FAIL','filter_result':'REJECT',
                'reason':'FAST_MANDATORY_VALUE_FAILED_CONFIRMED',
                'reject_authority':'AUTHORITATIVE_REJECT',
                'mode':mode,
                'matched':passed,
                'enabled':len(rules),
                'frames':scans,
                'rule_results':results,
                'failed_rule':name,
                'fail_fast':True,
                'skip_review':True,
                'disposition':'REJECT_NOW',
                'pipeline':'FINAL6_FOREGROUND_ROW_V11_2'
            }

        results.append({
            'option_name':name,'operator':op,'target':rule.get('value'),
            'passed':False,
            'state':'UNRESOLVED_NUMERIC',
            'found_value':None,
            'match_source':None,
            'strong_hits':strong,
            'numeric_conflict':numeric_conflict,
            'numeric_unconfirmed':numeric_unconfirmed,
            'all_observed_values':vals,
        })
        unresolved=True
        unresolved_reason=unresolved_reason or 'FAST_STRONG_NAME_NUMERIC_UNRESOLVED'

    if passed==len(rules):
        return {
            'decision':'PASS','filter_result':'MATCH','reason':'FAST_WANTED_CONDITIONS_MET',
            'reject_authority':'NOT_APPLICABLE',
            'mode':mode,'matched':passed,'enabled':len(rules),
            'frames':scans,'rule_results':results,
            'fail_fast':False,'skip_review':False,'disposition':'KEEP_NOW',
            'pipeline':'FINAL6_FOREGROUND_ROW_V11_2'
        }

    # V11.0 THREE-STATE CONTRACT: bounded OCR exhaustion is UNKNOWN, never
    # REJECT.  No destructive input has begun, therefore the item is recoverable.
    failed = next((r for r in results if not r.get('passed')), None) or {}
    if len(scans) >= 2:
        return {
            'decision':'UNCERTAIN','filter_result':'UNRESOLVED',
            'reject_authority':'UNRESOLVED',
            'reason':unresolved_reason or 'WANTED_OPTION_VALUE_UNRESOLVED',
            'unresolved_reason':_v112_precise_unresolved_reason(results,scans),
            'rejection_reason':None,
            'mode':mode,'matched':passed,'enabled':len(rules),
            'frames':scans,'rule_results':results,
            'failed_rule':failed.get('option_name'),
            'fail_fast':False,'skip_review':False,'disposition':'RECHECK_PENDING',
            'pipeline':'MULTI_PROFILE_THREE_STATE_FOREGROUND_V11_2'
        }

    return {
        'decision':'UNCERTAIN','filter_result':'UNRESOLVED',
        'reject_authority':'UNRESOLVED',
        'reason':unresolved_reason or 'FAST_WANTED_UNRESOLVED',
        'unresolved_reason':_v112_precise_unresolved_reason(results,scans),
        'mode':mode,'matched':passed,'enabled':len(rules),
        'frames':scans,'rule_results':results,
        'fail_fast':False,'skip_review':False,'disposition':'RETRY_ONCE',
        'pipeline':'FINAL6_FOREGROUND_ROW_V11_2'
    }



def _fast_evaluate_profiles(image_paths, filter_config):
    """V1.7.10 adaptive two-stage shared-evidence evaluator.

    Stage A is the canonical fast Tesseract + ClosedWorld + numeric pipeline
    with Paddle deliberately deferred.  Stage B runs Paddle only when the pure
    escalation policy proves that the slow NAME/FAMILY tie-breaker is needed.

    This is not a lower threshold / fewer-frame shortcut.  All existing Final6,
    Vision, unit and numeric authority gates remain unchanged.  Paddle remains
    evidence-only and every PASS, UNKNOWN, suspicious absence, or weak positive
    name witness escalates before the final disposition.
    """
    cfg=migrate_filter_config(filter_config or {})
    profile_validation=_profile_rule_validation(cfg)
    if not profile_validation.get('ok'):
        return {
            'decision':'UNCERTAIN','filter_result':'UNRESOLVED','reject_authority':'UNRESOLVED',
            'reason':'PROFILE_RULE_OUTSIDE_CLOSED_REGISTRY','frames':[],'profile_results':[],
            'profile_registry':profile_validation,'pipeline':'PROFILE_SLOT_AWARE_TWO_STAGE_V1_7_10',
            'disposition':'RECHECK_PENDING','skip_review':False,
        }
    profiles=filter_enabled_profiles(cfg)
    if not profiles:
        return {'decision':'NO_FILTER','filter_result':'UNRESOLVED','reason':'NO_ENABLED_PROFILES','frames':[],
                'profile_results':[],'pipeline':'MULTI_PROFILE_SHARED_EVIDENCE_V1'}
    scan_rules=union_scan_rules(cfg)

    def _evaluate_scans(scans):
        profile_results=[]
        pe0=time.perf_counter()
        for prof in profiles:
            pcfg={
                'scope':cfg.get('scope','GLOBAL'),'scope_value':cfg.get('scope_value','GLOBAL'),
                'group_id':cfg.get('group_id'),'family':cfg.get('family'),'mode':'ALL',
                'rules':[dict(r) for r in (prof.get('rules') or []) if r.get('enabled',True)]
            }
            rr=_fast_evaluate_filter(image_paths,pcfg,precomputed_scans=scans)
            reject_authority=str(rr.get('reject_authority') or '').upper() or ('AUTHORITATIVE_REJECT' if rr.get('decision')=='FAIL' and rr.get('filter_result')=='REJECT' else 'UNRESOLVED')
            authoritative_fail=bool(rr.get('decision')=='FAIL' and reject_authority=='AUTHORITATIVE_REJECT')
            profile_results.append({
                'profile_id':prof.get('profile_id'),'enabled':True,'rules':pcfg['rules'],
                'decision':rr.get('decision'),
                'reject_authority':reject_authority,
                'state':('MATCHED_N_OF_N' if rr.get('decision')=='PASS' else ('ELIMINATED' if authoritative_fail else 'PENDING')),
                'matched_count':rr.get('matched',0),'required_count':len(pcfg['rules']),
                'failed_condition':rr.get('failed_rule'),'reason':rr.get('reason'),
                'rule_results':rr.get('rule_results',[]),'inner':rr,
            })
            # OR short-circuit: one full N/N profile is sufficient to KEEP.
            if rr.get('decision')=='PASS':
                break
        return profile_results,(time.perf_counter()-pe0)*1000.0

    # Stage A — fast path, no Paddle inference.
    stage1_t0=time.perf_counter()
    stage1_scans=[_fast_scan_one_crop(p,scan_rules,cfg.get('scope_value','GLOBAL'),paddle_policy='DEFER') for p in image_paths]
    stage1_scan_ms=(time.perf_counter()-stage1_t0)*1000.0
    stage1_profiles,stage1_eval_ms=_evaluate_scans(stage1_scans)
    stage1_out=compose_profile_result(stage1_profiles,frames=stage1_scans,active_count=len(profiles))
    escalation=adaptive_paddle_escalation_policy(stage1_profiles,stage1_scans)

    scans=stage1_scans
    profile_results=stage1_profiles
    profile_eval_ms=stage1_eval_ms
    paddle_scan_ms=0.0
    if bool(escalation.get('escalate')):
        stage2_t0=time.perf_counter()
        scans=[_fast_scan_one_crop(p,scan_rules,cfg.get('scope_value','GLOBAL'),paddle_policy='FORCE') for p in image_paths]
        paddle_scan_ms=(time.perf_counter()-stage2_t0)*1000.0
        profile_results,profile_eval_ms=_evaluate_scans(scans)

    out=compose_profile_result(profile_results,frames=scans,active_count=len(profiles))
    out['wanted_options']=wanted_option_set(cfg)
    out['wanted_option_count']=len(out['wanted_options'])
    out['profile_registry']=profile_validation
    out['OCR_pass_count']=len(image_paths)
    out['adaptive_paddle']={
        'policy':ADAPTIVE_PADDLE_POLICY_VERSION,
        'escalated':bool(escalation.get('escalate')),
        'reason':escalation.get('reason'),
        'diagnostics':escalation.get('diagnostics') or [],
        'stage1_decision':stage1_out.get('decision'),
        'stage1_filter_result':stage1_out.get('filter_result'),
        'stage1_profile_states':[{
            'profile_id':x.get('profile_id'),'decision':x.get('decision'),
            'reason':x.get('reason'),'failed_condition':x.get('failed_condition')
        } for x in stage1_profiles],
    }
    paddle_frames=[x.get('paddle_runtime_bridge') for x in scans if isinstance(x,dict)]
    out['paddle_runtime_bridge']={
        'bridge_version':'PADDLE_RUNTIME_BRIDGE_V1_7_10_ADAPTIVE_FINAL6_ROI',
        'used':bool(any(bool((x or {}).get('used')) for x in paddle_frames)),
        'frames':paddle_frames,
        'engine_status':paddleocr_engine_status(),
        'adaptive_escalated':bool(escalation.get('escalate')),
    }
    family_eval_ms=sum(float((x.get('timings') or {}).get('family_eval_ms') or 0.0) for x in scans)
    percent_value_ms=sum(float((x.get('timings') or {}).get('percent_value_ms') or 0.0) for x in scans)
    targeted_family_rescue_ms=sum(float((x.get('timings') or {}).get('targeted_family_rescue_ms') or 0.0) for x in scans)
    targeted_percent_rescue_ms=sum(float((x.get('timings') or {}).get('targeted_percent_rescue_ms') or 0.0) for x in scans)
    total_ms=stage1_scan_ms+stage1_eval_ms+paddle_scan_ms+(profile_eval_ms if escalation.get('escalate') else 0.0)
    out['timings']={
        'stage1_fast_scan_ms':round(stage1_scan_ms,3),
        'stage1_profile_eval_ms':round(stage1_eval_ms,3),
        'paddle_escalation_scan_ms':round(paddle_scan_ms,3),
        'shared_scan_ms':round((paddle_scan_ms if escalation.get('escalate') else stage1_scan_ms),3),
        'profile_eval_ms':round(profile_eval_ms,3),
        'family_eval_ms':round(family_eval_ms,3),'percent_value_ms':round(percent_value_ms,3),
        'targeted_family_rescue_ms':round(targeted_family_rescue_ms,3),
        'targeted_percent_rescue_ms':round(targeted_percent_rescue_ms,3),
        'total_scan_ms':round(total_ms,3),
    }
    out['pipeline']='PROFILE_SLOT_AWARE_TWO_STAGE_V1_7_10_ADAPTIVE_PADDLE'
    return out


def _actual_fast_observed_names(fast_filter):
    """Return canonical option names backed by CURRENT-tooltip strong hits.

    Configured filter names alone never appear in this result. A canonical name
    is returned only when the fast scan recorded a strong raw hit from the item
    currently under the cursor and, for NỘI/NGOẠI families, the semantic
    qualifier is compatible.
    """
    names=[]
    evidence=[]
    for rr in (fast_filter or {}).get('rule_results',[]) or []:
        opt=rr.get('option_name')
        if not opt:
            continue
        for hit in (rr.get('strong_hits') or []):
            if not hit.get('strong_name') or not hit.get('raw'):
                continue
            qcheck=hit.get('qualifier_check') or _semantic_qualifier_check(hit.get('raw'),opt)
            if not qcheck.get('compatible'):
                continue
            names.append(opt)
            evidence.append({
                'canonical':opt,'raw':hit.get('raw'),'score':hit.get('score'),
                'frame':hit.get('frame'),'source':'CURRENT_TOOLTIP_ACTUAL_FAST_MATCH',
                'qualifier_check':qcheck,
            })
            break
    return list(dict.fromkeys(names)), evidence


def _v122_all_canonical_observed_names(fast_filter):
    """All authoritative canonical V12 row names from the CURRENT tooltip.

    V12.1 group-scope gating accidentally consumed only filter-rule strong hits.
    That reintroduced a legacy perception authority above ClosedWorldVision and
    caused a proven Skill +2 MATCH to become PROFILE_MATCH_SCOPE_IDENTITY_UNRESOLVED.
    Group identity may use all authoritative canonical row observations, never the
    configured rule names by themselves.
    """
    names=[]; evidence=[]
    for frame_index,fr in enumerate((fast_filter or {}).get('frames') or []):
        for row in (fr.get('v120_row_observations') or []):
            if not isinstance(row,dict) or not row.get('identity_authority'):
                continue
            name=str(row.get('option_name') or '').strip()
            if not name:
                continue
            names.append(name)
            evidence.append({
                'canonical':name,'option_id':row.get('option_id'),'family':row.get('family'),
                'qualifier':row.get('qualifier'),'physical_row_index':row.get('physical_row_index'),
                'frame':frame_index,'source':'V12_CANONICAL_OBSERVED_OPTION_SET',
            })
    return list(dict.fromkeys(names)), evidence


def _candidate_tesseract_paths():
    paths = []
    which = shutil.which('tesseract')
    if which:
        paths.append(Path(which))

    envs = [
        Path(os.environ.get('PROGRAMFILES', r'C:\Program Files')),
        Path(os.environ.get('PROGRAMFILES(X86)', r'C:\Program Files (x86)')),
        Path(os.environ.get('LOCALAPPDATA', '')),
        Path(os.environ.get('USERPROFILE', '')) / 'AppData' / 'Local' / 'Programs',
    ]
    for root in envs:
        if not str(root):
            continue
        paths += [
            root / 'Tesseract-OCR' / 'tesseract.exe',
            root / 'Programs' / 'Tesseract-OCR' / 'tesseract.exe',
            root / 'tesseract' / 'tesseract.exe',
        ]

    if OCR_CONFIG_PATH.exists():
        try:
            saved = json.loads(OCR_CONFIG_PATH.read_text(encoding='utf-8')).get('tesseract_path')
            if saved:
                paths.insert(0, Path(saved))
        except Exception:
            pass

    unique, seen = [], set()
    for p in paths:
        s = str(p)
        if s not in seen:
            seen.add(s)
            unique.append(p)
    return unique


def configure_tesseract():
    for p in _candidate_tesseract_paths():
        if p.exists() and p.is_file():
            pytesseract.pytesseract.tesseract_cmd = str(p)
            try:
                _ = pytesseract.get_tesseract_version()
                return str(p)
            except Exception:
                continue
    return None


def get_languages():
    try:
        return list(pytesseract.get_languages(config=''))
    except Exception:
        return []


TESSERACT = configure_tesseract()
SELF_PID = os.getpid()

EXCLUDED_PROCESS_NAMES = {
    'chrome.exe', 'msedge.exe', 'firefox.exe', 'opera.exe',
    'explorer.exe', 'notepad.exe', 'code.exe', 'python.exe', 'pythonw.exe'
}
EXCLUDED_TITLE_MARKERS = (
    'auto pro by eric', 'autoprobyeric', 'stage17', 'stage 17',
    'google chrome', 'microsoft edge', 'youtube',
)
GAME_TITLE_MARKERS = (
    'võ lâm', 'vo lam', 'võ lâm truyền kỳ', 'vo lam truyen ky',
    'jx1', 'jx 1', 'volam',
    'sword3ctc', 'sword3', 'sword 3', 'ctc title',
)
GAME_PROCESS_MARKERS = (
    'jx', 'volam', 'sword3ctc', 'sword3',
    'game.exe', 'game', 'client'
)


def jx1_score(w):
    if getattr(w, 'pid', 0) == SELF_PID:
        return -999
    title = (w.title or '').lower()
    pname = (getattr(w, 'process_name', '') or '').lower()
    if any(x in title for x in EXCLUDED_TITLE_MARKERS):
        return -999
    if pname in EXCLUDED_PROCESS_NAMES:
        return -999

    score = 0

    # Strong JX1/VLTK identity signals.
    if any(x in title for x in GAME_TITLE_MARKERS):
        score += 110
    if any(x in pname for x in GAME_PROCESS_MARKERS):
        score += 80

    # The real test client observed during development used Sword3CTC Title / game.exe.
    if 'sword3ctc' in title:
        score += 90
    if pname == 'game.exe':
        score += 75

    ratio = (w.client_width / w.client_height) if w.client_height else 0
    if 1.28 <= ratio <= 1.38:
        score += 12

    common_size = False
    for cw, ch in [(800, 600), (1024, 768), (1280, 960), (640, 480), (1152, 864)]:
        if abs(w.client_width - cw) <= 24 and abs(w.client_height - ch) <= 24:
            score += 16
            common_size = True
            break

    # Geometry can support an identity but can never be the only strong signal.
    if 600 <= w.client_width <= 1350 and 450 <= w.client_height <= 1000:
        score += 4
    if score < 70 and common_size:
        score = min(score, 45)

    return score


def _cursor_inside(img, cur):
    if img is None or cur is None:
        return False
    x, y = cur
    return 0 <= x < img.width and 0 <= y < img.height



user32_bridge = ctypes.windll.user32

WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_MOUSEMOVE = 0x0200
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
MK_LBUTTON = 0x0001
MK_RBUTTON = 0x0002
SW_RESTORE = 9
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008
MAPVK_VK_TO_VSC = 0
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
TOKEN_QUERY = 0x0008
TOKEN_ELEVATION_CLASS = 20

VK_MAP = {
    "1": 0x31,
    "2": 0x32,
    "3": 0x33,
    "Q": 0x51,
    "F4": 0x73,
    "F9": 0x78,
    "F12": 0x7B,
}

kernel32_bridge = ctypes.windll.kernel32
advapi32_bridge = ctypes.windll.advapi32
shell32_bridge = ctypes.windll.shell32

ULONG_PTR = wintypes.WPARAM

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]

class INPUTUNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT)]

class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", INPUTUNION)]


class TOKEN_ELEVATION(ctypes.Structure):
    _fields_ = [("TokenIsElevated", wintypes.DWORD)]


def _config_recovery_notify(reason, path, error):
    # Visible in diagnostics and console; never expose raw config contents.
    try:
        with (LOGDIR / 'config_recovery.jsonl').open('a',encoding='utf-8') as stream:
            stream.write(json.dumps({'time':time.time(),'reason':reason,'path':Path(path).name,'error':str(error)[:200]},ensure_ascii=False)+'\n')
    except Exception:
        pass
    print('[AutoPro Config] '+reason+' '+Path(path).name)

def _load_app_config():
    default = {
        "input_mode": "Auto",
        "shortcut_mode": "Mặc định",
        "locked_client": None,
        "modules": {
            "chest": {"open_mode": "Auto", "batch": 1, "confirm_each": True, "safe_pause": True, "continuous": True, "auto_resume_after_lag_enabled": False},
            "shop": {"disabled": True, "continuous": False},
            "roll": {"material": "Lục Thủy Tinh", "max_rolls": 50, "delay_ms": 2500},
            "boss": {"boss_count": 1, "point_a": "", "point_b": "", "safe_pause": True},
            "store": {"placement": "COMPACT_ADJACENT_RESERVED_SAFE", "safe_pause": True},
            "common": {
                "thien_son_bao_lo_enabled": False,
                "que_hoa_tuu_enabled": False,
                "thien_son_bao_lo_last_used_epoch": 0.0,
                "que_hoa_tuu_last_used_epoch": 0.0,
                "thien_son_bao_lo_last_attempt_epoch": 0.0,
                "que_hoa_tuu_last_attempt_epoch": 0.0
            },
        },
        "runtime": {"active_module": "roll", "module_running": {}},
    }
    if APP_CONFIG_PATH.exists():
        try:
            saved = json.loads(APP_CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                for k, v in saved.items():
                    default[k] = v
        except Exception:
            pass
    return default

def _save_app_config(cfg):
    _safe_save_json(APP_CONFIG_PATH,cfg)

def _window_title(hwnd):
    n = user32_bridge.GetWindowTextLengthW(wintypes.HWND(hwnd))
    if n <= 0:
        return ""
    buf = ctypes.create_unicode_buffer(n + 1)
    user32_bridge.GetWindowTextW(wintypes.HWND(hwnd), buf, n + 1)
    return buf.value

def _window_pid(hwnd):
    pid = wintypes.DWORD()
    user32_bridge.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
    return int(pid.value)

def _largest_child(hwnd):
    best = {"hwnd": int(hwnd), "area": 0}
    EnumChildProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    def cb(ch, lp):
        if not user32_bridge.IsWindowVisible(ch):
            return True
        r = wintypes.RECT()
        if user32_bridge.GetClientRect(ch, ctypes.byref(r)):
            area = max(0, int(r.right-r.left)) * max(0, int(r.bottom-r.top))
            if area > best["area"]:
                best["hwnd"] = int(ch)
                best["area"] = area
        return True

    try:
        user32_bridge.EnumChildWindows(wintypes.HWND(hwnd), EnumChildProc(cb), 0)
    except Exception:
        pass
    return best["hwnd"]

def _is_current_process_elevated():
    try:
        return bool(shell32_bridge.IsUserAnAdmin())
    except Exception:
        return False

def _process_elevated(pid):
    """
    Return True/False when Windows token elevation can be read.
    Return None on any Win32/ctypes failure. Never let privilege probing
    abort the actual input path.
    """
    handle = None
    token = wintypes.HANDLE()
    try:
        handle = kernel32_bridge.OpenProcess(
            PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid)
        )
        if not handle:
            return None

        if not advapi32_bridge.OpenProcessToken(
            wintypes.HANDLE(handle), TOKEN_QUERY, ctypes.byref(token)
        ):
            return None

        elev = TOKEN_ELEVATION()
        ret_len = wintypes.DWORD()
        ok = advapi32_bridge.GetTokenInformation(
            token,
            TOKEN_ELEVATION_CLASS,
            ctypes.byref(elev),
            ctypes.sizeof(TOKEN_ELEVATION),
            ctypes.byref(ret_len),
        )
        if not ok:
            return None
        return bool(elev.TokenIsElevated)
    except Exception:
        return None
    finally:
        try:
            if token and token.value:
                kernel32_bridge.CloseHandle(token)
        except Exception:
            pass
        try:
            if handle:
                kernel32_bridge.CloseHandle(handle)
        except Exception:
            pass

def _post_key(hwnd, vk):
    target = _largest_child(hwnd)
    # Include repeat/scancode-like lParam bits so legacy controls get a realistic key event.
    scan = int(user32_bridge.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC))
    down_lp = 1 | (scan << 16)
    up_lp = down_lp | (1 << 30) | (1 << 31)
    ok1 = bool(user32_bridge.PostMessageW(wintypes.HWND(target), WM_KEYDOWN, vk, down_lp))
    time.sleep(0.045)
    ok2 = bool(user32_bridge.PostMessageW(wintypes.HWND(target), WM_KEYUP, vk, up_lp))
    if target != hwnd:
        user32_bridge.PostMessageW(wintypes.HWND(hwnd), WM_KEYDOWN, vk, down_lp)
        time.sleep(0.020)
        user32_bridge.PostMessageW(wintypes.HWND(hwnd), WM_KEYUP, vk, up_lp)
    return ok1 and ok2, target

def _activate_window(hwnd):
    hwnd = int(hwnd)
    target = _largest_child(hwnd)

    current_tid = kernel32_bridge.GetCurrentThreadId()
    target_pid = wintypes.DWORD()
    target_tid = user32_bridge.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(target_pid))
    fg = int(user32_bridge.GetForegroundWindow() or 0)
    fg_pid = wintypes.DWORD()
    fg_tid = user32_bridge.GetWindowThreadProcessId(wintypes.HWND(fg), ctypes.byref(fg_pid)) if fg else 0

    attached_target = False
    attached_fg = False
    try:
        if target_tid and target_tid != current_tid:
            attached_target = bool(user32_bridge.AttachThreadInput(current_tid, target_tid, True))
        if fg_tid and fg_tid != current_tid and fg_tid != target_tid:
            attached_fg = bool(user32_bridge.AttachThreadInput(current_tid, fg_tid, True))

        user32_bridge.ShowWindow(wintypes.HWND(hwnd), SW_RESTORE)
        user32_bridge.BringWindowToTop(wintypes.HWND(hwnd))
        user32_bridge.SetForegroundWindow(wintypes.HWND(hwnd))
        user32_bridge.SetActiveWindow(wintypes.HWND(hwnd))
        try:
            user32_bridge.SetFocus(wintypes.HWND(target))
        except Exception:
            pass
        time.sleep(0.12)

        foreground = int(user32_bridge.GetForegroundWindow() or 0)
        return {
            "ok": foreground == hwnd,
            "foreground_hwnd": foreground,
            "target_hwnd": int(target),
            "target_pid": int(target_pid.value),
        }
    finally:
        if attached_fg:
            user32_bridge.AttachThreadInput(current_tid, fg_tid, False)
        if attached_target:
            user32_bridge.AttachThreadInput(current_tid, target_tid, False)

def _sendinput_scancode(vk):
    scan = int(user32_bridge.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC))
    if scan <= 0:
        return False, scan

    arr = (INPUT * 2)()
    arr[0].type = INPUT_KEYBOARD
    arr[0].ki = KEYBDINPUT(0, scan, KEYEVENTF_SCANCODE, 0, 0)
    arr[1].type = INPUT_KEYBOARD
    arr[1].ki = KEYBDINPUT(0, scan, KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0, 0)
    sent = user32_bridge.SendInput(2, ctypes.byref(arr), ctypes.sizeof(INPUT))
    return int(sent) == 2, scan

def _sendinput_vk(vk):
    arr = (INPUT * 2)()
    arr[0].type = INPUT_KEYBOARD
    arr[0].ki = KEYBDINPUT(vk, 0, 0, 0, 0)
    arr[1].type = INPUT_KEYBOARD
    arr[1].ki = KEYBDINPUT(vk, 0, KEYEVENTF_KEYUP, 0, 0)
    sent = user32_bridge.SendInput(2, ctypes.byref(arr), ctypes.sizeof(INPUT))
    return int(sent) == 2


def _window_rect(hwnd):
    r = wintypes.RECT()
    if not user32_bridge.GetWindowRect(wintypes.HWND(int(hwnd)), ctypes.byref(r)):
        return None
    return int(r.left), int(r.top), int(r.right), int(r.bottom)

def _client_origin_screen(hwnd):
    pt = wintypes.POINT(0, 0)
    if not user32_bridge.ClientToScreen(wintypes.HWND(int(hwnd)), ctypes.byref(pt)):
        return None
    return int(pt.x), int(pt.y)

def _send_left_click_screen(x, y):
    old = _cursor_screen() if "_cursor_screen" in globals() else None
    user32_bridge.SetCursorPos(int(x), int(y))
    time.sleep(.035)

    arr = (INPUT * 2)()
    arr[0].type = INPUT_MOUSE
    arr[0].mi = MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTDOWN, 0, 0)
    arr[1].type = INPUT_MOUSE
    arr[1].mi = MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTUP, 0, 0)
    sent = user32_bridge.SendInput(2, ctypes.byref(arr), ctypes.sizeof(INPUT))
    time.sleep(.075)
    return int(sent) == 2, old

def _safe_game_hud_focus_click(hwnd):
    """Physically focus JX1 inside the client before Q/F4 inventory toggles.

    This client can ignore Q/F4 after SetForegroundWindow/SetFocus alone.  The
    click is intentionally placed in the thin top HUD strip (same proven rule
    used by AutoBoss V1.5.3+), outside the navigable world and inventory cells.
    It never clicks the map and never sends the inventory hotkey itself.
    """
    try:
        hwnd=int(hwnd)
        activation=_activate_window(hwnd)
        if not activation.get("ok"):
            return {"ok":False,"reason":"INVENTORY_FOCUS_ACTIVATION_FAILED","activation":activation}
        img=capture_client(hwnd)
        if img is None:
            return {"ok":False,"reason":"INVENTORY_FOCUS_CAPTURE_FAILED","activation":activation}
        w,h=int(img.width),int(img.height)
        if w < 320 or h < 200:
            return {"ok":False,"reason":"INVENTORY_FOCUS_CLIENT_TOO_SMALL","client_size":[w,h],"activation":activation}
        cx=max(120,min(w-180,int(round(w*0.50))))
        cy=max(6,min(18,int(round(h*0.018))))
        sp=_client_to_screen(hwnd,cx,cy)
        if not sp:
            return {"ok":False,"reason":"INVENTORY_FOCUS_CLIENT_TO_SCREEN_FAILED","client_point":[cx,cy],"activation":activation}
        old=_cursor_screen()
        _set_cursor_screen(*sp)
        time.sleep(.035)
        arr=(INPUT*2)()
        arr[0].type=INPUT_MOUSE
        arr[0].mi=MOUSEINPUT(0,0,0,MOUSEEVENTF_LEFTDOWN,0,0)
        arr[1].type=INPUT_MOUSE
        arr[1].mi=MOUSEINPUT(0,0,0,MOUSEEVENTF_LEFTUP,0,0)
        sent=user32_bridge.SendInput(2,ctypes.byref(arr),ctypes.sizeof(INPUT))
        time.sleep(.10)
        fg=int(user32_bridge.GetForegroundWindow() or 0)
        ok=bool(int(sent)==2 and fg==hwnd)
        return {
            "ok":ok,"sent":bool(int(sent)==2),"foreground_ok":bool(fg==hwnd),
            "foreground_hwnd":fg,"client_point":[cx,cy],"screen_point":[int(sp[0]),int(sp[1])],
            "client_size":[w,h],"old_cursor":old,"activation":activation,
            "reason":None if ok else "INVENTORY_FOCUS_CLICK_NOT_CONFIRMED",
        }
    except Exception as e:
        return {"ok":False,"reason":"INVENTORY_FOCUS_CLICK_EXCEPTION","error":str(e)}


def _safe_focus_click(hwnd):
    """
    Give the legacy JX1 client a real mouse activation without clicking gameplay.

    We only click the NON-CLIENT caption/titlebar strip. If no safe non-client
    strip exists, we refuse rather than clicking the map/inventory.
    """
    hwnd = int(hwnd)
    wr = _window_rect(hwnd)
    co = _client_origin_screen(hwnd)
    if not wr or not co:
        return {"ok": False, "reason": "WINDOW_GEOMETRY_FAILED"}

    left, top, right, bottom = wr
    client_x, client_y = co

    # Safe caption area exists only when client origin is visibly below window top.
    caption_h = client_y - top
    if caption_h < 8:
        return {
            "ok": False,
            "reason": "FOCUS_CLICK_UNAVAILABLE",
            "window_rect": [left, top, right, bottom],
            "client_origin": [client_x, client_y],
            "caption_height": caption_h,
        }

    # Stay away from minimize/maximize/close buttons on the right.
    x = left + max(70, min(220, (right-left)//3))
    x = min(x, right - 150)
    y = top + max(4, min(caption_h - 3, caption_h//2))

    sent, old = _send_left_click_screen(x, y)
    time.sleep(.11)

    foreground = int(user32_bridge.GetForegroundWindow() or 0)
    return {
        "ok": bool(sent and foreground == hwnd),
        "sent": bool(sent),
        "foreground_ok": bool(foreground == hwnd),
        "click_screen": [int(x), int(y)],
        "caption_height": int(caption_h),
        "old_cursor": old,
        "foreground_hwnd": foreground,
        "reason": None if sent and foreground == hwnd else "FOCUS_HANDSHAKE_FAILED",
    }


def _inventory_header_client_point(grid):
    xs=[int(x) for x in (grid or {}).get("x_lines",[])]
    ys=[int(y) for y in (grid or {}).get("y_lines",[])]
    if len(xs)!=7 or len(ys)!=11:
        return None
    cx=int((xs[0]+xs[-1])//2)
    cell_h=max(20,int(round((ys[-1]-ys[0])/10.0)))
    cy=int(max(8,ys[0]-max(22,int(cell_h*.90))))
    if not (xs[0] <= cx <= xs[-1] and 8 <= cy < ys[0]-4):
        return None
    return cx,cy


def _park_cursor_on_inventory_header(hwnd, grid, wait_sec=.24):
    """
    Move cursor away from every inventory item before sensor snapshots.
    This dismisses any tooltip that would otherwise cover cells and corrupt
    empty/occupied detection. No mouse button is pressed.
    """
    pt=_inventory_header_client_point(grid)
    if not pt:
        return {"ok":False,"reason":"INVENTORY_HEADER_POINT_UNAVAILABLE"}
    sp=_client_to_screen(hwnd,pt[0],pt[1])
    if not sp:
        return {"ok":False,"reason":"CLIENT_TO_SCREEN_FAILED"}
    ok=_set_cursor_screen(*sp)
    time.sleep(float(wait_sec))
    return {
        "ok":bool(ok),
        "client":[int(pt[0]),int(pt[1])],
        "screen":[int(sp[0]),int(sp[1])],
        "wait_ms":int(wait_sec*1000),
    }


def _safe_inventory_header_click(hwnd, grid):
    """
    JX1-specific client activation handshake.

    The old handshake clicked the Windows titlebar. That focuses the HWND but
    does not activate JX1's internal mouse/tooltip state. This version clicks
    INSIDE the game client, on the inventory header above the 6x10 grid.

    The point is derived from the detected inventory grid:
      x = grid horizontal center
      y = 24-30 px above first inventory row
    This is inside the HÀNH TRANG header/frame, not an item and not the map.
    """
    try:
        hwnd = int(hwnd)
        xs = [int(x) for x in (grid or {}).get("x_lines", [])]
        ys = [int(y) for y in (grid or {}).get("y_lines", [])]
        if len(xs) != 7 or len(ys) != 11:
            return {"ok": False, "reason": "CLIENT_CLICK_GRID_NOT_READY"}

        point=_inventory_header_client_point(grid)
        if not point:
            return {"ok":False,"reason":"CLIENT_CLICK_POINT_UNSAFE"}
        cx,cy=point

        sp = _client_to_screen(hwnd, cx, cy)
        if not sp:
            return {"ok": False, "reason": "CLIENT_TO_SCREEN_FAILED"}

        old_cursor = _cursor_screen()
        _set_cursor_screen(*sp)
        time.sleep(.04)

        arr = (INPUT * 2)()
        arr[0].type = INPUT_MOUSE
        arr[0].mi = MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTDOWN, 0, 0)
        arr[1].type = INPUT_MOUSE
        arr[1].mi = MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTUP, 0, 0)
        sent = user32_bridge.SendInput(2, ctypes.byref(arr), ctypes.sizeof(INPUT))
        time.sleep(.14)

        foreground = int(user32_bridge.GetForegroundWindow() or 0)
        return {
            "ok": bool(int(sent) == 2 and foreground == hwnd),
            "sent": bool(int(sent) == 2),
            "foreground_ok": bool(foreground == hwnd),
            "target": "INVENTORY_HEADER_CLIENT_AREA",
            "click_client": [cx, cy],
            "click_screen": [int(sp[0]), int(sp[1])],
            "grid_top": int(ys[0]),
            "old_cursor": old_cursor,
            "foreground_hwnd": foreground,
            "reason": None if int(sent) == 2 and foreground == hwnd else "CLIENT_AREA_HANDSHAKE_FAILED",
        }
    except Exception as e:
        return {"ok": False, "reason": "CLIENT_AREA_HANDSHAKE_EXCEPTION", "error": str(e)}

def _image_change_score(a, b):
    try:
        import numpy as np
        aa = np.asarray(a.resize((160, 120))).astype("int16")
        bb = np.asarray(b.resize((160, 120))).astype("int16")
        return float(np.abs(aa - bb).mean())
    except Exception:
        return 0.0

def _max_screen_change(hwnd, before, delays=(0.14, 0.32, 0.58)):
    best = 0.0
    if before is None:
        return best
    last = 0.0
    for d in delays:
        wait = max(0.0, d - last)
        time.sleep(wait)
        last = d
        after = capture_client(hwnd)
        if after is not None:
            best = max(best, _image_change_score(before, after))
    return best



def _client_to_screen(hwnd, x, y):
    pt = wintypes.POINT(int(x), int(y))
    if not user32_bridge.ClientToScreen(wintypes.HWND(int(hwnd)), ctypes.byref(pt)):
        return None
    return int(pt.x), int(pt.y)


def _screen_to_client(hwnd, x, y):
    pt = wintypes.POINT(int(x), int(y))
    if not user32_bridge.ScreenToClient(wintypes.HWND(int(hwnd)), ctypes.byref(pt)):
        return None
    return int(pt.x), int(pt.y)

def _cursor_screen():
    pt = wintypes.POINT()
    if not user32_bridge.GetCursorPos(ctypes.byref(pt)):
        return None
    return int(pt.x), int(pt.y)

def _set_cursor_screen(x, y):
    return bool(user32_bridge.SetCursorPos(int(x), int(y)))


def _send_right_click_screen(x, y):
    """One physical right-click. Never retries automatically."""
    old = _cursor_screen()
    if not user32_bridge.SetCursorPos(int(x), int(y)):
        return False, old
    time.sleep(.025)
    arr = (INPUT * 2)()
    arr[0].type = INPUT_MOUSE
    arr[0].mi = MOUSEINPUT(0, 0, 0, MOUSEEVENTF_RIGHTDOWN, 0, 0)
    arr[1].type = INPUT_MOUSE
    arr[1].mi = MOUSEINPUT(0, 0, 0, MOUSEEVENTF_RIGHTUP, 0, 0)
    sent = user32_bridge.SendInput(2, ctypes.byref(arr), ctypes.sizeof(INPUT))
    time.sleep(.045)
    return int(sent) == 2, old


def _post_right_click_client(hwnd, cx, cy):
    """Send exactly one background right-click to the JX1 child HWND."""
    hwnd = int(hwnd)
    target = int(_largest_child(hwnd))
    sp = _client_to_screen(hwnd, int(cx), int(cy))
    if not sp:
        return False, target, None
    pt = wintypes.POINT(int(sp[0]), int(sp[1]))
    if not user32_bridge.ScreenToClient(wintypes.HWND(target), ctypes.byref(pt)):
        return False, target, None
    tx, ty = int(pt.x), int(pt.y)
    if tx < 0 or ty < 0:
        return False, target, (tx, ty)
    lp = (ty << 16) | (tx & 0xFFFF)
    # Legacy JX clients often need a move message before the button event.
    user32_bridge.PostMessageW(wintypes.HWND(target), WM_MOUSEMOVE, 0, lp)
    time.sleep(.012)
    ok1 = bool(user32_bridge.PostMessageW(wintypes.HWND(target), WM_RBUTTONDOWN, MK_RBUTTON, lp))
    time.sleep(.025)
    ok2 = bool(user32_bridge.PostMessageW(wintypes.HWND(target), WM_RBUTTONUP, 0, lp))
    return bool(ok1 and ok2), target, (tx, ty)


def _post_left_click_client(hwnd, cx, cy):
    """Send exactly one background left-click to the JX1 child HWND."""
    hwnd = int(hwnd)
    target = int(_largest_child(hwnd))
    sp = _client_to_screen(hwnd, int(cx), int(cy))
    if not sp:
        return False, target, None
    pt = wintypes.POINT(int(sp[0]), int(sp[1]))
    if not user32_bridge.ScreenToClient(wintypes.HWND(target), ctypes.byref(pt)):
        return False, target, None
    tx, ty = int(pt.x), int(pt.y)
    if tx < 0 or ty < 0:
        return False, target, (tx, ty)
    lp = (ty << 16) | (tx & 0xFFFF)
    user32_bridge.PostMessageW(wintypes.HWND(target), WM_MOUSEMOVE, 0, lp)
    time.sleep(.010)
    ok1 = bool(user32_bridge.PostMessageW(wintypes.HWND(target), WM_LBUTTONDOWN, MK_LBUTTON, lp))
    time.sleep(.022)
    ok2 = bool(user32_bridge.PostMessageW(wintypes.HWND(target), WM_LBUTTONUP, 0, lp))
    return bool(ok1 and ok2), target, (tx, ty)


@dataclass(frozen=True)
class ClientPoint:
    x: int
    y: int
    coordinate_space: str = 'CLIENT'


@dataclass(frozen=True)
class ScreenPoint:
    x: int
    y: int
    coordinate_space: str = 'SCREEN'


class InputCoordinateAdapter:
    """V12.10 single owner for CLIENT -> physical input coordinates.

    Store planners and grid geometry stop at ClientPoint.  Foreground SendInput
    receives a ScreenPoint produced by exactly one ClientToScreen call in
    prepare_client_point().  dispatch_prepared_left_click() never converts it
    again.  Background keeps the existing PostMessage client contract.
    """
    version = 'INPUT_COORDINATE_ADAPTER_V12_10'

    @staticmethod
    def _client_rect(hwnd):
        r=wintypes.RECT()
        if not user32_bridge.GetClientRect(wintypes.HWND(int(hwnd)),ctypes.byref(r)):
            return None
        return [int(r.left),int(r.top),int(r.right),int(r.bottom)]

    @staticmethod
    def _dpi(hwnd):
        try:
            fn=getattr(user32_bridge,'GetDpiForWindow',None)
            if fn:
                v=int(fn(wintypes.HWND(int(hwnd))) or 0)
                return v or None
        except Exception:
            pass
        return None

    def prepare_client_point(self, hwnd, client_point, input_mode='Auto', purpose='LEFT_CLICK', require_foreground=False):
        hwnd=int(hwnd)
        cp=client_point if isinstance(client_point,ClientPoint) else ClientPoint(int(client_point[0]),int(client_point[1]))
        mode=str(input_mode or 'Auto')
        cr=self._client_rect(hwnd)
        wr=_window_rect(hwnd)
        base={
            'ok':False,'adapter_version':self.version,'purpose':str(purpose),
            'hwnd':hwnd,'requested_mode':mode,'client_point':[int(cp.x),int(cp.y)],
            'client_coordinate_space':'CLIENT','client_rect':cr,'window_rect':list(wr) if wr else None,
            'dpi':self._dpi(hwnd),'conversion_count':0,'prepared_only':True,'require_foreground':bool(require_foreground),
        }
        if not cr or not (int(cr[0]) <= cp.x < int(cr[2]) and int(cr[1]) <= cp.y < int(cr[3])):
            base['reason']='CLIENT_POINT_OUTSIDE_CLIENT_RECT'
            return base
        if mode=='Background':
            base.update({'ok':True,'dispatch_coordinate_space':'CLIENT','screen_point':None,
                         'client_origin_screen':None,'conversion_function':'BACKGROUND_CLIENT_POSTMESSAGE'})
            return base

        activation=None
        if int(user32_bridge.GetForegroundWindow() or 0)!=hwnd:
            activation=_activate_window(hwnd)
            # Preserve the proven Source Pick semantics by default: legacy source
            # input attempted SendInput even when the activation probe did not
            # immediately report foreground.  Store destination opts into the
            # stricter require_foreground gate below.
            if require_foreground and not activation.get('ok'):
                base.update({'reason':'FOREGROUND_ACTIVATION_FAILED','activation':activation})
                return base
        # Exactly ONE conversion of the destructive point.
        sp=_client_to_screen(hwnd,cp.x,cp.y)
        if not sp:
            base.update({'reason':'CLIENT_TO_SCREEN_FAILED','activation':activation})
            return base
        screen=ScreenPoint(int(sp[0]),int(sp[1]))
        origin=[int(screen.x-cp.x),int(screen.y-cp.y)]
        expected=[int(origin[0]+cp.x),int(origin[1]+cp.y)]
        transform_ok=bool(abs(expected[0]-screen.x)<=1 and abs(expected[1]-screen.y)<=1)
        if not transform_ok:
            base.update({'reason':'CLIENT_SCREEN_TRANSFORM_VIOLATION','activation':activation,
                         'screen_point':[screen.x,screen.y],'client_origin_screen':origin,
                         'conversion_count':1,'conversion_function':'ClientToScreen'})
            return base
        base.update({
            'ok':True,'activation':activation,'screen_point':[screen.x,screen.y],
            'screen_coordinate_space':'SCREEN','dispatch_coordinate_space':'SCREEN',
            'client_origin_screen':origin,'conversion_count':1,
            'conversion_function':'ClientToScreen','transform_assertion_ok':True,
            '_client_point_obj':cp,'_screen_point_obj':screen,
        })
        return base

    def dispatch_prepared_left_click(self, prepared, verify_cursor=False):
        out={k:v for k,v in dict(prepared or {}).items() if not str(k).startswith('_')}
        out.update({'exactly_once':True,'prepared_only':False,'input_sent':False})
        if not prepared or not prepared.get('ok'):
            out['ok']=False
            out['reason']=out.get('reason') or 'INPUT_COORDINATE_PREPARE_FAILED'
            return out
        hwnd=int(prepared['hwnd']); mode=str(prepared.get('requested_mode') or 'Auto')
        cx,cy=[int(v) for v in prepared.get('client_point',[0,0])]
        if mode=='Background':
            sent,target,tpt=_post_left_click_client(hwnd,cx,cy)
            out.update({'ok':bool(sent),'input_sent':bool(sent),'used_mode':'Background/PostMessageLeftClick',
                        'target_hwnd':int(target),'target_point':list(tpt) if tpt else None,
                        'actual_dispatch_space':'CLIENT'})
            if not sent: out['reason']='BACKGROUND_LEFT_CLICK_FAILED'
            return out

        sp=prepared.get('screen_point')
        if not sp or int(prepared.get('conversion_count',0))!=1:
            out.update({'ok':False,'reason':'FOREGROUND_SCREEN_POINT_NOT_PREPARED'})
            return out
        sx,sy=int(sp[0]),int(sp[1])
        old=_cursor_screen()
        if not _set_cursor_screen(sx,sy):
            out.update({'ok':False,'reason':'SET_CURSOR_POS_FAILED','old_cursor':list(old) if old else None})
            return out
        time.sleep(.035)
        actual=_cursor_screen()
        delta=None
        if actual:
            delta=[int(actual[0]-sx),int(actual[1]-sy)]
        if verify_cursor and (not actual or abs(delta[0])>2 or abs(delta[1])>2):
            if old: _set_cursor_screen(old[0],old[1])
            out.update({'ok':False,'reason':'CURSOR_TARGET_MISMATCH','expected_screen_point':[sx,sy],
                        'actual_screen_point':list(actual) if actual else None,'cursor_delta':delta,
                        'old_cursor':list(old) if old else None,'actual_dispatch_space':'SCREEN'})
            return out
        arr=(INPUT*2)()
        arr[0].type=INPUT_MOUSE; arr[0].mi=MOUSEINPUT(0,0,0,MOUSEEVENTF_LEFTDOWN,0,0)
        arr[1].type=INPUT_MOUSE; arr[1].mi=MOUSEINPUT(0,0,0,MOUSEEVENTF_LEFTUP,0,0)
        sent=user32_bridge.SendInput(2,ctypes.byref(arr),ctypes.sizeof(INPUT))
        time.sleep(.075)
        if old: _set_cursor_screen(old[0],old[1])
        ok=bool(int(sent)==2)
        out.update({'ok':ok,'input_sent':ok,'used_mode':'Foreground/SendInputLeftClick',
                    'actual_dispatch_space':'SCREEN','actual_screen_point':list(actual) if actual else [sx,sy],
                    'cursor_delta':delta,'old_cursor':list(old) if old else None})
        if not ok: out['reason']='FOREGROUND_SENDINPUT_LEFT_CLICK_FAILED'
        return out

    def click_client_point(self, hwnd, client_point, input_mode='Auto', purpose='LEFT_CLICK', verify_cursor=False, require_foreground=False):
        prepared=self.prepare_client_point(hwnd,client_point,input_mode,purpose=purpose,require_foreground=require_foreground)
        return self.dispatch_prepared_left_click(prepared,verify_cursor=verify_cursor)


INPUT_COORDINATE_ADAPTER=InputCoordinateAdapter()


def _storage_screen_dispatch_safety(grid, prepared):
    """Cross-check Store destination in CLIENT and derived SCREEN space.

    No extra ClientToScreen calls are made here.  The client origin is derived
    from the one prepared point conversion: screen_point - client_point.
    """
    try:
        if not prepared or not prepared.get('ok'):
            return {'ok':False,'reason':'INPUT_COORDINATE_PREPARE_FAILED'}
        if str(prepared.get('requested_mode') or '')=='Background':
            return {'ok':True,'reason':'BACKGROUND_CLIENT_SPACE','conversion_count':0,
                    'screen_storage_grid_rect':None}
        if int(prepared.get('conversion_count',0))!=1:
            return {'ok':False,'reason':'CLIENT_SCREEN_TRANSFORM_VIOLATION','conversion_count':prepared.get('conversion_count')}
        cp=prepared.get('client_point'); sp=prepared.get('screen_point'); origin=prepared.get('client_origin_screen')
        rect=list((grid or {}).get('grid_rect') or [])
        if not cp or not sp or not origin or len(rect)!=4:
            return {'ok':False,'reason':'STORE_SCREEN_SAFETY_GEOMETRY_INCOMPLETE'}
        expected=[int(origin[0]+cp[0]),int(origin[1]+cp[1])]
        if abs(expected[0]-int(sp[0]))>1 or abs(expected[1]-int(sp[1]))>1:
            return {'ok':False,'reason':'CLIENT_SCREEN_TRANSFORM_VIOLATION','expected_screen_point':expected,'screen_point':sp}
        sr=[int(origin[0]+rect[0]),int(origin[1]+rect[1]),int(origin[0]+rect[2]),int(origin[1]+rect[3])]
        inside=bool(sr[0] < int(sp[0]) < sr[2] and sr[1] < int(sp[1]) < sr[3])
        if not inside:
            return {'ok':False,'reason':'SCREEN_POINT_OUTSIDE_CONVERTED_STORAGE_GRID',
                    'screen_point':sp,'screen_storage_grid_rect':sr,'client_storage_grid_rect':rect}
        return {'ok':True,'reason':'CLIENT_SCREEN_STORE_SAFETY_PASS','conversion_count':1,
                'client_point':list(cp),'screen_point':list(sp),'client_origin_screen':list(origin),
                'client_storage_grid_rect':rect,'screen_storage_grid_rect':sr}
    except Exception as e:
        return {'ok':False,'reason':'STORE_SCREEN_SAFETY_EXCEPTION','error':str(e)}


def _safe_ground_drop_points(image, grid):
    """
    Return map-ground points that stay away from inventory, chat and hotbar.
    The points are proportional to the JX1 client instead of hard-coded 800x600
    pixels, so the same flow also works when the client is scaled.
    """
    if image is None:
        return []
    w, h = int(image.width), int(image.height)
    xs = [int(x) for x in (grid or {}).get('x_lines', [])]
    inv_left = min(xs) if xs else int(w * .73)
    xmax = min(int(w * .56), inv_left - 42)
    xmin = max(90, int(w * .20))
    if xmax <= xmin + 30:
        xmax = max(xmin + 35, inv_left - 24)
    # Upper/middle-left map region: clear of bottom chat/hotbar and right bag.
    norms = [(.30,.31),(.39,.31),(.25,.39),(.36,.40),(.45,.37),(.29,.48),(.42,.48),(.22,.31)]
    pts=[]
    for nx,ny in norms:
        x=max(xmin,min(xmax,int(w*nx)))
        y=max(82,min(int(h*.68),int(h*ny)))
        pt=(int(x),int(y))
        if pt not in pts:
            pts.append(pt)
    return pts


def _ground_roi_mae(before_image, after_image, point, radius=DROP_GROUND_ROI_RADIUS):
    """Diagnostic-only motion score for a map-ground ROI.

    This score never decides whether a Drop committed. It is used only to rank
    candidate ground points and to label WORLD_OCCLUSION_TRANSIENT in traces.
    """
    try:
        import numpy as np
        if before_image is None or after_image is None or not point:
            return None
        a=np.asarray(before_image.convert('RGB'),dtype=np.float32)
        b=np.asarray(after_image.convert('RGB'),dtype=np.float32)
        if a.shape!=b.shape or a.size==0:
            return None
        h,w=a.shape[:2]; x,y=int(point[0]),int(point[1]); r=max(8,int(radius))
        x0=max(0,x-r); x1=min(w,x+r+1); y0=max(0,y-r); y1=min(h,y+r+1)
        aa=a[y0:y1,x0:x1]; bb=b[y0:y1,x0:x1]
        if aa.shape!=bb.shape or aa.size==0:
            return None
        return round(float(np.abs(aa-bb).mean()),3)
    except Exception:
        return None


def _rank_ground_drop_points_by_motion(before_image, after_image, points):
    """Return approved client-relative ground points ordered by recent motion."""
    ranked=[]
    for idx,pt in enumerate(points or []):
        score=_ground_roi_mae(before_image,after_image,pt)
        ranked.append({'point':[int(pt[0]),int(pt[1])],'motion_mae':score,'original_index':idx})
    ranked.sort(key=lambda x: (999999.0 if x.get('motion_mae') is None else float(x['motion_mae']), int(x['original_index'])))
    return ranked


def _cursor_carry_reprobe_points(image, grid=None, primary=None):
    """Approved CLIENT-RELATIVE neutral zones for cursor-carry reprobe.

    Zones stay in the quiet upper-middle world band: left of source inventory,
    below the title strip, above character center/chat, and away from minimap.
    They are geometry-derived rather than absolute screen coordinates.
    """
    if image is None:
        return []
    w,h=int(image.width),int(image.height)
    if w<320 or h<240:
        return []
    raw=[
        (int(round(w*.43)),int(round(h*.11))),
        (int(round(w*.55)),int(round(h*.11))),
        (int(round(w*.43)),int(round(h*.20))),
        (int(round(w*.55)),int(round(h*.20))),
    ]
    xs=[int(x) for x in (grid or {}).get('x_lines',[])]; ys=[int(y) for y in (grid or {}).get('y_lines',[])]
    grid_rect=None
    if len(xs)>=2 and len(ys)>=2:
        grid_rect=(min(xs)-24,min(ys)-24,max(xs)+24,max(ys)+24)
    out=[]
    for x,y in raw:
        if primary and abs(x-int(primary[0]))<28 and abs(y-int(primary[1]))<28:
            continue
        if grid_rect and grid_rect[0]<=x<=grid_rect[2] and grid_rect[1]<=y<=grid_rect[3]:
            continue
        # conservative exclusions: minimap/right-top, bottom chat/buttons, center actor.
        if x>=int(w*.70) and y<=int(h*.34):
            continue
        if y>=int(h*.65):
            continue
        if abs(x-w//2)<55 and abs(y-h//2)<75:
            continue
        pt=(int(x),int(y))
        if pt not in out:
            out.append(pt)
    return out


def _rank_cursor_reprobe_points(reference_image, motion_image, points):
    ranked=[]
    for idx,pt in enumerate(points or []):
        score=_ground_roi_mae(reference_image,motion_image,pt,radius=18) if motion_image is not None else None
        ranked.append({'point':[int(pt[0]),int(pt[1])],'motion_mae':score,'original_index':idx})
    ranked.sort(key=lambda x:(999999.0 if x.get('motion_mae') is None else float(x['motion_mae']),int(x['original_index'])))
    return ranked


def _drop_reconcile_source_cursor(source_state, cursor_state):
    """V10.6 authoritative Drop state precedence."""
    source=str(source_state or 'SOURCE_AMBIGUOUS')
    cursor=str(cursor_state or 'CURSOR_AMBIGUOUS')
    if cursor=='CURSOR_HOLDING_ITEM_CONFIRMED':
        return {'reconciliation':'PARTIAL','reason':'DROP_PARTIAL_COMMIT_CURSOR_HOLDING','ok':False}
    if source=='SOURCE_CLEAR_CONFIRMED' and cursor=='CURSOR_EMPTY_CONFIRMED':
        return {'reconciliation':'COMMITTED','reason':'DROP_COMMITTED_SOURCE_CLEAR_CURSOR_EMPTY','ok':True}
    if source in ('SOURCE_STILL_PRESENT','SOURCE_PRESENT_CONFIRMED') and cursor=='CURSOR_EMPTY_CONFIRMED':
        return {'reconciliation':'NOT_COMMITTED','reason':'DROP_NOT_COMMITTED_SOURCE_PRESENT_CURSOR_EMPTY','ok':False}
    return {'reconciliation':'UNKNOWN','reason':'DROP_CONFIRM_TRULY_UNCERTAIN','ok':False}


def _drop_recovery_decision(reconciliation_state, retry_count, max_recovery_attempts=DROP_RECOVERY_MAX_ATTEMPTS):
    """Pure policy decision for one logical Drop transaction.

    retry_count counts recovery actions already sent after the initial action.
    A known Drop state never becomes UNKNOWN merely because the retry budget is
    exhausted.  At the budget boundary we perform one final reconcile-only
    pass; only a genuinely UNKNOWN result may enter Safe Pause.
    """
    state=str(reconciliation_state or 'UNKNOWN').upper()
    used=max(0,int(retry_count or 0)); limit=max(0,int(max_recovery_attempts or 0))
    if state=='COMMITTED':
        return 'FINALIZE'
    if state=='NOT_COMMITTED':
        return 'RETRY_PAIR' if used < limit else 'FINAL_RECONCILE'
    if state=='PARTIAL':
        return 'RETRY_GROUND_ONLY' if used < limit else 'FINAL_RECONCILE'
    return 'SAFE_PAUSE'


def _personal_bag_icon_point(image):
    """Bottom-bar HÀNH TRANG icon, calibrated from the user's current 800x600 client.

    v9.1 clicked near the top edge of this button (~526,544). The latest
    screenshot shows the stable center at ~531,571 client pixels.
    """
    if image is None:
        return None
    w, h = int(image.width), int(image.height)
    if w < 640 or h < 450:
        return None
    return int(round(w * (531.0/800.0))), int(round(h * (571.0/600.0)))


def _personal_bag_close_point(image, grid=None):
    """Center of the popup's own Đóng button."""
    if image is None:
        return None
    w, h = int(image.width), int(image.height)
    xs=[int(x) for x in (grid or {}).get('x_lines',[])]
    ys=[int(y) for y in (grid or {}).get('y_lines',[])]
    if len(xs)==7 and len(ys)==11:
        return int(round((xs[0]+xs[-1])/2.0)), int(round(ys[-1] + 15*(h/600.0)))
    return int(round(w*(442.0/800.0))), int(round(h*(444.0/600.0)))


def _park_cursor_personal_bag_header(hwnd, grid, wait_sec=.075):
    """Move cursor away from source item so its tooltip cannot cover the bag grid."""
    try:
        xs=[int(x) for x in (grid or {}).get('x_lines',[])]
        ys=[int(y) for y in (grid or {}).get('y_lines',[])]
        if len(xs)!=7 or len(ys)!=11:
            return {'ok':False,'reason':'PERSONAL_HEADER_GRID_INVALID'}
        cx=int(round((xs[0]+xs[-1])/2.0))
        cy=max(24,int(ys[0]-24))
        sp=_client_to_screen(int(hwnd),cx,cy)
        if not sp:
            return {'ok':False,'reason':'PERSONAL_HEADER_CLIENT_TO_SCREEN_FAILED'}
        ok=_set_cursor_screen(int(sp[0]),int(sp[1]))
        if ok and wait_sec:
            time.sleep(float(wait_sec))
        return {'ok':bool(ok),'client_point':[cx,cy],'screen_point':[int(sp[0]),int(sp[1])]}
    except Exception as e:
        return {'ok':False,'reason':'PERSONAL_HEADER_PARK_EXCEPTION','error':str(e)}


def _personal_bag_fail_diagnostic(tag, image, payload):
    """Best-effort personal-bag diagnostic; never affects the action result."""
    try:
        stamp=time.strftime('%Y%m%d_%H%M%S')
        if image is not None:
            image.save(LOGDIR/f'{stamp}_{tag}.png')
        (LOGDIR/f'{stamp}_{tag}.json').write_text(
            json.dumps(payload,ensure_ascii=False,indent=2,default=str),
            encoding='utf-8'
        )
    except Exception:
        pass


def _left_click_client_once(hwnd, cx, cy, input_mode='Auto'):
    """Exactly one client-relative left click through the canonical adapter.

    V12.10 preserves the source-pick contract while making the coordinate space
    explicit. Foreground is CLIENT -> ClientToScreen exactly once -> SendInput.
    """
    return INPUT_COORDINATE_ADAPTER.click_client_point(
        int(hwnd), ClientPoint(int(cx),int(cy)), input_mode,
        purpose='GENERIC_CLIENT_LEFT_CLICK', verify_cursor=False
    )



def _try_personal_bag_open_once(hwnd, image, input_mode='Auto'):
    """V12.9 panel/grid-rect verified Personal Storage open.

    A 6x10 lattice is never enough by itself.  The destination becomes usable
    only after the center Personal Storage panel and the right Player Inventory
    panel are both resolved as distinct structural owners.
    """
    if image is None:
        return {'ok':False,'reason':'PERSONAL_BAG_NO_REFERENCE_IMAGE'}

    ident=detect_jx1_panel_identities(image)
    if ident.get('ok'):
        return {
            'ok':True,'image':image,'grid':ident['storage_grid'],
            'storage_identity':ident.get('storage_identity'),
            'inventory_identity':ident.get('inventory_identity'),
            'owner_identity':ident,
            'opened':False,'already_open':True,
            'open_method':'PERSONAL_STORAGE_PANEL_GRID_VERIFIED_ALREADY_OPEN_V12_9'
        }

    pt=_personal_bag_icon_point(image)
    if not pt:
        return {'ok':False,'reason':'PERSONAL_BAG_ICON_POINT_UNAVAILABLE','owner_identity':ident}
    action=_left_click_client_once(hwnd,pt[0],pt[1],input_mode)
    if not action.get('ok'):
        return {'ok':False,'reason':'PERSONAL_BAG_ICON_CLICK_FAILED','action':action,'owner_identity':ident}

    t0=time.time(); polls=0; best=None; last_img=None
    while time.time()-t0 <= 1.25:
        time.sleep(0.085 if polls else 0.18)
        polls += 1
        img=capture_client(int(hwnd))
        if img is None:
            continue
        last_img=img
        owner=detect_jx1_panel_identities(img)
        score=float(owner.get('structural_anchor_score',0) or 0)
        if best is None or score > float(best.get('structural_anchor_score',0) or 0):
            best=owner
        if owner.get('ok'):
            return {
                'ok':True,'image':img,'grid':owner['storage_grid'],
                'storage_identity':owner.get('storage_identity'),
                'inventory_identity':owner.get('inventory_identity'),
                'owner_identity':owner,
                'action':action,'opened':True,
                'open_method':'BOTTOM_BAR_PERSONAL_STORAGE_PANEL_GRID_VERIFIED_V12_9',
                'open_polls':polls,'open_wait_ms':int((time.time()-t0)*1000),
            }

    payload={
        'reason':'PERSONAL_STORAGE_OWNER_NOT_PROVEN_AFTER_ICON_CLICK',
        'action':action,'owner_identity':best,'polls':polls,
        'wait_ms':int((time.time()-t0)*1000),
        'icon_point':list(pt),'version':'v12.9',
    }
    _personal_bag_fail_diagnostic('personal_storage_panel_grid_fail_v12_9',last_img,payload)
    return {
        'ok':False,'reason':'PERSONAL_STORAGE_OWNER_NOT_PROVEN_AFTER_ICON_CLICK',
        'action':action,'owner_identity':best,'polls':polls,'wait_ms':payload['wait_ms']
    }


def _try_personal_bag_close_once(hwnd, image=None, input_mode='Auto'):
    """Close personal HÀNH TRANG with its own Đóng button, exactly once."""
    img=image if image is not None else capture_client(int(hwnd))
    if img is None:
        return {'ok':False,'reason':'PERSONAL_BAG_CLOSE_CAPTURE_FAILED'}
    grid=detect_personal_storage_grid(img)
    if not grid.get('ok'):
        return {'ok':True,'closed':True,'already_closed':True}

    pt=_personal_bag_close_point(img,grid)
    if not pt:
        return {'ok':False,'reason':'PERSONAL_BAG_CLOSE_POINT_UNAVAILABLE'}
    action=_left_click_client_once(hwnd,pt[0],pt[1],input_mode)
    if not action.get('ok'):
        return {'ok':False,'reason':'PERSONAL_BAG_CLOSE_CLICK_FAILED','action':action}

    t0=time.time(); polls=0; last_grid=grid; last_img=img
    while time.time()-t0 <= 0.95:
        time.sleep(0.085 if polls else 0.16)
        polls += 1
        after=capture_client(int(hwnd))
        if after is None:
            continue
        last_img=after
        still=detect_personal_storage_grid(after)
        last_grid=still
        if not still.get('ok'):
            return {
                'ok':True,'closed':True,'action':action,'image':after,
                'close_method':'PERSONAL_BAG_DIALOG_CLOSE_BUTTON_V9_2',
                'close_polls':polls,'close_wait_ms':int((time.time()-t0)*1000),
            }

    payload={
        'reason':'PERSONAL_BAG_CLOSE_NOT_CONFIRMED_NO_RETRY',
        'action':action,'grid':last_grid,'polls':polls,
        'wait_ms':int((time.time()-t0)*1000),
        'close_point':list(pt),
        'version':'v9.2',
    }
    _personal_bag_fail_diagnostic('personal_bag_close_fail_v9_2',last_img,payload)
    return {'ok':False,'reason':'PERSONAL_BAG_CLOSE_NOT_CONFIRMED_NO_RETRY','action':action,'grid':last_grid,'polls':polls,'wait_ms':payload['wait_ms']}


def _try_personal_storage_close_owner_once_v1211(hwnd, image=None, input_mode='Auto', proof_dir=None):
    """Close ONLY the center PERSONAL_STORAGE footer button and prove it closed.

    V12.11 final Store rule: the right PLAYER_INVENTORY remains open.  Therefore
    a generic 6x10-grid probe is not sufficient evidence for either the close
    target or close confirmation.  Resolve the center panel structurally, click
    its owner-bound footer button, then require the center storage seed to vanish
    while the right source inventory grid remains visible.
    """
    try:
        hwnd=int(hwnd)
        img=image if image is not None else capture_client(hwnd)
        if img is None:
            return {'ok':False,'reason':'PERSONAL_STORAGE_CLOSE_CAPTURE_FAILED'}
        owners=detect_jx1_panel_identities(img)
        if not owners.get('ok'):
            # If the center panel is already absent but the right source grid is
            # still present, this is already the required post-Store state.
            inv=detect_inventory_grid(img)
            seed=detect_personal_storage_grid(img)
            if inv.get('ok') and not seed.get('ok'):
                return {'ok':True,'closed':True,'already_closed':True,
                        'storage_closed_confirmed':True,'source_inventory_still_open':True,
                        'close_owner':'PERSONAL_STORAGE_FOOTER_CLOSE','input_sent':False}
            return {'ok':False,'reason':'PERSONAL_STORAGE_CLOSE_OWNER_NOT_PROVEN',
                    'owner_identity':owners,'inventory_probe':inv,'storage_probe':seed}

        si=dict(owners.get('storage_identity') or {})
        ii=dict(owners.get('inventory_identity') or {})
        if str(si.get('owner') or '')!=GridOwner.PERSONAL_STORAGE.value:
            return {'ok':False,'reason':'PERSONAL_STORAGE_CLOSE_OWNER_MISMATCH','storage_identity':si}
        if str(ii.get('owner') or '')!=GridOwner.PLAYER_INVENTORY.value:
            return {'ok':False,'reason':'PERSONAL_STORAGE_CLOSE_SOURCE_OWNER_MISMATCH','inventory_identity':ii}
        close_rect=[int(v) for v in (si.get('close_button_rect') or [])]
        footer_rect=[int(v) for v in (si.get('footer_rect') or [])]
        grid_rect=[int(v) for v in (si.get('grid_rect') or [])]
        inv_grid=[int(v) for v in (ii.get('grid_rect') or [])]
        if any(len(r)!=4 for r in (close_rect,footer_rect,grid_rect,inv_grid)):
            return {'ok':False,'reason':'PERSONAL_STORAGE_CLOSE_RECTS_INCOMPLETE',
                    'close_button_rect':close_rect,'footer_rect':footer_rect,'grid_rect':grid_rect,'inventory_grid_rect':inv_grid}
        cx=int(round((close_rect[0]+close_rect[2])/2.0)); cy=int(round((close_rect[1]+close_rect[3])/2.0))
        gate={
            'point_inside_footer':bool(_point_in_rect((cx,cy),footer_rect)),
            'point_inside_storage_grid':bool(_point_in_rect((cx,cy),grid_rect)),
            'point_inside_player_inventory':bool(_point_in_rect((cx,cy),inv_grid)),
        }
        if not gate['point_inside_footer'] or gate['point_inside_storage_grid'] or gate['point_inside_player_inventory']:
            return {'ok':False,'reason':'PERSONAL_STORAGE_CLOSE_SAFETY_GATE_FAILED','client_point':[cx,cy],
                    'gate':gate,'storage_identity':si,'inventory_identity':ii}

        pdir=Path(proof_dir) if proof_dir else (LOG_PROOF_STORAGE_DIR/'physical'/'storage_close')
        try:
            pdir.mkdir(parents=True,exist_ok=True)
            from PIL import ImageDraw
            ov=img.copy().convert('RGB'); dr=ImageDraw.Draw(ov)
            dr.rectangle(tuple(grid_rect),outline=(60,220,90),width=2)
            dr.rectangle(tuple(footer_rect),outline=(255,210,60),width=2)
            dr.rectangle(tuple(close_rect),outline=(60,180,255),width=2)
            rr=7; dr.ellipse((cx-rr,cy-rr,cx+rr,cy+rr),outline=(255,60,180),width=3)
            dr.text((cx+9,max(0,cy-12)),'PERSONAL STORAGE CLOSE',fill=(255,100,210))
            ov.save(pdir/'07_storage_close_point_CLIENT.png')
        except Exception:
            pass

        prepared=INPUT_COORDINATE_ADAPTER.prepare_client_point(
            hwnd,ClientPoint(cx,cy),input_mode,purpose='PERSONAL_STORAGE_FOOTER_CLOSE',
            require_foreground=(str(input_mode or 'Auto')!='Background')
        )
        try:
            if proof_dir:
                (pdir/'07b_storage_close_point_SCREEN.json').write_text(
                    json.dumps({k:v for k,v in prepared.items() if not str(k).startswith('_')},ensure_ascii=False,indent=2,default=str),
                    encoding='utf-8'
                )
        except Exception:
            pass
        if not prepared.get('ok'):
            return {'ok':False,'reason':prepared.get('reason') or 'PERSONAL_STORAGE_CLOSE_COORDINATE_PREPARE_FAILED',
                    'prepared':{k:v for k,v in prepared.items() if not str(k).startswith('_')},'gate':gate}
        action=INPUT_COORDINATE_ADAPTER.dispatch_prepared_left_click(prepared,verify_cursor=True)
        if not action.get('ok'):
            return {'ok':False,'reason':action.get('reason') or 'PERSONAL_STORAGE_CLOSE_CLICK_FAILED','action':action,'gate':gate}

        t0=time.time(); polls=0; last=None
        while time.time()-t0 <= 1.20:
            time.sleep(.085 if polls else .16); polls+=1
            after=capture_client(hwnd)
            if after is None:
                continue
            owners_after=detect_jx1_panel_identities(after)
            storage_seed=detect_personal_storage_grid(after)
            inv_after=detect_inventory_grid(after)
            last={'owners':owners_after,'storage_seed':storage_seed,'inventory_probe':inv_after}
            # Required post-state: center storage gone; right source inventory stays.
            if (not owners_after.get('ok')) and (not storage_seed.get('ok')) and inv_after.get('ok'):
                try:
                    if proof_dir:
                        after.save(pdir/'08_storage_closed.png')
                except Exception:
                    pass
                return {
                    'ok':True,'closed':True,'storage_closed_confirmed':True,
                    'source_inventory_still_open':True,'close_owner':'PERSONAL_STORAGE_FOOTER_CLOSE',
                    'client_point':[cx,cy],'action':action,'gate':gate,'polls':polls,
                    'close_wait_ms':int((time.time()-t0)*1000),
                }
        return {'ok':False,'reason':'PERSONAL_STORAGE_CLOSE_NOT_CONFIRMED_OWNER_AWARE',
                'storage_closed_confirmed':False,'source_inventory_still_open':bool((last or {}).get('inventory_probe',{}).get('ok')),
                'client_point':[cx,cy],'action':action,'gate':gate,'last_probe':last,'polls':polls}
    except Exception as e:
        return {'ok':False,'reason':'PERSONAL_STORAGE_CLOSE_OWNER_EXCEPTION','error':str(e)}


def _personal_snapshot_blocked_cells(snapshot, reserved_cells=None):
    """Stage 29.3 storage occupancy with rectangular-footprint reservation.

    V9_8 visual evidence is preserved. The root fix is a conservative expansion:
    connected visual cells belonging to one small inventory sprite reserve their
    full bounding rectangle. Transparent pixels inside that rectangle are NOT
    treated as free game cells. Session-reserved cells remain authoritative.
    """
    reserved=set()
    for rc in (reserved_cells or set()):
        try:
            reserved.add((int(rc[0]),int(rc[1])))
        except Exception:
            pass
    visual_cells=set()
    for c in (snapshot or {}).get('cells',[]) or []:
        try:
            rc=(int(c['row']),int(c['col']))
        except Exception:
            continue
        bright=float(c.get('bright',0) or 0)
        max90=float(c.get('max90',0) or 0)
        colorbright=float(c.get('colorbright',0) or 0)
        mean=float(c.get('mean',0) or 0)
        std=float(c.get('std',0) or 0)
        sat=float(c.get('sat',0) or 0)
        visual=bool(
            c.get('occupied') or
            bright >= 0.015 or
            max90 >= 0.018 or
            colorbright >= 0.015 or
            (sat >= 125.0 and std >= 18.0) or
            (std >= 24.0 and mean >= 32.0)
        )
        if visual:
            visual_cells.add(rc)

    blocked=set(reserved)|set(visual_cells)
    # 8-neighbour connected components. Filling each small component's bounding
    # rectangle is conservative and exactly addresses transparent holes inside
    # multi-cell item sprites without changing V9_8 first-fit search.
    remaining=set(visual_cells)
    while remaining:
        seed=remaining.pop(); comp={seed}; stack=[seed]
        while stack:
            r,c=stack.pop()
            neigh=[]
            for dr in (-1,0,1):
                for dc in (-1,0,1):
                    if dr==0 and dc==0:
                        continue
                    q=(r+dr,c+dc)
                    if q in remaining:
                        neigh.append(q)
            for q in neigh:
                remaining.remove(q); comp.add(q); stack.append(q)
        rs=[r for r,c in comp]; cs=[c for r,c in comp]
        r0,r1=min(rs),max(rs); c0,c1=min(cs),max(cs)
        fw=c1-c0+1; fh=r1-r0+1; area=fw*fh
        # Known JX1 equipment geometry is small (<=6 cells). For larger visual
        # masses, keep only originally observed cells to avoid swallowing space.
        if 1 <= area <= 6 and fw <= 4 and fh <= 4:
            for rr in range(r0,r1+1):
                for cc in range(c0,c1+1):
                    blocked.add((rr,cc))

    # Local rectangular closure handles a transparent item that touches another
    # item and therefore belongs to a larger visual component. False OCCUPIED is
    # safe for storage planning; false EMPTY is destructive. In particular, any
    # 2x3 / 3x2 window with >=4 visual cells reserves all six game cells.
    closures=((2,3,4),(3,2,4),(2,2,3),(1,4,3),(4,1,3))
    for fw,fh,min_hits in closures:
        for r0 in range(0,10-fh+1):
            for c0 in range(0,6-fw+1):
                rect={(r,c) for r in range(r0,r0+fh) for c in range(c0,c0+fw)}
                if len(rect & visual_cells) >= min_hits:
                    blocked.update(rect)
    return blocked


def _personal_cell_strict_empty(c):
    if not c:
        return False
    return bool(
        not c.get('occupied') and
        float(c.get('bright',1) or 0) <= 0.012 and
        float(c.get('max90',1) or 0) <= 0.016 and
        float(c.get('colorbright',1) or 0) <= 0.012 and
        not (float(c.get('sat',0) or 0) >= 125.0 and float(c.get('std',0) or 0) >= 18.0) and
        not (float(c.get('std',0) or 0) >= 24.0 and float(c.get('mean',0) or 0) >= 32.0)
    )


def _free_personal_block(snapshot, footprint, reserved_cells=None):
    """v9.8 deterministic STRICT-FIRST-FIT destination finder.

    No adjacency scoring is used anymore. The Auto scans row-major and chooses
    the first rectangle whose *every* cell is definitely empty and not reserved.
    This makes placement stable and prevents a later item from being aimed onto
    an item that was already present before Auto started.
    """
    if not snapshot or not snapshot.get('ok'):
        return None
    try:
        fw=max(1,int((footprint or [1,1])[0])); fh=max(1,int((footprint or [1,1])[1]))
    except Exception:
        fw=fh=1
    if fw>6 or fh>10:
        return None
    cmap={(int(c['row']),int(c['col'])):c for c in snapshot.get('cells',[]) or []}
    blocked=_personal_snapshot_blocked_cells(snapshot,reserved_cells)

    for r in range(0,10-fh+1):
        for col in range(0,6-fw+1):
            cells=[(rr,cc) for rr in range(r,r+fh) for cc in range(col,col+fw)]
            if any(rc in blocked for rc in cells):
                continue
            if not all(_personal_cell_strict_empty(cmap.get(rc)) for rc in cells):
                continue
            return {
                'row':r,'col':col,'cells':[[a,b] for a,b in cells],
                'footprint':[fw,fh],
                'placement_policy':'V9_8_STRICT_FIRST_FIT_REAL_OCCUPANCY',
                'blocked_count':len(blocked),
                'reserved_count':len(set(reserved_cells or set())),
            }
    return None



def _compact_personal_block(snapshot, footprint, reserved_cells=None, placement_history=None, item_group=None):
    """V10.6 deterministic compact packing over ALL legal placements.

    Hard validity is identical to the proven real-occupancy planner. Only the
    destination ranking changes: prefer same-session affinity, boundary/cluster
    contact, and low fragmentation; deterministic top-left breaks ties.
    """
    if not snapshot or not snapshot.get('ok'):
        return None
    try:
        fw=max(1,int((footprint or [1,1])[0])); fh=max(1,int((footprint or [1,1])[1]))
    except Exception:
        fw=fh=1
    if fw>6 or fh>10:
        return None
    cmap={(int(c['row']),int(c['col'])):c for c in snapshot.get('cells',[]) or []}
    blocked=_personal_snapshot_blocked_cells(snapshot,reserved_cells)
    hist=placement_history if isinstance(placement_history,dict) else {}
    candidates=[]

    def neigh(rc):
        r,c=rc
        for dr,dc in ((-1,0),(1,0),(0,-1),(0,1)):
            nr,nc=r+dr,c+dc
            if 0<=nr<10 and 0<=nc<6:
                yield (nr,nc)

    for r in range(0,10-fh+1):
        for col in range(0,6-fw+1):
            cells=[(rr,cc) for rr in range(r,r+fh) for cc in range(col,col+fw)]
            if any(rc in blocked for rc in cells):
                continue
            if not all(_personal_cell_strict_empty(cmap.get(rc)) for rc in cells):
                continue
            cellset=set(cells)
            boundary_contact=sum(1 for rr,cc in cells if rr in (0,9) or cc in (0,5))
            cluster_contact=0; affinity=0
            for rc in cells:
                for nb in neigh(rc):
                    if nb in cellset:
                        continue
                    if nb in blocked:
                        cluster_contact+=1
                    meta=hist.get(tuple(nb)) or hist.get(str(tuple(nb)))
                    if isinstance(meta,dict):
                        if item_group and meta.get('group')==item_group:
                            affinity+=2
                        if list(meta.get('footprint') or [])==[fw,fh]:
                            affinity+=1
            # Penalize new isolated one-cell holes in the remaining free set.
            after_blocked=set(blocked)|cellset
            frag=0
            for rr in range(10):
                for cc in range(6):
                    rc=(rr,cc)
                    if rc in after_blocked or not _personal_cell_strict_empty(cmap.get(rc)):
                        continue
                    free_neighbors=sum(1 for nb in neigh(rc) if nb not in after_blocked and _personal_cell_strict_empty(cmap.get(nb)))
                    if free_neighbors==0:
                        frag+=3
                    elif free_neighbors==1:
                        frag+=1
            score=(affinity*12)+(cluster_contact*4)+(boundary_contact*2)-(frag*5)
            candidates.append({
                'row':r,'col':col,'cells':[[a,b] for a,b in cells],
                'footprint':[fw,fh],'placement_policy':'V10_6_COMPACT_REAL_OCCUPANCY',
                'blocked_count':len(blocked),'reserved_count':len(set(reserved_cells or set())),
                'affinity_score':affinity,'compactness_score':cluster_contact+boundary_contact,
                'fragmentation_penalty':frag,'final_score':score,
            })
    if not candidates:
        return None
    candidates.sort(key=lambda x:(-float(x['final_score']), int(x['row']), int(x['col'])))
    best=dict(candidates[0]); best['valid_candidate_count']=len(candidates)
    return best


def _target_cells_signature_stable(before_snapshot, after_snapshot, target_cells, max_mae=7.0):
    """Pre-click guard: selected EMPTY cells must remain visually stable.

    We run this before touching the source item. If animation, tooltip residue, or
    a just-rendered item changes a target cell, we re-plan instead of clicking.
    """
    bm=_snapshot_cell_map(before_snapshot)
    am=_snapshot_cell_map(after_snapshot)
    details=[]
    ok=True
    for raw in target_cells or []:
        rc=(int(raw[0]),int(raw[1]))
        b=bm.get(rc); a=am.get(rc)
        mae=_sig_mae((b or {}).get('_sig'),(a or {}).get('_sig')) if b and a else 255.0
        empty_now=_personal_cell_strict_empty(a) if a else False
        details.append({'cell':[rc[0],rc[1]],'mae':round(float(mae),3),'empty_now':bool(empty_now)})
        if (not empty_now) or mae>float(max_mae):
            ok=False
    return {'ok':bool(ok),'max_mae':float(max_mae),'details':details}


def _write_personal_bag_occupancy_diag(image, grid, snapshot, reserved_cells=None, target=None, note=None):
    """Write latest storage occupancy overlay.

    RED=currently occupied, GREEN=selected destination, YELLOW=uncertain,
    BLUE=session reservation. Diagnostic only; never participates in clicks.
    """
    try:
        if image is None or not grid or not snapshot or not snapshot.get('ok'):
            return {'ok':False,'reason':'DIAG_INPUT_NOT_READY'}
        from PIL import ImageDraw
        overlay=image.copy().convert('RGB')
        draw=ImageDraw.Draw(overlay)
        xs=[int(x) for x in grid.get('x_lines',[])]
        ys=[int(y) for y in grid.get('y_lines',[])]
        if len(xs)!=7 or len(ys)!=11:
            return {'ok':False,'reason':'DIAG_BAD_GRID'}
        reserved=set((int(r),int(c)) for r,c in (reserved_cells or set()))
        occupied=_personal_snapshot_blocked_cells(snapshot,set())
        cmap={(int(c['row']),int(c['col'])):c for c in (snapshot.get('cells') or [])}
        uncertain=set()
        for r in range(10):
            for c in range(6):
                rc=(r,c)
                if rc in occupied or rc in reserved:
                    continue
                if not _personal_cell_strict_empty(cmap.get(rc)):
                    uncertain.add(rc)
        for r,c in sorted(occupied):
            if 0<=r<10 and 0<=c<6:
                draw.rectangle([xs[c]+2,ys[r]+2,xs[c+1]-2,ys[r+1]-2],outline=(255,70,70),width=2)
        for r,c in sorted(uncertain):
            if 0<=r<10 and 0<=c<6:
                draw.rectangle([xs[c]+3,ys[r]+3,xs[c+1]-3,ys[r+1]-3],outline=(255,220,70),width=2)
        for r,c in sorted(reserved):
            if 0<=r<10 and 0<=c<6:
                draw.rectangle([xs[c]+4,ys[r]+4,xs[c+1]-4,ys[r+1]-4],outline=(70,140,255),width=2)
        target_cells={tuple(int(v) for v in x[:2]) for x in ((target or {}).get('cells') or []) if isinstance(x,(list,tuple)) and len(x)>=2}
        for r,c in sorted(target_cells):
            if 0<=r<10 and 0<=c<6:
                draw.rectangle([xs[c]+3,ys[r]+3,xs[c+1]-3,ys[r+1]-3],outline=(80,255,120),width=3)
        png=LOGDIR/'storage_occupancy_debug.png'
        js=LOGDIR/'storage_occupancy_debug.json'
        overlay.save(png)
        payload={
            'version':'v10.4.5',
            'occupied_cells':[list(x) for x in sorted(occupied)],
            'reserved_cells':[list(x) for x in sorted(reserved)],
            'uncertain_cells':[list(x) for x in sorted(uncertain)],
            'target':target,'note':note,
            'grid':{
                'x_lines':xs,'y_lines':ys,'confidence':grid.get('confidence'),
                'rows':10,'columns':6,'total_cells':60,
                'grid_origin_x':xs[0],'grid_origin_y':ys[0]
            },
        }
        js.write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
        return {
            'ok':True,'png':str(png),'json':str(js),
            'occupied_count':len(occupied),'reserved_count':len(reserved),
            'uncertain_count':len(uncertain)
        }
    except Exception as e:
        return {'ok':False,'reason':'DIAG_WRITE_FAILED','error':str(e)}




def _grid_cell_from_client_point(grid, point):
    """Resolve a CLIENT point to one logical grid cell; no input is sent."""
    try:
        xs=[int(x) for x in (grid or {}).get('x_lines',[])]; ys=[int(y) for y in (grid or {}).get('y_lines',[])]
        if len(xs)!=7 or len(ys)!=11 or not point:
            return None
        x,y=int(point[0]),int(point[1])
        col=next((c for c in range(6) if xs[c] <= x < xs[c+1]),None)
        row=next((r for r in range(10) if ys[r] <= y < ys[r+1]),None)
        return (int(row),int(col)) if row is not None and col is not None else None
    except Exception:
        return None


def _derive_item_placement_anchor_policy(item, source_grid, source_client_point):
    """Preserve the real JX1 cursor pivot established by the successful source PICK.

    Source PICK is frozen. Its helper is allowed to click the first *visually occupied*
    cell when the geometric top-left anchor cell is transparent. V12.6 then discarded
    that pivot and always clicked the planned destination top-left cell. For multi-cell
    items this shifts the resulting footprint. The only safe coordinate contract is to
    carry the source click-cell offset into the destination click.
    """
    try:
        ar,ac=[int(x) for x in (item or {}).get('anchor',[0,0])[:2]]
        fw,fh=[max(1,int(x)) for x in (item or {}).get('footprint',[1,1])[:2]]
        src_cell=_grid_cell_from_client_point(source_grid,source_client_point)
        if src_cell is None:
            return {'ok':False,'reason':'SOURCE_PICK_CELL_UNRESOLVED'}
        sr,sc=src_cell
        dr,dc=int(sr-ar),int(sc-ac)
        if not (0<=dr<fh and 0<=dc<fw):
            return {'ok':False,'reason':'SOURCE_PICK_PIVOT_OUTSIDE_FOOTPRINT',
                    'source_anchor':[ar,ac],'source_click_cell':[sr,sc],
                    'footprint':[fw,fh],'pivot_offset':[dr,dc]}
        return {
            'ok':True,'policy':'CURSOR_PIVOT_CELL_FROM_SOURCE_PICK',
            'source_anchor':[ar,ac],'source_click_cell':[sr,sc],
            'pivot_offset':[dr,dc],'footprint':[fw,fh],
        }
    except Exception as e:
        return {'ok':False,'reason':'SOURCE_PICK_PIVOT_RESOLVE_EXCEPTION','error':str(e)}



def _bind_storage_grid_owner_identity(controller, hwnd, owner_result):
    """Attach an explicit PERSONAL_STORAGE lease to the freshly detected grid."""
    if not isinstance(owner_result,dict) or not owner_result.get('ok'):
        return {'ok':False,'reason':'STORAGE_OWNER_IDENTITY_NOT_PROVEN'}
    sg=dict(owner_result.get('storage_grid') or {})
    si=dict(owner_result.get('storage_identity') or {})
    ii=dict(owner_result.get('inventory_identity') or {})
    if str(si.get('owner') or '') != GridOwner.PERSONAL_STORAGE.value:
        return {'ok':False,'reason':'STORAGE_IDENTITY_OWNER_MISMATCH','storage_identity':si}
    if str(ii.get('owner') or '') != GridOwner.PLAYER_INVENTORY.value:
        return {'ok':False,'reason':'PLAYER_INVENTORY_IDENTITY_OWNER_MISMATCH','inventory_identity':ii}
    if not bool(si.get('inner_grid_verified')) or not bool(sg.get('inner_grid_verified')):
        return {'ok':False,'reason':'STORAGE_INNER_GRID_NOT_VERIFIED','storage_identity':si}
    srect=list(si.get('grid_rect') or [])
    irect=list(ii.get('grid_rect') or [])
    header_rect=list(si.get('header_rect') or [])
    footer_rect=list(si.get('footer_rect') or [])
    if len(srect)!=4 or len(irect)!=4 or len(header_rect)!=4 or len(footer_rect)!=4:
        return {'ok':False,'reason':'OWNER_GRID_RECT_MISSING','storage_rect':srect,'inventory_rect':irect,
                'storage_header_rect':header_rect,'storage_footer_rect':footer_rect}
    if _rect_intersection_area_local(srect,header_rect)!=0 or _rect_intersection_area_local(srect,footer_rect)!=0:
        return {'ok':False,'reason':'STORAGE_GRID_INTERSECTS_NONCLICK_REGION','storage_rect':srect,
                'storage_header_rect':header_rect,'storage_footer_rect':footer_rect}
    ix0=max(int(srect[0]),int(irect[0])); iy0=max(int(srect[1]),int(irect[1]))
    ix1=min(int(srect[2]),int(irect[2])); iy1=min(int(srect[3]),int(irect[3]))
    if max(0,ix1-ix0)*max(0,iy1-iy0) != 0:
        return {'ok':False,'reason':'OWNER_GRID_RECTS_OVERLAP','storage_rect':srect,'inventory_rect':irect}

    sig=(int(hwnd),tuple(int(v) for v in si.get('panel_rect',[])),
         tuple(int(v) for v in srect),
         tuple(int(v) for v in si.get('header_rect',[])),
         tuple(int(v) for v in si.get('footer_rect',[])),
         tuple(int(v) for v in sg.get('x_lines',[])),
         tuple(int(v) for v in sg.get('y_lines',[])))
    old=getattr(controller,'_storage_grid_lease_signature',None)
    if old != sig:
        controller._storage_grid_lease_generation=int(getattr(controller,'_storage_grid_lease_generation',0) or 0)+1
        controller._storage_grid_lease_signature=sig
    gen=int(getattr(controller,'_storage_grid_lease_generation',1) or 1)

    sg.update({
        'kind':GridOwner.PERSONAL_STORAGE.value,
        'owner':GridOwner.PERSONAL_STORAGE.value,
        'lease_owner':GridOwner.PERSONAL_STORAGE.value,
        'lease_generation':gen,
        'coordinate_space':'CLIENT',
        'panel_rect':[int(v) for v in si.get('panel_rect',[])],
        'grid_rect':[int(v) for v in srect],
        'header_rect':[int(v) for v in si.get('header_rect',[])],
        'footer_rect':[int(v) for v in si.get('footer_rect',[])],
        'inner_grid_verified':bool(si.get('inner_grid_verified') and sg.get('inner_grid_verified')),
        'grid_authority':owner_result.get('grid_authority'),
        'player_inventory_panel_rect':[int(v) for v in ii.get('panel_rect',[])],
        'player_inventory_grid_rect':[int(v) for v in irect],
        'owner_confidence':float(si.get('confidence',0) or 0),
        'structural_anchor_score':float(si.get('structural_anchor_score',0) or 0),
    })
    return {
        'ok':True,'grid':sg,'generation':gen,
        'storage_identity':si,'inventory_identity':ii,
        'owner_result':owner_result,
    }


def _point_in_rect(point, rect):
    if not point or not rect or len(rect)<4:
        return False
    x,y=int(point[0]),int(point[1]); x0,y0,x1,y1=[int(v) for v in rect[:4]]
    return x0 <= x < x1 and y0 <= y < y1


def _write_store_owner_overlay(proof_dir, image, storage_grid, target=None, click_point=None):
    """V12.9 panel/grid proof with explicit header + footer exclusion."""
    try:
        if image is None or not storage_grid:
            return None
        from PIL import ImageDraw
        d=Path(proof_dir); d.mkdir(parents=True,exist_ok=True)
        out=image.copy().convert('RGB'); draw=ImageDraw.Draw(out)
        sp=list(storage_grid.get('panel_rect') or [])
        sh=list(storage_grid.get('header_rect') or [])
        sg=list(storage_grid.get('grid_rect') or storage_grid.get('roi') or [])
        sf=list(storage_grid.get('footer_rect') or [])
        ip=list(storage_grid.get('player_inventory_panel_rect') or [])
        ig=list(storage_grid.get('player_inventory_grid_rect') or [])
        if len(ip)==4:
            draw.rectangle(ip,outline=(80,170,255),width=3)
            draw.text((ip[0]+4,ip[1]+4),'PLAYER_INVENTORY_PANEL',fill=(80,200,255))
        if len(ig)==4:
            draw.rectangle(ig,outline=(80,170,255),width=2)
            draw.text((ig[0]+4,ig[1]+4),'PLAYER_INVENTORY_GRID',fill=(80,200,255))
        if len(sp)==4:
            draw.rectangle(sp,outline=(255,210,60),width=3)
            draw.text((sp[0]+4,sp[1]+4),'PERSONAL_STORAGE_PANEL',fill=(255,230,80))
        if len(sh)==4:
            draw.rectangle(sh,outline=(255,110,70),width=2)
            draw.text((sh[0]+4,sh[1]+4),'STORAGE_HEADER / NO CLICK',fill=(255,130,80))
        if len(sg)==4:
            draw.rectangle(sg,outline=(80,255,120),width=3)
            draw.text((sg[0]+4,sg[1]+4),'PERSONAL_STORAGE_GRID',fill=(80,255,120))
        if len(sf)==4:
            draw.rectangle(sf,outline=(255,150,70),width=2)
            draw.text((sf[0]+4,max(sf[1]+2,sf[3]-14)),'STORAGE_FOOTER / NO CLICK',fill=(255,170,80))
        xs=[int(x) for x in storage_grid.get('x_lines',[])]; ys=[int(y) for y in storage_grid.get('y_lines',[])]
        for x in xs:
            if len(sg)==4: draw.line((x,sg[1],x,sg[3]),fill=(90,255,130),width=1)
        for y in ys:
            if len(sg)==4: draw.line((sg[0],y,sg[2],y),fill=(90,255,130),width=1)
        for rr,cc in [tuple(x) for x in ((target or {}).get('cells') or []) if len(x)>=2]:
            if 0<=int(rr)<10 and 0<=int(cc)<6 and len(xs)==7 and len(ys)==11:
                draw.rectangle((xs[int(cc)]+2,ys[int(rr)]+2,xs[int(cc)+1]-2,ys[int(rr)+1]-2),
                               outline=(255,80,80),width=3)
        if click_point:
            x,y=[int(v) for v in click_point]; r=7
            draw.ellipse((x-r,y-r,x+r,y+r),outline=(255,0,255),width=3)
            draw.line((x-r-5,y,x+r+5,y),fill=(255,0,255),width=2)
            draw.line((x,y-r-5,x,y+r+5),fill=(255,0,255),width=2)
            draw.text((x+10,max(0,y-14)),'DESTINATION CLICK',fill=(255,100,255))
        paths=[]
        for name in ('PANEL_OWNER_OVERLAY.png','STORAGE_DESTINATION_PRECLICK.png','STORE_OWNER_OVERLAY.png','DESTINATION_PRECLICK.png'):
            pp=d/name; out.save(pp); paths.append(str(pp))
        return paths[0]
    except Exception:
        return None


def _rect_intersection_area_local(a, b):
    if not a or not b or len(a)<4 or len(b)<4:
        return 0
    x0=max(int(a[0]),int(b[0])); y0=max(int(a[1]),int(b[1]))
    x1=min(int(a[2]),int(b[2])); y1=min(int(a[3]),int(b[3]))
    return max(0,x1-x0)*max(0,y1-y0)


def _storage_destination_coordinate_contract(hwnd, grid, target, anchor_policy=None):
    """V12.9 authoritative INNER PersonalStorageGrid -> CLIENT -> Input coordinate contract."""
    try:
        g=dict(grid or {}); policy=dict(anchor_policy or {})
        owner=str(g.get('lease_owner') or g.get('owner') or g.get('kind') or '')
        if owner!=GridOwner.PERSONAL_STORAGE.value:
            return {'ok':False,'reason':'STORAGE_DESTINATION_OWNER_VIOLATION','grid_owner':owner or None}
        if not bool(g.get('inner_grid_verified')):
            return {'ok':False,'reason':'STORAGE_GRID_NOT_VERIFIED','grid_owner':owner,'grid_authority':g.get('grid_authority')}
        if str(g.get('coordinate_space') or '')!='CLIENT':
            return {'ok':False,'reason':'STORAGE_COORDINATE_SPACE_NOT_CLIENT','coordinate_space':g.get('coordinate_space')}
        xs=[int(x) for x in g.get('x_lines',[])]; ys=[int(y) for y in g.get('y_lines',[])]
        if len(xs)!=7 or len(ys)!=11:
            return {'ok':False,'reason':'DESTINATION_STORAGE_GEOMETRY_INVALID','grid_owner':owner}
        storage_grid_rect=list(g.get('grid_rect') or [])
        storage_panel_rect=list(g.get('panel_rect') or [])
        storage_header_rect=list(g.get('header_rect') or [])
        storage_footer_rect=list(g.get('footer_rect') or [])
        inventory_grid_rect=list(g.get('player_inventory_grid_rect') or [])
        if any(len(r)!=4 for r in (storage_grid_rect,storage_panel_rect,storage_header_rect,storage_footer_rect)):
            return {'ok':False,'reason':'STORAGE_PANEL_GRID_RECTS_INCOMPLETE',
                    'storage_panel_rect':storage_panel_rect,'storage_grid_rect':storage_grid_rect,
                    'storage_header_rect':storage_header_rect,'storage_footer_rect':storage_footer_rect}
        if storage_grid_rect != [xs[0],ys[0],xs[-1],ys[-1]]:
            return {'ok':False,'reason':'STORAGE_GRID_RECT_LINE_MISMATCH','grid_rect':storage_grid_rect,
                    'line_rect':[xs[0],ys[0],xs[-1],ys[-1]]}
        if _rect_intersection_area_local(storage_grid_rect,storage_header_rect)!=0 or _rect_intersection_area_local(storage_grid_rect,storage_footer_rect)!=0:
            return {'ok':False,'reason':'STORAGE_GRID_INTERSECTS_NONCLICK_REGION','grid_rect':storage_grid_rect,
                    'header_rect':storage_header_rect,'footer_rect':storage_footer_rect}
        row=int((target or {}).get('row')); col=int((target or {}).get('col'))
        fw,fh=[max(1,int(x)) for x in (target or {}).get('footprint',[1,1])[:2]]
        if not (0<=row<10 and 0<=col<6 and col+fw<=6 and row+fh<=10):
            return {'ok':False,'reason':'DESTINATION_LOGICAL_FOOTPRINT_OUT_OF_BOUNDS',
                    'grid_owner':owner,'row':row,'col':col,'footprint':[fw,fh]}
        if policy.get('ok'):
            dr,dc=[int(x) for x in policy.get('pivot_offset',[0,0])[:2]]
            policy_name=str(policy.get('policy') or 'CURSOR_PIVOT_CELL_FROM_SOURCE_PICK')
        else:
            if [fw,fh] != [1,1]:
                return {'ok':False,'reason':'ITEM_PLACEMENT_ANCHOR_POLICY_UNRESOLVED','anchor_policy':policy}
            dr=dc=0; policy_name='SINGLE_CELL_CENTER'
        click_row=row+dr; click_col=col+dc
        if not (row<=click_row<row+fh and col<=click_col<col+fw):
            return {'ok':False,'reason':'DESTINATION_PIVOT_OUTSIDE_PLANNED_FOOTPRINT',
                    'planned_anchor':[row,col],'click_cell':[click_row,click_col],
                    'footprint':[fw,fh],'anchor_policy':policy}
        x0,x1=int(xs[click_col]),int(xs[click_col+1]); y0,y1=int(ys[click_row]),int(ys[click_row+1])
        if not (x1>x0 and y1>y0):
            return {'ok':False,'reason':'DESTINATION_CELL_RECT_INVALID','grid_owner':owner,'row':click_row,'col':click_col}
        # Stable interior point inside the actual inner cell; never panel/header coordinates.
        inset_x=max(3,int(round((x1-x0)*.22))); inset_y=max(3,int(round((y1-y0)*.22)))
        cx=min(x1-inset_x-1,max(x0+inset_x,int((x0+x1)//2)))
        cy=min(y1-inset_y-1,max(y0+inset_y,int((y0+y1)//2)))
        inside_cell=bool(x0<cx<x1 and y0<cy<y1)
        inside_storage=bool(_point_in_rect((cx,cy),storage_grid_rect))
        inside_panel=bool(_point_in_rect((cx,cy),storage_panel_rect))
        inside_header=bool(_point_in_rect((cx,cy),storage_header_rect))
        inside_footer=bool(_point_in_rect((cx,cy),storage_footer_rect))
        inside_inventory=bool(_point_in_rect((cx,cy),inventory_grid_rect)) if len(inventory_grid_rect)==4 else False
        gate_ok=bool(inside_cell and inside_storage and inside_panel and not inside_header and not inside_footer and not inside_inventory)
        if not gate_ok:
            return {
                'ok':False,'reason':'DESTINATION_OUTSIDE_STORAGE_GRID','grid_owner':owner,
                'planned_anchor':[row,col],'click_cell':[click_row,click_col],
                'client_point':[cx,cy],'cell_rect':[x0,y0,x1,y1],
                'storage_panel_rect':storage_panel_rect,'storage_header_rect':storage_header_rect,
                'storage_grid_rect':storage_grid_rect,'storage_footer_rect':storage_footer_rect,
                'player_inventory_grid_rect':inventory_grid_rect,
                'inside_cell':inside_cell,'inside_storage_grid':inside_storage,'inside_storage_panel':inside_panel,
                'inside_storage_header':inside_header,'inside_storage_footer':inside_footer,
                'inside_player_inventory_grid':inside_inventory,'destination_safety_gate':False,
            }
        # IMPORTANT V12.10: Storage geometry STOPS in CLIENT space.
        # The destructive point is converted only by InputCoordinateAdapter
        # immediately before dispatch. No ScreenPoint is allowed to escape the
        # planner/grid contract.
        return {
            'ok':True,'reason':'DESTINATION_CLIENT_POINT_RESOLVED','destination_safety_gate':True,
            'grid_owner':owner,'coordinate_space':'CLIENT','input_adapter':'InputCoordinateAdapter',
            'grid_authority':g.get('grid_authority'),'inner_grid_verified':True,
            'lease_generation':g.get('lease_generation'),'owner_confidence':g.get('owner_confidence'),
            'anchor_policy':policy_name,'pivot_offset':[dr,dc],
            'planned_anchor':[row,col],'click_cell':[click_row,click_col],
            'row':row,'col':col,'client_point':[cx,cy],
            'screen_point':None,'conversion_count':0,'screen_conversion_deferred_to_input_adapter':True,
            'cell_rect':[x0,y0,x1,y1],
            'storage_panel_rect':storage_panel_rect,'storage_header_rect':storage_header_rect,
            'storage_grid_rect':storage_grid_rect,'storage_footer_rect':storage_footer_rect,
            'player_inventory_grid_rect':inventory_grid_rect,
            'inside_cell':inside_cell,'inside_storage_grid':inside_storage,'inside_storage_panel':inside_panel,
            'inside_storage_header':False,'inside_storage_footer':False,'inside_player_inventory_grid':inside_inventory,
            'footprint':[fw,fh],
            'pitch_x':float(sum(xs[i+1]-xs[i] for i in range(6))/6.0),
            'pitch_y':float(sum(ys[i+1]-ys[i] for i in range(10))/10.0),
            'crop_origin':[0,0],
        }
    except Exception as e:
        return {'ok':False,'reason':'DESTINATION_COORDINATE_RESOLVE_EXCEPTION','error':str(e)}


def _candidate_cells(candidate):
    """Return canonical GEOMETRIC inventory cells for an item candidate.

    `candidate['cells']` may contain only visually changed sprite cells. For
    collision/clear/reservation semantics, the full rectangular footprint is
    authoritative once anchor+footprint are established.
    """
    out=[]
    for raw in (candidate or {}).get('geometric_cells', []) or []:
        if isinstance(raw,(list,tuple)) and len(raw)==2:
            try:
                rc=(int(raw[0]),int(raw[1]))
            except Exception:
                continue
            if 0<=rc[0]<10 and 0<=rc[1]<6 and rc not in out:
                out.append(rc)
    if out:
        return out
    try:
        ar,ac=[int(x) for x in (candidate or {}).get('anchor',[0,0])[:2]]
        fw,fh=[max(1,int(x)) for x in (candidate or {}).get('footprint',[1,1])[:2]]
    except Exception:
        return []
    for r in range(ar,min(10,ar+fh)):
        for c in range(ac,min(6,ac+fw)):
            out.append((r,c))
    return out


def _candidate_click_point(candidate, grid):
    pts = hover_points_for_candidate(candidate or {}, grid or {})
    if pts:
        return int(pts[0][0]), int(pts[0][1])
    return None


def _snapshot_cell_map(snapshot):
    return {
        (int(c.get('row',-1)), int(c.get('col',-1))): c
        for c in (snapshot or {}).get('cells', []) or []
    }


def _sig_mae(a, b):
    try:
        import numpy as np
        aa = np.asarray(a, dtype=np.float32)
        bb = np.asarray(b, dtype=np.float32)
        if aa.size == 0 or bb.size == 0 or aa.shape != bb.shape:
            return 255.0
        return float(np.mean(np.abs(aa-bb)))
    except Exception:
        return 255.0


def _candidate_clear_metrics(candidate, before, after, baseline=None):
    """Verify that the exact item footprint disappeared after ONE sell click."""
    cells = _candidate_cells(candidate)
    bm = _snapshot_cell_map(before)
    am = _snapshot_cell_map(after)
    rm = _snapshot_cell_map(baseline) if baseline else {}
    details = []
    vacated = 0
    restored = 0
    before_occ = 0
    after_occ = 0
    change_vals = []
    before_ref_vals = []
    after_ref_vals = []
    for rc in cells:
        b, a, ref = bm.get(rc), am.get(rc), rm.get(rc)
        if not b or not a:
            continue
        bo = bool(b.get('occupied'))
        ao = bool(a.get('occupied'))
        before_occ += int(bo)
        after_occ += int(ao)
        if bo and not ao:
            vacated += 1
        change = _sig_mae(b.get('_sig'), a.get('_sig'))
        change_vals.append(change)
        d0 = d1 = None
        if ref:
            d0 = _sig_mae(b.get('_sig'), ref.get('_sig'))
            d1 = _sig_mae(a.get('_sig'), ref.get('_sig'))
            before_ref_vals.append(d0)
            after_ref_vals.append(d1)
            # Returned close to the pre-open empty texture, or improved strongly.
            if d1 <= 8.5 or (d0 >= 8.0 and d1 <= d0 * 0.58):
                restored += 1
        details.append({
            'cell':[rc[0],rc[1]], 'before_occupied':bo, 'after_occupied':ao,
            'before_after_mae':round(change,3),
            'before_ref_mae':None if d0 is None else round(d0,3),
            'after_ref_mae':None if d1 is None else round(d1,3),
        })
    n = max(1, len(details))
    mean_change = sum(change_vals)/max(1,len(change_vals))
    mean_before_ref = sum(before_ref_vals)/max(1,len(before_ref_vals)) if before_ref_vals else None
    mean_after_ref = sum(after_ref_vals)/max(1,len(after_ref_vals)) if after_ref_vals else None
    occupancy_clear = bool(before_occ >= 1 and after_occ == 0 and vacated >= 1)
    baseline_clear = bool(
        baseline and details and restored >= max(1, int((len(details)*0.60)+0.999))
        and mean_change >= 5.5
        and (mean_before_ref is None or mean_after_ref is None or mean_after_ref <= max(9.5, mean_before_ref*0.72))
    )
    return {
        'confirmed': bool(occupancy_clear or baseline_clear),
        'occupancy_clear': occupancy_clear,
        'baseline_clear': baseline_clear,
        'candidate_cell_count': len(cells),
        'checked_cell_count': len(details),
        'before_occupied': before_occ,
        'after_occupied': after_occ,
        'vacated': vacated,
        'restored': restored,
        'mean_before_after_mae': round(mean_change,3),
        'mean_before_ref_mae': None if mean_before_ref is None else round(mean_before_ref,3),
        'mean_after_ref_mae': None if mean_after_ref is None else round(mean_after_ref,3),
        'details': details,
    }



def _build_source_item_fingerprint(candidate, before, baseline=None):
    """Stage 29.6.6: item-level source evidence for DROP secondary confirmation.

    The fingerprint is deliberately snapshot-only: it does not alter inventory
    geometry, OCR, filtering, or the successful primary Drop fast path.
    """
    cells=_candidate_cells(candidate)
    bm=_snapshot_cell_map(before)
    rm=_snapshot_cell_map(baseline) if baseline else {}
    owned=[]; entries=[]
    for rc in cells:
        b=bm.get(rc); ref=rm.get(rc)
        if not b:
            continue
        dref=_sig_mae(b.get('_sig'),ref.get('_sig')) if ref else None
        # Ownership requires current occupancy plus either baseline delta or no
        # available baseline. This prevents unrelated geometric cells from
        # silently becoming authoritative item evidence.
        own=bool(b.get('occupied')) and (ref is None or dref>=6.0 or not bool(ref.get('occupied')))
        if own: owned.append(rc)
        entries.append({'cell':[rc[0],rc[1]],'owned':own,'before_ref_mae':None if dref is None else round(dref,3)})
    return {
        'source_item_owned_cells':[list(x) for x in owned],
        'geometric_candidate_cells':[list(x) for x in cells],
        'owned_count':len(owned),
        'entries':entries,
    }


def _source_item_fingerprint_state(fingerprint, before, after, baseline=None):
    """Classify whether the SAME source item still exists after Drop.

    Conservative by design: only strong majority evidence becomes ITEM_GONE or
    ITEM_STILL_IN_SOURCE. Split evidence remains SOURCE_STATE_UNCERTAIN and is
    handled by fresh-frame revalidation instead of a destructive retry.
    """
    owned=[tuple(x) for x in (fingerprint or {}).get('source_item_owned_cells',[]) or []]
    bm=_snapshot_cell_map(before); am=_snapshot_cell_map(after); rm=_snapshot_cell_map(baseline) if baseline else {}
    details=[]; gone_votes=0; present_votes=0
    for rc in owned:
        b= bm.get(rc); a=am.get(rc); ref=rm.get(rc)
        if not b or not a: continue
        d_before=_sig_mae(a.get('_sig'),b.get('_sig'))
        d_base=_sig_mae(a.get('_sig'),ref.get('_sig')) if ref else None
        ao=bool(a.get('occupied'))
        # Strong gone: current cell is unoccupied, or it returned much closer
        # to the pre-open baseline than to the item's pre-drop appearance.
        gone=bool(not ao)
        if ref is not None and d_base is not None:
            gone = gone or bool(d_base<=8.5 or (d_before>=8.0 and d_base<=d_before*0.58))
        # Strong present: occupied and still clearly resembles the pre-drop
        # item more than the baseline texture.
        present=bool(ao and d_before<=12.0)
        if ref is not None and d_base is not None:
            present = bool(ao and d_before+5.0<d_base)
        gone_votes+=int(gone); present_votes+=int(present)
        details.append({'cell':[rc[0],rc[1]],'current_occupied':ao,'after_vs_item_mae':round(d_before,3),'after_vs_baseline_mae':None if d_base is None else round(d_base,3),'gone_vote':gone,'present_vote':present})
    n=len(details)
    need=max(1,int((n*0.75)+0.999)) if n else 1
    if n and gone_votes>=need and present_votes==0:
        state='ITEM_GONE'
    elif n and present_votes>=need and gone_votes==0:
        state='ITEM_STILL_IN_SOURCE'
    else:
        state='SOURCE_STATE_UNCERTAIN'
    return {'state':state,'owned_cell_count':len(owned),'checked_cell_count':n,'gone_votes':gone_votes,'present_votes':present_votes,'required_votes':need,'details':details}


def _classify_weak_template_distances(after_vs_pre, after_vs_empty):
    """Relative weak-template classifier using the CURRENT source-fingerprint calibration.

    No new magic thresholds are introduced here.  The values mirror the
    existing strong fingerprint rules already used by this runtime:
      - baseline-close <= 8.5
      - material source change >= 8.0 with baseline ratio <= 0.58
      - source-present margin: after_vs_pre + 5.0 < after_vs_empty
    """
    try:
        dpre=float(after_vs_pre); dempty=float(after_vs_empty)
    except Exception:
        return {'state':'WEAK_TEMPLATE_UNCERTAIN','present_vote':False,'clear_vote':False}
    clear_vote=bool(dempty<=8.5 or (dpre>=8.0 and dempty<=dpre*0.58))
    present_vote=bool(dpre+5.0<dempty)
    # A contradictory dual vote is not authoritative.
    if clear_vote and present_vote:
        state='WEAK_TEMPLATE_UNCERTAIN'
        clear_vote=False; present_vote=False
    elif present_vote:
        state='WEAK_TEMPLATE_PRESENT'
    elif clear_vote:
        state='WEAK_TEMPLATE_CLEAR'
    else:
        state='WEAK_TEMPLATE_UNCERTAIN'
    return {
        'state':state,'present_vote':present_vote,'clear_vote':clear_vote,
        'after_vs_pre_mae':round(dpre,3),'after_vs_empty_mae':round(dempty,3),
    }


def _build_source_evidence_bundle(candidate, before, baseline=None, grid=None, capture_timestamp=None,
                                  reacquire_count=0):
    """Build authoritative pre-action source evidence for ONE queue item.

    Strong occupancy remains the first channel.  For geometric candidate cells
    that fail the occupancy threshold, preserve a validated visual template
    against the pre-open empty baseline so low-contrast 1x1 items can still be
    reconciled later.  Weak templates do NOT broaden click authority: they are
    accepted only at the existing >=6.0 source-vs-baseline delta used by the
    current fingerprint ownership logic, and only when that baseline cell was
    empty.
    """
    cells=_candidate_cells(candidate)
    bm=_snapshot_cell_map(before)
    rm=_snapshot_cell_map(baseline) if baseline else {}
    fingerprint=_build_source_item_fingerprint(candidate,before,baseline)
    strong={tuple(x) for x in (fingerprint or {}).get('source_item_owned_cells',[]) or []}
    weak=[]; entries=[]; pre_templates={}; empty_templates={}; pre_empty_vals=[]
    for rc in cells:
        b=bm.get(rc); ref=rm.get(rc)
        if not b:
            continue
        pre_sig=b.get('_sig') or []
        empty_sig=(ref or {}).get('_sig') or []
        dref=_sig_mae(pre_sig,empty_sig) if ref and pre_sig and empty_sig else None
        strong_owned=rc in strong
        weak_valid=bool(
            not strong_owned and ref is not None and not bool(ref.get('occupied'))
            and pre_sig and empty_sig and dref is not None and float(dref)>=6.0
        )
        if weak_valid:
            weak.append(rc)
            pre_templates[f'{rc[0]},{rc[1]}']=pre_sig
            empty_templates[f'{rc[0]},{rc[1]}']=empty_sig
        if dref is not None:
            pre_empty_vals.append(float(dref))
        entries.append({
            'cell':[rc[0],rc[1]],'strong_owned':bool(strong_owned),
            'weak_template_valid':bool(weak_valid),
            'pre_vs_empty_mae':None if dref is None else round(float(dref),3),
        })
    anchor=[]
    try: anchor=[int(x) for x in (candidate or {}).get('anchor',[0,0])[:2]]
    except Exception: anchor=[]
    footprint=[]
    try: footprint=[max(1,int(x)) for x in (candidate or {}).get('footprint',[1,1])[:2]]
    except Exception: footprint=[]
    all_cells_present=bool(cells and all(rc in bm for rc in cells))
    anchor_revalidated=bool(len(anchor)==2 and tuple(anchor) in cells and all_cells_present)
    mode='STRONG_OCCUPANCY' if strong else ('WEAK_VISUAL_TEMPLATE' if weak else 'NONE')
    grid_identity={}
    try:
        g=grid or (before or {}).get('grid') or {}
        grid_identity={
            'rows':int(g.get('rows') or 0),'cols':int(g.get('cols') or 0),
            'x_lines':[int(x) for x in (g.get('x_lines') or [])],
            'y_lines':[int(y) for y in (g.get('y_lines') or [])],
        }
    except Exception:
        grid_identity={}
    return {
        'queue_id':str((candidate or {}).get('queue_id') or (candidate or {}).get('item_id') or 'Q01'),
        'source_anchor':anchor,'footprint':footprint,
        'queue_confidence':float((candidate or {}).get('confidence') or 0.0),
        'geometric_candidate_cells':[list(x) for x in cells],
        'source_evidence_mode':mode,
        'strong_owned_count':len(strong),
        'weak_template_count':len(weak),
        'source_pre_template_valid':bool(strong or weak),
        'pre_vs_empty_mae':None if not pre_empty_vals else round(sum(pre_empty_vals)/len(pre_empty_vals),3),
        'capture_timestamp':float(capture_timestamp or time.time()),
        'grid_identity':grid_identity,
        'source_evidence_reacquire_count':int(reacquire_count or 0),
        'source_anchor_revalidated':bool(anchor_revalidated),
        # Retry-time metadata is populated by the Drop controller.  Keeping the
        # fields on the evidence object prevents stale weak templates from being
        # silently reused across destructive attempts.
        'source_reacquire_reason':None,
        'retry_pre_template_id':None,
        'retry_pre_vs_empty_mae':None if not pre_empty_vals else round(sum(pre_empty_vals)/len(pre_empty_vals),3),
        'retry_anchor_revalidated':bool(anchor_revalidated),
        'source_hover_probe_used':False,
        'source_hover_probe_result':None,
        'attempt_source_template_age_ms':0.0,
        'template_fresh':True,
        'attempt_no':1,
        'entries':entries,
        '_weak_cells':[list(x) for x in weak],
        '_pre_templates':pre_templates,
        '_empty_templates':empty_templates,
        '_fingerprint':fingerprint,
        '_before_snapshot':before,
    }


def _source_evidence_precommit_confirmed(bundle):
    return bool(
        isinstance(bundle,dict)
        and bundle.get('source_anchor_revalidated')
        and (int(bundle.get('strong_owned_count',0) or 0)>0 or int(bundle.get('weak_template_count',0) or 0)>0)
    )


def _public_source_evidence(bundle):
    if not isinstance(bundle,dict):
        return {}
    return {k:v for k,v in bundle.items() if not str(k).startswith('_')}


def _source_evidence_state(bundle, after, baseline=None):
    """Resolve SAME-source state using strong occupancy first, weak template second."""
    bundle=bundle or {}
    fingerprint=bundle.get('_fingerprint') or {}
    strong_state=_source_item_fingerprint_state(fingerprint,bundle.get('_before_snapshot') or {},after,baseline)
    if int(bundle.get('strong_owned_count',0) or 0)>0 and strong_state.get('state') in ('ITEM_GONE','ITEM_STILL_IN_SOURCE'):
        out=dict(strong_state)
        out['evidence_mode']='STRONG_OCCUPANCY'
        out['source_state_decision_reason']='STRONG_OCCUPANCY_FINGERPRINT'
        return out

    am=_snapshot_cell_map(after)
    weak=[tuple(x) for x in (bundle.get('_weak_cells') or [])]
    pre_templates=bundle.get('_pre_templates') or {}
    empty_templates=bundle.get('_empty_templates') or {}
    details=[]; clear_votes=0; present_votes=0; dpre_vals=[]; dempty_vals=[]
    for rc in weak:
        a=am.get(rc)
        if not a:
            continue
        key=f'{rc[0]},{rc[1]}'
        pre=pre_templates.get(key) or []
        empty=empty_templates.get(key) or []
        cur=a.get('_sig') or []
        if not pre or not empty or not cur:
            continue
        dpre=_sig_mae(cur,pre); dempty=_sig_mae(cur,empty)
        vote=_classify_weak_template_distances(dpre,dempty)
        clear_votes+=int(bool(vote.get('clear_vote')))
        present_votes+=int(bool(vote.get('present_vote')))
        dpre_vals.append(float(dpre)); dempty_vals.append(float(dempty))
        details.append({'cell':[rc[0],rc[1]],**vote})
    n=len(details); need=max(1,int((n*0.75)+0.999)) if n else 1
    if n and clear_votes>=need and present_votes==0:
        state='ITEM_GONE'; reason='WEAK_TEMPLATE_CLOSER_TO_EMPTY_BASELINE'
    elif n and present_votes>=need and clear_votes==0:
        state='ITEM_STILL_IN_SOURCE'; reason='WEAK_TEMPLATE_CLOSER_TO_PRE_ITEM'
    else:
        state='SOURCE_STATE_UNCERTAIN'; reason='WEAK_TEMPLATE_NOT_SEPARATED'
    return {
        'state':state,'evidence_mode':'WEAK_VISUAL_TEMPLATE' if weak else 'NONE',
        'owned_cell_count':int(bundle.get('strong_owned_count',0) or 0),
        'weak_template_count':len(weak),'checked_cell_count':n,
        'gone_votes':clear_votes,'present_votes':present_votes,'required_votes':need,
        'post_vs_pre_mae':None if not dpre_vals else round(sum(dpre_vals)/len(dpre_vals),3),
        'post_vs_empty_mae':None if not dempty_vals else round(sum(dempty_vals)/len(dempty_vals),3),
        'source_state_decision_reason':reason,'details':details,
    }


def _probe_cursor_attachment(before_image, after_image, point, radius=24, center_mask=7):
    """Conservative cursor-held-item probe using an outer ROI around cursor.

    Center pixels are masked so the normal mouse cursor itself does not count.
    A low delta is authoritative CURSOR_CLEAR. A high delta is only SUSPECT,
    never sufficient by itself to send another destructive click.
    """
    try:
        import numpy as np
        if before_image is None or after_image is None or not point:
            return {'state':'CURSOR_UNCERTAIN','outer_mae':None}
        x,y=int(point[0]),int(point[1]); r=int(radius); m=int(center_mask)
        a=np.asarray(before_image.convert('RGB'),dtype=np.float32)
        b=np.asarray(after_image.convert('RGB'),dtype=np.float32)
        h,w=a.shape[:2]
        x0=max(0,x-r); x1=min(w,x+r+1); y0=max(0,y-r); y1=min(h,y+r+1)
        aa=a[y0:y1,x0:x1]; bb=b[y0:y1,x0:x1]
        if aa.shape!=bb.shape or aa.size==0:
            return {'state':'CURSOR_UNCERTAIN','outer_mae':None}
        mask=np.ones(aa.shape[:2],dtype=bool)
        cx=x-x0; cy=y-y0
        mask[max(0,cy-m):min(mask.shape[0],cy+m+1),max(0,cx-m):min(mask.shape[1],cx+m+1)]=False
        vals=np.abs(aa-bb).mean(axis=2)[mask]
        mae=float(vals.mean()) if vals.size else 255.0
        if mae<=7.5: state='CURSOR_CLEAR'
        elif mae>=20.0: state='ITEM_ON_CURSOR_SUSPECT'
        else: state='CURSOR_UNCERTAIN'
        return {'state':state,'outer_mae':round(mae,3),'probe_point':[x,y]}
    except Exception as e:
        return {'state':'CURSOR_UNCERTAIN','outer_mae':None,'error':str(e)}

def _shop_guard_patch_rects(image, grid):
    """Build candidate rectangles on the shop side, excluding inventory."""
    w, h = int(image.width), int(image.height)
    roi = (grid or {}).get('roi') or [int(w*.76),0,w,h]
    inv_left = int(roi[0]) if roi else int(w*.76)
    right = max(int(w*.46), min(inv_left-10, int(w*.78)))
    left = max(2, int(w*.015))
    top = max(2, int(h*.035))
    bottom = min(h-2, int(h*.965))
    if right-left < 160 or bottom-top < 160:
        return []
    cols, rows = 4, 4
    pw = (right-left)/cols
    ph = (bottom-top)/rows
    rects=[]
    for rr in range(rows):
        for cc in range(cols):
            x0=int(round(left+cc*pw+4)); x1=int(round(left+(cc+1)*pw-4))
            y0=int(round(top+rr*ph+4)); y1=int(round(top+(rr+1)*ph-4))
            if x1-x0 >= 40 and y1-y0 >= 36:
                rects.append((x0,y0,x1,y1))
    return rects


def _shop_guard_select_patches(frames, grid):
    try:
        import cv2, numpy as np
        if not frames:
            return []
        base=frames[0].convert('RGB')
        w,h=base.size
        rows=[]
        for rect in _shop_guard_patch_rects(base, grid):
            thumbs=[]
            for im in frames:
                crop=np.asarray(im.convert('RGB').crop(rect).resize((64,48))).astype(np.uint8)
                gray=cv2.cvtColor(crop,cv2.COLOR_RGB2GRAY)
                thumbs.append(gray)
            ref=thumbs[0]
            temporal=float(np.mean([np.mean(np.abs(ref.astype(np.float32)-x.astype(np.float32))) for x in thumbs[1:]]) if len(thumbs)>1 else 0.0)
            edge=cv2.Canny(ref,45,105)
            edge_density=float((edge>0).mean())
            contrast=float(ref.std())
            # Prefer stable, textured/edged UI rectangles. Dynamic map patches lose score.
            score=(edge_density*4.8)+(min(contrast,55.0)/55.0*0.75)-(min(temporal,35.0)/35.0*1.25)
            rows.append((score, temporal, edge_density, contrast, rect))
        good=[r for r in rows if r[1] <= 14.0 and r[2] >= 0.025 and r[3] >= 8.0]
        # Some JX1 skins have flatter shop panels. Relax in stages instead of
        # failing calibration outright. The user still explicitly confirms that
        # Shop is open, and runtime Guard must continue matching this reference.
        if len(good) < 4:
            good=[r for r in rows if r[1] <= 20.0 and r[3] >= 6.0]
        if len(good) < 3:
            good=[r for r in rows if r[1] <= 26.0 and (r[2] >= 0.010 or r[3] >= 3.5)]
        if len(good) < 3:
            # Last calibration fallback: take the most temporally-stable regions
            # with non-trivial visual content. This makes TEST GUARD usable on
            # low-contrast / scaled clients without weakening runtime matching.
            candidates=[r for r in rows if r[3] >= 2.0]
            good=sorted(candidates, key=lambda x:(x[1], -x[0]))[:6]
        good=sorted(good, key=lambda x:x[0], reverse=True)[:6]
        out=[]
        for score, temporal, edge_density, contrast, rect in good:
            x0,y0,x1,y1=rect
            out.append({
                'rect_norm':[round(x0/w,6),round(y0/h,6),round(x1/w,6),round(y1/h,6)],
                'calibration_score':round(float(score),4),
                'temporal_mae':round(float(temporal),3),
                'edge_density':round(float(edge_density),4),
                'contrast':round(float(contrast),3),
            })
        return out
    except Exception:
        return []


def _shop_guard_compare(current, reference, descriptor):
    try:
        import cv2, numpy as np
        patches=(descriptor or {}).get('patches') or []
        if len(patches) < 3:
            return {'ok':False,'reason':'SHOP_GUARD_PATCHES_INSUFFICIENT','patches':[]}
        cw,ch=current.size; rw,rh=reference.size
        results=[]
        for p in patches:
            n=p.get('rect_norm') or []
            if len(n)!=4: continue
            def rect_for(w,h):
                x0=max(0,min(w-2,int(round(float(n[0])*w))))
                y0=max(0,min(h-2,int(round(float(n[1])*h))))
                x1=max(x0+2,min(w,int(round(float(n[2])*w))))
                y1=max(y0+2,min(h,int(round(float(n[3])*h))))
                return x0,y0,x1,y1
            rc=rect_for(cw,ch); rr=rect_for(rw,rh)
            ca=np.asarray(current.convert('RGB').crop(rc).resize((64,48))).astype(np.uint8)
            ra=np.asarray(reference.convert('RGB').crop(rr).resize((64,48))).astype(np.uint8)
            cg=cv2.cvtColor(ca,cv2.COLOR_RGB2GRAY); rg=cv2.cvtColor(ra,cv2.COLOR_RGB2GRAY)
            mae=float(np.mean(np.abs(cg.astype(np.float32)-rg.astype(np.float32))))
            ce=cv2.Canny(cg,45,105); re=cv2.Canny(rg,45,105)
            inter=float(np.logical_and(ce>0,re>0).sum())
            union=float(np.logical_or(ce>0,re>0).sum())
            edge_iou=(inter/union) if union else 1.0
            try:
                corr=float(cv2.matchTemplate(cg,rg,cv2.TM_CCOEFF_NORMED)[0,0])
                if not np.isfinite(corr): corr=0.0
            except Exception:
                corr=0.0
            photometric=max(0.0,1.0-min(1.0,mae/72.0))
            score=0.48*max(0.0,corr)+0.32*edge_iou+0.20*photometric
            match=bool(score>=0.535 or (corr>=0.68 and mae<=31.0))
            results.append({'score':round(score,4),'corr':round(corr,4),'edge_iou':round(edge_iou,4),'mae':round(mae,3),'match':match})
        matched=sum(1 for x in results if x['match'])
        avg=sum(x['score'] for x in results)/max(1,len(results))
        needed=max(2,int(len(results)*0.55+0.999))
        ok=bool(len(results)>=3 and matched>=needed and avg>=0.50)
        return {'ok':ok,'reason':None if ok else 'SHOP_OPEN_GUARD_MISMATCH','matched':matched,'needed':needed,'avg_score':round(avg,4),'patches':results}
    except Exception as e:
        return {'ok':False,'reason':'SHOP_GUARD_COMPARE_EXCEPTION','error':str(e),'patches':[]}



def _public_json_safe(value, _active=None):
    """Create a JSON-safe public DTO without mutating the internal runtime result.

    Stage 29.6 / v10.4 root fix: ``_active`` tracks only the CURRENT recursion
    path, not every object ever visited.  v10.3 used a global ``_seen`` set; a
    perfectly valid shared list such as ``queue_item.footprint`` appearing in
    both ``drop_result.queue_item`` and top-level ``queue_item`` was therefore
    mislabelled as ``CYCLE_REFERENCE`` on the second occurrence.  That changed
    canonical ``[w,h]`` into a dict and later crashed the UI formatter.

    Repeated acyclic references must serialize normally at each JSON location;
    only an object reached again while it is still on the active recursion path
    is a true cycle.  This remains an explicit API-boundary conversion, not
    ``json.dumps(default=str)``.
    """
    if _active is None:
        _active=set()
    if value is None or isinstance(value,(str,int,float,bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (bytes,bytearray,memoryview)):
        return {'omitted':True,'internal_type':'bytes','length':len(value)}
    if isinstance(value, BaseException):
        return {'error_type':type(value).__name__,'message':str(value)}
    # Explicit PIL boundary. Import locally so startup does not depend on it here.
    try:
        from PIL import Image as _PILImage
        if isinstance(value,_PILImage.Image):
            return {'omitted':True,'internal_type':'PIL.Image.Image','size':[int(value.width),int(value.height)],'mode':str(value.mode)}
    except Exception:
        pass
    # Explicit numpy boundary. Scalars become native numbers; arrays are metadata only.
    try:
        import numpy as _np
        if isinstance(value,_np.generic):
            return _public_json_safe(value.item(),_active)
        if isinstance(value,_np.ndarray):
            return {'omitted':True,'internal_type':'numpy.ndarray','shape':[int(x) for x in value.shape],'dtype':str(value.dtype)}
    except Exception:
        pass

    if isinstance(value, (dict,list,tuple,set)):
        oid=id(value)
        if oid in _active:
            return {'omitted':True,'reason':'CYCLE_REFERENCE'}
        _active.add(oid)
        try:
            if isinstance(value, dict):
                return {str(k):_public_json_safe(v,_active) for k,v in value.items()}
            if isinstance(value, (list,tuple)):
                return [_public_json_safe(v,_active) for v in value]
            return [_public_json_safe(v,_active) for v in sorted(value,key=lambda x:repr(x))]
        finally:
            _active.remove(oid)

    # Native handles / ctypes and any other custom class are never stringified as a fake payload.
    return {'omitted':True,'internal_type':type(value).__name__}

def _public_api_boundary(fn):
    @functools.wraps(fn)
    def _wrapped(*args,**kwargs):
        internal=fn(*args,**kwargs)
        return _public_json_safe(internal)
    return _wrapped

class Api:
    # Keep internal state private. pywebview only needs the public methods below.
    def __init__(self):
        self._active_hwnd = None
        self._active_group = '__all__'
        self._hover_enabled = False
        self._hover_stable_hits = 0
        self._hover_last_rect = None
        self._hover_last_signature = None
        self._hover_last_read_time = 0.0
        self._poll_last_time = 0.0
        self._cfg = _load_app_config()
        mods = self._cfg.setdefault("modules", {})
        common = mods.setdefault("common", {})
        common.setdefault("thien_son_bao_lo_enabled", False)
        common.setdefault("que_hoa_tuu_enabled", False)
        common.setdefault("thien_son_bao_lo_last_used_epoch", 0.0)
        common.setdefault("que_hoa_tuu_last_used_epoch", 0.0)
        common.setdefault("thien_son_bao_lo_last_attempt_epoch", 0.0)
        common.setdefault("que_hoa_tuu_last_attempt_epoch", 0.0)
        chest_cfg = mods.setdefault("chest", {})
        chest_cfg.setdefault("auto_resume_after_lag_enabled", False)
        # Stage 29.6.7 / v10.4.7 — in-memory, monotonic, one-shot lag auto-resume.
        # Only the enable checkbox is persisted; pending timers/tokens never survive app restart.
        self._auto_resume = AutoResumeAfterLagController(
            enabled=bool(chest_cfg.get("auto_resume_after_lag_enabled", False)),
            delay_sec=AUTO_RESUME_DELAY_SECONDS,
        )
        self._auto_resume_last_hwnd = None
        # V12.11: the 15-second scheduler is backend-owned. The UI may display
        # countdown state, but it is no longer the owner that fires recovery.
        self._auto_resume_backend_timer_lock = threading.RLock()
        self._auto_resume_backend_timer = None
        self._auto_resume_backend_timer_meta = None
        self._auto_resume_backend_last_result = None
        self._auto_resume_backend_continuation = None
        # V12.0: timer grants a claim; ResumeCoordinator owns the full pending-item
        # recovery execution. No generic Start/timer loop is allowed to substitute
        # for fresh scan -> same item -> new tooltip -> new Filter -> action/defer.
        self._resume_coordinator = ResumeCoordinator(self)
        self._v120_resume_step_log_path = LOG_PROOF_RESUME_DIR / 'resume_coordinator.jsonl'
        self._auto_resume_storage_full_confirmed = False
        self._auto_resume_chests_exhausted_confirmed = False
        self._auto_resume_destructive_uncertain = False
        # v10.4.8: safe, reconciled non-committed Store/Drop may become a
        # one-shot TEMPORARY_ACTION_LAG. This context is in-memory only and
        # never survives application restart.
        self._auto_resume_action_lag_context = None
        shop_cfg = mods.setdefault("shop", {})
        # Stage 27: feature cancelled. Preserve any old calibration only as dormant
        # rollback data, but force the live switch OFF on every launch.
        shop_cfg["disabled"] = True
        shop_cfg["continuous"] = False
        self._locked_client_hwnd = self._cfg.get("locked_client")
        self._inventory_grid = None
        self._inventory_baseline = None
        self._inventory_last = None
        # v10.5.2: authoritative recovery→DropPrecheck handoff.
        self._verified_grid_lease_generation = 0
        self._verified_grid_lease = None
        self._new_item_queue = []
        self._queue_read_results = []
        self._batch_preopen_snapshot = None
        # V10.6: known-item recovery ledger. Pending items are remembered across
        # chest cycles so a failed action never makes an old item look NEW again.
        self._item_recovery_ledger = ItemRecoveryLedger()
        self._pending_disposition_queue = self._item_recovery_ledger.pending
        self._recovery_event_seq = 0
        # V12.1 explicit BlockingRecoveryOwner. Q01 is only a queue slot.
        # Every filter-recovery timer is bound to the exact logical item that
        # owned FILTER_RECHECK_PENDING when the timer was scheduled.
        self._v114_recovery_owner = None
        self._v114_resume_commit_seq = 0
        self._v121_recovery_owner_seq = 0
        self._v121_resume_owner_bindings = {}
        self._v121_active_resume_owner_binding = None
        self._v121_recovery_owner_log_path = LOGDIR / 'RECOVERY_OWNER.jsonl'
        # V1.7.11E: Auto Chest recovery ownership is self-consistent with the
        # in-memory ledger. A stale owner may never block a fresh Chest start.
        self._v1711_last_recovery_reconcile = None
        self._shop_guard_armed_hwnd = None
        self._shop_guard_descriptor = None
        self._drop_point_cursor = 0
        # Stage 29 / v9.8: remember cells placed by Auto during the current chest
        # session. This is a hard reservation layer on top of visual occupancy so
        # a later item can never be clicked onto a cell that Auto already used,
        # even if a dark/transparent sprite fools one image frame.
        self._personal_bag_reserved_cells = set()
        self._personal_bag_reserved_hwnd = None
        # V10.6 compact packing remembers only placements made in this session.
        # Visual occupancy remains authoritative before every click.
        self._personal_bag_placement_history = {}
        # Usage timer/accounting. Presentation polls this state; no extra loop owner.
        self._usage_session_started_mono = 0.0
        self._usage_session_accum = 0.0
        self._usage_active_started_mono = 0.0
        self._usage_recovery_started_mono = 0.0
        self._usage_active_accum = 0.0
        self._usage_recovery_accum = 0.0
        self._usage_timer_state = 'STOPPED'
        self._usage_lifetime_seconds = float((chest_cfg.get('lifetime_usage_seconds',0.0) or 0.0))
        # Stage 29.5 / v10.3: one monotonically increasing chest-cycle identity.
        # It is diagnostic only; destructive exactly-once ownership remains in the
        # existing action functions.
        self._chest_cycle_seq = 0
        # V11.2: every explicit Start owns a new session generation. Queue slots
        # such as Q01 are reusable labels and never identify a physical item.
        self._chest_session_generation = 0
        # Chest Master Foundation: production batching is five atomic item cycles.
        # We keep the proven one-item exactly-once action path and group every five
        # completed opens into one production batch without introducing a second loop owner.
        self._chest_batch_seq = 0
        self._chest_batch_item_index = 0
        self._chest_batch_size = 5

        # Stage 29.6 / v10.4: one backend STOP owner for the chest session.
        # Frontend SPACE/UI Stop mirrors this state; the backend uses it only as a
        # safe-boundary gate. It never retries or interrupts an atomic DROP/STORE.
        self._chest_control_lock = threading.RLock()
        # V11.6 one canonical lifecycle owner. UI renders a mirror of this backend
        # state; transient start flags are no longer presentation authority.
        self._runtime_lifecycle_lock = threading.RLock()
        self._runtime_lifecycle_state = 'STOPPED'
        self._runtime_lifecycle_generation = 0
        self._runtime_lifecycle_start_request_id = None
        self._runtime_lifecycle_resume_event_id = None
        self._runtime_lifecycle_stop_generation = 0
        self._runtime_lifecycle_scheduler_owner = None
        self._chest_stop_requested = False
        self._chest_stop_reason = None
        self._chest_stop_requested_at = 0.0
        self._chest_action_in_flight = False
        self._chest_action_name = None
        # Stage 29.6.3: bounded/observable terminal-action ownership.
        self._chest_action_owner_cycle = None
        self._chest_action_started_at = 0.0
        self._chest_action_trace = {}
        # Stage 29.6.4: STORE trace is separate from DROP trace, and one temporary
        # no-new-item observation is not equivalent to confirmed chest exhaustion.
        self._chest_store_action_trace = {}
        self._chest_no_new_item_streak = 0
        # V10.7 config/runtime provenance. UI Start always calls save_option_filter
        # before chest_prepare_loop, so the exact visible payload gets a generation/hash.
        self._filter_config_generation = 0
        self._last_ui_filter_snapshot = None
        self._last_ui_filter_hash = None
        self._last_backend_filter_snapshot = None
        self._last_backend_filter_hash = None
        self._runtime_provenance = _v107_runtime_provenance()
        try:
            (LOGDIR/'RUNTIME_PROVENANCE_STARTUP.json').write_text(
                json.dumps(self._runtime_provenance,ensure_ascii=False,indent=2),encoding='utf-8')
        except Exception:
            pass
        try:
            if SHOP_GUARD_PATH.exists():
                self._shop_guard_descriptor = json.loads(SHOP_GUARD_PATH.read_text(encoding='utf-8'))
        except Exception:
            self._shop_guard_descriptor = None

    def filter_runtime_guard(self, purpose='GENERIC', selected_profile_ids=None, require_enabled_rules=True):
        """Canonical runtime filter preflight shared by each automation mode.

        The registry owns its own schema/size truth.  No automation is allowed to
        hard-code historical option counts because slot-specific registry growth is
        intentional.  Each mode receives an independent preflight result and may
        therefore fail without poisoning the startup path of another mode.
        """
        purpose=re.sub(r'[^A-Z0-9]+','_',str(purpose or 'GENERIC').upper()).strip('_') or 'GENERIC'
        prefix=purpose if purpose.startswith('AUTO_') else 'AUTO_'+purpose
        try:
            payload=registry_payload() if callable(registry_payload) else {}
            validation=validate_registry() if callable(validate_registry) else {'ok':False}
            entries=list((payload or {}).get('entries') or [])
            counts=dict((payload or {}).get('counts') or {})
            if not validation.get('ok'):
                return {
                    'ok':False,'reason':prefix+'_FILTER_REGISTRY_INVALID',
                    'validation':validation,'counts':counts,'registry_total':len(entries),
                }
            # Derived consistency checks only: compare registry metadata with the
            # registry itself, never with historical magic numbers.
            declared_total=int(counts.get('total',len(entries)) or 0)
            if declared_total!=len(entries):
                return {
                    'ok':False,'reason':prefix+'_FILTER_REGISTRY_INVALID',
                    'validation':validation,'counts':counts,'registry_total':len(entries),
                    'error':'REGISTRY_DECLARED_TOTAL_MISMATCH',
                }
            cfg=_load_option_filter()
            scope_value=str((cfg or {}).get('scope_value','GLOBAL') or 'GLOBAL')
            profile_validation=_profile_rule_validation(cfg)
            if not profile_validation.get('ok'):
                return {
                    'ok':False,'reason':prefix+'_FILTER_SCOPE_INVALID',
                    'scope_value':scope_value,'profile_validation':profile_validation,
                    'validation':validation,'counts':counts,'config':cfg,
                }
            scope_options=list(profile_options(scope_value))
            registry_names={str(x.get('display_name') or '') for x in entries}
            missing_scope=[x for x in scope_options if x not in registry_names]
            missing_units=[x for x in scope_options if option_unit_type(x) is None]
            if missing_scope or missing_units:
                return {
                    'ok':False,'reason':prefix+'_FILTER_SCOPE_INVALID',
                    'scope_value':scope_value,'missing_scope_options':missing_scope,
                    'missing_unit_contracts':missing_units,'profile_validation':profile_validation,
                    'validation':validation,'counts':counts,'config':cfg,
                }
            enabled=list(filter_enabled_profiles(cfg) or [])
            enabled_ids=[]
            enabled_rule_count=0
            for prof in enabled:
                try: pid=int(prof.get('profile_id') or 0)
                except Exception: pid=0
                if pid and pid not in enabled_ids: enabled_ids.append(pid)
                enabled_rule_count += len(prof.get('rules') or [])
            selected=[]
            # A missing filter is a stronger and clearer startup diagnosis than a
            # selected-profile mismatch. Evaluate it before mode-local selection.
            if require_enabled_rules and enabled_rule_count<=0:
                return {
                    'ok':False,'reason':prefix+'_FILTER_NOT_CONFIGURED',
                    'enabled_profile_ids':enabled_ids,'enabled_rule_count':enabled_rule_count,
                    'scope_value':scope_value,'config':cfg,'validation':validation,'counts':counts,
                }
            if selected_profile_ids is not None:
                for raw in (selected_profile_ids or []):
                    try: pid=int(raw)
                    except Exception: continue
                    if pid in (1,2,3,4) and pid not in selected: selected.append(pid)
                if not selected:
                    return {
                        'ok':False,'reason':prefix+'_FILTER_PROFILE_SELECTION_EMPTY',
                        'enabled_profile_ids':enabled_ids,'scope_value':scope_value,'config':cfg,
                        'validation':validation,'counts':counts,
                    }
                if not any(pid in enabled_ids for pid in selected):
                    return {
                        'ok':False,'reason':prefix+'_FILTER_SELECTED_PROFILES_INACTIVE',
                        'selected_profile_ids':selected,'enabled_profile_ids':enabled_ids,
                        'scope_value':scope_value,'config':cfg,'validation':validation,'counts':counts,
                    }
            return {
                'ok':True,'reason':prefix+'_FILTER_READY','scope_value':scope_value,
                'scope_profile_key':profile_key_for_scope(scope_value),
                'scope_option_count':len(scope_options),'scope_options':scope_options,
                'registry_total':len(entries),'global_filterable_count':len(FILTERABLE_OPTIONS),
                'counts':counts,'validation':validation,'profile_validation':profile_validation,
                'enabled_profile_ids':enabled_ids,'enabled_rule_count':enabled_rule_count,
                'selected_profile_ids':selected if selected_profile_ids is not None else None,
                'config':cfg,
            }
        except Exception as e:
            return {'ok':False,'reason':prefix+'_FILTER_CONFIG_LOAD_FAILED','error':str(e)}

    @staticmethod
    def _auto_chest_snapshot_has_free_rect(snapshot, width, height):
        """Pure occupancy check; no input and no Storage dependency."""
        if not isinstance(snapshot,dict) or not snapshot.get('ok'):
            return False
        grid=snapshot.get('grid') or {}
        rows=int(grid.get('rows',10) or 10); cols=int(grid.get('cols',6) or 6)
        w=max(1,int(width)); h=max(1,int(height))
        free={(int(c.get('row',-1)),int(c.get('col',-1))) for c in (snapshot.get('cells') or []) if not c.get('occupied')}
        if len(free) < w*h:
            return False
        for r in range(0,max(0,rows-h)+1):
            for c in range(0,max(0,cols-w)+1):
                if all((rr,cc) in free for rr in range(r,r+h) for cc in range(c,c+w)):
                    return True
        return False

    def _auto_chest_capacity_guard(self, snapshot):
        """Conservative V12.11 inventory-only reward capacity guard.

        V12.11 geometry supports 2x3 armor / weapon, 1x4 vertical weapons and
        4x1 horizontal weapons.  Requiring room for all three maximum canonical
        shapes guarantees the smaller canonical footprints also have safe space.
        """
        if not isinstance(snapshot,dict) or not snapshot.get('ok'):
            return {'ok':False,'safe':False,'reason':'INVENTORY_CAPACITY_UNVERIFIED'}
        shapes=((2,3),(1,4),(4,1))
        fits={f'{w}x{h}':bool(self._auto_chest_snapshot_has_free_rect(snapshot,w,h)) for w,h in shapes}
        safe=all(fits.values())
        return {
            'ok':True,'safe':safe,
            'reason':'INVENTORY_CAPACITY_OK' if safe else 'STOPPED_INVENTORY_FULL',
            'free_count':int(snapshot.get('free_count',0) or 0),
            'maximum_supported_shapes':[list(x) for x in shapes],
            'shape_fits':fits,
            'policy':'V12_11_KEEP_DROP_CONSERVATIVE_ALL_MAX_SHAPES_FIT',
        }

    def _auto_chest_refresh_capacity(self, hwnd):
        """Fresh read-only Player Inventory capacity check after KEEP/DROP."""
        ready=self._capture_source_grid_visible(int(hwnd))
        if not ready.get('ok'):
            return {'ok':False,'safe':False,'reason':'INVENTORY_CAPACITY_UNVERIFIED','inventory':ready}
        self._inventory_grid=ready.get('grid')
        snap=snapshot_inventory(ready.get('image'),self._inventory_grid)
        if not snap.get('ok'):
            return {'ok':False,'safe':False,'reason':'INVENTORY_CAPACITY_UNVERIFIED','snapshot':snap}
        self._inventory_last=snap
        out=self._auto_chest_capacity_guard(snap)
        out['snapshot_free_count']=int(snap.get('free_count',0) or 0)
        out['capture_mode']=ready.get('capture_mode')
        return out

    def _auto_chest_keep_finalize(self, hwnd, item, cycle_id=None):
        """MATCH terminal for Auto Chest: logical finalize only, ZERO item input."""
        item=item or {}
        lid=_logical_item_id(item)
        item['logical_item_id']=lid
        item['decision']='KEEP'
        item['status']='KEEP_FINALIZED'
        item['action']='KEEP_IN_INVENTORY'
        item['action_status']='CONFIRMED'
        item['reason']='MATCH_KEEP_IN_PLAYER_INVENTORY'
        le=self._ledger_upsert(item,'MATCH','KEEP','FINALIZED',None,authoritative=True)
        capacity=self._auto_chest_refresh_capacity(hwnd)
        # Current item is terminal regardless of whether another chest can safely open.
        self._new_item_queue=[]
        self._queue_read_results=[]
        self._inventory_baseline=None
        self._batch_preopen_snapshot=None
        capacity_verified=bool(capacity.get('ok'))
        safe=bool(capacity_verified and capacity.get('safe'))
        full=bool(capacity_verified and not capacity.get('safe'))
        stop_reason=(None if safe else ('STOPPED_INVENTORY_FULL' if full else 'INVENTORY_CAPACITY_UNVERIFIED'))
        return {
            'ok':True,'kept':True,'logical_item_id':lid,'ledger_finalized':bool(le.get('finalized')),
            'cycle_id':cycle_id,'cycle_complete':True,'cycle_terminal_action':'KEEP_IN_INVENTORY',
            'action_confirmed':True,'physical_item_click_count':0,'storage_call_count':0,
            'next_cycle_ready':safe,'loop_result':'CONTINUE' if safe else 'STOP',
            'loop_state':'READY_NEXT' if safe else stop_reason,
            'stop_loop':not safe,'stop_reason':stop_reason,
            'normal_stop':full,'safe_pause':bool((not safe) and (not full)),
            'continuation_reason':'KEEP_FINALIZED_CAPACITY_OK' if safe else stop_reason,
            'capacity':capacity,'fresh_state_required':True,
        }

    def _auto_chest_uncertain_continue_finalize(self, hwnd, item, unresolved_reason, cycle_id=None, reader=None):
        """V1.7.14: read instability is non-fatal for Auto Chest.

        UNKNOWN/UNRESOLVED never authorizes DROP or STORE. The current item is
        retained physically in Player Inventory, finalized logically as a safe
        deferred keep, and the chest loop continues if fresh capacity still
        permits another chest. This removes the old FILTER_RECHECK_PENDING
        stop/resume hand-off for pure reader uncertainty.
        """
        item=item or {}
        lid=_logical_item_id(item)
        item['logical_item_id']=lid
        item['decision']='UNCERTAIN'
        item['filter_result']='UNRESOLVED'
        item['status']='UNRESOLVED_DEFERRED_SAFE_KEEP'
        item['action']='NO_DESTRUCTIVE_ACTION_KEEP_IN_INVENTORY'
        item['action_status']='CONFIRMED_SAFE_NO_ACTION'
        item['reason']=str(unresolved_reason or 'FINAL6_UNRESOLVED')
        le=self._ledger_upsert(item,'UNRESOLVED','SAFE_KEEP_DEFERRED','FINALIZED',None,authoritative=False)
        try:
            self._v114_release_recovery_owner(lid,deferred=False,reason='UNRESOLVED_DEFERRED_SAFE_KEEP')
        except Exception:
            pass
        try:
            self._pending_disposition_queue=[x for x in list(self._pending_disposition_queue or []) if str(x)!=str(lid)]
        except Exception:
            pass
        capacity=self._auto_chest_refresh_capacity(hwnd)
        self._new_item_queue=[]
        self._queue_read_results=[]
        self._inventory_baseline=None
        self._batch_preopen_snapshot=None
        capacity_verified=bool(capacity.get('ok'))
        safe=bool(capacity_verified and capacity.get('safe'))
        full=bool(capacity_verified and not capacity.get('safe'))
        stop_reason=(None if safe else ('STOPPED_INVENTORY_FULL' if full else 'INVENTORY_CAPACITY_UNVERIFIED'))
        return {
            'ok':True if (safe or full) else False,
            'safe_pause':bool((not safe) and (not full)),
            'normal_stop':bool(full),
            'uncertain':True,'deferred_safe_keep':True,'logical_item_id':lid,
            'ledger_finalized':bool(le.get('finalized')),'cycle_id':cycle_id,
            'cycle_complete':True,'cycle_terminal_action':'UNRESOLVED_DEFERRED_SAFE_KEEP',
            'action_confirmed':True,'physical_item_click_count':0,'destructive_input_count':0,
            'drop_authorized':False,'store_authorized':False,'keep_authorized':False,
            'next_cycle_ready':safe,'loop_result':'CONTINUE' if safe else 'STOP',
            'loop_state':'READY_NEXT' if safe else stop_reason,
            'stop_loop':not safe,'stop_reason':stop_reason,
            'continuation_reason':'READ_UNSTABLE_DEFERRED_CONTINUE' if safe else stop_reason,
            'unresolved_reason':str(unresolved_reason or 'FINAL6_UNRESOLVED'),
            'reader':reader,'capacity':capacity,'fresh_state_required':True,
        }

    def _v107_filter_snapshot_state(self, cfg=None):
        snap=_v107_canonical_filter_snapshot(cfg if isinstance(cfg,dict) else _load_option_filter())
        h=_v107_json_hash(snap)
        self._last_backend_filter_snapshot=snap; self._last_backend_filter_hash=h
        return {'snapshot':snap,'hash':h,'generation':int(self._filter_config_generation)}

    def _v107_decision_envelope(self, cycle_id, item, read):
        read=read if isinstance(read,dict) else {}
        ff=read.get('fast_filter') if isinstance(read.get('fast_filter'),dict) else {}
        top_result=str(read.get('filter_result') or '').upper() or None
        nested_result=str(ff.get('filter_result') or '').upper() or None
        # V11.2 accepts both engine encodings for the same authoritative state:
        #   filter_result=REJECT + reject_authority=AUTHORITATIVE_REJECT
        #   filter_result=AUTHORITATIVE_REJECT
        # Normalize before authorization so a fresh authoritative resume result
        # can never be blocked by stale/string-level representation differences.
        if top_result=='AUTHORITATIVE_REJECT':
            top_result='REJECT'
        if nested_result=='AUTHORITATIVE_REJECT':
            nested_result='REJECT' 
        decision=str(read.get('decision') or (item or {}).get('decision') or '').upper()
        matched=read.get('matched_profile_id')
        if matched is None: matched=ff.get('matched_profile_id')
        if top_result is None:
            if decision=='KEEP': top_result='MATCH'
            elif decision=='FAIL': top_result='REJECT'
        disposition='KEEP' if top_result=='MATCH' else ('DROP' if top_result=='REJECT' else 'BLOCK')
        reject_authority=str(read.get('reject_authority') or ff.get('reject_authority') or '').upper() or ('UNRESOLVED' if top_result!='REJECT' else 'MISSING')
        decision_fingerprint=_v110_item_decision_fingerprint(item or {},cycle_id)
        conflict=False; conflict_reason=None
        if nested_result=='MATCH' and top_result=='REJECT':
            conflict=True; conflict_reason='NESTED_MATCH_TOP_REJECT'
        if matched is not None and disposition=='DROP':
            conflict=True; conflict_reason=conflict_reason or 'MATCHED_PROFILE_WITH_DROP'
        cfg_state=self._v107_filter_snapshot_state(getattr(self,'_batch_filter_cache',None))
        ui_hash=self._last_ui_filter_hash
        backend_hash=cfg_state['hash']
        if ui_hash and ui_hash!=backend_hash:
            conflict=True; conflict_reason=conflict_reason or 'FILTER_CONFIG_DESYNC'
        frames=ff.get('frames') or read.get('filter',{}).get('frames') or []
        observed=[]
        for fr in frames[:1]:
            for row in (fr.get('row_evidence') or []):
                if row.get('canonical_option_id') or row.get('canonical_option_name'):
                    observed.append({
                        'physical_row_index':row.get('physical_row_index'),'option_id':row.get('canonical_option_id'),
                        'option_name':row.get('canonical_option_name'),'family':row.get('family'),'qualifier':row.get('qualifier'),
                        'unit':row.get('expected_unit'),'value':row.get('canonical_value'),'authoritative':row.get('numeric_authoritative'),
                    })
        return {
            'logical_item_id':_logical_item_id(item or {}),'queue_id':(item or {}).get('queue_id'),'cycle_id':cycle_id,
            'item_fingerprint':decision_fingerprint,'source_fingerprint':(item or {}).get('fingerprint'),
            'fingerprint_current':True,'item_anchor':(item or {}).get('anchor'),'footprint':(item or {}).get('footprint'),
            'build_id':V107_BUILD_ID,'filter_config_generation':cfg_state['generation'],'ui_filter_hash':ui_hash,
            'backend_filter_hash':backend_hash,'filter_config_snapshot':cfg_state['snapshot'],
            'reader_generation':V107_READER_VERSION,'evidence_generation':f"{cycle_id}:{(item or {}).get('queue_id')}:{len(frames)}",
            'ObservedOptionSet':observed,'profile_results':ff.get('profile_results') or [],'matched_profile_id':matched,
            'nested_filter_result':nested_result,'filter_result':top_result,'reject_authority':reject_authority,'disposition':disposition,
            'conflict':conflict,'conflict_reason':conflict_reason,
        }

    def _v107_drop_authorization_gate(self, envelope):
        """V11.0 false-drop hard barrier immediately before destructive input."""
        e=envelope or {}
        if e.get('conflict'):
            return {'ok':False,'reason':'DECISION_PROVENANCE_MISMATCH','detail':e.get('conflict_reason'),'destructive_input_count':0}
        if e.get('ui_filter_hash') and e.get('ui_filter_hash')!=e.get('backend_filter_hash'):
            return {'ok':False,'reason':'FILTER_CONFIG_DESYNC','destructive_input_count':0}
        if not e.get('queue_id') or not e.get('item_fingerprint') or not e.get('fingerprint_current'):
            return {'ok':False,'reason':'DROP_AUTHORIZATION_DENIED_STALE_ITEM_IDENTITY','destructive_input_count':0}
        if e.get('filter_config_generation') is None or not e.get('evidence_generation'):
            return {'ok':False,'reason':'DROP_AUTHORIZATION_DENIED_STALE_EVIDENCE','destructive_input_count':0}
        if str(e.get('filter_result') or '').upper()!='REJECT':
            return {'ok':False,'reason':'DROP_AUTHORIZATION_DENIED_FILTER_NOT_REJECT','destructive_input_count':0}
        if str(e.get('reject_authority') or '').upper()!='AUTHORITATIVE_REJECT':
            return {'ok':False,'reason':'DROP_AUTHORIZATION_DENIED_REJECT_NOT_AUTHORITATIVE','destructive_input_count':0}
        if e.get('matched_profile_id') is not None:
            return {'ok':False,'reason':'DROP_AUTHORIZATION_DENIED_MATCHED_PROFILE','destructive_input_count':0}
        for pr in (e.get('profile_results') or []):
            if str(pr.get('state') or '').upper()=='MATCHED_N_OF_N' or str(pr.get('decision') or '').upper()=='PASS':
                return {'ok':False,'reason':'DROP_AUTHORIZATION_DENIED_MATCHED_PROFILE_EVIDENCE','destructive_input_count':0}
        return {'ok':True,'reason':'DROP_AUTHORIZED_AUTHORITATIVE_REJECT','build_id':V107_BUILD_ID}

    def _v107_store_authorization_gate(self, envelope):
        e=envelope or {}
        if e.get('conflict'):
            return {'ok':False,'reason':'DECISION_PROVENANCE_MISMATCH','detail':e.get('conflict_reason'),'destructive_input_count':0}
        if e.get('ui_filter_hash') and e.get('ui_filter_hash')!=e.get('backend_filter_hash'):
            return {'ok':False,'reason':'FILTER_CONFIG_DESYNC','destructive_input_count':0}
        if str(e.get('filter_result') or '').upper()!='MATCH' or e.get('matched_profile_id') is None:
            return {'ok':False,'reason':'STORE_AUTHORIZATION_DENIED_NOT_MATCHED_N_OF_N','destructive_input_count':0}
        return {'ok':True,'reason':'STORE_AUTHORIZED_MATCH','build_id':V107_BUILD_ID}

    def _ledger_upsert(self, item, filter_result=None, intended_disposition=None, state=None, tx_id=None, authoritative=True):
        item=item or {}
        if item.get('session_generation') is None:
            item['session_generation']=int(getattr(self,'_chest_session_generation',0) or 0)
        if item.get('originating_cycle_id') is None:
            item['originating_cycle_id']=int(item.get('recovery_origin_cycle_id') or getattr(self,'_chest_cycle_seq',0) or 0)
        item['original_anchor']=list(item.get('original_anchor') or item.get('anchor') or [0,0])
        if not str(item.get('logical_item_id') or '').startswith('ITEM-'):
            item.pop('logical_item_id',None)
        lid=_logical_item_id(item); now=time.time()
        try:
            item['logical_item_id']=lid
        except Exception:
            pass
        e=dict(self._item_recovery_ledger.get(lid) or {})
        e.update({
            'logical_item_id':lid,'queue_id':item.get('queue_id'),'fingerprint':item.get('fingerprint'),
            'session_generation':int(item.get('session_generation') or e.get('session_generation') or 0),
            'originating_cycle_id':int(item.get('originating_cycle_id') or e.get('originating_cycle_id') or 0),
            'original_anchor':e.get('original_anchor') or list(item.get('anchor') or [0,0]),
            'current_anchor':list(item.get('anchor') or e.get('current_anchor') or [0,0]),
            'footprint':list(item.get('footprint') or [1,1]),
            'item_snapshot':dict(item),
            'source_item_visual_hash':item.get('source_item_visual_hash') or e.get('source_item_visual_hash'),
            'tooltip_option_signature':item.get('tooltip_option_signature') or e.get('tooltip_option_signature'),
            'filter_result':filter_result if filter_result is not None else e.get('filter_result'),
            'filter_authoritative':bool(authoritative if filter_result is not None else e.get('filter_authoritative',False)),
            'matched_profile_id':item.get('matched_profile_id') if item.get('matched_profile_id') is not None else e.get('matched_profile_id'),
            'intended_disposition':intended_disposition or e.get('intended_disposition'),
            'pending_state':state or e.get('pending_state') or 'NEW',
            'drop_tx_id':tx_id if intended_disposition=='DROP' else e.get('drop_tx_id'),
            'store_tx_id':tx_id if intended_disposition=='STORE' else e.get('store_tx_id'),
            'action_retry_count':int(e.get('action_retry_count',0) or 0),
            'filter_rescan_count':int(e.get('filter_rescan_count',0) or 0),
            'reread_count':int(e.get('reread_count',0) or 0),
            'recovery_generation':int(e.get('recovery_generation',0) or 0),
            'last_seen_timestamp':now,'last_seen_grid_generation':int(getattr(self,'_verified_grid_lease_generation',0) or 0),
            'finalized':bool(state=='FINALIZED'),
        })
        snap=getattr(self,'_inventory_last',None)
        if state in ('FILTER_RECHECK_PENDING','FILTER_RECHECK_DEFERRED') and isinstance(snap,dict) and snap.get('ok'):
            sm=_snapshot_cell_map(snap); sigs=[]
            for rc in _candidate_cells(item):
                c=sm.get(tuple(rc))
                if c:
                    sigs.append({'offset':[int(rc[0])-int((item.get('anchor') or [0,0])[0]),int(rc[1])-int((item.get('anchor') or [0,0])[1])],
                                 'occupied':bool(c.get('occupied')),'sig':c.get('_sig') or []})
            if sigs:
                e['source_signatures']=sigs
                sig_hash=_v113_source_signature_hash(sigs)
                e['source_item_visual_hash']=sig_hash
                try:
                    item['source_item_visual_hash']=sig_hash
                except Exception:
                    pass
            e['item_instance_evidence']={
                'logical_item_id':lid,
                'originating_cycle_id':e.get('originating_cycle_id'),
                'initial_anchor':e.get('original_anchor'),
                'current_anchor':e.get('current_anchor'),
                'footprint':e.get('footprint'),
                'source_item_visual_hash':e.get('source_item_visual_hash'),
                'tooltip_option_signature':e.get('tooltip_option_signature'),
                'source_signature_count':len(e.get('source_signatures') or []),
            }
            e['unresolved_reason']=str(item.get('reason') or e.get('unresolved_reason') or 'FILTER_UNRESOLVED')
            e['next_recheck_due_epoch']=now+V109_PENDING_RECHECK_INTERVAL_SEC
        self._item_recovery_ledger[lid]=e
        if state in ('REJECT_PENDING_DROP','MATCH_PENDING_STORE','FILTER_RECHECK_PENDING','FILTER_RECHECK_DEFERRED') and lid not in self._pending_disposition_queue:
            self._pending_disposition_queue.append(lid)
        if state=='FINALIZED' and lid in self._pending_disposition_queue:
            self._pending_disposition_queue.remove(lid)
        return e

    def _pending_capacity_safe(self, snapshot=None):
        # Conservative cell budget; do not open endlessly while pending items accumulate.
        if len(self._pending_disposition_queue)>=PENDING_DISPOSITION_MAX:
            return False
        if isinstance(snapshot,dict) and snapshot.get('ok'):
            return int(snapshot.get('free_count',0) or 0) >= max(2,len(self._pending_disposition_queue)+1)
        return True

    def _v109_classify_unresolved_reason(self, read):
        """Return a concrete V10.9 unresolved cause without authorizing action."""
        if not isinstance(read,dict):
            return 'OCR_INPUT_CONTRACT_VIOLATION'
        explicit=str(read.get('unresolved_reason') or read.get('reason') or read.get('rejection_reason') or '').upper()
        ff=read.get('fast_filter') if isinstance(read.get('fast_filter'),dict) else {}
        frames=ff.get('frames') if isinstance(ff.get('frames'),list) else []
        for fr in frames:
            if not isinstance(fr,dict):
                continue
            if int(fr.get('final6_row_count') or 0) not in (0,6):
                return 'ROW_SEGMENTATION_FAILED'
            fr_reason=str(fr.get('reason') or '').upper()
            if 'LAST6' in fr_reason or 'FINAL6_NOT_FOUND' in fr_reason:
                return 'FINAL6_NOT_FOUND'
            if fr.get('primary_ocr_source') and str(fr.get('primary_ocr_source')).upper() not in {
                'FINAL6_FOREGROUND_SYNTHETIC_ZOOM4X','FINAL6_DIRECT_CROP_ZOOM4X'
            }:
                return 'OCR_INPUT_CONTRACT_VIOLATION'
        if 'CONFIG' in explicit and ('MISMATCH' in explicit or 'DESYNC' in explicit):
            return 'CONFIG_GENERATION_MISMATCH'
        if 'SKILL' in explicit:
            return 'SKILL_VALUE_UNRESOLVED'
        if 'PERCENT' in explicit or '%' in explicit:
            return 'PERCENT_VALUE_UNRESOLVED'
        if 'SCOPE_IDENTITY' in explicit or 'IDENTITY' in explicit or 'FAMILY' in explicit or 'OPTION' in explicit:
            return 'OPTION_IDENTITY_UNRESOLVED'
        if 'VALUE' in explicit or 'OCR_UNREADABLE' in explicit:
            return 'WANTED_OPTION_VALUE_UNRESOLVED'
        if explicit in {
            'FINAL6_NOT_FOUND','ROW_SEGMENTATION_FAILED','OPTION_IDENTITY_UNRESOLVED',
            'WANTED_OPTION_VALUE_UNRESOLVED','SKILL_VALUE_UNRESOLVED',
            'PERCENT_VALUE_UNRESOLVED','CONFIG_GENERATION_MISMATCH',
            'OCR_INPUT_CONTRACT_VIOLATION'
        }:
            return explicit
        return 'WANTED_OPTION_VALUE_UNRESOLVED'

    def _v109_pending_filter_entry(self, preferred_logical_item_id=None):
        """Return the exact bound recovery item when supplied.

        V12.0 selected FIFO across both PENDING and DEFERRED states. In the
        160109 real run timer #2 was scheduled from cycle 36, but FIFO selected
        older deferred ITEM-...000031. V12.1 makes timer ownership explicit.
        """
        preferred=str(preferred_logical_item_id or '')
        if preferred:
            e=self._item_recovery_ledger.get(preferred)
            if isinstance(e,dict) and e.get('pending_state') in ('FILTER_RECHECK_PENDING','FILTER_RECHECK_DEFERRED') and not e.get('finalized'):
                return preferred,dict(e)
            return None,None
        # Without an explicit timer binding, a currently blocking owner outranks
        # every retained deferred entry.
        blocked,owner,entry=self._v114_has_blocking_pending_owner()
        if blocked:
            lid=str((owner or {}).get('logical_item_id') or (entry or {}).get('logical_item_id') or '')
            if lid:
                e=self._item_recovery_ledger.get(lid)
                if isinstance(e,dict) and not e.get('finalized'):
                    return lid,dict(e)
        # Manual deferred servicing fallback: pending states first, deferred last.
        for wanted_state in ('FILTER_RECHECK_PENDING','FILTER_RECHECK_DEFERRED'):
            for lid in list(self._pending_disposition_queue):
                e=self._item_recovery_ledger.get(lid)
                if isinstance(e,dict) and str(e.get('pending_state') or '').upper()==wanted_state and not e.get('finalized'):
                    return lid,dict(e)
        return None,None

    def _v109_reidentify_pending_filter_item(self, snapshot, entry):
        """V11.3: reidentify the SAME pending physical instance from a fresh bag scan.

        Q01 and stale coordinates have no destructive authority. A resume action is
        authorized only when stored source signatures uniquely identify the instance.
        """
        if not isinstance(snapshot,dict) or not snapshot.get('ok') or not isinstance(entry,dict):
            return {'ok':False,'reason':'PENDING_REIDENTIFY_SNAPSHOT_INVALID','identity_state':'ITEM_IDENTITY_UNKNOWN'}
        item=dict(entry.get('item_snapshot') or {})
        fp=list(entry.get('footprint') or item.get('footprint') or [1,1])
        try: fw,fh=max(1,int(fp[0])),max(1,int(fp[1]))
        except Exception: fw,fh=1,1
        old=list(entry.get('current_anchor') or entry.get('original_anchor') or item.get('anchor') or [0,0])
        sigs=list(entry.get('source_signatures') or [])
        if not sigs:
            return {
                'ok':False,'reason':'PENDING_ITEM_INSTANCE_EVIDENCE_MISSING',
                'identity_state':'ITEM_IDENTITY_UNKNOWN','old_anchor':old,
                'logical_item_id':entry.get('logical_item_id'),
            }
        sm=_snapshot_cell_map(snapshot)
        candidates=[]
        for r in range(0,max(1,10-fh+1)):
            for c in range(0,max(1,6-fw+1)):
                maes=[]; occ_mismatch=0; observed=0; hard_missing=False
                for sg in sigs:
                    off=sg.get('offset') or [0,0]
                    cur=sm.get((r+int(off[0]),c+int(off[1])))
                    if not cur:
                        hard_missing=True; break
                    observed+=1
                    expected_occ=bool(sg.get('occupied'))
                    current_occ=bool(cur.get('occupied'))
                    # A source-owned occupied cell becoming empty cannot be the same
                    # physical instance at this candidate anchor. Reject the anchor
                    # outright instead of letting empty/background pixels compete.
                    if expected_occ and not current_occ:
                        hard_missing=True; break
                    if expected_occ != current_occ:
                        occ_mismatch+=1
                    if sg.get('sig') and cur.get('_sig'):
                        maes.append(float(_sig_mae(sg.get('sig'),cur.get('_sig'))))
                if hard_missing or observed!=len(sigs):
                    continue
                if not maes:
                    continue
                score=sum(maes)/len(maes) + occ_mismatch*18.0
                same=(r==int(old[0]) and c==int(old[1]))
                candidates.append({'score':float(score),'r':int(r),'c':int(c),'same_anchor':same,'occ_mismatch':int(occ_mismatch)})
        if not candidates:
            return {
                'ok':False,'reason':'PENDING_ITEM_NOT_FOUND','identity_state':'ITEM_NOT_FOUND',
                'old_anchor':old,'logical_item_id':entry.get('logical_item_id'),
            }
        candidates.sort(key=lambda x:x['score'])
        best=candidates[0]
        if best['score'] > float(V113_SAME_ITEM_MAX_MAE):
            return {
                'ok':False,'reason':'PENDING_ITEM_FINGERPRINT_MISMATCH','identity_state':'ITEM_IDENTITY_UNKNOWN',
                'best_score':round(best['score'],3),'old_anchor':old,'best_anchor':[best['r'],best['c']],
                'logical_item_id':entry.get('logical_item_id'),
            }
        plausible=[x for x in candidates if x['score'] <= float(V113_SAME_ITEM_MAX_MAE)]
        if len(plausible)>1:
            second=plausible[1]
            if (second['score']-best['score']) < float(V113_SAME_ITEM_MIN_MARGIN):
                return {
                    'ok':False,'reason':'PENDING_ITEM_REIDENTIFY_AMBIGUOUS','identity_state':'MULTIPLE_POSSIBLE_INSTANCES',
                    'best_score':round(best['score'],3),'second_score':round(second['score'],3),
                    'best_anchor':[best['r'],best['c']],'second_anchor':[second['r'],second['c']],
                    'logical_item_id':entry.get('logical_item_id'),
                }
        r,c=best['r'],best['c']
        old_anchor=list(item.get('anchor') or old)
        rel_cells=[]
        for rc in item.get('cells') or []:
            try: rel_cells.append([int(rc[0])-int(old_anchor[0]),int(rc[1])-int(old_anchor[1])])
            except Exception: pass
        item['anchor']=[r,c]; item['current_anchor']=[r,c]; item['footprint']=[fw,fh]
        item['geometric_cells']=[[rr,cc] for rr in range(r,r+fh) for cc in range(c,c+fw)]
        item['cells']=[[r+off[0],c+off[1]] for off in rel_cells] if rel_cells else list(item['geometric_cells'])
        item['logical_item_id']=entry.get('logical_item_id') or _logical_item_id(item)
        item['queue_id']=entry.get('queue_id') or item.get('queue_id') or 'Q01'
        item['source_item_visual_hash']=entry.get('source_item_visual_hash') or _v113_source_signature_hash(sigs)
        item['tooltip_option_signature']=entry.get('tooltip_option_signature') or item.get('tooltip_option_signature')
        identity_state='SAME_ITEM_CONFIRMED' if [r,c]==old else 'SAME_ITEM_MOVED'
        return {
            'ok':True,'item':item,'old_anchor':old,'new_anchor':[r,c],
            'score':round(best['score'],3),'moved':bool([r,c]!=old),
            'identity_state':identity_state,'same_item_confirmed':True,
            'logical_item_id':item.get('logical_item_id'),
            'source_item_visual_hash':item.get('source_item_visual_hash'),
            'candidate_count':len(plausible),
        }

    def _v113_save_resume_drop_image(self, event_id, suffix, image, logical_item_id=None):
        try:
            return PROOF_ARTIFACTS.save_image(
                'resume_drop',f'{event_id}_{suffix}.png',image,
                logical_item_id=logical_item_id,
                extra={'resume_event_id':str(event_id or ''),'artifact_role':str(suffix or '')},
            )
        except Exception:
            return None

    def _v115_post_drop_presence_classifier(self, snapshot, ledger_entry):
        """Classify post-Drop whole-bag presence without conflating absence with ambiguity.

        Metric contract is inherited from V11.3: _sig_mae is a DISTANCE, so lower
        is closer. A candidate is compatible only at/below the already-proven
        V113_SAME_ITEM_MAX_MAE threshold. Ambiguity requires >=2 compatible
        candidates inside the existing score-margin band. If a canonical 6x10 bag
        scan is valid and every structural candidate is outside the compatible
        threshold, the pending item is ABSENT, not ambiguous.
        """
        base={
            'state':'BAG_SCAN_INVALID','classification':'BAG_SCAN_INVALID',
            'scan_valid':False,'candidate_count':0,'compatible_candidate_count':0,
            'ambiguous_candidate_count':0,'candidates':[],
            'present_threshold':float(V115_POSTDROP_PRESENT_MAX_MAE),
            'ambiguous_score_margin':float(V115_POSTDROP_AMBIGUOUS_SCORE_MARGIN),
            'excluded_threshold':float(V115_POSTDROP_EXCLUDED_MIN_MAE),
            'metric':'MEAN_ABSOLUTE_ERROR','metric_direction':'LOWER_IS_CLOSER',
        }
        if not isinstance(snapshot,dict) or not snapshot.get('ok') or not isinstance(ledger_entry,dict):
            base['reason']='POST_DROP_SNAPSHOT_INVALID'; return base
        cells=list(snapshot.get('cells') or [])
        seen={(int(c.get('row',-1)),int(c.get('col',-1))) for c in cells if isinstance(c,dict)}
        if len(cells)!=60 or len(seen)!=60 or any((r,c) not in seen for r in range(10) for c in range(6)):
            base['reason']='POST_DROP_CANONICAL_6X10_SCAN_INCOMPLETE'; return base
        sigs=list(ledger_entry.get('source_signatures') or [])
        if not sigs:
            base['reason']='POST_DROP_INSTANCE_EVIDENCE_MISSING'; return base
        item=dict(ledger_entry.get('item_snapshot') or {})
        fp=list(ledger_entry.get('footprint') or item.get('footprint') or [1,1])
        try: fw,fh=max(1,int(fp[0])),max(1,int(fp[1]))
        except Exception: fw,fh=1,1
        old=list(ledger_entry.get('current_anchor') or ledger_entry.get('original_anchor') or item.get('anchor') or [0,0])
        sm=_snapshot_cell_map(snapshot)
        candidates=[]
        for r in range(0,max(1,10-fh+1)):
            for c in range(0,max(1,6-fw+1)):
                maes=[]; occ_mismatch=0; observed=0; structurally_possible=True
                for sg in sigs:
                    off=sg.get('offset') or [0,0]
                    cur=sm.get((r+int(off[0]),c+int(off[1])))
                    if not cur:
                        structurally_possible=False; break
                    observed+=1
                    expected_occ=bool(sg.get('occupied')); current_occ=bool(cur.get('occupied'))
                    if expected_occ and not current_occ:
                        structurally_possible=False; break
                    if expected_occ != current_occ: occ_mismatch+=1
                    if sg.get('sig') and cur.get('_sig'):
                        maes.append(float(_sig_mae(sg.get('sig'),cur.get('_sig'))))
                if not structurally_possible or observed!=len(sigs) or not maes:
                    continue
                score=float(sum(maes)/len(maes) + occ_mismatch*18.0)
                similarity=max(0.0,min(1.0,1.0-(score/255.0)))
                cls='PRESENT_COMPATIBLE' if score <= float(V115_POSTDROP_PRESENT_MAX_MAE) else 'EXCLUDED'
                candidates.append({
                    'anchor':[int(r),int(c)],'footprint':[int(fw),int(fh)],
                    'visual_distance':round(score,3),'fingerprint_similarity':round(similarity,6),
                    'present_threshold':float(V115_POSTDROP_PRESENT_MAX_MAE),
                    'ambiguous_threshold_margin':float(V115_POSTDROP_AMBIGUOUS_SCORE_MARGIN),
                    'classification':cls,'same_anchor':bool([int(r),int(c)]==[int(old[0]),int(old[1])]),
                    'occupancy_mismatch':int(occ_mismatch),
                })
        candidates.sort(key=lambda x:float(x['visual_distance']))
        compatible=[x for x in candidates if x.get('classification')=='PRESENT_COMPATIBLE']
        base.update({'scan_valid':True,'candidate_count':len(candidates),'compatible_candidate_count':len(compatible),'candidates':candidates})
        if not candidates:
            base.update({'state':'ITEM_ABSENT_CONFIRMED','classification':'ITEM_ABSENT_CONFIRMED','reason':'VALID_SCAN_ZERO_CANDIDATES'})
            return base
        if not compatible:
            base.update({'state':'ITEM_ABSENT_CONFIRMED','classification':'ITEM_ABSENT_CONFIRMED','reason':'ALL_CANDIDATES_EXCLUDED'})
            return base
        best=compatible[0]
        if len(compatible)>1:
            margin=float(compatible[1]['visual_distance'])-float(best['visual_distance'])
            if margin < float(V115_POSTDROP_AMBIGUOUS_SCORE_MARGIN):
                amb=[x for x in compatible if (float(x['visual_distance'])-float(best['visual_distance'])) < float(V115_POSTDROP_AMBIGUOUS_SCORE_MARGIN)]
                for x in amb: x['classification']='AMBIGUOUS_COMPATIBLE'
                base.update({
                    'state':'ITEM_IDENTITY_AMBIGUOUS','classification':'ITEM_IDENTITY_AMBIGUOUS',
                    'reason':'REAL_COMPETING_CANDIDATES_IN_AMBIGUITY_BAND',
                    'ambiguous_candidate_count':len(amb),'best_candidate':best,
                })
                return base
        present_state='ITEM_STILL_PRESENT_SAME_ANCHOR' if best.get('same_anchor') else 'ITEM_STILL_PRESENT_MOVED'
        base.update({
            'state':'ITEM_STILL_PRESENT_CONFIRMED','classification':'ITEM_STILL_PRESENT_CONFIRMED',
            'reason':present_state,'best_candidate':best,'current_anchor':list(best.get('anchor') or []),
        })
        return base

    def _v113_post_drop_whole_bag_reconcile(self, hwnd, ledger_entry, dropped_item, resume_event_id, low_level_result):
        """V11.5 PhysicalDropConfirmation: fuse source/cursor/fingerprint/whole-bag truth."""
        scan_id=f'V115-POSTDROP-{resume_event_id}-{int(time.time()*1000)}'
        ready=self._capture_inventory_ready(hwnd,try_open=True)
        if not ready.get('ok'):
            return {
                'ok':False,'state':'BAG_SCAN_INVALID','reason':ready.get('reason','POST_DROP_INVENTORY_NOT_READY'),
                'absence_reason':'BAG_SCAN_INVALID','post_inventory_scan_id':scan_id,'scan_valid':False,
                'post_drop_candidate_count':0,'post_drop_candidates':[],
            }
        self._inventory_grid=ready.get('grid') or self._inventory_grid
        img=ready.get('image') or capture_client(hwnd)
        snap=snapshot_inventory(img,self._inventory_grid)
        proof=self._v113_save_resume_drop_image(resume_event_id,'05_post_inventory_full',img,logical_item_id=(ledger_entry or {}).get('logical_item_id'))
        if not isinstance(snap,dict) or not snap.get('ok'):
            return {
                'ok':False,'state':'BAG_SCAN_INVALID','reason':'POST_DROP_WHOLE_BAG_SNAPSHOT_FAILED',
                'absence_reason':'BAG_SCAN_INVALID','post_inventory_scan_id':scan_id,'proof_path':proof,
                'scan_valid':False,'post_drop_candidate_count':0,'post_drop_candidates':[],
            }
        self._inventory_last=snap
        presence=self._v115_post_drop_presence_classifier(snap,ledger_entry)
        conf=(low_level_result or {}).get('confirm') or {}
        source_clear=str(conf.get('source_state_after') or '').upper()=='SOURCE_CLEAR_CONFIRMED'
        cursor_empty=str(conf.get('cursor_item_state') or '').upper()=='CURSOR_EMPTY_CONFIRMED'
        fp_checks=list(conf.get('post_drop_fingerprint_match') or [])
        gone_votes=sum(1 for x in fp_checks if str((x or {}).get('state') or '').upper()=='ITEM_GONE')
        common={
            'post_inventory_scan_id':scan_id,'snapshot':snap,'proof_path':proof,
            'scan_valid':bool(presence.get('scan_valid')),
            'post_drop_candidate_count':int(presence.get('candidate_count',0) or 0),
            'compatible_candidate_count':int(presence.get('compatible_candidate_count',0) or 0),
            'ambiguous_candidate_count':int(presence.get('ambiguous_candidate_count',0) or 0),
            'post_drop_candidates':list(presence.get('candidates') or []),
            'absence_reason':presence.get('reason'),
            'presence_classifier':presence,
            'source_clear_confirmed':bool(source_clear),'cursor_empty_confirmed':bool(cursor_empty),
            'item_gone_fresh_frame_count':int(gone_votes),
            'metric_direction':presence.get('metric_direction'),
        }
        pstate=presence.get('state')
        if pstate=='BAG_SCAN_INVALID':
            return dict(common,ok=False,state='BAG_SCAN_INVALID',reason=presence.get('reason') or 'BAG_SCAN_INVALID',item_absent_confirmed=False)
        if pstate=='ITEM_IDENTITY_AMBIGUOUS':
            return dict(common,ok=False,state='ITEM_IDENTITY_AMBIGUOUS',reason=presence.get('reason') or 'ITEM_IDENTITY_AMBIGUOUS',item_absent_confirmed=False)
        if pstate=='ITEM_STILL_PRESENT_CONFIRMED':
            state=str(presence.get('reason') or 'ITEM_STILL_PRESENT_SAME_ANCHOR')
            return dict(common,ok=False,state=state,reason=state,current_anchor=presence.get('current_anchor'),item_absent_confirmed=False)
        if pstate!='ITEM_ABSENT_CONFIRMED':
            return dict(common,ok=False,state='DROP_CONFIRM_UNRESOLVED',reason='POST_DROP_PRESENCE_CLASSIFIER_UNKNOWN',item_absent_confirmed=False)
        # Absence is meaningful only with the already-proven low-level physical signals.
        if not cursor_empty:
            return dict(common,ok=False,state='DROP_PARTIAL_COMMIT',reason='CURSOR_NOT_EMPTY_AFTER_ITEM_ABSENT',item_absent_confirmed=True,physical_truth=None)
        if not source_clear:
            return dict(common,ok=False,state='DROP_CONFIRM_UNRESOLVED',reason='SOURCE_NOT_CLEAR_AFTER_ITEM_ABSENT',item_absent_confirmed=True,physical_truth=None)
        if gone_votes < 2:
            return dict(common,ok=False,state='DROP_CONFIRM_UNRESOLVED',reason='INSUFFICIENT_FRESH_ITEM_GONE_EVIDENCE',item_absent_confirmed=True,physical_truth=None)
        return dict(
            common,ok=True,state='ITEM_ABSENT_CONFIRMED',reason='PHYSICAL_DROP_CONFIRMED',
            item_absent_confirmed=True,cursor_empty_confirmed=True,physical_truth='PHYSICAL_DROP_CONFIRMED',
        )

    def _v113_write_physical_drop_terminal(self, action_result, physical, item, ledger_entry, resume_event_id):
        """Write a resume Drop terminal only after whole-bag physical truth passes."""
        if not (isinstance(physical,dict) and physical.get('ok') and physical.get('physical_truth')=='PHYSICAL_DROP_CONFIRMED'):
            return None
        out=dict(action_result or {})
        out.pop('_v113_terminal_deferred',None)
        out['logical_item_id']=str((item or {}).get('logical_item_id') or (ledger_entry or {}).get('logical_item_id') or '')
        out['originating_cycle_id']=(ledger_entry or {}).get('originating_cycle_id')
        out['resume_event_id']=str(resume_event_id)
        out['pre_drop_anchor']=list((ledger_entry or {}).get('current_anchor') or (item or {}).get('anchor') or [0,0])
        out['drop_anchor']=list((item or {}).get('anchor') or [0,0])
        out['pre_item_fingerprint']=(ledger_entry or {}).get('source_item_visual_hash')
        out['post_inventory_scan_id']=physical.get('post_inventory_scan_id')
        out['post_drop_candidate_count']=int(physical.get('post_drop_candidate_count',0) or 0)
        out['post_drop_candidates']=list(physical.get('post_drop_candidates') or [])
        out['absence_reason']=physical.get('absence_reason')
        out['item_absent_confirmed']=bool(physical.get('item_absent_confirmed'))
        out['cursor_empty_confirmed']=bool(physical.get('cursor_empty_confirmed'))
        out['physical_truth']='PHYSICAL_DROP_CONFIRMED'
        out['physical_drop_confirmed']=True
        out['post_inventory_proof_path']=physical.get('proof_path')
        out['queue_item']=public_queue_item(item or {})
        stamp=time.strftime('%Y%m%d_%H%M%S')
        path=LOGDIR/f'{stamp}_chest_drop_item.json'
        path.write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
        return str(path)

    def _v109_write_resume_trace(self, event_id, payload):
        try:
            out={'build_id':V109_BUILD_ID,'resume_event_id':str(event_id),**dict(payload or {})}
            rr=str(out.get('new_filter_result') or out.get('reread_result') or '').upper()
            disp=str(out.get('disposition') or '').upper()
            if rr in ('REJECT','AUTHORITATIVE_REJECT') and (
                disp!='DROP'
                or (out.get('action_dispatched') and not out.get('action_tx_id'))
                or (out.get('ready_next') and not out.get('action_confirmed'))
                or (out.get('ready_next') and not out.get('physical_drop_confirmed'))
                or (out.get('pending_finalized') and not out.get('physical_drop_confirmed'))
            ):
                out['resume_invariant']='RESUME_DISPOSITION_INVARIANT_VIOLATION'
                out['ready_next']=False; out['next_chest_started']=False
            if rr=='MATCH' and (
                disp!='STORE'
                or (out.get('action_dispatched') and not out.get('action_tx_id'))
                or (out.get('ready_next') and not out.get('action_confirmed'))
            ):
                out['resume_invariant']='RESUME_DISPOSITION_INVARIANT_VIOLATION'
                out['ready_next']=False; out['next_chest_started']=False
            path=LOGDIR/f'AUTO_RESUME_EVENT_{event_id}.json'
            path.write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            return str(path)
        except Exception:
            return None

    def _v109_mark_resume_next_chest_started(self):
        """Mark next chest only after terminal action or explicit retained defer.

        V11.2 hard invariant: disposition=None/action_confirmed=False can never
        silently become READY_NEXT unless the same logical item is explicitly
        FILTER_RECHECK_DEFERRED and still present in the recovery ledger.
        """
        event_id=getattr(self,'_v109_resume_event_waiting_next_chest',None)
        if not event_id:
            return None
        try:
            path=LOGDIR/f'AUTO_RESUME_EVENT_{event_id}.json'
            data=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'resume_event_id':event_id,'build_id':V109_BUILD_ID}
            lid=str(data.get('pending_item_id') or '')
            disp=str(data.get('disposition') or '').upper()
            terminal=bool(
                data.get('action_confirmed')
                and data.get('pending_finalized')
                and disp in ('STORE','DROP')
                and (disp!='DROP' or data.get('physical_drop_confirmed'))
            )
            ledger_entry=self._item_recovery_ledger.get(lid) if lid else None
            deferred=bool(
                data.get('deferred')
                and str(data.get('pending_state') or '').upper()=='FILTER_RECHECK_DEFERRED'
                and isinstance(ledger_entry,dict)
                and str(ledger_entry.get('pending_state') or '').upper()=='FILTER_RECHECK_DEFERRED'
                and not ledger_entry.get('finalized')
            )
            if not (terminal or deferred):
                data['next_chest_started']=False
                data['resume_invariant']='RESUME_STATE_INVARIANT_VIOLATION'
                data['resume_invariant_detail']={
                    'terminal':terminal,'deferred':deferred,'disposition':data.get('disposition'),
                    'action_confirmed':bool(data.get('action_confirmed')),
                    'pending_finalized':bool(data.get('pending_finalized')),
                    'pending_state':data.get('pending_state'),'ledger_present':bool(isinstance(ledger_entry,dict)),
                }
                path.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
                return None
            data['next_chest_started']=True
            data['next_chest_started_at']=time.time()
            data['resume_invariant']='PASS_TERMINAL' if terminal else 'PASS_EXPLICIT_DEFERRED_LEDGER_RETAINED'
            path.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            self._v109_resume_event_waiting_next_chest=None
            return str(path)
        except Exception:
            return None

    def _v121_recovery_owner_log(self, event, payload=None):
        rec={'ts_epoch':time.time(),'event':str(event or 'RECOVERY_OWNER_EVENT'),'build_id':V121_BUILD_ID}
        if isinstance(payload,dict): rec.update(payload)
        try:
            with self._v121_recovery_owner_log_path.open('a',encoding='utf-8') as f:
                f.write(json.dumps(rec,ensure_ascii=False,default=str)+'\n')
        except Exception:
            pass
        return rec

    def _v114_set_recovery_owner(self, logical_item_id, event_id=None, state='FILTER_RECHECK_PENDING', blocking=True):
        """V12.1 BlockingRecoveryOwner acquisition/update.

        Q01 and FIFO position have zero ownership authority. One logical item owns
        the blocking recovery lane at a time; deferred items remain in the ledger
        but stop being blocking only after the explicit release gate passes.
        """
        lid=str(logical_item_id or '')
        if not lid:
            return None
        entry=self._item_recovery_ledger.get(lid)
        entry=entry if isinstance(entry,dict) else {}
        current=getattr(self,'_v114_recovery_owner',None)
        same=bool(isinstance(current,dict) and str(current.get('logical_item_id') or '')==lid)
        if not same:
            self._v121_recovery_owner_seq=int(getattr(self,'_v121_recovery_owner_seq',0) or 0)+1
        owner=dict(current) if same else {
            'logical_item_id':lid,
            'owner_generation':int(getattr(self,'_v121_recovery_owner_seq',0) or 0),
            'acquired_at':time.time(),
        }
        owner.update({
            'owner_kind':'BlockingRecoveryOwner',
            'automation_mode':'AUTO_CHEST',
            'logical_item_id':lid,
            'originating_cycle_id':entry.get('originating_cycle_id'),
            'resume_event_id':str(event_id) if event_id is not None else owner.get('resume_event_id'),
            'state':str(state or 'FILTER_RECHECK_PENDING'),
            'blocking':bool(blocking),
            'recovery_generation':int(entry.get('recovery_generation',0) or 0),
            'disposition':entry.get('intended_disposition'),
            'transaction_id':entry.get('drop_tx_id') or entry.get('store_tx_id'),
            'updated_at':time.time(),
        })
        self._v114_recovery_owner=owner
        self._v121_recovery_owner_log('RECOVERY_OWNER_SET',owner)
        return dict(owner)

    def _v121_owner_binding_snapshot(self, *, require_blocking=True):
        blocked,owner,entry=self._v114_has_blocking_pending_owner()
        if require_blocking and not blocked:
            return {'ok':False,'reason':'NO_BLOCKING_RECOVERY_OWNER'}
        if not owner and isinstance(entry,dict):
            owner={'logical_item_id':entry.get('logical_item_id'),'state':entry.get('pending_state'),'blocking':blocked}
        lid=str((owner or {}).get('logical_item_id') or (entry or {}).get('logical_item_id') or '')
        if not lid:
            return {'ok':False,'reason':'RECOVERY_OWNER_ID_MISSING'}
        return {
            'ok':True,
            'logical_item_id':lid,
            'owner_generation':int((owner or {}).get('owner_generation',0) or 0),
            'originating_cycle_id':(owner or {}).get('originating_cycle_id') or (entry or {}).get('originating_cycle_id'),
            'owner_state':(owner or {}).get('state') or (entry or {}).get('pending_state'),
            'recovery_generation':int((entry or {}).get('recovery_generation',0) or 0),
            'blocking':bool(blocked),
        }

    def _v114_release_recovery_owner(self, logical_item_id, terminal=False, deferred=False, reason=None):
        lid=str(logical_item_id or '')
        current=getattr(self,'_v114_recovery_owner',None)
        if not isinstance(current,dict) or str(current.get('logical_item_id') or '')!=lid:
            self._v121_recovery_owner_log('OWNER_RELEASE_DENIED_ID_MISMATCH',{
                'requested_logical_item_id':lid,
                'current_owner_id':(current or {}).get('logical_item_id') if isinstance(current,dict) else None,
                'terminal':bool(terminal),'deferred':bool(deferred),'reason':reason,
            })
            return None
        owner=dict(current)
        owner['terminal']=bool(terminal)
        owner['deferred']=bool(deferred)
        owner['blocking']=False if (terminal or deferred) else bool(owner.get('blocking',True))
        owner['state']='FINALIZED' if terminal else ('FILTER_RECHECK_DEFERRED' if deferred else str(owner.get('state') or 'RECOVERY_ACTIVE'))
        owner['release_reason']=reason
        owner['released_at']=time.time() if (terminal or deferred) else None
        owner['updated_at']=time.time()
        self._v114_recovery_owner=owner
        self._v121_recovery_owner_log('RECOVERY_OWNER_RELEASED' if (terminal or deferred) else 'RECOVERY_OWNER_UPDATED',owner)
        return dict(owner)

    def _v1711_reconcile_autochest_recovery_state(self, context='RUNTIME'):
        """Reconcile Auto Chest recovery owner, ledger, pending queue and timer bindings.

        Root invariant: a BlockingRecoveryOwner has authority only when its exact
        logical item still has a non-finalized blocking ledger entry. Historical
        code deliberately kept an owner blocking even when its ledger entry was
        missing/finalized; manual Start then called recovery with an impossible ID
        and stopped as RECOVERY_OWNER_ENTRY_NOT_FOUND even though Q/F4 + Grid were OK.

        Non-destructive orphan owners are retired fail-safe (item stays in bag).
        Destructive/transaction-bearing orphans remain a hard stop because losing
        that ledger could hide an in-flight item action.
        """
        context=str(context or 'RUNTIME')
        blocking_states={
            'FILTER_RECHECK_PENDING','REJECT_PENDING_DROP','MATCH_PENDING_STORE',
            'RESUME_RECOVERY_ACTIVE','RESUME_CALLBACK_NO_REREAD',
            'RESUME_REJECT_DROP_COMMIT_PENDING','RESUME_MATCH_KEEP_COMMIT_PENDING',
        }
        destructive_states={
            'REJECT_PENDING_DROP','MATCH_PENDING_STORE',
            'RESUME_REJECT_DROP_COMMIT_PENDING',
        }
        deferred_states={'FILTER_RECHECK_DEFERRED'}

        def _remove_pending_id(lid):
            removed=0
            try:
                while lid in self._pending_disposition_queue:
                    self._pending_disposition_queue.remove(lid); removed+=1
            except Exception:
                pass
            return removed

        # First prune queue entries that have no live pending ledger state. This is
        # housekeeping only; it never removes a non-finalized blocking/deferred item.
        pruned=[]
        for qlid in list(self._pending_disposition_queue):
            qe=self._item_recovery_ledger.get(qlid)
            qstate=str((qe or {}).get('pending_state') or '').upper() if isinstance(qe,dict) else ''
            if (not isinstance(qe,dict)) or qe.get('finalized') or qstate not in (blocking_states|deferred_states):
                if _remove_pending_id(qlid):
                    pruned.append(str(qlid))

        owner=getattr(self,'_v114_recovery_owner',None)
        owner=dict(owner) if isinstance(owner,dict) else None
        mutation=None
        hard_error=None
        valid_owner=None
        valid_entry=None

        if owner:
            mode=str(owner.get('automation_mode') or 'AUTO_CHEST').upper()
            lid=str(owner.get('logical_item_id') or '')
            state=str(owner.get('state') or '').upper()
            tx=owner.get('transaction_id')
            entry=self._item_recovery_ledger.get(lid) if lid else None
            entry=entry if isinstance(entry,dict) else None

            if mode!='AUTO_CHEST':
                hard_error='CROSS_AUTO_RECOVERY_OWNER_CONTRACT_VIOLATION'
            elif not lid:
                if tx or state in destructive_states:
                    hard_error='RECOVERY_LEDGER_CORRUPTION_DESTRUCTIVE_UNKNOWN'
                else:
                    mutation='OWNER_WITHOUT_ID_RETIRED'
            elif entry is None:
                if tx or state in destructive_states:
                    hard_error='RECOVERY_LEDGER_CORRUPTION_DESTRUCTIVE_UNKNOWN'
                else:
                    # FILTER_RECHECK/reader recovery has not moved the item. If its
                    # in-memory entry disappeared, preserving it in the Player Bag is
                    # safer than blocking every future Auto Chest start forever.
                    mutation='ORPHANED_NONDESTRUCTIVE_OWNER_RETIRED'
            elif entry.get('finalized') or str(entry.get('pending_state') or '').upper()=='FINALIZED':
                _remove_pending_id(lid)
                mutation='FINALIZED_OWNER_RETIRED'
            else:
                estate=str(entry.get('pending_state') or '').upper()
                if estate in deferred_states:
                    # Deferred is explicitly non-blocking. Keep diagnostic owner
                    # metadata, but it must never own the producer barrier.
                    owner.update({'automation_mode':'AUTO_CHEST','blocking':False,'state':estate,'updated_at':time.time()})
                    self._v114_recovery_owner=owner
                    valid_owner=owner; valid_entry=entry
                elif estate in blocking_states:
                    # Ledger is canonical. Repair owner metadata from it rather than
                    # trusting stale owner state/generation labels.
                    owner.update({
                        'automation_mode':'AUTO_CHEST','owner_kind':'BlockingRecoveryOwner',
                        'logical_item_id':lid,'state':estate,'blocking':True,
                        'originating_cycle_id':entry.get('originating_cycle_id'),
                        'recovery_generation':int(entry.get('recovery_generation',0) or 0),
                        'disposition':entry.get('intended_disposition'),
                        'transaction_id':entry.get('drop_tx_id') or entry.get('store_tx_id') or tx,
                        'updated_at':time.time(),
                    })
                    self._v114_recovery_owner=owner
                    valid_owner=owner; valid_entry=entry
                else:
                    if tx:
                        hard_error='RECOVERY_LEDGER_CORRUPTION_DESTRUCTIVE_UNKNOWN'
                    else:
                        mutation='OWNER_LEDGER_STATE_NOT_PENDING_RETIRED'

            if mutation:
                old_owner=dict(owner)
                self._v114_recovery_owner=None
                if lid:
                    _remove_pending_id(lid) if (entry is None or (entry and entry.get('finalized'))) else None
                    try:
                        self._v121_resume_owner_bindings={
                            k:v for k,v in self._v121_resume_owner_bindings.items()
                            if not (isinstance(v,dict) and str(v.get('logical_item_id') or '')==lid)
                        }
                    except Exception:
                        pass
                    active=getattr(self,'_v121_active_resume_owner_binding',None)
                    if isinstance(active,dict) and str(active.get('logical_item_id') or '')==lid:
                        self._v121_active_resume_owner_binding=None
                self._v121_recovery_owner_log('RECOVERY_OWNER_RECONCILED',{
                    'context':context,'reconcile_action':mutation,'old_owner':old_owner,
                    'ledger_entry_present':bool(entry),'ledger_finalized':bool((entry or {}).get('finalized')),
                    'pending_queue_pruned':pruned,
                })
                owner=None

        if hard_error:
            out={
                'ok':False,'blocking':True,'reason':hard_error,'context':context,
                'owner':owner or {},'entry':valid_entry or {},'pending_queue_pruned':pruned,
            }
            self._v1711_last_recovery_reconcile=out
            self._v121_recovery_owner_log('RECOVERY_OWNER_RECONCILE_HARD_FAIL',out)
            return out

        # If no valid blocking owner survived, reconstruct only from a real live
        # blocking ledger entry. This is the sole source of producer ownership.
        if not (valid_owner and valid_owner.get('blocking')):
            for lid in list(self._pending_disposition_queue):
                e=self._item_recovery_ledger.get(lid)
                if not isinstance(e,dict) or e.get('finalized'):
                    continue
                estate=str(e.get('pending_state') or '').upper()
                if estate in blocking_states:
                    valid_owner=self._v114_set_recovery_owner(lid,None,estate,blocking=True)
                    valid_entry=dict(e)
                    break

        blocking=bool(valid_owner and valid_owner.get('blocking') and isinstance(valid_entry,dict) and not valid_entry.get('finalized'))
        out={
            'ok':True,'blocking':blocking,'reason':'VALID_BLOCKING_RECOVERY_OWNER' if blocking else ('STALE_RECOVERY_OWNER_RETIRED' if mutation else 'NO_BLOCKING_RECOVERY_OWNER'),
            'context':context,'owner':dict(valid_owner or {}),'entry':dict(valid_entry or {}),
            'reconcile_action':mutation,'pending_queue_pruned':pruned,
            'stale_owner_retired':bool(mutation),
        }
        self._v1711_last_recovery_reconcile=out
        return out

    def _v114_has_blocking_pending_owner(self):
        rec=self._v1711_reconcile_autochest_recovery_state('BLOCKING_OWNER_QUERY')
        if not rec.get('ok'):
            # A destructive unknown remains blocking by construction. The caller
            # receives the exact corruption reason through owner metadata.
            owner=dict(rec.get('owner') or {})
            owner['reconcile_error']=rec.get('reason')
            return True,owner,dict(rec.get('entry') or {})
        if rec.get('blocking'):
            return True,dict(rec.get('owner') or {}),dict(rec.get('entry') or {})
        return False,dict(rec.get('owner') or {}),dict(rec.get('entry') or {})

    def _v121_recovery_owner_release_gate(self, logical_item_id, *, mode, capacity_safe=False, safety=None):
        lid=str(logical_item_id or '')
        entry=self._item_recovery_ledger.get(lid)
        entry=entry if isinstance(entry,dict) else None
        safety=safety if isinstance(safety,dict) else {}
        mode=str(mode or '').upper()
        base={
            'logical_item_id':lid,'mode':mode,'entry_present':bool(entry),
            'pending_state':(entry or {}).get('pending_state'),'capacity_safe':bool(capacity_safe),
            'cursor_empty':bool(safety.get('no_item_on_cursor')),
            'no_destructive_action_unresolved':bool(safety.get('no_destructive_action_unresolved')),
        }
        if mode in ('DROP_CONFIRMED','STORE_CONFIRMED','KEEP_FINALIZED'):
            ok=bool(entry and entry.get('finalized'))
            out={**base,'ok':ok,'reason':'OWNER_RELEASE_TERMINAL_CONFIRMED' if ok else 'OWNER_RELEASE_DENIED_TERMINAL_NOT_FINALIZED'}
        elif mode=='FILTER_RECHECK_DEFERRED':
            retained=bool(entry and not entry.get('finalized') and str(entry.get('pending_state') or '').upper()=='FILTER_RECHECK_DEFERRED')
            ok=bool(retained and capacity_safe and base['cursor_empty'] and base['no_destructive_action_unresolved'])
            out={**base,'ok':ok,'ledger_retained':retained,
                 'reason':'OWNER_RELEASE_DEFERRED_CONFIRMED' if ok else 'OWNER_RELEASE_DENIED_DEFER_SAFETY'}
        else:
            out={**base,'ok':False,'reason':'OWNER_RELEASE_DENIED_UNKNOWN_MODE'}
        self._v121_recovery_owner_log('RECOVERY_OWNER_RELEASE_GATE',out)
        return out

    def _v114_can_produce_new_item(self):
        blocked,owner,entry=self._v114_has_blocking_pending_owner()
        if blocked:
            out={
                'ok':False,'reason':'PENDING_OWNER_COMMIT_BARRIER',
                'logical_item_id':owner.get('logical_item_id') or entry.get('logical_item_id'),
                'pending_state':entry.get('pending_state') or owner.get('state'),
                'owner':owner,
            }
            self._v121_recovery_owner_log('CHEST_PRODUCER_GATE',{**out,'attempted_new_cycle':int(getattr(self,'_chest_cycle_seq',0) or 0)+1,'allowed':False})
            return out
        out={'ok':True,'reason':'NO_BLOCKING_PENDING_OWNER','owner':owner}
        self._v121_recovery_owner_log('CHEST_PRODUCER_GATE',{**out,'attempted_new_cycle':int(getattr(self,'_chest_cycle_seq',0) or 0)+1,'allowed':True})
        return out

    def _v114_resume_disposition_commit_gate(self, trace, logical_item_id):
        """Final state-machine barrier before Resume may re-arm Chest producer."""
        data=trace if isinstance(trace,dict) else {}
        lid=str(logical_item_id or data.get('logical_item_id') or data.get('pending_item_id') or '')
        rr=str(data.get('new_filter_result') or data.get('reread_result') or 'UNRESOLVED').upper()
        disp=str(data.get('disposition') or '').upper()
        entry=self._item_recovery_ledger.get(lid) if lid else None
        entry=entry if isinstance(entry,dict) else None
        base={
            'logical_item_id':lid,'recovery_filter_result':rr,'disposition':disp or None,
            'action_tx_id':data.get('action_tx_id'),'action_dispatched':bool(data.get('action_dispatched')),
            'action_confirmed':bool(data.get('action_confirmed')),'pending_finalized':bool(data.get('pending_finalized')),
            'pending_state':data.get('pending_state') or (entry or {}).get('pending_state'),
        }
        if rr=='MATCH':
            # V12.11 KEEP/DROP Master: a fresh MATCH is terminal without item input.
            # Commit truth is the logical KEEP finalizer + preserved inventory occupancy.
            ok=bool(disp=='KEEP' and (not base['action_tx_id']) and (not base['action_dispatched']) and base['action_confirmed'] and base['pending_finalized'])
            capacity_safe=bool(data.get('capacity_safe',True))
            return {**base,'ok':ok,'mode':'MATCH_KEEP_COMMIT','allows_producer':ok,
                    'capacity_safe':capacity_safe,
                    'reason':('RESUME_KEEP_COMMIT_CONFIRMED' if ok else 'RESUME_COMMIT_GATE_FAIL')}
        if rr in ('REJECT','AUTHORITATIVE_REJECT'):
            physical=bool(data.get('physical_drop_confirmed'))
            absent=bool(data.get('item_absent_confirmed'))
            cursor_empty=bool(data.get('cursor_empty_confirmed'))
            ok=bool(disp=='DROP' and base['action_tx_id'] and base['action_dispatched'] and base['action_confirmed'] and physical and absent and cursor_empty and base['pending_finalized'])
            return {**base,'ok':ok,'mode':'REJECT_DROP_COMMIT','allows_producer':ok,'physical_drop_confirmed':physical,'item_absent_confirmed':absent,'cursor_empty_confirmed':cursor_empty,'reason':'RESUME_DROP_COMMIT_CONFIRMED' if ok else 'RESUME_COMMIT_GATE_FAIL'}
        if rr=='UNRESOLVED':
            retained=bool(entry and not entry.get('finalized') and str(entry.get('pending_state') or '').upper()=='FILTER_RECHECK_DEFERRED')
            clean=bool(disp=='' and not base['action_tx_id'] and not base['action_dispatched'] and not base['action_confirmed'] and not base['pending_finalized'])
            ds=data.get('defer_safety') if isinstance(data.get('defer_safety'),dict) else {}
            cursor_empty=bool(ds.get('no_item_on_cursor'))
            no_destructive=bool(ds.get('no_destructive_action_unresolved'))
            ok=bool(data.get('deferred') and retained and clean and cursor_empty and no_destructive)
            return {**base,'ok':ok,'mode':'UNRESOLVED_EXPLICIT_DEFER',
                    'allows_producer':bool(ok and data.get('capacity_safe',True)),
                    'ledger_retained':retained,'cursor_empty':cursor_empty,
                    'no_destructive_action_unresolved':no_destructive,
                    'reason':'RESUME_DEFER_COMMIT_CONFIRMED' if ok else 'RESUME_COMMIT_GATE_FAIL'}
        return {**base,'ok':False,'mode':'UNKNOWN','allows_producer':False,'reason':'RESUME_COMMIT_GATE_FAIL'}

    def _v112_resume_disposition_gate(self, read, item, logical_item_id):
        """Map the current authoritative reread to exactly STORE/DROP/DEFER.

        This gate ignores stale pre-resume decisions. It rebuilds disposition
        from the CURRENT read envelope and current filter/config generation.
        """
        read=read if isinstance(read,dict) else {}
        ff=read.get('fast_filter') if isinstance(read.get('fast_filter'),dict) else {}
        filter_result=str(read.get('filter_result') or ff.get('filter_result') or 'UNRESOLVED').upper()
        reject_authority=str(read.get('reject_authority') or ff.get('reject_authority') or 'UNRESOLVED').upper()
        matched=read.get('matched_profile_id')
        if matched is None:
            matched=ff.get('matched_profile_id')
        ui_hash=read.get('ui_filter_hash')
        backend_hash=read.get('backend_filter_hash')
        if ui_hash and backend_hash and ui_hash!=backend_hash:
            return {'ok':False,'reason':'FILTER_CONFIG_GENERATION_MISMATCH','filter_result':filter_result,'disposition':None}
        if filter_result=='MATCH':
            profile_match=matched is not None or any(str((x or {}).get('state') or '').upper()=='MATCHED_N_OF_N' for x in (ff.get('profile_results') or []))
            if not profile_match:
                return {'ok':False,'reason':'RESUME_MATCH_WITHOUT_MATCHED_PROFILE','filter_result':filter_result,'disposition':None}
            return {'ok':True,'decision':'KEEP','recovery_result':'MATCH','disposition':'KEEP','deferred':False,'matched_profile_id':matched}
        if filter_result in ('REJECT','AUTHORITATIVE_REJECT'):
            if reject_authority!='AUTHORITATIVE_REJECT' or matched is not None:
                return {'ok':False,'reason':'RESUME_REJECT_NOT_AUTHORITATIVE','filter_result':filter_result,'disposition':None,'reject_authority':reject_authority}
            return {'ok':True,'decision':'FAIL','recovery_result':'AUTHORITATIVE_REJECT','disposition':'DROP','deferred':False,'matched_profile_id':None,'reject_authority':reject_authority}
        if filter_result=='UNRESOLVED':
            return {'ok':True,'decision':'UNCERTAIN','recovery_result':'UNRESOLVED','disposition':None,'deferred':True,'matched_profile_id':matched,'reject_authority':reject_authority}
        return {'ok':False,'reason':'RESUME_DISPOSITION_INVARIANT_VIOLATION','filter_result':filter_result,'disposition':None}

    def _v120_resume_step_log(self, event_id, step, payload=None):
        rec={'ts_epoch':time.time(),'event_id':str(event_id or ''),'step':str(step or '')}
        if isinstance(payload,dict): rec.update(payload)
        try:
            with self._v120_resume_step_log_path.open('a',encoding='utf-8') as f:
                f.write(json.dumps(rec,ensure_ascii=False,default=str)+'\n')
        except Exception:
            pass
        return rec

    def _v120_resume_open_source_inventory(self, hwnd, event_id, logical_item_id):
        """Bounded recovery-specific source-grid acquisition.

        V11.6 used one fixed-delay post-hotkey capture. The 121410 corpus proves
        three timer firings reached recovery but each stopped at
        SOURCE_GRID_NOT_FOUND_AFTER_HOTKEY. V12 first polls with no input, then
        performs at most one selected-hotkey reopen + bounded multi-frame grid
        consensus. It never rearms another timer when no fresh scan was obtained.
        """
        hwnd=int(hwnd); lid=str(logical_item_id or '')
        self._v120_resume_step_log(event_id,'RESUME_INVENTORY_SCAN_BEGIN',{'logical_item_id':lid})
        # 1) Non-destructive poll first: delayed animation/focus must not cause a
        # second blind toggle.
        probe=self._poll_source_grid_expected_layout(hwnd,0.85)
        if probe.get('ok'):
            ready=probe.get('ready') or {}
            self._inventory_grid=ready.get('grid') or self._inventory_grid
            self._v120_resume_step_log(event_id,'RESUME_INVENTORY_SCAN',{'logical_item_id':lid,'result':'VISIBLE_NO_INPUT','polls':probe.get('polls')})
            return {'ok':True,'image':ready.get('image'),'grid':ready.get('grid'),'opened':False,'capture_mode':'V120_RESUME_POLL_VISIBLE','resume_inventory_path':'POLL_NO_INPUT'}

        # 2) Canonical opener may send exactly one configured F4/Q. It also
        # activates the game before capture.
        ready=self._capture_inventory_ready(hwnd,try_open=True)
        if ready.get('ok'):
            self._v120_resume_step_log(event_id,'RESUME_INVENTORY_SCAN',{'logical_item_id':lid,'result':'CAPTURE_READY','opened':bool(ready.get('opened')),'capture_mode':ready.get('capture_mode')})
            return ready

        first_reason=str(ready.get('reason') or 'INVENTORY_NOT_READY')
        # 3) The historical failure happens here. Before any further key input,
        # wait for the already-sent hotkey to finish opening the source panel.
        if first_reason=='SOURCE_GRID_NOT_FOUND_AFTER_HOTKEY':
            late=self._poll_source_grid_expected_layout(hwnd,1.35)
            if late.get('ok'):
                rr=late.get('ready') or {}; self._inventory_grid=rr.get('grid') or self._inventory_grid
                self._v120_resume_step_log(event_id,'RESUME_INVENTORY_SCAN',{'logical_item_id':lid,'result':'LATE_AFTER_HOTKEY','polls':late.get('polls')})
                return {'ok':True,'image':rr.get('image'),'grid':rr.get('grid'),'opened':True,'capture_mode':'V120_RESUME_LATE_GRID_CONSENSUS','resume_inventory_path':'LATE_AFTER_HOTKEY'}

            # 4) One bounded corrective selected-hotkey press. If the first press
            # closed an open panel because detection missed it, this reopens it;
            # if it never opened, this is the single bounded retry. No loop.
            key=str(self.get_inventory_hotkey() or '')
            if key in ('F4','Q') and not self._chest_is_stop_requested():
                ir=self.send_inventory_hotkey_once(hwnd,key,self._cfg.get('input_mode','Auto'),'RESUME_INVENTORY_REOPEN')
                self._v120_resume_step_log(event_id,'RESUME_INVENTORY_REOPEN_INPUT',{'logical_item_id':lid,'hotkey':key,'input_ok':bool(ir.get('ok'))})
                if ir.get('ok'):
                    late2=self._poll_source_grid_expected_layout(hwnd,1.45)
                    if late2.get('ok'):
                        rr=late2.get('ready') or {}; self._inventory_grid=rr.get('grid') or self._inventory_grid
                        self._v120_resume_step_log(event_id,'RESUME_INVENTORY_SCAN',{'logical_item_id':lid,'result':'BOUNDED_REOPEN_PASS','polls':late2.get('polls')})
                        return {'ok':True,'image':rr.get('image'),'grid':rr.get('grid'),'opened':True,'capture_mode':'V120_RESUME_BOUNDED_REOPEN','resume_inventory_path':'BOUNDED_REOPEN'}
                    ready={'ok':False,'reason':'RESUME_SOURCE_GRID_REOPEN_FAILED','first_reason':first_reason,'late_probe':late,'reopen_probe':late2,'input':ir}

        self._v120_resume_step_log(event_id,'RESUME_CALLBACK_NO_REREAD',{'logical_item_id':lid,'reason':ready.get('reason') or first_reason})
        return {'ok':False,'reason':'RESUME_CALLBACK_NO_REREAD','detail':ready.get('reason') or first_reason,'inventory':ready,'hard_failure':True,'no_input_sent':False}

    def _v120_resume_resolve_pending_item_core(self, hwnd, logical_item_id=None):
        """Single V12.1 owner-bound recovery entry point."""
        return self._v109_recover_pending_filter_item(int(hwnd), preferred_logical_item_id=logical_item_id)

    def _v109_recover_pending_filter_item(self, hwnd, preferred_logical_item_id=None):
        """Resolve FILTER_RECHECK_PENDING before another chest is opened.

        Called only after the canonical-delay claim is revalidated. It reopens/verifies the
        source inventory, rescans, reidentifies the same item, performs one fresh
        Final6 read, then resolves exactly one KEEP or DROP only from an
        authoritative MATCH/REJECT. Still-unresolved evidence is deferred safely.
        """
        hwnd=int(hwnd); lid,e=self._v109_pending_filter_entry(preferred_logical_item_id)
        if not lid or not e:
            reason='RECOVERY_OWNER_ENTRY_NOT_FOUND' if preferred_logical_item_id else 'NO_FILTER_RECHECK_PENDING'
            return {'ok':False,'reason':reason,'requested_logical_item_id':preferred_logical_item_id,'no_input_sent':True,'recovery_hard_failure':bool(preferred_logical_item_id)}
        event_id=f"{int(time.time()*1000)}-{int(e.get('recovery_generation',0) or 0)+1}"
        self._v114_set_recovery_owner(lid,event_id,'RESUME_RECOVERY_ACTIVE',blocking=True)
        fired=time.time()
        sched=getattr(self,'_v109_resume_schedule_snapshot',None)
        sched=sched if isinstance(sched,dict) else {}
        scheduled_at=sched.get('scheduled_at_epoch')
        due_at=sched.get('due_at_epoch')
        trace={
            'trigger_reason':'FILTER_RECHECK_PENDING','pending_item_id':lid,'logical_item_id':lid,'queue_id':e.get('queue_id'),'queue_slot':e.get('queue_id'),
            'scheduled_at':scheduled_at,'due_at':due_at,'fired_at':fired,
            'elapsed_ms':(round((fired-float(scheduled_at))*1000,3) if scheduled_at is not None else None),
            'user_stop_generation':int(self._auto_resume.status().get('resume_generation',0) or 0),
            'inventory_visible':False,'inventory_reopened':False,'item_reidentified':False,
            'old_anchor':e.get('current_anchor'),'new_anchor':None,'old_filter_result':e.get('filter_result'),
            'reread_result':'UNRESOLVED','new_filter_result':'UNRESOLVED','reject_authority':'UNRESOLVED','matched_profile_id':None,
            'disposition':None,'action_tx_id':None,'action_confirmed':False,'pending_finalized':False,
            'physical_drop_confirmed':False,'item_absent_confirmed':False,'cursor_empty_confirmed':False,
            'pending_state':e.get('pending_state'),'deferred':False,'ledger_retained':True,
            'ready_next':False,'next_chest_started':False,'action_dispatched':False,
            'unresolved_reason_old':e.get('unresolved_reason'),'unresolved_reason_new':None,
            'filter_config_generation':int(getattr(self,'_filter_config_generation',0) or 0),'six_row_decisions':[],
            'final6_raw_path':None,'final6_foreground_path':None,'row_evidence_paths':[],'ocr_input_hash':None,
            'requested_logical_item_id':str(preferred_logical_item_id or lid),
            'recovery_owner_binding':dict(getattr(self,'_v121_active_resume_owner_binding',None) or {}),
            'recovery_owner_snapshot':dict(getattr(self,'_v114_recovery_owner',None) or {}),
        }
        if self._chest_is_stop_requested():
            trace['revalidation_result']='USER_STOP'; self._v109_write_resume_trace(event_id,trace)
            return {'ok':False,'reason':'AUTO_RESUME_ABORTED_USER_PRIORITY','no_input_sent':True,'resume_event_id':event_id}
        ready=self._v120_resume_open_source_inventory(hwnd,event_id,lid)
        trace['inventory_visible']=bool(ready.get('ok')); trace['inventory_reopened']=bool(ready.get('opened'))
        trace['resume_inventory_path']=ready.get('resume_inventory_path') or ready.get('capture_mode')
        if not ready.get('ok'):
            trace['revalidation_result']='RESUME_CALLBACK_NO_REREAD'
            trace['resume_hard_failure_reason']=ready.get('detail') or ready.get('reason')
            trace['ledger_retained']=bool(lid in self._item_recovery_ledger)
            self._v109_write_resume_trace(event_id,trace)
            # Keep the item tracked and block new chest work. Critically, this is
            # NOT FILTER_RECHECK_PENDING scheduling authority: the timer fired but
            # no fresh read occurred, so blind timer re-arm is forbidden.
            self._v114_set_recovery_owner(lid,event_id,'RESUME_CALLBACK_NO_REREAD',blocking=True)
            return {'ok':False,'reason':'RESUME_CALLBACK_NO_REREAD','recovery_pending':False,'recovery_hard_failure':True,
                    'detail':ready.get('detail') or ready.get('reason'),'no_input_sent':bool(ready.get('no_input_sent')),
                    'resume_event_id':event_id,'ledger_retained':trace['ledger_retained']}
        self._inventory_grid=ready.get('grid')
        snap=snapshot_inventory(ready.get('image'),self._inventory_grid)
        if not snap.get('ok'):
            trace['revalidation_result']='RESUME_CALLBACK_NO_REREAD'; trace['resume_hard_failure_reason']='INVENTORY_SNAPSHOT_FAILED'
            self._v120_resume_step_log(event_id,'RESUME_CALLBACK_NO_REREAD',{'logical_item_id':lid,'reason':'INVENTORY_SNAPSHOT_FAILED'})
            self._v109_write_resume_trace(event_id,trace)
            self._v114_set_recovery_owner(lid,event_id,'RESUME_CALLBACK_NO_REREAD',blocking=True)
            return {'ok':False,'reason':'RESUME_CALLBACK_NO_REREAD','recovery_pending':False,'recovery_hard_failure':True,
                    'detail':'INVENTORY_SNAPSHOT_FAILED','no_input_sent':True,'resume_event_id':event_id,'ledger_retained':bool(lid in self._item_recovery_ledger)}
        self._inventory_last=snap
        self._v120_resume_step_log(event_id,'RESUME_INVENTORY_SCAN',{'logical_item_id':lid,'result':'SNAPSHOT_OK','occupied_count':snap.get('occupied_count')})
        rid=self._v109_reidentify_pending_filter_item(snap,e)
        trace['item_identity_state']=rid.get('identity_state')
        trace['item_identity_score']=rid.get('score')
        if not rid.get('ok') or rid.get('identity_state') not in ('SAME_ITEM_CONFIRMED','SAME_ITEM_MOVED'):
            detail=rid.get('reason') or 'ITEM_IDENTITY_UNKNOWN'
            trace['revalidation_result']='RESUME_CALLBACK_NO_REREAD'; trace['resume_hard_failure_reason']=detail
            self._v120_resume_step_log(event_id,'RESUME_CALLBACK_NO_REREAD',{'logical_item_id':lid,'reason':detail,'identity_state':rid.get('identity_state')})
            self._v109_write_resume_trace(event_id,trace)
            self._v114_set_recovery_owner(lid,event_id,'RESUME_CALLBACK_NO_REREAD',blocking=True)
            return {'ok':False,'reason':'RESUME_CALLBACK_NO_REREAD','recovery_pending':False,'recovery_hard_failure':True,
                    'detail':detail,'reidentify':rid,'no_input_sent':True,'resume_event_id':event_id,'ledger_retained':bool(lid in self._item_recovery_ledger)}
        item=rid['item']; trace['item_reidentified']=True; trace['new_anchor']=rid.get('new_anchor')
        self._v120_resume_step_log(event_id,'RESUME_ITEM_REIDENTIFIED',{'logical_item_id':lid,'identity_state':rid.get('identity_state'),'old_anchor':rid.get('old_anchor'),'new_anchor':rid.get('new_anchor')})
        trace['same_physical_item_confirmed']=True
        e=dict(e)
        e['current_anchor']=list(item.get('anchor') or e.get('current_anchor') or [0,0])
        e['item_snapshot']=dict(item)
        e['last_reidentify_state']=rid.get('identity_state')
        e['last_reidentify_score']=rid.get('score')
        self._item_recovery_ledger[lid]=e
        proof_before=self._v113_save_resume_drop_image(event_id,'01_pending_item_before_resume',ready.get('image'),logical_item_id=lid)
        proof_reid=self._v113_save_resume_drop_image(event_id,'02_item_reidentified',ready.get('image'),logical_item_id=lid)
        trace['pending_item_before_resume_proof']=proof_before
        trace['item_reidentified_proof']=proof_reid
        self._new_item_queue=[item]; self._queue_read_results=[]
        self._batch_filter_cache=_load_option_filter()
        rr=self._recovery_filter_reread_once(hwnd,item,None,fresh_event=True)
        read=(rr.get('reader') or {}) if isinstance(rr,dict) else {}
        self._v120_resume_step_log(event_id,'RESUME_TOOLTIP_CAPTURE',{'logical_item_id':lid,'reader_ok':bool(read.get('ok'))})
        ff=(read.get('fast_filter') or {}) if isinstance(read,dict) else {}
        disposition_gate=self._v112_resume_disposition_gate(read,item,lid)
        self._v120_resume_step_log(event_id,'RESUME_OPTION_READ',{'logical_item_id':lid,'reader_result':read.get('filter_result') or read.get('decision')})
        self._v120_resume_step_log(event_id,'RESUME_FILTER_RESULT',{'logical_item_id':lid,'recovery_result':disposition_gate.get('recovery_result'),'disposition':disposition_gate.get('disposition')})
        if not disposition_gate.get('ok'):
            trace['revalidation_result']=disposition_gate.get('reason','RESUME_DISPOSITION_INVARIANT_VIOLATION')
            trace['resume_disposition_gate']=disposition_gate
            self._v109_write_resume_trace(event_id,trace)
            return {'ok':False,'reason':trace['revalidation_result'],'resume_event_id':event_id,'no_input_sent':True}
        decision=disposition_gate.get('decision')
        trace['resume_disposition_gate']=disposition_gate
        # Persist the fresh result before crossing into the action dispatcher.
        le_now=dict(self._item_recovery_ledger.get(lid) or e or {})
        le_now['recovery_result']=disposition_gate.get('recovery_result')
        le_now['intended_disposition']=disposition_gate.get('disposition')
        le_now['disposition_generation']=int(le_now.get('recovery_generation',0) or 0)+1
        le_now['last_recovery_event_id']=event_id
        le_now['last_recovery_result_at']=time.time()
        self._item_recovery_ledger[lid]=le_now
        if disposition_gate.get('disposition')=='DROP':
            self._v114_set_recovery_owner(lid,event_id,'RESUME_REJECT_DROP_COMMIT_PENDING',blocking=True)
        elif disposition_gate.get('disposition')=='KEEP':
            self._v114_set_recovery_owner(lid,event_id,'RESUME_MATCH_KEEP_COMMIT_PENDING',blocking=True)
        frames=(ff.get('frames') or []) if isinstance(ff.get('frames'),list) else []
        fr0=frames[0] if frames and isinstance(frames[0],dict) else {}
        proof=fr0.get('foreground_proof_paths') if isinstance(fr0.get('foreground_proof_paths'),dict) else {}
        trace['final6_raw_path']=proof.get('final6_raw') or fr0.get('final6_raw_path')
        trace['final6_foreground_path']=proof.get('final6_foreground_zoom4x') or proof.get('final6_foreground') or fr0.get('final6_zoom4x_path')
        trace['final6_path']=trace.get('final6_foreground_path') or trace.get('final6_raw_path')
        trace['row_evidence_paths']=[
            (x.get('foreground_path') or x.get('row_foreground_path') or x.get('clean_path'))
            for x in (fr0.get('row_foreground_provenance') or []) if isinstance(x,dict)
            if (x.get('foreground_path') or x.get('row_foreground_path') or x.get('clean_path'))
        ]
        trace['ocr_input_hash']=fr0.get('actual_name_ocr_input_sha256') or fr0.get('foreground_zoom4x_sha256')
        trace['new_filter_result']=disposition_gate.get('recovery_result')
        trace['reject_authority']=str(read.get('reject_authority') or ff.get('reject_authority') or 'UNRESOLVED').upper()
        trace['matched_profile_id']=read.get('matched_profile_id') if read.get('matched_profile_id') is not None else ff.get('matched_profile_id')
        trace['unresolved_reason_new']=read.get('unresolved_reason') or ff.get('unresolved_reason')
        for row in (fr0.get('row_evidence') or []):
            if isinstance(row,dict):
                trace['six_row_decisions'].append({
                    'physical_row_index':row.get('physical_row_index'),
                    'canonical_option':row.get('canonical_option_name'),
                    'family':row.get('family'),'value':row.get('canonical_value'),
                    'identity_authoritative':row.get('identity_authoritative'),
                    'numeric_authoritative':row.get('numeric_authoritative'),
                })
        if disposition_gate.get('deferred'):
            item['decision']='UNCERTAIN'; item['status']='FILTER_RECHECK_DEFERRED'; item['reason']='FILTER_RECHECK_DEFERRED'
            le=self._ledger_upsert(item,'UNRESOLVED',None,'FILTER_RECHECK_DEFERRED',None,authoritative=False)
            le['next_recheck_due_epoch']=time.time()+V109_PENDING_RECHECK_INTERVAL_SEC; self._item_recovery_ledger[lid]=le
            capacity_safe=bool(self._pending_capacity_safe(snap))
            defer_safety=self._auto_resume_safety_snapshot(hwnd,runtime_running=False)
            trace['revalidation_result']='PASS'; trace['reread_result']='UNRESOLVED'; trace['new_filter_result']='UNRESOLVED'
            trace['disposition']=None; trace['action_tx_id']=None; trace['action_confirmed']=False
            trace['pending_finalized']=False; trace['pending_state']='FILTER_RECHECK_DEFERRED'
            trace['deferred']=True; trace['ledger_retained']=bool(lid in self._item_recovery_ledger)
            trace['capacity_safe']=capacity_safe; trace['defer_safety']=defer_safety
            commit_gate=self._v114_resume_disposition_commit_gate(trace,lid)
            trace['resume_commit_gate']=commit_gate
            owner_release_gate=self._v121_recovery_owner_release_gate(
                lid,mode='FILTER_RECHECK_DEFERRED',capacity_safe=capacity_safe,safety=defer_safety
            )
            trace['recovery_owner_release_gate']=owner_release_gate
            trace['ready_next']=bool(commit_gate.get('ok') and commit_gate.get('allows_producer') and owner_release_gate.get('ok'))
            if trace['ready_next']:
                self._v114_release_recovery_owner(lid,deferred=True,reason='FILTER_RECHECK_DEFERRED')
            self._new_item_queue=[]; self._queue_read_results=[]
            trace_path=self._v109_write_resume_trace(event_id,trace)
            return {'ok':bool(trace['ready_next']),'reason':('FILTER_RECHECK_DEFERRED' if commit_gate.get('ok') else 'RESUME_COMMIT_GATE_FAIL'),'filter_recheck_deferred':True,
                    'pending_item_id':lid,'pending_state':'FILTER_RECHECK_DEFERRED','deferred':True,'ledger_retained':trace['ledger_retained'],
                    'reader':read,'next_cycle_ready':bool(trace['ready_next']),'capacity_safe':capacity_safe,
                    'resume_commit_gate':commit_gate,'resume_event_id':event_id,'resume_trace_path':trace_path,'no_destructive_action_started':True}
        envelope=self._v107_decision_envelope(int(getattr(self,'_chest_cycle_seq',0) or 0),item,read)
        ar={}
        if disposition_gate.get('disposition')=='KEEP':
            # Fresh authoritative MATCH: preserve the same item in Player Inventory.
            trace['reread_result']='MATCH'; trace['new_filter_result']='MATCH'; trace['disposition']='KEEP'; trace['deferred']=False
            trace['action_dispatched']=False; trace['action_tx_id']=None
            final=self._auto_chest_keep_finalize(hwnd,item,cycle_id=int(getattr(self,'_chest_cycle_seq',0) or 0))
            trace['action_confirmed']=bool(final.get('action_confirmed'))
            trace['physical_item_click_count']=0
            trace['storage_call_count']=0
        elif disposition_gate.get('disposition')=='DROP':
            auth=self._v107_drop_authorization_gate(envelope)
            if not auth.get('ok'):
                trace['revalidation_result']=auth.get('reason'); self._v109_write_resume_trace(event_id,trace)
                return {'ok':False,'reason':'RESUME_DEFINITIVE_DROP_AUTHORIZATION_FAILED','detail':auth.get('reason'),'no_input_sent':True,'resume_event_id':event_id,'recovery_hard_failure':True,'recovery_pending':False}
            trace['reread_result']='AUTHORITATIVE_REJECT'; trace['new_filter_result']='AUTHORITATIVE_REJECT'; trace['disposition']='DROP'; trace['deferred']=False
            gate=self._chest_begin_atomic_action('DROP')
            if not gate.get('started'):
                trace['revalidation_result']=gate.get('reason'); self._v109_write_resume_trace(event_id,trace)
                return {'ok':False,'reason':gate.get('reason','DROP_ACTION_GATE_FAILED'),'resume_event_id':event_id}
            trace['action_dispatched']=True
            trace['pre_drop_anchor']=list(item.get('anchor') or [0,0])
            trace['source_item_visual_hash']=e.get('source_item_visual_hash')
            trace['before_source_click_proof']=self._v113_save_resume_drop_image(event_id,'03_before_source_click',capture_client(hwnd),logical_item_id=lid)
            expected_source_click=_candidate_click_point(item,self._inventory_grid)
            trace['expected_source_click_client']=list(expected_source_click) if expected_source_click else None
            trace['source_grid_generation']=int(getattr(self,'_verified_grid_lease_generation',0) or 0)
            if not expected_source_click:
                trace['revalidation_result']='RESUME_CURRENT_SOURCE_POINT_UNAVAILABLE'; self._v109_write_resume_trace(event_id,trace)
                self._chest_end_atomic_action()
                return {'ok':False,'reason':'RESUME_CURRENT_SOURCE_POINT_UNAVAILABLE','resume_event_id':event_id,'no_input_sent':True}
            resume_ctx={
                'active':True,'logical_item_id':lid,'resume_event_id':event_id,
                'originating_cycle_id':e.get('originating_cycle_id'),
                'pre_drop_anchor':list(item.get('anchor') or [0,0]),
            }
            self._v113_resume_drop_context=resume_ctx
            try:
                ar=self.chest_drop_queue_item(hwnd,0)
            finally:
                self._v113_resume_drop_context=None
                self._chest_end_atomic_action()
            trace['after_ground_click_proof']=self._v113_save_resume_drop_image(event_id,'04_after_ground_click',capture_client(hwnd),logical_item_id=lid)
            trace['action_tx_id']=ar.get('drop_tx_id')
            actual_source_click=((ar.get('action') or {}).get('source_client') if isinstance(ar,dict) else None)
            trace['actual_source_click_client']=actual_source_click
            trace['source_click_current_grid_match']=bool(actual_source_click and list(actual_source_click)==list(expected_source_click))
            low_level_confirmed=bool(ar.get('ok') and ar.get('dropped') and (ar.get('confirm') or {}).get('ok') and trace['source_click_current_grid_match'])
            trace['low_level_source_cursor_confirmed']=low_level_confirmed
            if not low_level_confirmed:
                self._ledger_upsert(item,'REJECT','DROP','REJECT_PENDING_DROP',ar.get('drop_tx_id'),authoritative=True)
                trace['action_confirmed']=False
                trace['revalidation_result']=ar.get('reason','DROP_NOT_CONFIRMED'); self._v109_write_resume_trace(event_id,trace)
                return {'ok':False,'reason':ar.get('reason','DROP_NOT_CONFIRMED'),'drop_result':ar,'resume_event_id':event_id}

            physical=self._v113_post_drop_whole_bag_reconcile(hwnd,e,item,event_id,ar)
            trace['physical_drop_state']=physical.get('state')
            trace['post_inventory_scan_id']=physical.get('post_inventory_scan_id')
            trace['post_drop_candidate_count']=int(physical.get('post_drop_candidate_count',0) or 0)
            trace['post_drop_candidates']=list(physical.get('post_drop_candidates') or [])
            trace['absence_reason']=physical.get('absence_reason')
            trace['bag_scan_valid']=bool(physical.get('scan_valid'))
            trace['item_gone_fresh_frame_count']=int(physical.get('item_gone_fresh_frame_count',0) or 0)
            trace['item_absent_confirmed']=bool(physical.get('item_absent_confirmed'))
            trace['cursor_empty_confirmed']=bool(physical.get('cursor_empty_confirmed'))
            trace['physical_drop_confirmed']=bool(physical.get('ok') and physical.get('physical_truth')=='PHYSICAL_DROP_CONFIRMED')
            trace['post_inventory_proof_path']=physical.get('proof_path')
            if not trace['physical_drop_confirmed']:
                self._v114_set_recovery_owner(lid,event_id,'REJECT_PENDING_DROP',blocking=True)
                # Low-level source clear is not terminal truth for resumed items.
                # Keep the same logical item pending; if it moved, update its anchor.
                if physical.get('current_anchor'):
                    item['anchor']=list(physical.get('current_anchor'))
                    item['current_anchor']=list(physical.get('current_anchor'))
                item['status']='REJECT_PENDING_DROP'; item['reason']=physical.get('state') or 'DROP_CONFIRM_UNRESOLVED'
                le=self._ledger_upsert(item,'REJECT','DROP','REJECT_PENDING_DROP',ar.get('drop_tx_id'),authoritative=True)
                le['physical_drop_state']=physical.get('state'); self._item_recovery_ledger[lid]=le
                trace['action_confirmed']=False; trace['pending_finalized']=False; trace['ready_next']=False; trace['next_chest_started']=False
                trace['revalidation_result']=physical.get('state') or 'DROP_CONFIRM_UNRESOLVED'
                self._v109_write_resume_trace(event_id,trace)
                return {
                    'ok':False,'reason':trace['revalidation_result'],'drop_result':ar,'physical_drop':physical,
                    'resume_event_id':event_id,'logical_item_id':lid,'pending_state':'REJECT_PENDING_DROP',
                    'no_terminal_artifact':True,'next_cycle_ready':False,
                }

            item['status']='DROPPED'
            item['action']='DROP'
            item['action_status']='CONFIRMED'
            item['reason']='PHYSICAL_DROP_CONFIRMED'
            ar['requires_physical_drop_truth']=True
            ar['resume_pending_drop']=True
            ar['physical_drop_confirmed']=True
            ar['item_absent_confirmed']=True
            ar['cursor_empty_confirmed']=True
            ar['physical_truth']='PHYSICAL_DROP_CONFIRMED'
            ar['post_inventory_scan_id']=physical.get('post_inventory_scan_id')
            ar['logical_item_id']=lid
            ar['resume_event_id']=event_id
            ar['originating_cycle_id']=e.get('originating_cycle_id')
            ar['terminal_path']=self._v113_write_physical_drop_terminal(ar,physical,item,e,event_id)
            trace['terminal_path']=ar.get('terminal_path')
            trace['action_confirmed']=bool(ar.get('terminal_path'))
            if not trace['action_confirmed']:
                trace['revalidation_result']='PHYSICAL_DROP_TERMINAL_WRITE_FAILED'; self._v109_write_resume_trace(event_id,trace)
                return {'ok':False,'reason':'PHYSICAL_DROP_TERMINAL_WRITE_FAILED','drop_result':ar,'physical_drop':physical,'resume_event_id':event_id}
            final=self._finalize_chest_cycle(hwnd,'DROP',ar,public_queue_item(item))
        else:
            trace['revalidation_result']='RESUME_DISPOSITION_INVARIANT_VIOLATION'
            self._v109_write_resume_trace(event_id,trace)
            return {'ok':False,'reason':'RESUME_DISPOSITION_INVARIANT_VIOLATION','resume_event_id':event_id,'no_input_sent':True}
        trace['action_confirmed']=bool(final.get('action_confirmed'))
        trace['capacity_safe']=bool(final.get('next_cycle_ready'))
        if final.get('cycle_complete') and trace['action_confirmed']:
            self._ledger_upsert(item,'MATCH' if decision=='KEEP' else 'REJECT','KEEP' if decision=='KEEP' else 'DROP','FINALIZED',trace.get('action_tx_id'),authoritative=True)
            trace['pending_finalized']=True
            trace['pending_state']='FINALIZED'
            trace['ledger_retained']=False
            if decision!='KEEP' and isinstance(ar,dict) and ar.get('physical_drop_confirmed'):
                try:
                    stage_payload={
                        'cycle_id':int(getattr(self,'_chest_cycle_seq',0) or 0),
                        'originating_cycle_id':e.get('originating_cycle_id'),
                        'resume_event_id':event_id,'logical_item_id':lid,
                        'physical_truth':'PHYSICAL_DROP_CONFIRMED',
                        'item_absent_confirmed':True,'cursor_empty_confirmed':True,
                        **dict(final),
                    }
                    stamp=time.strftime('%Y%m%d_%H%M%S')
                    stage_path=LOGDIR/f'{stamp}_stage22_cycle.json'
                    stage_path.write_text(json.dumps(stage_payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
                    trace['stage22_terminal_path']=str(stage_path)
                except Exception as stage_exc:
                    trace['stage22_terminal_write_error']=str(stage_exc)
        else:
            trace['pending_finalized']=False
        # V11.4 commit barrier: result truth is not disposition commit truth.
        commit_gate=self._v114_resume_disposition_commit_gate(trace,lid)
        trace['resume_commit_gate']=commit_gate
        terminal_mode='KEEP_FINALIZED' if decision=='KEEP' else 'DROP_CONFIRMED'
        owner_release_gate=self._v121_recovery_owner_release_gate(lid,mode=terminal_mode,capacity_safe=bool(trace.get('capacity_safe')),safety={})
        trace['recovery_owner_release_gate']=owner_release_gate
        trace['ready_next']=bool(commit_gate.get('ok') and commit_gate.get('allows_producer') and owner_release_gate.get('ok'))
        trace['revalidation_result']='PASS' if trace['ready_next'] else 'RESUME_COMMIT_GATE_FAIL'
        if trace['ready_next']:
            self._v114_release_recovery_owner(lid,terminal=True,reason=commit_gate.get('reason'))
        trace_path=self._v109_write_resume_trace(event_id,trace)
        return {**final,
                'ok':bool(trace.get('ready_next')),'reason':('FILTER_RECOVERY_RESOLVED' if trace.get('ready_next') else 'RESUME_COMMIT_GATE_FAIL'),
                'filter_recovery_resolved':bool(trace.get('ready_next')),'pending_finalized':bool(trace.get('pending_finalized')),
                'resume_commit_gate':commit_gate,
                'decision':decision,'reader':read,'action_result':ar,'resume_event_id':event_id,'resume_trace_path':trace_path}

    def _safe_pause_v2(self, requested_reason, destructive_input_started=False, source_state=None, cursor_state=None, destination_state=None):
        """Central chest Safe-Pause authorization.

        A Drop can enter terminal Safe Pause only after destructive input AND when
        the full source/cursor reconciliation matrix remains UNKNOWN after bounded
        recovery. A single known axis is not enough to claim a recoverable state.
        """
        reason=str(requested_reason or 'UNKNOWN').upper()
        source=str(source_state or '').upper(); cursor=str(cursor_state or '').upper(); destination=str(destination_state or '').upper()
        self._usage_timer_transition('RECOVERY')
        if not destructive_input_started:
            return {'safe_pause':False,'allowed':False,'reason':'PRE_ACTION_RUNTIME_RECOVERABLE','requested_reason':reason}
        if cursor=='CURSOR_HOLDING_ITEM_CONFIRMED':
            return {'safe_pause':False,'allowed':False,'reason':'DROP_PARTIAL_COMMIT_CURSOR_HOLDING','requested_reason':reason}
        store_reason=reason.startswith('STORE_')
        if store_reason:
            source_unknown=source in ('','SOURCE_AMBIGUOUS','SOURCE_UNKNOWN')
            cursor_unknown=cursor in ('','CURSOR_AMBIGUOUS','CURSOR_UNCERTAIN','CURSOR_UNKNOWN')
            dest_unknown=destination in ('','DESTINATION_AMBIGUOUS','DESTINATION_UNKNOWN')
            if not (source_unknown and cursor_unknown and dest_unknown):
                try:
                    _auto_resume_log('SAFE_PAUSE_REQUEST_REJECTED',{'requested_reason':reason,'source_state':source,'cursor_state':cursor,'destination_state':destination,'denial':'KNOWN_STORE_STATE'})
                except Exception:
                    pass
                return {'safe_pause':False,'allowed':False,'reason':'PRE_SAFE_PAUSE_RECOVERY','requested_reason':reason,'known_store_state':True}
        drop_reason=(reason.startswith('DROP_') or reason in {'DESTRUCTIVE_TRANSACTION_TRUE_UNKNOWN','SOURCE_AND_CURSOR_BOTH_UNRESOLVED_AFTER_ACTION','CURSOR_TRUE_UNKNOWN_AFTER_BOUNDED_REPROBE'})
        if drop_reason:
            # V1.7.12: reject Safe Pause only when the source/cursor matrix itself
            # proves an actionable known state.  A single known axis is NOT enough:
            # SOURCE_AMBIGUOUS + CURSOR_EMPTY_CONFIRMED still leaves the item either
            # in the bag or already dropped and therefore is genuine transaction
            # uncertainty after bounded observation.
            matrix=_drop_reconcile_source_cursor(source,cursor)
            if str(matrix.get('reconciliation') or 'UNKNOWN').upper() in {'COMMITTED','NOT_COMMITTED','PARTIAL'}:
                try:
                    _auto_resume_log('SAFE_PAUSE_REQUEST_REJECTED',{'requested_reason':reason,'source_state':source,'cursor_state':cursor,'denial':'KNOWN_DROP_STATE','reconciliation_state':matrix.get('reconciliation')})
                except Exception:
                    pass
                return {'safe_pause':False,'allowed':False,'reason':'DROP_KNOWN_STATE_RECOVERY_REQUIRED','requested_reason':reason,'known_drop_state':True,'reconciliation_state':matrix.get('reconciliation')}
        allowed=_safe_pause_v2_allowed(reason)
        if not allowed:
            try:
                _auto_resume_log('SAFE_PAUSE_REQUEST_REJECTED',{'requested_reason':reason,'source_state':source,'cursor_state':cursor})
            except Exception:
                pass
        return {'safe_pause':bool(allowed),'allowed':bool(allowed),'reason':reason if allowed else 'PRE_SAFE_PAUSE_RECOVERY','requested_reason':reason}

    def _drop_settle_reconcile_without_input(self, hwnd, item, before, before_image, ground_point,
                                             cursor_reference_image, cursor_probe_point,
                                             drop_tx_id, source_evidence, max_rounds=3):
        """V1.7.12: settle a transient post-Drop source ambiguity without any click.

        This recovery is intentionally observation-only.  It exists for the exact
        state seen in logs(20261014-142738): source evidence alternated between
        PRESENT/GONE while the cursor was authoritatively empty and world pixels
        were moving.  The old flow converted that temporary contradiction into
        PRE_SAFE_PAUSE_RECOVERY, then stopped because no scheduler owned that
        pseudo-state.

        Contract:
          * no source click, no ground click, no new Drop transaction;
          * keep the same drop_tx_id and the same logical item;
          * move the cursor only to neutral/header/source-hover probes;
          * COMMITTED -> finalize existing Drop;
          * NOT_COMMITTED -> existing same-item retry policy;
          * PARTIAL -> existing ground-only policy;
          * still UNKNOWN after bounded fresh observations -> true Safe Pause.
        """
        rounds=max(1,min(4,int(max_rounds or 3)))
        observations=[]
        last=None
        for idx in range(rounds):
            try:
                _park_cursor_on_inventory_header(int(hwnd),self._inventory_grid,.055)
            except Exception:
                pass
            # Give JX1 enough time to settle transient world/tooltip pixels.  This
            # is not an action retry and therefore does not consume Drop retry budget.
            time.sleep(0.14 + (0.06*idx))
            cur=self._drop_wait_confirm(
                hwnd,item,before,before_image=before_image,ground_point=ground_point,
                cursor_reference_image=cursor_reference_image,cursor_probe_point=cursor_probe_point,
                drop_tx_id=drop_tx_id,source_evidence=source_evidence,
                timeout_sec=min(.60,DROP_CONFIRM_TIMEOUT_SEC),poll_sec=min(.06,DROP_CONFIRM_POLL_SEC),
            )
            last=cur
            recon=str(cur.get('reconciliation_state') or 'UNKNOWN').upper()
            source=str(cur.get('source_state_after') or 'SOURCE_AMBIGUOUS').upper()
            cursor=str(cur.get('cursor_item_state') or 'CURSOR_AMBIGUOUS').upper()
            hover=None
            # A tooltip at the SAME source cell can prove NOT_COMMITTED. Absence
            # never proves a Drop, so this probe cannot manufacture COMMITTED.
            if recon=='UNKNOWN' and source=='SOURCE_AMBIGUOUS' and cursor=='CURSOR_EMPTY_CONFIRMED':
                try:
                    hover=self._source_hover_presence_probe(hwnd,item,samples=2)
                except Exception as e:
                    hover={'state':'SOURCE_HOVER_PROBE_ERROR','error':str(e)}
                if isinstance(hover,dict) and hover.get('state')=='SOURCE_PRESENT_CONFIRMED':
                    cur=dict(cur)
                    cur['source_state_after']='SOURCE_STILL_PRESENT'
                    cur['source_hover_probe_used']=True
                    cur['source_hover_probe_result']='SOURCE_PRESENT_CONFIRMED'
                    cur['source_state_decision_reason']='SOURCE_HOVER_TOOLTIP_PRESENT_SETTLE'
                    cur['reconciliation_state']='NOT_COMMITTED'
                    cur['reason']='DROP_NOT_COMMITTED_SOURCE_PRESENT_CURSOR_EMPTY'
                    cur['ok']=False
                    last=cur; recon='NOT_COMMITTED'; source='SOURCE_STILL_PRESENT'
            observations.append({
                'round':idx+1,'reconciliation_state':recon,'source_state_after':source,
                'cursor_state_after':cursor,'reason':cur.get('reason'),
                'world_occlusion_detected':bool(cur.get('world_occlusion_detected')),
                'source_hover_probe_result':None if not isinstance(hover,dict) else hover.get('state'),
            })
            if recon!='UNKNOWN':
                break
        return {
            'ok':bool(last is not None and str(last.get('reconciliation_state') or 'UNKNOWN').upper()!='UNKNOWN'),
            'confirm':last,'observations':observations,'rounds_used':len(observations),
            'drop_tx_id':drop_tx_id,'no_input_sent':True,
        }

    def _drop_preaction_recoverable_result(self, reason, drop_tx_id=None, **extra):
        """Classify a Drop failure before source/ground item input as recoverable.

        Pre-action sensor/UI failures cannot make item location transaction-unknown,
        because no destructive item action has started. Stage22 may defer the same
        authoritative REJECT item and return loop ownership to READY_NEXT.
        """
        self._usage_timer_transition('RECOVERY')
        out={
            'ok':False,'safe_pause':False,'recoverable_known_state':True,
            'pre_action_only':True,'destructive_input_started':False,
            'recovery_policy':'DROP_RECOVERY_RESCAN_ONCE',
            'reason':str(reason or 'PRE_ACTION_RUNTIME_RECOVERABLE'),
            'drop_tx_id':drop_tx_id,
        }
        out.update(extra)
        return out

    def _recovery_filter_reread_once(self, hwnd, item, prior_read=None, fresh_event=False):
        """One bounded Final6 reread.

        V10.8 attempted to call a non-existent ``read_new_item_queue_item`` alias,
        so the advertised reread could return READER_ENTRY_UNAVAILABLE. V10.9 calls
        the canonical live reader directly. A 15-second recovery is a new event and gets
        one fresh read budget after a fresh inventory scan/reidentification.
        """
        lid=_logical_item_id(item); e=dict(self._item_recovery_ledger.get(lid) or {})
        if fresh_event:
            e['filter_rescan_count']=0
            e['recovery_generation']=int(e.get('recovery_generation',0) or 0)+1
        if int(e.get('filter_rescan_count',0) or 0)>=RECOVERY_FILTER_REREAD_MAX:
            return {'ok':False,'reason':'RECOVERY_FILTER_REREAD_LIMIT','filter_rescan_count':int(e.get('filter_rescan_count',0) or 0),'recovery_generation':int(e.get('recovery_generation',0) or 0)}
        # Authoritative MATCH/REJECT survives action failure; reread only unresolved.
        if e.get('filter_authoritative') and e.get('filter_result') in ('MATCH','REJECT'):
            return {'ok':True,'reason':'AUTHORITATIVE_FILTER_PRESERVED','decision':e.get('filter_result'),'filter_rescan_count':int(e.get('filter_rescan_count',0) or 0),'recovery_generation':int(e.get('recovery_generation',0) or 0)}
        e['filter_rescan_count']=int(e.get('filter_rescan_count',0) or 0)+1
        e['reread_count']=int(e.get('reread_count',0) or 0)+1
        self._item_recovery_ledger[lid]=e
        rr=self._read_queue_item_internal(int(hwnd),0,batch_session=True,execution_mode='LIVE_CHEST_TEST')
        return {'ok':bool(rr.get('ok')),'reason':'RECOVERY_RESCAN_ONCE','reader':rr,'filter_rescan_count':e['filter_rescan_count'],'recovery_generation':int(e.get('recovery_generation',0) or 0)}

    def get_option_filter_setup(self):
        try:
            cfg=_load_option_filter()
            return {
                "ok": True,
                "options": _all_filter_options(cfg.get('scope_value','GLOBAL')),
                "options_by_scope": {k:v.get('options',[]) for k,v in profile_registry_payload().get('profiles',{}).items()},
                "profile_registry": profile_registry_payload(),
                "option_registry": registry_payload(),
                "registry_validation": validate_registry(),
                "config": cfg,
                "schema_version": FILTER_CONFIG_SCHEMA_VERSION,
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def save_option_filter(self, payload):
        try:
            payload=dict(payload or {})
            scope_value=str(payload.get('scope_value','GLOBAL'))
            if scope_value == 'GLOBAL':
                scope,group_id,family='GLOBAL',None,None
            elif scope_value == 'jewelry':
                scope,group_id,family='FAMILY',None,'DÂY CHUYỀN / NGỌC BỘI'
            elif scope_value == 'common':
                scope,group_id,family='PROFILE',None,'ĐỒ CHUNG'
            elif scope_value == 'vukhi':
                scope,group_id,family='GROUP','vukhi',None
            elif scope_value == 'ao':
                # V1.7.5 explicit Áo scope: Common-10 + Sinh lực tối đa.
                scope,group_id,family='GROUP','ao',None
            elif scope_value == 'baotay':
                # V1.7.5 explicit Bao tay scope: Common-10 + Tăng công kích kỹ năng.
                scope,group_id,family='GROUP','baotay',None
            elif scope_value == 'daychuyen':
                # V1.7.5 explicit Dây chuyền scope: Accessory-2 + Mức kháng tính tối đa.
                scope,group_id,family='GROUP','daychuyen',None
            elif scope_value == 'ngocboi':
                scope,group_id,family='GROUP','ngocboi',None
            elif scope_value in ('giay','non','dailung','dai','nhan'):
                # Legacy per-piece common scopes without a taught slot extension
                # still collapse safely to the Common Base-10 profile.
                scope_value='common'; scope,group_id,family='PROFILE',None,'ĐỒ CHUNG'
            else:
                scope,group_id,family='GLOBAL',None,None

            incoming={
                'schema_version':FILTER_CONFIG_SCHEMA_VERSION,
                'name':'Auto Pro By Eric - Multi Filter Profiles',
                'scope':scope,'scope_value':scope_value,'group_id':group_id,'family':family,
                'profiles':payload.get('profiles') if isinstance(payload.get('profiles'),list) else None,
            }
            if incoming['profiles'] is None:
                # Backward-compatible UI/API call: old single rules become Profile 1.
                incoming.pop('profiles',None)
                incoming['rules']=payload.get('rules') or []
            cfg=migrate_filter_config(incoming)
            profile_validation=_profile_rule_validation(cfg)
            if not profile_validation.get('ok'):
                return {
                    'ok':False,'error':'PROFILE_RULE_OUTSIDE_CLOSED_REGISTRY',
                    'profile_registry':profile_validation,'config':cfg,
                }
            _safe_save_json(USER_FILTER_PATH, cfg)
            snap=_v107_canonical_filter_snapshot(cfg); h=_v107_json_hash(snap)
            self._filter_config_generation=int(getattr(self,'_filter_config_generation',0) or 0)+1
            self._last_ui_filter_snapshot=snap; self._last_ui_filter_hash=h
            return {'ok':True,'config':cfg,'registry':registry_payload(),'profile_registry':profile_validation,
                    'ui_filter_snapshot':snap,'ui_filter_hash':h,'filter_config_generation':self._filter_config_generation,
                    'build_id':V107_BUILD_ID}
        except Exception as e:
            return {'ok':False,'error':str(e)}

    def set_selection(self, hwnd, group_id):
        try:
            h = int(hwnd) if hwnd else None
        except Exception:
            h = None

        if h and not window_exists(h):
            return {'ok': False, 'error': 'HWND không còn tồn tại.'}

        previous_hwnd = self._active_hwnd
        self._active_hwnd = h
        self._active_group = group_id or '__all__'
        if previous_hwnd not in (None, h):
            try:
                self._auto_resume.invalidate('SESSION_CHANGED')
            except Exception:
                pass
        self._hover_stable_hits = 0
        self._hover_last_rect = None

        if h:
            self._locked_client_hwnd = h
            self._cfg['locked_client'] = h
            _save_app_config(self._cfg)

        return {'ok': True, 'hwnd': h}

    def set_auto_hover(self, enabled):
        self._hover_enabled = bool(enabled)
        self._hover_stable_hits = 0
        self._hover_last_rect = None
        if not self._hover_enabled:
            self._hover_last_signature = None
        return {'ok': True, 'enabled': self._hover_enabled}

    def runtime_status(self):
        global TESSERACT
        if not TESSERACT:
            TESSERACT = configure_tesseract()
        langs = get_languages() if TESSERACT else []
        return {
            'tesseract_ready': bool(TESSERACT),
            'tesseract_path': TESSERACT or '',
            'languages': langs,
            'vie_ready': 'vie' in langs,
            'eng_ready': 'eng' in langs,
            'ocr_quality_warning': None if 'vie' in langs else "Thiếu language data 'vie'; đang dùng eng + dictionary fallback.",
        }

    def choose_tesseract(self):
        global TESSERACT
        try:
            win = webview.active_window()
            if win is None:
                return {'ok': False, 'error': 'Window chưa sẵn sàng.'}
            files = win.create_file_dialog(
                webview.OPEN_DIALOG,
                allow_multiple=False,
                file_types=('Tesseract executable (*.exe)',)
            )
            if not files:
                return {'ok': False, 'cancelled': True}
            p = Path(files[0])
            pytesseract.pytesseract.tesseract_cmd = str(p)
            _ = pytesseract.get_tesseract_version()
            TESSERACT = str(p)
            OCR_CONFIG_PATH.write_text(
                json.dumps({'tesseract_path': TESSERACT}, ensure_ascii=False, indent=2),
                encoding='utf-8'
            )
            return {'ok': True, **self.runtime_status()}
        except Exception as e:
            return {'ok': False, 'error': str(e)}


    # ------------------------------------------------------------------
    # Stage 29.6.7 / v10.4.7 — race-safe Auto Resume After Lag
    # ------------------------------------------------------------------
    def _internet_connected_for_auto_resume(self):
        """Windows connectivity signal used only as a deny gate; failure = not proven."""
        try:
            wininet = ctypes.windll.wininet
            flags = wintypes.DWORD(0)
            fn = wininet.InternetGetConnectedState
            fn.argtypes = [ctypes.POINTER(wintypes.DWORD), wintypes.DWORD]
            fn.restype = wintypes.BOOL
            return bool(fn(ctypes.byref(flags), 0))
        except Exception:
            return False

    def _auto_resume_session_token_for_hwnd(self, hwnd):
        try:
            hwnd = int(hwnd)
            pid = int(_window_pid(hwnd) or 0) if window_exists(hwnd) else 0
            return f"{hwnd}:{pid}:{_window_title(hwnd)}"
        except Exception:
            return f"{int(hwnd or 0)}:0:"

    def _clear_auto_resume_action_lag_context(self, *, uncertain=False):
        self._auto_resume_action_lag_context = None
        self._auto_resume_destructive_uncertain = bool(uncertain)

    def _arm_auto_resume_action_lag_context(self, hwnd, *, action, cycle_id, item,
                                            source_grid, source_before, fingerprint,
                                            baseline_snapshot=None, cursor_probe_point=None,
                                            cursor_clear_reference_image=None,
                                            target_grid=None, target_before=None, destination_cells=None):
        self._auto_resume_destructive_uncertain = False
        self._auto_resume_action_lag_context = {
            'action': str(action or '').upper(),
            'cycle_id': int(cycle_id or 0),
            'item_id': str((item or {}).get('id') or (item or {}).get('slot_id') or (item or {}).get('queue_id') or 'Q01'),
            'session_token': self._auto_resume_session_token_for_hwnd(hwnd),
            'source_grid': source_grid,
            'source_before': source_before,
            'source_fingerprint': fingerprint,
            'baseline_snapshot': baseline_snapshot,
            'cursor_probe_point': list(cursor_probe_point) if cursor_probe_point else None,
            'cursor_clear_reference_image': cursor_clear_reference_image,
            'target_grid': target_grid,
            'target_before': target_before,
            'destination_cells': [list(x) for x in (destination_cells or [])],
            'armed_monotonic': time.monotonic(),
        }

    def _auto_resume_revalidate_action_lag_context(self, hwnd):
        """Re-prove a non-committed destructive transaction before auto-resume.

        Fail closed: TEMPORARY_ACTION_LAG remains eligible only when the SAME
        source item is still present, cursor is clear, and (for Store) the
        destination region is unchanged. No old action callback is replayed.
        """
        ctx = self._auto_resume_action_lag_context
        if not isinstance(ctx, dict):
            return {'safe': False, 'reason': 'NO_ACTION_LAG_CONTEXT', 'source_inventory_stable': False, 'cursor_clear': False}
        try:
            hwnd = int(hwnd)
            if self._auto_resume_session_token_for_hwnd(hwnd) != str(ctx.get('session_token') or ''):
                return {'safe': False, 'reason': 'SESSION_CHANGED', 'source_inventory_stable': False, 'cursor_clear': False}
            img = capture_client(hwnd)
            if img is None:
                return {'safe': False, 'reason': 'ACTION_LAG_RECAPTURE_FAILED', 'source_inventory_stable': False, 'cursor_clear': False}
            sg = ctx.get('source_grid')
            valid = validate_known_grid(img, sg) if sg else {'ok': False}
            if not valid.get('ok'):
                ng = detect_inventory_grid(img)
                if not ng.get('ok'):
                    return {'safe': False, 'reason': 'ACTION_LAG_SOURCE_GRID_INVALID', 'source_inventory_stable': False, 'cursor_clear': False}
                sg = ng
            current_source = snapshot_inventory(img, sg)
            if not current_source.get('ok'):
                return {'safe': False, 'reason': 'ACTION_LAG_SOURCE_SNAPSHOT_FAILED', 'source_inventory_stable': False, 'cursor_clear': False}
            fp_state = _source_item_fingerprint_state(
                ctx.get('source_fingerprint') or {},
                ctx.get('source_before') or {},
                current_source,
                ctx.get('baseline_snapshot'),
            )
            source_stable = fp_state.get('state') == 'ITEM_STILL_IN_SOURCE'

            cursor_state = 'CURSOR_UNCERTAIN'
            probe_point = ctx.get('cursor_probe_point')
            ref_img = ctx.get('cursor_clear_reference_image')
            if probe_point and ref_img is not None:
                sp = _client_to_screen(hwnd, int(probe_point[0]), int(probe_point[1]))
                if sp:
                    _set_cursor_screen(int(sp[0]), int(sp[1])); time.sleep(.045)
                    ci = capture_client(hwnd)
                    if ci is not None:
                        cursor_state = (_probe_cursor_attachment(ref_img, ci, probe_point) or {}).get('state') or 'CURSOR_UNCERTAIN'
            cursor_clear = cursor_state == 'CURSOR_CLEAR'

            destination_unchanged = True
            target_diag = None
            if str(ctx.get('action') or '').upper() == 'STORE':
                tg = ctx.get('target_grid')
                tv = validate_known_grid(img, tg) if tg else {'ok': False}
                if not tv.get('ok'):
                    tg2 = detect_personal_storage_grid(img)
                    if not tg2.get('ok'):
                        destination_unchanged = False
                        target_diag = {'ok': False, 'reason': 'ACTION_LAG_TARGET_GRID_INVALID'}
                    else:
                        tg = tg2
                if destination_unchanged:
                    cur_target = snapshot_inventory(img, tg)
                    if not cur_target.get('ok'):
                        destination_unchanged = False
                        target_diag = {'ok': False, 'reason': 'ACTION_LAG_TARGET_SNAPSHOT_FAILED'}
                    else:
                        target_diag = _target_cells_signature_stable(
                            ctx.get('target_before') or {}, cur_target,
                            ctx.get('destination_cells') or [], max_mae=7.0
                        )
                        destination_unchanged = bool(target_diag.get('ok'))

            safe = bool(source_stable and cursor_clear and destination_unchanged)
            return {
                'safe': safe,
                'reason': 'ACTION_LAG_REVALIDATED_SAFE' if safe else 'ACTION_LAG_REVALIDATION_FAILED',
                'action': ctx.get('action'), 'cycle_id': ctx.get('cycle_id'), 'item_id': ctx.get('item_id'),
                'source_inventory_stable': source_stable, 'source_state': fp_state,
                'cursor_clear': cursor_clear, 'cursor_item_state': cursor_state,
                'destination_unchanged': destination_unchanged, 'destination_check': target_diag,
            }
        except Exception as e:
            return {'safe': False, 'reason': 'ACTION_LAG_REVALIDATION_EXCEPTION', 'error': str(e), 'source_inventory_stable': False, 'cursor_clear': False}

    def _auto_resume_safety_snapshot(self, hwnd, runtime_running=False):
        """One atomic pre-flight evidence snapshot. Unknown facts fail closed."""
        try:
            hwnd = int(hwnd)
        except Exception:
            hwnd = 0
        hwnd_valid = bool(hwnd and window_exists(hwnd))
        probe = self.probe_client(hwnd) if hwnd_valid else {'ok':False,'connected':False,'capture_ok':False}
        control = self._chest_control_snapshot()
        input_target_valid = False
        try:
            input_target_valid = bool(hwnd_valid and int(_largest_child(hwnd) or 0) > 0)
        except Exception:
            input_target_valid = False
        action_ctx = getattr(self, '_auto_resume_action_lag_context', None)
        action_reval = self._auto_resume_revalidate_action_lag_context(hwnd) if isinstance(action_ctx, dict) else None
        destructive_uncertain = bool(getattr(self,'_auto_resume_destructive_uncertain',False))
        no_action_in_flight = not bool(control.get('action_in_flight'))
        return {
            'hwnd_valid': hwnd_valid,
            'game_connected': bool(probe.get('connected')),
            'internet_connected': bool(self._internet_connected_for_auto_resume()),
            'capture_healthy': bool(probe.get('capture_ok')),
            'input_target_valid': input_target_valid,
            'no_chest_exhaustion': not bool(getattr(self,'_auto_resume_chests_exhausted_confirmed',False)),
            'storage_not_full': not bool(getattr(self,'_auto_resume_storage_full_confirmed',False)),
            'no_destructive_action_unresolved': (not destructive_uncertain) and no_action_in_flight and (not isinstance(action_ctx,dict) or bool((action_reval or {}).get('safe'))),
            'no_item_on_cursor': (not destructive_uncertain) and no_action_in_flight and (not isinstance(action_ctx,dict) or bool((action_reval or {}).get('cursor_clear'))),
            'action_lag_transaction_safe': bool((action_reval or {}).get('safe')) if isinstance(action_ctx,dict) else False,
            'source_inventory_stable': bool((action_reval or {}).get('source_inventory_stable')) if isinstance(action_ctx,dict) else False,
            'action_lag_revalidation': action_reval,
            'user_stop_clear': not bool(control.get('stop_requested')),
            'no_duplicate_scheduler_owner': True,
            'runtime_not_running': not bool(runtime_running),
            'probe': probe,
            'control': control,
        }

    def _auto_resume_cancel_backend_timer(self, reason='CANCELLED', clear_continuation=True):
        """Cancel the single backend-owned 15s scheduler, if any."""
        with self._auto_resume_backend_timer_lock:
            t=self._auto_resume_backend_timer
            self._auto_resume_backend_timer=None
            meta=dict(self._auto_resume_backend_timer_meta or {}) if isinstance(self._auto_resume_backend_timer_meta,dict) else None
            self._auto_resume_backend_timer_meta=None
            if clear_continuation:
                self._auto_resume_backend_continuation=None
            if t is not None:
                try: t.cancel()
                except Exception: pass
            if meta:
                _auto_resume_log('AUTO_RESUME_BACKEND_TIMER_CANCELLED',{'reason':str(reason or 'CANCELLED'),**meta})
            return {'cancelled':bool(t is not None),'reason':str(reason or 'CANCELLED'),'meta':meta}

    def _auto_resume_backend_state_snapshot(self):
        with self._auto_resume_backend_timer_lock:
            meta=dict(self._auto_resume_backend_timer_meta or {}) if isinstance(self._auto_resume_backend_timer_meta,dict) else None
            last=dict(self._auto_resume_backend_last_result or {}) if isinstance(self._auto_resume_backend_last_result,dict) else None
            cont=dict(self._auto_resume_backend_continuation or {}) if isinstance(self._auto_resume_backend_continuation,dict) else None
            if cont:
                cont={k:v for k,v in cont.items() if k!='prep'}
            return {
                'backend_timer_armed':bool(self._auto_resume_backend_timer is not None),
                'backend_timer_meta':meta,
                'backend_recovery':last,
                'backend_continuation':cont,
            }

    def _auto_resume_arm_backend_timer(self, hwnd, schedule_result, pause_category):
        """Arm exactly one real backend timer for the canonical 15-second deadline."""
        p=(schedule_result or {}).get('pending') if isinstance(schedule_result,dict) else None
        if not isinstance(p,dict):
            return {'ok':False,'reason':'AUTO_RESUME_PENDING_SNAPSHOT_MISSING'}
        with self._auto_resume_backend_timer_lock:
            if self._auto_resume_backend_timer is not None:
                return {'ok':False,'reason':'AUTO_RESUME_BACKEND_TIMER_ALREADY_ARMED'}
            due=float(p.get('resume_due_monotonic') or (time.monotonic()+AUTO_RESUME_DELAY_SECONDS))
            delay=max(0.0,due-time.monotonic())
            gen=int(p.get('scheduled_generation',-1)); pause_id=int(p.get('pause_id',-1))
            category=str(pause_category or p.get('pause_category') or 'UNKNOWN')
            start_source=('AUTO_RESUME_FILTER_RECHECK' if category=='RECOVERABLE_FILTER_SENSOR_STATE' else
                          ('AUTO_RESUME_AFTER_ACTION_LAG' if category=='TEMPORARY_ACTION_LAG' else 'AUTO_RESUME_AFTER_LAG'))
            event_id=f"AR-{pause_id}-G{gen}"
            meta={
                'event_id':event_id,'hwnd':int(hwnd),'pause_id':pause_id,'generation':gen,
                'pause_category':category,'start_source':start_source,
                'scheduled_at_epoch':p.get('scheduled_at_epoch'),'due_at_epoch':p.get('due_at_epoch'),
                'armed_at_epoch':time.time(),'delay_seconds':float(delay),
            }
            self._auto_resume_backend_timer_meta=meta
            self._auto_resume_backend_last_result={'state':'WAITING','reason':'AUTO_RESUME_BACKEND_TIMER_ARMED',**meta}
            t=threading.Timer(delay,self._auto_resume_backend_timer_fire,args=(dict(meta),))
            t.daemon=True
            self._auto_resume_backend_timer=t
            t.start()
        _auto_resume_log('AUTO_RESUME_SCHEDULED',{'scheduler_owner':'BACKEND_TIMER_V12_11',**meta})
        return {'ok':True,'armed':True,**meta}

    def _auto_resume_backend_timer_fire(self, meta):
        """Real T+15 callback: revalidate then run the canonical recovery pipeline."""
        meta=dict(meta or {})
        with self._auto_resume_backend_timer_lock:
            current=dict(self._auto_resume_backend_timer_meta or {}) if isinstance(self._auto_resume_backend_timer_meta,dict) else {}
            if not current or str(current.get('event_id'))!=str(meta.get('event_id')):
                return
            self._auto_resume_backend_timer=None
            self._auto_resume_backend_timer_meta=None
            self._auto_resume_backend_last_result={'state':'RECOVERY_RUNNING','reason':'AUTO_RESUME_TIMER_FIRED',**meta,'fired_at_epoch':time.time()}
        hwnd=int(meta.get('hwnd') or 0); gen=int(meta.get('generation') or -1); pause_id=int(meta.get('pause_id') or -1)
        start_source=str(meta.get('start_source') or 'AUTO_RESUME_AFTER_LAG')
        start_request_id=f"BACKEND-{meta.get('event_id')}-{int(time.time()*1000)}"
        try:
            pre=self.auto_resume_preflight(hwnd,gen,pause_id,False)
            if not pre.get('approved'):
                result={'state':'FAILED','reason':pre.get('reason') or 'AUTO_RESUME_PREFLIGHT_DENIED',**meta,
                        'timer_elapsed_ms':pre.get('timer_elapsed_ms'),'preflight':pre,'fresh_recovery_executed':False}
                with self._auto_resume_backend_timer_lock:self._auto_resume_backend_last_result=result
                return
            gate=self.auto_resume_start_gate(hwnd,gen,pause_id,start_request_id,False)
            if not gate.get('approved'):
                result={'state':'FAILED','reason':gate.get('reason') or 'AUTO_RESUME_CLAIM_DENIED',**meta,
                        'timer_elapsed_ms':pre.get('timer_elapsed_ms'),'fresh_recovery_executed':False}
                with self._auto_resume_backend_timer_lock:self._auto_resume_backend_last_result=result
                return
            valid=self.auto_resume_validate_claim(hwnd,gate.get('claim_token'),gen,pause_id,False)
            if not valid.get('approved'):
                result={'state':'FAILED','reason':valid.get('reason') or 'AUTO_RESUME_CLAIM_INVALID',**meta,
                        'timer_elapsed_ms':pre.get('timer_elapsed_ms'),'fresh_recovery_executed':False}
                with self._auto_resume_backend_timer_lock:self._auto_resume_backend_last_result=result
                return
            # IMPORTANT: this is the real callback work. For FILTER_RECHECK the
            # canonical chest_prepare_loop path invokes ResumeCoordinator for the
            # exact bound logical item before any next chest can be opened.
            prep=self.chest_prepare_loop(hwnd,start_source,gate.get('claim_token'),gen)
            resolved=bool(isinstance(prep,dict) and prep.get('ok'))
            reason=str((prep or {}).get('reason') or ('AUTO_RESUME_RECOVERY_READY' if resolved else 'AUTO_RESUME_RECOVERY_FAILED'))
            if not resolved:
                result={'state':'FAILED','reason':reason,**meta,'timer_elapsed_ms':pre.get('timer_elapsed_ms'),
                        'fresh_recovery_executed':bool((prep or {}).get('filter_recovery')),
                        'recovery_pending':bool((prep or {}).get('recovery_pending')),
                        'filter_recovery_resolved':bool((prep or {}).get('filter_recovery_resolved'))}
                with self._auto_resume_backend_timer_lock:self._auto_resume_backend_last_result=result
                _auto_resume_log('AUTO_RESUME_CALLBACK_NO_WORK' if not result['fresh_recovery_executed'] else 'AUTO_RESUME_RECOVERY_FAILED',result)
                return
            token=hashlib.sha256(f"{meta.get('event_id')}|{time.time_ns()}|{hwnd}".encode()).hexdigest()[:32]
            continuation={
                'token':token,'hwnd':hwnd,'generation':gen,'pause_id':pause_id,'event_id':meta.get('event_id'),
                'source':'AUTO_RESUME_BACKEND_CONTINUE','created_at_epoch':time.time(),'consumed':False,'prep':prep,
            }
            result={'state':'CONTINUE_READY','reason':'AUTO_RESUME_REAL_RECOVERY_COMPLETE',**meta,
                    'timer_elapsed_ms':pre.get('timer_elapsed_ms'),'fresh_recovery_executed':True,
                    'filter_recovery_resolved':bool(prep.get('filter_recovery_resolved')),
                    'filter_recheck_deferred':bool(prep.get('filter_recheck_deferred')),
                    'next_cycle_ready':True,'continuation_token':token}
            with self._auto_resume_backend_timer_lock:
                self._auto_resume_backend_continuation=continuation
                self._auto_resume_backend_last_result=result
            _auto_resume_log('AUTO_RESUME_REAL_RECOVERY_COMPLETE',result)
        except Exception as e:
            result={'state':'FAILED','reason':'AUTO_RESUME_BACKEND_CALLBACK_EXCEPTION','error':str(e),**meta,'fresh_recovery_executed':False}
            with self._auto_resume_backend_timer_lock:self._auto_resume_backend_last_result=result
            _auto_resume_log('AUTO_RESUME_BACKEND_CALLBACK_EXCEPTION',result)

    def auto_resume_consume_backend_continuation(self, hwnd, token, expected_generation=None):
        """Atomically hand UI loop ownership back only AFTER backend recovery finished."""
        hwnd=int(hwnd); tok=str(token or '')
        with self._auto_resume_backend_timer_lock:
            c=self._auto_resume_backend_continuation
            if not isinstance(c,dict):
                return {'ok':False,'approved':False,'reason':'NO_BACKEND_CONTINUATION'}
            if tok!=str(c.get('token') or ''):
                return {'ok':False,'approved':False,'reason':'BACKEND_CONTINUATION_TOKEN_MISMATCH'}
            if int(c.get('hwnd') or 0)!=hwnd:
                return {'ok':False,'approved':False,'reason':'BACKEND_CONTINUATION_HWND_MISMATCH'}
            if expected_generation is not None and int(expected_generation)!=int(c.get('generation') or -1):
                return {'ok':False,'approved':False,'reason':'BACKEND_CONTINUATION_GENERATION_MISMATCH'}
            if c.get('consumed'):
                return {'ok':False,'approved':False,'reason':'BACKEND_CONTINUATION_ALREADY_CONSUMED'}
            if self._chest_is_stop_requested() or not bool(self._auto_resume.status().get('auto_resume_enabled')):
                return {'ok':False,'approved':False,'reason':'AUTO_RESUME_ABORTED_USER_PRIORITY'}
            c['consumed']=True
            prep=c.get('prep') if isinstance(c.get('prep'),dict) else {'ok':False,'reason':'BACKEND_CONTINUATION_PREP_MISSING'}
            out={'ok':bool(prep.get('ok')),'approved':bool(prep.get('ok')),'reason':'BACKEND_CONTINUATION_CONSUMED' if prep.get('ok') else prep.get('reason'),
                 'generation':c.get('generation'),'pause_id':c.get('pause_id'),'event_id':c.get('event_id'),'prep':prep}
            self._auto_resume_backend_continuation=None
            if isinstance(self._auto_resume_backend_last_result,dict):
                self._auto_resume_backend_last_result=dict(self._auto_resume_backend_last_result,continuation_consumed=True)
            return out

    def get_auto_resume_after_lag(self, hwnd=0):
        st=self._auto_resume.status()
        return {'ok':True,'config_enabled':bool(st.get('auto_resume_enabled')),'auto_resume_enabled':bool(st.get('auto_resume_enabled')),'session_token':self._auto_resume_session_token_for_hwnd(hwnd) if hwnd else None,**st,**self._auto_resume_backend_state_snapshot()}

    def set_auto_resume_after_lag(self, enabled):
        enabled=bool(enabled)
        before=self._auto_resume.status()
        old_enabled=bool(before.get('auto_resume_enabled'))
        chest_cfg=self._cfg.setdefault('modules',{}).setdefault('chest',{})
        chest_cfg['auto_resume_after_lag_enabled']=enabled
        _save_app_config(self._cfg)
        st=self._auto_resume.set_enabled(enabled)
        if not enabled:
            self._auto_resume_action_lag_context=None
            self._auto_resume_cancel_backend_timer('CHECKBOX_DISABLED',clear_continuation=True)
        _auto_resume_log('AUTO_RESUME_SETTING_CHANGED',{'old':old_enabled,'new':enabled,'enabled':enabled,'resume_generation':st.get('resume_generation')})
        _auto_resume_log('AUTO_RESUME_CONFIG_CHANGED',{'enabled':enabled,'resume_generation':st.get('resume_generation')})
        return {'ok':True,'config_enabled':bool(st.get('auto_resume_enabled')),'auto_resume_enabled':bool(st.get('auto_resume_enabled')),**st}

    def auto_resume_cancel(self, event='CANCELLED'):
        ev=str(event or 'CANCELLED').upper()
        st=self._auto_resume.invalidate(ev)
        self._auto_resume_cancel_backend_timer(ev,clear_continuation=True)
        self._v121_resume_owner_bindings={}
        self._v121_active_resume_owner_binding=None
        # Pending safe non-commit evidence is only needed for that one resume
        # attempt. Cancellation never preserves a stale future action restart.
        self._auto_resume_action_lag_context=None
        _auto_resume_log('AUTO_RESUME_CANCELLED',{'cancel_reason':ev,'resume_generation':st.get('resume_generation')})
        return {'ok':True,'cancelled':True,'auto_resume_cancel_reason':ev,**st}

    def auto_resume_note_runtime_terminal(self, reason):
        """Keep confirmed terminal blockers separate from transient no-new-item/errors."""
        r=str(reason or '').upper()
        if r in ('CONFIRMED_CHESTS_EXHAUSTED','CHESTS_CONFIRMED_EXHAUSTED'):
            self._auto_resume_chests_exhausted_confirmed=True
            st=self._auto_resume.invalidate('CHESTS_EXHAUSTED')
            self._auto_resume_cancel_backend_timer('CHESTS_EXHAUSTED',clear_continuation=True)
            _auto_resume_log('AUTO_RESUME_INVALIDATED',{'reason':'CHESTS_EXHAUSTED','runtime_reason':r,'resume_generation':st.get('resume_generation')})
        elif r in ('PERSONAL_BAG_FULL','PERSONAL_BAG_CONFIRMED_FULL','STORAGE_FULL_CONFIRMED'):
            self._auto_resume_storage_full_confirmed=True
            st=self._auto_resume.invalidate('STORAGE_FULL')
            self._auto_resume_cancel_backend_timer('STORAGE_FULL',clear_continuation=True)
            _auto_resume_log('AUTO_RESUME_INVALIDATED',{'reason':'STORAGE_FULL','runtime_reason':r,'resume_generation':st.get('resume_generation')})
        return {'ok':True,'reason':r}

    def auto_resume_schedule_lag_pause(self, hwnd, pause_reason, runtime_running=False):
        hwnd=int(hwnd)
        category=classify_pause_reason(pause_reason)
        safety=self._auto_resume_safety_snapshot(hwnd,runtime_running=bool(runtime_running))
        session_token=self._auto_resume_session_token_for_hwnd(hwnd)
        owner_binding=None
        if category=='RECOVERABLE_FILTER_SENSOR_STATE':
            owner_binding=self._v121_owner_binding_snapshot(require_blocking=True)
            if not owner_binding.get('ok'):
                payload={
                    'pause_category':category,'pause_reason':str(pause_reason or 'UNKNOWN'),
                    'auto_resume_eligible':True,'auto_resume_enabled':bool(self._auto_resume.status().get('auto_resume_enabled')),
                    'auto_resume_scheduled':False,'session_token':session_token,'safety':safety,
                    'reason':'RECOVERY_OWNER_BINDING_MISSING','recovery_owner_binding':owner_binding,
                }
                _auto_resume_log('AUTO_RESUME_OWNER_BINDING_DENIED',payload)
                return {'ok':False,**payload}
        out=self._auto_resume.schedule_temporary_lag(
            pause_reason=str(pause_reason or 'UNKNOWN'),
            session_token=session_token,
            safety=safety,
        )
        if category=='RECOVERABLE_FILTER_SENSOR_STATE' and out.get('scheduled') and isinstance(owner_binding,dict):
            pending=out.get('pending') if isinstance(out.get('pending'),dict) else {}
            pause_id=pending.get('pause_id')
            if pause_id is not None:
                bound={**owner_binding,
                       'pause_id':pause_id,
                       'scheduled_generation':pending.get('scheduled_generation'),
                       'scheduled_at_epoch':pending.get('scheduled_at_epoch'),
                       'due_at_epoch':pending.get('due_at_epoch')}
                self._v121_resume_owner_bindings[str(pause_id)]=bound
                owner_binding=bound
                self._v121_recovery_owner_log('AUTO_RESUME_OWNER_BOUND',bound)
        backend_timer=None
        if out.get('scheduled'):
            backend_timer=self._auto_resume_arm_backend_timer(hwnd,out,category)
            if not backend_timer.get('ok'):
                self._auto_resume.invalidate('BACKEND_TIMER_ARM_FAILED')
                out={'scheduled':False,'reason':backend_timer.get('reason') or 'BACKEND_TIMER_ARM_FAILED',**self._auto_resume.status()}
        payload={'pause_category':category,'pause_reason':str(pause_reason or 'UNKNOWN'),'auto_resume_eligible':category in ('TEMPORARY_LAG','TEMPORARY_ACTION_LAG','RECOVERABLE_FILTER_SENSOR_STATE'),'auto_resume_enabled':bool(self._auto_resume.status().get('auto_resume_enabled')),'auto_resume_scheduled':bool(out.get('scheduled')),'session_token':session_token,'safety':safety,'recovery_owner_binding':owner_binding,'backend_timer':backend_timer,**out}
        _auto_resume_log('AUTO_RESUME_PAUSE_CLASSIFIED',payload)
        return {'ok':True,**payload}

    def auto_resume_status(self, hwnd=0):
        hwnd=int(hwnd or 0)
        st=self._auto_resume.status()
        p=st.get('pending') if isinstance(st,dict) else None
        cancel_reason=None
        if p and hwnd:
            current_token=self._auto_resume_session_token_for_hwnd(hwnd)
            if current_token != str(p.get('session_token') or ''):
                cancel_reason='SESSION_CHANGED'
            elif not self._internet_connected_for_auto_resume():
                cancel_reason='INTERNET_LOST'
            elif not window_exists(hwnd):
                cancel_reason='GAME_DISCONNECTED'
            elif bool(getattr(self,'_auto_resume_chests_exhausted_confirmed',False)):
                cancel_reason='CHESTS_EXHAUSTED'
            elif bool(getattr(self,'_auto_resume_storage_full_confirmed',False)):
                cancel_reason='STORAGE_FULL'
            if cancel_reason:
                st=self._auto_resume.invalidate(cancel_reason)
                self._auto_resume_cancel_backend_timer(cancel_reason,clear_continuation=True)
                self._auto_resume_action_lag_context=None
                _auto_resume_log('AUTO_RESUME_CANCELLED',{'cancel_reason':cancel_reason,'resume_generation':st.get('resume_generation')})
        return {'ok':True,'session_token':self._auto_resume_session_token_for_hwnd(hwnd) if hwnd else None,'auto_resume_cancel_reason':cancel_reason,**st,**self._auto_resume_backend_state_snapshot()}

    def auto_resume_preflight(self, hwnd, expected_generation, pause_id, runtime_running=False):
        hwnd=int(hwnd)
        safety=self._auto_resume_safety_snapshot(hwnd,runtime_running=bool(runtime_running))
        session_token=self._auto_resume_session_token_for_hwnd(hwnd)
        pre_status=self._auto_resume.status()
        pending=(pre_status.get('pending') or {}) if isinstance(pre_status,dict) else {}
        fired_at=time.time()
        scheduled_at=pending.get('scheduled_at_epoch'); due_at=pending.get('due_at_epoch')
        elapsed_ms=None
        try:
            if scheduled_at is not None: elapsed_ms=round((fired_at-float(scheduled_at))*1000.0,3)
        except Exception:
            elapsed_ms=None
        _auto_resume_log('AUTO_RESUME_TIMER_FIRED',{
            'recovery_event_id':f"AR-{int(pause_id)}-G{int(expected_generation)}",
            'pause_id':int(pause_id),'recovery_generation':int(expected_generation),
            'scheduled_at':scheduled_at,'due_at':due_at,'fired_at':fired_at,'elapsed_ms':elapsed_ms,
            'canonical_delay_seconds':float(AUTO_RESUME_DELAY_SECONDS),
        })
        out=self._auto_resume.preflight(
            expected_generation=int(expected_generation),pause_id=int(pause_id),
            session_token=session_token,safety=safety,consume_attempt_on_denied=True,
        )
        _auto_resume_log('AUTO_RESUME_REVALIDATION_PASS' if out.get('approved') else 'AUTO_RESUME_REVALIDATION_DENIED',{'pause_id':pause_id,'expected_generation':expected_generation,'reason':out.get('reason'),'safety':safety,'elapsed_ms':elapsed_ms})
        return {'ok':True,'session_token':session_token,'safety':safety,'timer_elapsed_ms':elapsed_ms,**out}

    def auto_resume_start_gate(self, hwnd, expected_generation, pause_id, start_request_id, runtime_running=False):
        hwnd=int(hwnd)
        safety=self._auto_resume_safety_snapshot(hwnd,runtime_running=bool(runtime_running))
        session_token=self._auto_resume_session_token_for_hwnd(hwnd)
        out=self._auto_resume.claim_start(
            expected_generation=int(expected_generation),pause_id=int(pause_id),
            session_token=session_token,safety=safety,start_request_id=str(start_request_id),
        )
        _auto_resume_log('AUTO_RESUME_START_REQUESTED' if out.get('approved') else 'AUTO_RESUME_START_DENIED',{'pause_id':pause_id,'expected_generation':expected_generation,'start_request_id':start_request_id,'reason':out.get('reason')})
        return {'ok':True,'session_token':session_token,'safety':safety,**out}

    def auto_resume_validate_claim(self, hwnd, claim_token, expected_generation, pause_id, runtime_running=False):
        hwnd=int(hwnd)
        safety=self._auto_resume_safety_snapshot(hwnd,runtime_running=bool(runtime_running))
        session_token=self._auto_resume_session_token_for_hwnd(hwnd)
        out=self._auto_resume.validate_claim(
            claim_token=str(claim_token or ''),expected_generation=int(expected_generation),
            pause_id=int(pause_id),session_token=session_token,safety=safety,
        )
        _auto_resume_log('AUTO_RESUME_CLAIM_VALID' if out.get('approved') else 'AUTO_RESUME_ABORTED_USER_PRIORITY',{'pause_id':pause_id,'expected_generation':expected_generation,'reason':out.get('reason')})
        return {'ok':True,'session_token':session_token,'safety':safety,**out}


    def set_shortcut_mode(self, mode):
        mode = str(mode or "Mặc định")
        if mode not in ("Kết hợp", "Mặc định"):
            return {'ok': False, 'error': 'Chế độ phím tắt không hợp lệ.'}
        self._cfg['shortcut_mode'] = mode
        _save_app_config(self._cfg)
        return {
            'ok': True,
            'shortcut_mode': mode,
            'inventory_hotkey': 'Q' if mode == 'Kết hợp' else 'F4'
        }

    def get_shortcut_mode(self):
        mode = str(self._cfg.get('shortcut_mode', 'Mặc định'))
        return mode if mode in ('Kết hợp', 'Mặc định') else 'Mặc định'

    def get_inventory_hotkey(self):
        return 'Q' if self.get_shortcut_mode() == 'Kết hợp' else 'F4'

    def get_runtime_config(self):
        return self._cfg

    def _common_consumable_status_payload(self):
        now = time.time()
        cfg = self._cfg.setdefault("modules", {}).setdefault("common", {})
        specs = [
            ("thien_son_bao_lo", "Thiên Sơn Bảo Lộ", "2", COMMON_WHITE_INTERVAL_SEC),
            ("que_hoa_tuu", "Quế Hoa Tửu", "3", COMMON_GREEN_INTERVAL_SEC),
        ]
        items = []
        for code, name, key, interval in specs:
            enabled = bool(cfg.get(f"{code}_enabled", False))
            last_used = float(cfg.get(f"{code}_last_used_epoch", 0.0) or 0.0)
            last_attempt = float(cfg.get(f"{code}_last_attempt_epoch", 0.0) or 0.0)
            if not enabled:
                remaining = None
                due = False
            elif last_used <= 0:
                remaining = 0
                due = True
            else:
                remaining = max(0, int(round(interval - (now - last_used))))
                due = remaining <= 0
            items.append({
                "code": code, "name": name, "key": key, "enabled": enabled,
                "interval_sec": int(interval), "last_used_epoch": last_used,
                "last_attempt_epoch": last_attempt, "remaining_sec": remaining,
                "due": bool(due),
            })
        return {"ok": True, "now_epoch": now, "items": items}

    def get_common_consumables(self):
        return self._common_consumable_status_payload()

    def save_common_consumables(self, payload):
        try:
            payload = dict(payload or {})
            cfg = self._cfg.setdefault("modules", {}).setdefault("common", {})
            for code in ("thien_son_bao_lo", "que_hoa_tuu"):
                key = f"{code}_enabled"
                old = bool(cfg.get(key, False))
                new = bool(payload.get(key, old))
                cfg[key] = new
                # Newly enabled = due immediately once, then real-time wall-clock interval.
                if new and not old:
                    cfg[f"{code}_last_used_epoch"] = 0.0
                    cfg[f"{code}_last_attempt_epoch"] = 0.0
            _save_app_config(self._cfg)
            return self._common_consumable_status_payload()
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _dismiss_consumable_popup_once(self, hwnd):
        """Click the visible right HÀNH TRANG header once after using key 2/3."""
        try:
            hwnd = int(hwnd)
            img = capture_client(hwnd)
            if img is None:
                return {"ok": False, "reason": "COMMON_DISMISS_CAPTURE_FAILED"}
            grid = detect_inventory_grid(img)
            if grid.get("ok"):
                # This is the user's requested one click on HÀNH TRANG, not a hotkey.
                return _safe_inventory_header_click(hwnd, grid)
            # Safety: never substitute a blind map click if HÀNH TRANG is not visible.
            return {"ok": False, "reason": "COMMON_DISMISS_INVENTORY_NOT_VISIBLE", "grid": grid}
        except Exception as e:
            return {"ok": False, "reason": "COMMON_DISMISS_EXCEPTION", "error": str(e)}

    def common_consumable_tick(self, hwnd, force_code=None):
        """Run due shared consumables at a safe cycle boundary. Never repeats a failed action rapidly."""
        try:
            hwnd = int(hwnd)
            if not window_exists(hwnd):
                status = self._common_consumable_status_payload()
                status.update({"ok": False, "reason": "CLIENT_WINDOW_GONE"})
                return status
            if is_minimized(hwnd):
                status = self._common_consumable_status_payload()
                status.update({"ok": False, "reason": "CLIENT_MINIMIZED"})
                return status
            cfg = self._cfg.setdefault("modules", {}).setdefault("common", {})
            now = time.time()
            specs = [
                ("thien_son_bao_lo", "Thiên Sơn Bảo Lộ", "2", COMMON_WHITE_INTERVAL_SEC),
                ("que_hoa_tuu", "Quế Hoa Tửu", "3", COMMON_GREEN_INTERVAL_SEC),
            ]
            actions = []
            for code, name, key, interval in specs:
                if force_code and str(force_code) != code:
                    continue
                enabled = bool(cfg.get(f"{code}_enabled", False))
                if force_code:
                    enabled = True
                if not enabled:
                    continue
                last_used = float(cfg.get(f"{code}_last_used_epoch", 0.0) or 0.0)
                last_attempt = float(cfg.get(f"{code}_last_attempt_epoch", 0.0) or 0.0)
                due = bool(force_code) or last_used <= 0 or (now - last_used) >= interval
                if not due:
                    continue
                if not force_code and last_attempt > 0 and (now - last_attempt) < COMMON_FAILED_RETRY_SEC:
                    continue
                cfg[f"{code}_last_attempt_epoch"] = now
                _save_app_config(self._cfg)
                sent = self.send_client_key_once(hwnd, key, self._cfg.get("input_mode", "Auto"))
                action = {"code": code, "name": name, "key": key, "sent": sent}
                if sent.get("ok"):
                    time.sleep(COMMON_POPUP_SETTLE_SEC)
                    dismiss = self._dismiss_consumable_popup_once(hwnd)
                    action["dismiss"] = dismiss
                    # Key delivery is the state-changing action; record real-time usage
                    # even if the cosmetic popup-dismiss click could not be confirmed.
                    used_at = time.time()
                    cfg[f"{code}_last_used_epoch"] = used_at
                    cfg[f"{code}_last_attempt_epoch"] = used_at
                    action["used_epoch"] = used_at
                    action["ok"] = True
                else:
                    action["ok"] = False
                    action["reason"] = sent.get("error") or "COMMON_KEY_SEND_FAILED"
                actions.append(action)
                _save_app_config(self._cfg)
                # Small separation if both buffs become due on the same boundary.
                if sent.get("ok"):
                    time.sleep(.16)
            status = self._common_consumable_status_payload()
            return {"ok": True, "actions": actions, **status}
        except Exception as e:
            return {"ok": False, "reason": "COMMON_CONSUMABLE_EXCEPTION", "error": str(e)}

    @_public_api_boundary
    def automation_mode_guard(self, requested_mode='CHEST'):
        """Authoritative mutual-exclusion guard for input-owning automations.

        Runtime object state is authoritative. Persisted module flags are diagnostic
        only when a live controller exists, preventing stale crash-state booleans
        from permanently blocking a new session.
        """
        license_guard = license_status()
        if not license_runtime_allowed():
            return {
                'ok': False,
                'requested_mode': str(requested_mode or 'CHEST').upper(),
                'active_modes': [],
                'blocking_mode': 'LICENSE',
                'reason': str(license_guard.get('reason') or 'LICENSE_NOT_ACTIVE'),
                'license': {
                    'active': bool(license_guard.get('active')),
                    'key_hint': license_guard.get('key_hint'),
                    'hwid_hint': license_guard.get('hwid_hint'),
                },
            }
        requested=str(requested_mode or 'CHEST').upper().replace('AUTO_','').replace('AUTO','')
        aliases={'CHEST':'CHEST','MỞ RƯƠNG':'CHEST','MO RUONG':'CHEST','ROLL':'ROLL','BOSS':'BOSS'}
        requested=aliases.get(requested,requested)
        active=[]
        try:
            chest_state=str(getattr(self,'_runtime_lifecycle_state','STOPPED') or 'STOPPED').upper()
            if chest_state in ('STARTING','RUNNING','RECOVERY_WAIT','RECOVERY_RUNNING','STOPPING'):
                active.append('CHEST')
        except Exception:
            chest_state='UNKNOWN'
        try:
            roll_ctl=getattr(self,'_auto_roll_record',None)
            if roll_ctl is not None:
                if bool(roll_ctl.is_running()) or str(getattr(roll_ctl,'state','')).upper()=='STOPPING': active.append('ROLL')
            elif bool((self._cfg.get('runtime',{}).get('module_running',{}) or {}).get('roll',False)):
                active.append('ROLL')
        except Exception:
            pass
        try:
            boss_ctl=getattr(self,'_auto_boss',None)
            if boss_ctl is not None:
                if bool(boss_ctl.is_running()) or str(getattr(boss_ctl,'state','')).upper()=='STOPPING': active.append('BOSS')
            elif bool((self._cfg.get('runtime',{}).get('module_running',{}) or {}).get('boss',False)):
                active.append('BOSS')
        except Exception:
            pass
        active=list(dict.fromkeys(active))
        blockers=[x for x in active if x!=requested]
        return {
            'ok':not blockers,'requested_mode':requested,'active_modes':active,
            'blocking_mode':blockers[0] if blockers else None,
            'reason':('AUTOMATION_MODE_READY' if not blockers else 'ACTIVE_AUTOMATION_MODE_'+blockers[0]),
            'chest_lifecycle_state':chest_state,
        }

    def save_module_config(self, module_name, config):
        if module_name not in self._cfg.setdefault('modules', {}):
            self._cfg['modules'][module_name] = {}
        if isinstance(config, dict):
            self._cfg['modules'][module_name].update(config)
        _save_app_config(self._cfg)
        return {'ok': True, 'config': self._cfg['modules'][module_name]}

    def set_active_module(self, module_name):
        # Stage 27: Auto Bán Shop was cancelled by user request. Any stale UI/config
        # request for 'shop' is redirected to the independent chest module.
        module_name = 'chest' if str(module_name) == 'shop' else str(module_name)
        self._cfg.setdefault('runtime', {})['active_module'] = module_name
        _save_app_config(self._cfg)
        return {'ok': True, 'active_module': module_name}

    def set_module_running(self, module_name, running):
        module_name=str(module_name)
        if module_name=='shop':
            return {'ok':False,'module':'shop','running':False,'disabled':True,'reason':'SHOP_FEATURE_CANCELLED_STAGE27'}
        rt = self._cfg.setdefault('runtime', {})
        states = rt.setdefault('module_running', {})
        states[module_name] = bool(running)
        _save_app_config(self._cfg)
        return {
            'ok': True,
            'module': module_name,
            'running': bool(running),
            'engine': ('CHEST_CONTINUOUS_LIVE_V9_6' if module_name == 'chest' else ('TOOLTIP_DRY_RUN' if module_name == 'roll' else 'CONFIG_STATE_ONLY')),
        }


    def _grid_layout_drifted(self, image, grid, tolerance_px=7):
        """Detect a confidently visible source grid whose anchor drifted from JX1 default."""
        try:
            if image is None or not isinstance(grid,dict) or not grid.get('ok'):
                return False
            xs=[int(x) for x in grid.get('x_lines',[])]; ys=[int(y) for y in grid.get('y_lines',[])]
            if len(xs)!=7 or len(ys)!=11:return False
            sx,sy=image.width/800.0,image.height/600.0
            ex=int(round(float(CANONICAL_X[0])*sx)); ey=int(round(float(CANONICAL_Y[0])*sy))
            return abs(xs[0]-ex)>int(tolerance_px*sx) or abs(ys[0]-ey)>int(tolerance_px*sy)
        except Exception:
            return False

    def _wait_source_grid_state(self, hwnd, want_open, timeout=0.95):
        t0=time.time(); polls=0; last=None
        while time.time()-t0<=timeout:
            polls+=1
            img=capture_client(int(hwnd)); last=img
            if img is not None:
                g=detect_inventory_grid(img)
                if want_open and g.get('ok'):
                    return {'ok':True,'image':img,'grid':g,'polls':polls}
                if not want_open and not g.get('ok'):
                    # A known canonical border also counts as open; absence of both is closed.
                    c=_canonical_source_grid_candidate(img)
                    if not c.get('ok'):
                        return {'ok':True,'image':img,'grid':None,'polls':polls}
            time.sleep(.055)
        return {'ok':False,'reason':'LAYOUT_STATE_TIMEOUT','want_open':bool(want_open),'polls':polls}

    def _recover_inventory_layout(self, hwnd, reason='LAYOUT_DRIFTED'):
        """Official Q/F4 close->reopen recovery at a safe boundary.

        This is called only when an OPEN grid was actually detected but its anchor
        is drifted. Therefore the first selected-hotkey press is deterministically
        a CLOSE, not a blind toggle guess.
        """
        key=self.get_inventory_hotkey(); mode=self._cfg.get('input_mode','Auto')
        close_input=self.send_inventory_hotkey_once(int(hwnd),key,mode,'LAYOUT_RECOVERY_CLOSE')
        if not close_input.get('ok'):
            return {'ok':False,'reason':'LAYOUT_RECOVERY_CLOSE_INPUT_FAILED','hotkey':key,'input':close_input}
        closed=self._wait_source_grid_state(hwnd,False)
        if not closed.get('ok'):
            return {'ok':False,'reason':'LAYOUT_RECOVERY_CLOSE_NOT_CONFIRMED','hotkey':key,'closed':closed}
        open_input=self.send_inventory_hotkey_once(int(hwnd),key,mode,'LAYOUT_RECOVERY_REOPEN')
        if not open_input.get('ok'):
            return {'ok':False,'reason':'LAYOUT_RECOVERY_REOPEN_INPUT_FAILED','hotkey':key,'input':open_input}
        reopened=self._wait_source_grid_state(hwnd,True,1.15)
        if not reopened.get('ok'):
            return {'ok':False,'reason':'LAYOUT_RECOVERY_REOPEN_NOT_CONFIRMED','hotkey':key,'reopened':reopened}
        self._inventory_grid=reopened.get('grid')
        return {'ok':True,'reason':'LAYOUT_RECOVERED','hotkey':key,'grid':self._inventory_grid,
                'close_polls':closed.get('polls'),'reopen_polls':reopened.get('polls'),'trigger':reason}

    def _capture_inventory_ready(self, hwnd, try_open=True):
        """
        Root fix:
        capture_client() uses visible-screen MSS. If Auto is foreground and overlaps
        JX1, the old code captured the Auto window on top of the game, then wrongly
        assumed the bag was closed and toggled the inventory hotkey.

        We now foreground JX1 BEFORE every inventory capture, then verify the grid.
        """
        hwnd = int(hwnd)

        activation = _activate_window(hwnd)
        time.sleep(.16)

        img = capture_client(hwnd)
        if img is None:
            return {
                "ok": False,
                "reason": "CAPTURE_FAILED",
                "activation": activation,
            }

        grid = detect_inventory_grid(img)
        if grid.get("ok"):
            # V1.7.7E: a verified live 6x10 grid is already the truth.  Never
            # close/reopen it merely because its anchor drifted from an old
            # canonical coordinate.  The old normalization path could turn a
            # healthy visible bag into a false "cannot open Q/F4" failure.
            layout_drifted=bool(self._grid_layout_drifted(img,grid))
            self._inventory_grid = grid

            # v4.9: dismiss any open tooltip before taking the actual inventory
            # snapshot used by occupancy/diff logic.
            parked=_park_cursor_on_inventory_header(hwnd,grid,.24)
            clean_img=capture_client(hwnd)
            clean_grid=detect_inventory_grid(clean_img) if clean_img is not None else {"ok":False}
            if clean_img is not None and clean_grid.get("ok"):
                self._inventory_grid=clean_grid
                return {
                    "ok":True,
                    "image":clean_img,
                    "grid":clean_grid,
                    "opened":False,
                    "capture_mode":"FOREGROUND_TOOLTIP_CLEARED",
                    "layout_drifted_accepted":layout_drifted,
                    "cursor_park":parked,
                    "activation":activation,
                }

            return {
                "ok": True,
                "image": img,
                "grid": grid,
                "opened": False,
                "capture_mode": "FOREGROUND_VISIBLE_FALLBACK",
                "layout_drifted_accepted":layout_drifted,
                "cursor_park": parked,
                "activation": activation,
            }

        # If we calibrated a valid grid earlier, verify that exact geometry before
        # touching any hotkey. This prevents a false toggle caused by a detector miss.
        if self._inventory_grid:
            known = validate_known_grid(img, self._inventory_grid)
            if known.get("ok"):
                grid = dict(self._inventory_grid)
                grid["ok"] = True
                grid["known_grid_validation"] = known
                parked=_park_cursor_on_inventory_header(hwnd,grid,.24)
                clean_img=capture_client(hwnd)
                if clean_img is not None:
                    clean_known=validate_known_grid(clean_img,grid)
                    if clean_known.get("ok"):
                        return {
                            "ok":True,
                            "image":clean_img,
                            "grid":grid,
                            "opened":False,
                            "capture_mode":"FOREGROUND_KNOWN_GRID_TOOLTIP_CLEARED",
                            "cursor_park":parked,
                            "activation":activation,
                        }
                return {
                    "ok": True,
                    "image": img,
                    "grid": grid,
                    "opened": False,
                    "capture_mode": "FOREGROUND_KNOWN_GRID_FALLBACK",
                    "cursor_park":parked,
                    "activation": activation,
                }

        if not try_open:
            return {
                "ok": False,
                "reason": "INVENTORY_GRID_NOT_FOUND",
                "grid": grid,
                "activation": activation,
            }

        # V1.7.7E: one detector miss must never flip a visible toggle closed.
        # Confirm absence on a second independent foreground frame before Q/F4.
        time.sleep(.065)
        confirm_absence=self._capture_inventory_ready(hwnd,try_open=False)
        if confirm_absence.get('ok'):
            confirm_absence=dict(confirm_absence)
            confirm_absence['absence_recheck_saved_toggle']=True
            confirm_absence['initial_absence_observations']=1
            return confirm_absence

        # Only after two foreground observations fail to prove the grid visible do
        # we send the configured inventory toggle exactly once.
        key = self.get_inventory_hotkey()
        mode = self._cfg.get("input_mode", "Auto")
        ir = self.send_inventory_hotkey_once(hwnd, key, mode, 'CAPTURE_INVENTORY_OPEN')
        if isinstance(ir,dict):
            ir=dict(ir); ir['absence_confirmed_samples']=2
        if not ir.get('ok'):
            return {
                "ok":False,
                "reason":ir.get('reason') or "INVENTORY_HOTKEY_SEND_FAILED",
                "input":ir,
                "activation":activation,
            }

        # V1.7.7E: Paddle/CPU load and legacy JX1 animation timing can make a
        # fixed 380 ms post-key capture too early.  Poll non-destructively and
        # require the same 6x10 geometry on two consecutive frames.
        deadline=time.monotonic()+1.85
        stable=[]; polls=0; img2=None; grid2={"ok":False}; known2=None
        activation2=None
        while time.monotonic()<deadline:
            time.sleep(.07 if polls else .14)
            polls+=1
            activation2=_activate_window(hwnd)
            time.sleep(.035)
            cur=capture_client(hwnd)
            if cur is None:
                continue
            cand=detect_inventory_grid(cur)
            if not cand.get('ok') and self._inventory_grid:
                kk=validate_known_grid(cur,self._inventory_grid)
                if kk.get('ok'):
                    cand=dict(self._inventory_grid); cand['ok']=True; cand['known_grid_validation']=kk
                    known2=kk
            if cand.get('ok'):
                geom=(tuple(int(x) for x in cand.get('x_lines',[])),tuple(int(y) for y in cand.get('y_lines',[])))
                if len(geom[0])==7 and len(geom[1])==11:
                    if stable and self._grid_geometry_agrees(stable[-1][2],cand,tolerance_px=2):
                        stable.append((geom,cur,cand))
                    else:
                        stable=[(geom,cur,cand)]
                    if len(stable)>=2:
                        img2=cur; grid2=cand
                        break
            else:
                stable=[]
        icon_fallback = None
        if img2 is None or not grid2.get('ok'):
            return {
                "ok": False,
                "reason": "SOURCE_GRID_NOT_FOUND_AFTER_HOTKEY",
                "grid": grid2,
                "known_grid": known2,
                "input": ir,
                "activation": activation2,
                "open_polls": polls,
                "open_timeout_sec": 1.85,
                "stable_frames": len(stable),
            }

        self._inventory_grid = grid2
        parked=_park_cursor_on_inventory_header(hwnd,grid2,.24)
        clean_img=capture_client(hwnd)
        if clean_img is not None:
            clean_grid=detect_inventory_grid(clean_img)
            if clean_grid.get("ok"):
                grid2=clean_grid
                img2=clean_img
                self._inventory_grid=grid2

        return {
            "ok": True,
            "image": img2,
            "grid": grid2,
            "opened": True,
            "open_method": (icon_fallback or {}).get("open_method", "HOTKEY"),
            "icon_fallback": icon_fallback,
            "capture_mode": "FOREGROUND_AFTER_HOTKEY_TOOLTIP_CLEARED",
            "cursor_park": parked,
            "input": ir,
            "activation": activation2,
            "open_polls": polls,
            "open_confirm_frames": 2,
        }

    def _capture_inventory_loop_fast(self, hwnd, try_open=True):
        """Fast Stage-22 inventory path; fall back to the proven full opener only when needed."""
        try:
            hwnd=int(hwnd)
            activation=None
            if int(user32_bridge.GetForegroundWindow() or 0)!=hwnd:
                activation=_activate_window(hwnd)
                time.sleep(.055)
            img=capture_client(hwnd)
            if img is not None:
                grid=None
                if self._inventory_grid:
                    known=validate_known_grid(img,self._inventory_grid)
                    if known.get('ok'):
                        grid=dict(self._inventory_grid); grid['ok']=True; grid['known_grid_validation']=known
                if grid is None:
                    g=detect_inventory_grid(img)
                    if g.get('ok'):
                        grid=g
                if grid is not None:
                    self._inventory_grid=grid
                    parked=_park_cursor_on_inventory_header(hwnd,grid,.045)
                    clean=capture_client(hwnd)
                    if clean is not None:
                        known2=validate_known_grid(clean,grid)
                        if known2.get('ok'):
                            return {'ok':True,'image':clean,'grid':grid,'opened':False,'capture_mode':'STAGE22_FAST_KNOWN_GRID','cursor_park':parked,'activation':activation}
                    return {'ok':True,'image':img,'grid':grid,'opened':False,'capture_mode':'STAGE22_FAST_GRID_FALLBACK','cursor_park':parked,'activation':activation}
            if not try_open:
                return {'ok':False,'reason':'INVENTORY_GRID_NOT_FOUND_FAST'}
        except Exception:
            if not try_open:
                return {'ok':False,'reason':'INVENTORY_FAST_CAPTURE_EXCEPTION'}
        return self._capture_inventory_ready(hwnd,try_open=try_open)

    def _capture_source_grid_visible(self, hwnd):
        """Capture the RIGHT-SIDE opened-item/source 6x10 grid without toggling UI.

        v9.1 self-healing order:
          1) reuse cached right-side grid when live borders still validate;
          2) generic detector;
          3) fixed canonical 6x10 geometry + live border validation;
          4) one quick cursor-clear recapture and repeat detector/canonical probe.

        No F4/Q and no personal-bag icon are sent here. The center personal
        HÀNH TRANG remains a different UI used only for KEEP storage.
        """
        try:
            hwnd=int(hwnd)
            activation=None
            if int(user32_bridge.GetForegroundWindow() or 0)!=hwnd:
                activation=_activate_window(hwnd)
                time.sleep(.055)
            img=capture_client(hwnd)
            if img is None:
                return {'ok':False,'reason':'SOURCE_GRID_CAPTURE_FAILED','activation':activation}

            # 1) Reuse only a known RIGHT-SIDE grid, never the center personal bag.
            known_diag=None
            if self._inventory_grid:
                xs=[int(x) for x in self._inventory_grid.get('x_lines',[])]
                if len(xs)==7 and xs[0] >= int(img.width*.68):
                    known=validate_known_grid(img,self._inventory_grid)
                    known_diag=known
                    if known.get('ok'):
                        g=dict(self._inventory_grid); g['ok']=True; g['known_grid_validation']=known
                        return {'ok':True,'image':img,'grid':g,'opened':False,'capture_mode':'SOURCE_GRID_KNOWN_VISIBLE_V9_1','activation':activation}

            # 2) Generic detector.
            g=detect_inventory_grid(img)
            if g.get('ok'):
                self._inventory_grid=g
                return {'ok':True,'image':img,'grid':g,'opened':False,'capture_mode':'SOURCE_GRID_VISIBLE_V9_1','activation':activation}

            # 3) Root fallback: exact fixed JX1 source geometry, but ONLY when
            # the real grid borders validate on this live frame. This is what
            # fixes SOURCE_GRID_NOT_VISIBLE_NO_HOTKEY when edge search gets
            # pulled toward consumables / item art / hover pixels.
            canon=_canonical_source_grid_candidate(img)
            if canon.get('ok'):
                cg=canon['grid']
                self._inventory_grid=cg
                return {
                    'ok':True,'image':img,'grid':cg,'opened':False,
                    'capture_mode':'SOURCE_GRID_CANONICAL_SELF_HEAL_V9_1',
                    'canonical_probe':canon.get('validation'),'activation':activation,
                }

            # 4) One fast cursor-clear recapture only; no key/click is sent.
            sp=_client_to_screen(hwnd,int(img.width*.18),int(img.height*.16))
            old=_cursor_screen()
            if sp:
                _set_cursor_screen(*sp); time.sleep(SOURCE_GRID_QUICK_RECAPTURE_SEC)
            img2=capture_client(hwnd)
            if old:
                _set_cursor_screen(*old)
            if img2 is not None:
                g2=detect_inventory_grid(img2)
                if g2.get('ok'):
                    self._inventory_grid=g2
                    return {'ok':True,'image':img2,'grid':g2,'opened':False,'capture_mode':'SOURCE_GRID_VISIBLE_AFTER_CURSOR_CLEAR_V9_1','activation':activation}
                canon2=_canonical_source_grid_candidate(img2)
                if canon2.get('ok'):
                    cg=canon2['grid']
                    self._inventory_grid=cg
                    return {
                        'ok':True,'image':img2,'grid':cg,'opened':False,
                        'capture_mode':'SOURCE_GRID_CANONICAL_AFTER_CURSOR_CLEAR_V9_1',
                        'canonical_probe':canon2.get('validation'),'activation':activation,
                    }
                g=g2
                canon=canon2
            return {
                'ok':False,
                'reason':'SOURCE_GRID_NOT_VISIBLE_NO_HOTKEY',
                'grid':g,
                'known_grid_validation':known_diag,
                'canonical_probe':canon,
                'hint':'Giữ khung đồ/rương bên phải đang mở. v9.1 tự thử detector + canonical 6x10 đã xác minh; không dùng F4/Q nên không mở nhầm Trang bị/Personal Bag.',
                'activation':activation,
            }
        except Exception as e:
            return {'ok':False,'reason':'SOURCE_GRID_CAPTURE_EXCEPTION','error':str(e)}


    def _verify_source_grid_expected_layout(self, ready):
        """Strict post-hotkey authority for the RIGHT-SIDE canonical/default 6x10 source grid."""
        if not isinstance(ready, dict) or not ready.get('ok'):
            return {
                'ok':False,
                'reason':str((ready or {}).get('reason') or 'SOURCE_GRID_NOT_VISIBLE'),
                'ready':ready,
            }
        image=ready.get('image'); grid=ready.get('grid') or {}
        try:
            xs=[int(x) for x in grid.get('x_lines',[])]
            ys=[int(y) for y in grid.get('y_lines',[])]
            declared_topology_ok=(
                int(grid.get('cols') or 0)==6 and int(grid.get('rows') or 0)==10
                and abs(len(xs)-7)<=1 and abs(len(ys)-11)<=1
            )
            right_side_raw=bool(image is not None and xs and xs[0]>=int(image.width*.68))
            live=validate_known_grid(image,grid) if image is not None and declared_topology_ok and right_side_raw else {'ok':False,'reason':'GRID_GEOMETRY_INVALID'}
            # Robust lattice recovery mutates only grid geometry (never pixels).
            # Re-read the snapped lines before deciding topology/drift/click safety.
            xs=[int(x) for x in grid.get('x_lines',[])]
            ys=[int(y) for y in grid.get('y_lines',[])]
            geom_ok=(
                int(grid.get('cols') or 0)==6 and int(grid.get('rows') or 0)==10
                and len(xs)==7 and len(ys)==11
            )
            right_side=bool(image is not None and xs and xs[0]>=int(image.width*.68))
            drifted=self._grid_layout_drifted(image,grid) if image is not None and geom_ok else True
            ok=bool(geom_ok and right_side and live.get('ok') and not drifted)
            return {
                'ok':ok,
                'reason':'SOURCE_GRID_EXPECTED_LAYOUT_OK' if ok else (
                    'SOURCE_GRID_LAYOUT_DRIFTED' if geom_ok and right_side and live.get('ok') and drifted
                    else 'SOURCE_GRID_EXPECTED_LAYOUT_NOT_VERIFIED'
                ),
                'geometry_6x10':bool(geom_ok),
                'right_side':bool(right_side),
                'right_side_raw':bool(right_side_raw),
                'lattice_recovered':bool(live.get('lattice_recovered')),
                'live_validation':live,
                'layout_drifted':bool(drifted),
                'ready':ready,
            }
        except Exception as e:
            return {'ok':False,'reason':'SOURCE_GRID_EXPECTED_LAYOUT_VERIFY_EXCEPTION','error':str(e),'ready':ready}

    def _grid_lease_geometry_signature(self, grid):
        try:
            return {
                'cols':int(grid.get('cols') or 0),'rows':int(grid.get('rows') or 0),
                'x_lines':[int(x) for x in (grid.get('x_lines') or [])],
                'y_lines':[int(y) for y in (grid.get('y_lines') or [])],
            }
        except Exception:
            return {'cols':0,'rows':0,'x_lines':[],'y_lines':[]}

    def _grid_geometry_agrees(self, a, b, tolerance_px=2):
        ga=self._grid_lease_geometry_signature(a or {}); gb=self._grid_lease_geometry_signature(b or {})
        if ga['cols']!=6 or ga['rows']!=10 or gb['cols']!=6 or gb['rows']!=10:
            return False
        if len(ga['x_lines'])!=7 or len(ga['y_lines'])!=11 or len(gb['x_lines'])!=7 or len(gb['y_lines'])!=11:
            return False
        vals=[abs(x-y) for x,y in zip(ga['x_lines'],gb['x_lines'])]+[abs(x-y) for x,y in zip(ga['y_lines'],gb['y_lines'])]
        return bool(vals and max(vals)<=int(tolerance_px))

    def _inventory_panel_presence_signature(self, image, grid):
        """JSON-safe lightweight signature at leased grid-line intersections.

        This does not rediscover the inventory.  It samples only the UI-coordinate
        geometry that recovery just verified, so world/camera movement outside the
        panel cannot invalidate the lease.
        """
        try:
            if image is None:
                return None
            xs=[int(x) for x in (grid or {}).get('x_lines') or []]
            ys=[int(y) for y in (grid or {}).get('y_lines') or []]
            if len(xs)!=7 or len(ys)!=11:
                return None
            gray=image.convert('L')
            samples=[]
            # Grid-line intersections are much more stable than cell interiors,
            # which may contain animated/transparent item sprites.
            for y in ys:
                for x in xs:
                    x0=max(0,x-2); y0=max(0,y-2); x1=min(gray.width,x+3); y1=min(gray.height,y+3)
                    if x1<=x0 or y1<=y0:
                        continue
                    h=gray.crop((x0,y0,x1,y1)).histogram()
                    total=sum(h) or 1
                    mean=sum(i*c for i,c in enumerate(h))/float(total)
                    samples.append(round(float(mean),3))
            if len(samples)<50:
                return None
            return {
                'kind':'GRID_INTERSECTION_LUMA_V1',
                'sample_count':len(samples),
                'samples':samples,
                'mean':round(sum(samples)/len(samples),3),
            }
        except Exception:
            return None

    def _inventory_panel_signature_distance(self, a, b):
        try:
            aa=list((a or {}).get('samples') or []); bb=list((b or {}).get('samples') or [])
            if not aa or len(aa)!=len(bb):
                return None
            ds=sorted(abs(float(x)-float(y)) for x,y in zip(aa,bb))
            n=len(ds)
            return {
                'median_mae':round(float(ds[n//2]),3),
                'p90_mae':round(float(ds[min(n-1,int(round((n-1)*0.90)))]),3),
                'max_mae':round(float(ds[-1]),3),
            }
        except Exception:
            return None

    def _create_verified_grid_lease(self, hwnd, ready, verify_result, recovery_stage, hotkey):
        """JSON-safe authoritative geometry handoff from InventoryLayoutRecovery.

        A lease is created only after bounded multi-frame agreement has already
        verified the live right-side 6x10 inventory.  It is intentionally short
        lived and client-relative; world/camera movement does not invalidate it.
        """
        image=(ready or {}).get('image'); grid=dict((ready or {}).get('grid') or {})
        if image is None or not grid:
            return None
        vr=verify_result or {}
        if not vr.get('ok'):
            return None
        self._verified_grid_lease_generation=int(getattr(self,'_verified_grid_lease_generation',0) or 0)+1
        panel_sig=(vr.get('panel_signature_consensus') or {}).get('reference') or self._inventory_panel_presence_signature(image,grid)
        panel_sig_noise=float(((vr.get('panel_signature_consensus') or {}).get('distance') or {}).get('p90_mae') or 0.0)
        lease={
            'lease_id':f"GRIDLEASE-{self._verified_grid_lease_generation:06d}",
            'hwnd':int(hwnd),'process_id':int(_window_pid(hwnd) or 0),
            'client_width':int(image.width),'client_height':int(image.height),
            'window_rect':list(_window_rect(hwnd) or []),
            'inventory_hotkey_mode':str(hotkey or ''),'inventory_mode':'SOURCE_RIGHT_6X10',
            'verified_timestamp_monotonic':float(time.monotonic()),
            'verified_frame_id':str((ready or {}).get('capture_mode') or ''),
            'panel_roi':[int(grid.get('x_lines',[0])[0]),int(grid.get('y_lines',[0])[0]),int(grid.get('x_lines',[0])[-1]),int(grid.get('y_lines',[0])[-1])] if len(grid.get('x_lines') or [])==7 and len(grid.get('y_lines') or [])==11 else None,
            'grid_roi':[int(grid.get('x_lines',[0])[0]),int(grid.get('y_lines',[0])[0]),int(grid.get('x_lines',[0])[-1]),int(grid.get('y_lines',[0])[-1])] if len(grid.get('x_lines') or [])==7 and len(grid.get('y_lines') or [])==11 else None,
            'cols':6,'rows':10,
            'x_lines':[int(x) for x in (grid.get('x_lines') or [])],
            'y_lines':[int(y) for y in (grid.get('y_lines') or [])],
            'origin_x':float((grid.get('x_lines') or [0])[0]),'origin_y':float((grid.get('y_lines') or [0])[0]),
            'pitch_x':float(sum(grid.get('spacing_x') or [0])/max(1,len(grid.get('spacing_x') or []))) if grid.get('spacing_x') else None,
            'pitch_y':float(sum(grid.get('spacing_y') or [0])/max(1,len(grid.get('spacing_y') or []))) if grid.get('spacing_y') else None,
            'lattice_confidence':float(((vr.get('live_validation') or {}).get('confidence') or grid.get('confidence') or 0.0)),
            'panel_presence_confidence':float(grid.get('confidence') or 0.0),
            'panel_presence_signature':panel_sig,
            'panel_signature_consensus_noise_p90':round(panel_sig_noise,3),
            'border_evidence':{
                'x':(vr.get('live_validation') or {}).get('x_border_ratio'),
                'y':(vr.get('live_validation') or {}).get('y_border_ratio'),
            },
            'validation_sources':['MULTI_FRAME_GRID_CONSENSUS','PANEL_SIGNATURE','RIGHT_SIDE','6X10','LIVE_FRAME'],
            'generation':int(self._verified_grid_lease_generation),
            'recovery_stage':str(recovery_stage or ''),'consensus_frames':int(vr.get('consensus_frames') or 1),
        }
        self._verified_grid_lease=dict(lease)
        return lease

    def _consume_verified_grid_lease(self, hwnd, lease, item=None, current_image=None):
        """Lightweight pre-Drop lease validation; never rediscovers the grid."""
        if not isinstance(lease,dict):
            return {'ok':False,'reason':'GRID_LEASE_MISSING'}
        now=time.monotonic(); age=max(0.0,now-float(lease.get('verified_timestamp_monotonic') or 0.0))
        if age>VERIFIED_GRID_LEASE_MAX_AGE_SEC:
            return {'ok':False,'reason':'GRID_LEASE_EXPIRED','lease_age_ms':round(age*1000.0,3)}
        if int(lease.get('hwnd') or 0)!=int(hwnd) or not window_exists(int(hwnd)):
            return {'ok':False,'reason':'GRID_LEASE_HWND_CHANGED','lease_age_ms':round(age*1000.0,3)}
        if int(lease.get('process_id') or 0)!=int(_window_pid(hwnd) or 0):
            return {'ok':False,'reason':'GRID_LEASE_PROCESS_CHANGED','lease_age_ms':round(age*1000.0,3)}
        img=current_image if current_image is not None else capture_client(int(hwnd))
        if img is None:
            return {'ok':False,'reason':'GRID_LEASE_CAPTURE_FAILED','lease_age_ms':round(age*1000.0,3)}
        if [int(img.width),int(img.height)] != [int(lease.get('client_width') or 0),int(lease.get('client_height') or 0)]:
            return {'ok':False,'reason':'GRID_LEASE_CLIENT_SIZE_CHANGED','lease_age_ms':round(age*1000.0,3)}
        old_wr=list(lease.get('window_rect') or []); new_wr=list(_window_rect(hwnd) or [])
        if old_wr and new_wr and old_wr!=new_wr:
            return {'ok':False,'reason':'GRID_LEASE_WINDOW_MOVED','lease_age_ms':round(age*1000.0,3)}
        if int(lease.get('generation') or 0)!=int(getattr(self,'_verified_grid_lease_generation',0) or 0):
            return {'ok':False,'reason':'GRID_LEASE_GENERATION_CHANGED','lease_age_ms':round(age*1000.0,3)}
        if str(lease.get('inventory_hotkey_mode') or '')!=str(self.get_inventory_hotkey() or ''):
            return {'ok':False,'reason':'GRID_LEASE_INVENTORY_MODE_CHANGED','lease_age_ms':round(age*1000.0,3)}
        xs=[int(x) for x in (lease.get('x_lines') or [])]; ys=[int(y) for y in (lease.get('y_lines') or [])]
        if len(xs)!=7 or len(ys)!=11 or xs[0] < int(img.width*.68):
            return {'ok':False,'reason':'GRID_LEASE_GEOMETRY_INVALID','lease_age_ms':round(age*1000.0,3)}
        leased_grid=canonical_inventory_grid_snapshot({
            'ok':True,'kind':'SOURCE_INVENTORY','cols':6,'rows':10,'x_lines':xs,'y_lines':ys,
            'roi':lease.get('grid_roi') or lease.get('panel_roi') or [xs[0],ys[0],xs[-1],ys[-1]],
            'grid_roi':lease.get('grid_roi') or lease.get('panel_roi') or [xs[0],ys[0],xs[-1],ys[-1]],
            'spacing_x':[xs[i+1]-xs[i] for i in range(6)],'spacing_y':[ys[i+1]-ys[i] for i in range(10)],
            'origin_x':lease.get('origin_x'),'origin_y':lease.get('origin_y'),
            'pitch_x':lease.get('pitch_x'),'pitch_y':lease.get('pitch_y'),
            'confidence':float(lease.get('lattice_confidence') or 0.0),
            'client_width':lease.get('client_width'),'client_height':lease.get('client_height'),
            'hwnd':lease.get('hwnd'),'generation':lease.get('generation'),
            'verified_grid_lease_id':lease.get('lease_id'),'verified_grid_generation':lease.get('generation'),
        },img)
        # Multi-signal live presence: exact leased geometry + current known-grid
        # validation + a calibrated grid-intersection signature.  Border contrast
        # alone is never allowed to declare the panel closed.
        known=validate_known_grid(img,leased_grid) or {}
        current_sig=self._inventory_panel_presence_signature(img,leased_grid)
        sig_dist=self._inventory_panel_signature_distance(lease.get('panel_presence_signature'),current_sig)
        noise=float(lease.get('panel_signature_consensus_noise_p90') or 0.0)
        # Calibrated from the two recovery-consensus frames; minimum allowance is
        # only for capture quantization, not a broad layout threshold relaxation.
        sig_limit=max(6.0,min(24.0,6.0+4.0*noise))
        sig_med=(sig_dist or {}).get('median_mae'); sig_p90=(sig_dist or {}).get('p90_mae')
        sig_ok=bool(sig_dist and sig_med is not None and sig_p90 is not None and float(sig_med)<=sig_limit and float(sig_p90)<=sig_limit*1.8)
        known_ok=bool(known.get('ok'))
        if not (sig_ok or known_ok):
            return {
                'ok':False,'reason':'GRID_LEASE_PANEL_PRESENCE_LOST','lease_age_ms':round(age*1000.0,3),
                'panel_signature_distance':sig_dist,'panel_signature_limit':round(sig_limit,3),
                'known_grid_validation':{k:v for k,v in known.items() if k!='debug'},
            }
        if item is not None:
            try:
                col,row=[int(v) for v in (item.get('anchor') or [0,0])]
                fw,fh=[int(v) for v in (item.get('footprint') or [1,1])]
                if not (0<=col<6 and 0<=row<10 and col+fw<=6 and row+fh<=10):
                    return {'ok':False,'reason':'GRID_LEASE_SOURCE_ANCHOR_OUTSIDE','lease_age_ms':round(age*1000.0,3)}
            except Exception:
                return {'ok':False,'reason':'GRID_LEASE_SOURCE_ANCHOR_INVALID','lease_age_ms':round(age*1000.0,3)}
        grid=canonical_inventory_grid_snapshot(leased_grid,img)
        grid.update({'verified_grid_lease_id':lease.get('lease_id'),'verified_grid_generation':lease.get('generation')})
        return {'ok':True,'reason':'VERIFIED_GRID_LEASE_CONSUMED','grid':grid,'image':img,
                'lease_id':lease.get('lease_id'),'generation':lease.get('generation'),
                'lease_age_ms':round(age*1000.0,3),'full_grid_rediscovery':False,
                'panel_presence':'LEASE_MULTI_SIGNAL_CONFIRMED',
                'panel_signature_distance':sig_dist,'panel_signature_limit':round(sig_limit,3),
                'known_grid_ok':known_ok,'signature_ok':sig_ok}

    def _poll_source_grid_expected_layout(self, hwnd, timeout_sec):
        """Bounded multi-frame consensus; never sends a key/click."""
        t0=time.time(); polls=0; last=None; good=[]
        while time.time()-t0<=float(timeout_sec):
            polls+=1
            ready=self._capture_source_grid_visible(int(hwnd))
            current=self._verify_source_grid_expected_layout(ready)
            last=current
            if current.get('ok'):
                good.append(current)
                if len(good)>=VERIFIED_GRID_LEASE_STABILITY_FRAMES:
                    a=(good[-2].get('ready') or {}).get('grid') or {}
                    b=(good[-1].get('ready') or {}).get('grid') or {}
                    if self._grid_geometry_agrees(a,b,tolerance_px=2):
                        out=dict(good[-1]); out['polls']=polls
                        out['consensus_frames']=VERIFIED_GRID_LEASE_STABILITY_FRAMES
                        out['consensus_reason']='STABLE_6X10_GEOMETRY'
                        ia=(good[-2].get('ready') or {}).get('image'); ib=(good[-1].get('ready') or {}).get('image')
                        sa=self._inventory_panel_presence_signature(ia,a); sb=self._inventory_panel_presence_signature(ib,b)
                        sd=self._inventory_panel_signature_distance(sa,sb)
                        if sa and sb and sd:
                            out['panel_signature_consensus']={'reference':sb,'distance':sd,'frames':2}
                        return out
                    good=good[-1:]
            else:
                good=[]
            time.sleep(SOURCE_GRID_RECOVERY_POLL_SEC)
        out=dict(last or {'ok':False,'reason':'SOURCE_GRID_NOT_VISIBLE'})
        out['ok']=False; out['polls']=polls; out['consensus_frames']=len(good)
        out.setdefault('reason','SOURCE_GRID_EXPECTED_LAYOUT_TIMEOUT')
        return out

    def _recover_source_grid_preaction(self, hwnd, cycle_id, drop_tx_id, destructive_input_started=False):
        """InventoryLayoutRecovery for a Drop PRE-ACTION source-grid failure.

        Safety contract:
        - may run only before the source click / ground click of this drop_tx_id;
        - uses only get_inventory_hotkey() => F4 or Q;
        - preserves the existing queue item and drop_tx_id;
        - one initial hard-reset/open attempt plus one bounded close/reopen recovery;
        - never loops indefinitely and never invokes Filter again.

        The Stage-22 dispatcher already owns the outer DROP action reservation while
        this precheck runs. That reservation is not a mouse action. We allow only
        that SAME cycle's DROP reservation and reject any different in-flight action.
        """
        hwnd=int(hwnd); cycle_id=int(cycle_id or 0)
        if bool(destructive_input_started):
            return {
                'ok':False,'reason':'INVENTORY_LAYOUT_RECOVERY_BLOCKED_AFTER_DROP_INPUT',
                'safe_to_retry':False,'drop_tx_id':drop_tx_id,
            }
        if self._chest_is_stop_requested():
            return {
                'ok':False,'reason':'INVENTORY_LAYOUT_RECOVERY_ABORTED_USER_STOP',
                'safe_to_retry':False,'drop_tx_id':drop_tx_id,
            }

        control=self._chest_control_snapshot()
        if bool(control.get('action_in_flight')):
            same_drop_reservation=(
                str(control.get('action_name') or '')=='DROP'
                and int(control.get('action_owner_cycle') or 0)==cycle_id
            )
            if not same_drop_reservation:
                return {
                    'ok':False,'reason':'INVENTORY_LAYOUT_RECOVERY_BLOCKED_ACTION_IN_FLIGHT',
                    'safe_to_retry':False,'drop_tx_id':drop_tx_id,'control':control,
                }

        key=str(self.get_inventory_hotkey() or '')
        if key not in ('F4','Q'):
            return {
                'ok':False,'reason':'INVENTORY_LAYOUT_RECOVERY_INVALID_SELECTED_HOTKEY',
                'safe_to_retry':False,'drop_tx_id':drop_tx_id,'hotkey':key,
            }
        mode=str(self._cfg.get('input_mode','Auto') or 'Auto')
        steps=[]

        # Attempt 1: selected canonical inventory hotkey only.
        first=self.send_inventory_hotkey_once(hwnd,key,mode,'DROP_PREACTION_INITIAL')
        steps.append({'step':'SELECTED_HOTKEY_INITIAL','hotkey':key,'input':first})
        if not first.get('ok'):
            return {
                'ok':False,'reason':'INVENTORY_LAYOUT_RECOVERY_INITIAL_INPUT_FAILED',
                'safe_to_retry':False,'drop_tx_id':drop_tx_id,'hotkey':key,'steps':steps,
            }
        probe=self._poll_source_grid_expected_layout(hwnd,SOURCE_GRID_RECOVERY_PRIMARY_TIMEOUT_SEC)
        steps.append({'step':'VERIFY_AFTER_INITIAL','probe':{k:v for k,v in probe.items() if k!='ready'}})
        if probe.get('ok'):
            ready=probe.get('ready') or {}
            self._inventory_grid=ready.get('grid') or self._inventory_grid
            lease=self._create_verified_grid_lease(hwnd,ready,probe,'INITIAL_SELECTED_HOTKEY',key)
            return {
                'ok':True,'reason':'INVENTORY_LAYOUT_RECOVERED','hotkey':key,
                'drop_tx_id':drop_tx_id,'queue_preserved':True,'transaction_preserved':True,
                'recovery_stage':'INITIAL_SELECTED_HOTKEY','ready':ready,'verified_grid_lease':lease,'steps':steps,
            }

        # One bounded close/reopen recovery. Determine whether the source grid is
        # presently visible (even if drifted) before deciding whether a CLOSE press
        # is needed. If it is already absent/closed, skip the redundant close and
        # send only the reopen press.
        last_ready=probe.get('ready') if isinstance(probe,dict) else None
        source_open_now=bool(isinstance(last_ready,dict) and last_ready.get('ok'))
        if source_open_now:
            close_input=self.send_inventory_hotkey_once(hwnd,key,mode,'DROP_PREACTION_BOUNDED_CLOSE')
            steps.append({'step':'BOUNDED_CLOSE','hotkey':key,'input':close_input})
            if not close_input.get('ok'):
                return {
                    'ok':False,'reason':'INVENTORY_LAYOUT_RECOVERY_CLOSE_INPUT_FAILED',
                    'safe_to_retry':False,'drop_tx_id':drop_tx_id,'hotkey':key,'steps':steps,
                }
            # Short bounded settle only. No click and no Filter/queue mutation.
            time.sleep(min(.16,SOURCE_GRID_RECOVERY_POLL_SEC*3.0))
        else:
            steps.append({'step':'BOUNDED_CLOSE','skipped':True,'reason':'SOURCE_ALREADY_NOT_VISIBLE'})

        reopen_input=self.send_inventory_hotkey_once(hwnd,key,mode,'DROP_PREACTION_BOUNDED_REOPEN')
        steps.append({'step':'BOUNDED_REOPEN','hotkey':key,'input':reopen_input})
        if not reopen_input.get('ok'):
            return {
                'ok':False,'reason':'INVENTORY_LAYOUT_RECOVERY_REOPEN_INPUT_FAILED',
                'safe_to_retry':False,'drop_tx_id':drop_tx_id,'hotkey':key,'steps':steps,
            }
        reprobe=self._poll_source_grid_expected_layout(hwnd,SOURCE_GRID_RECOVERY_REOPEN_TIMEOUT_SEC)
        steps.append({'step':'VERIFY_AFTER_REOPEN','probe':{k:v for k,v in reprobe.items() if k!='ready'}})
        if reprobe.get('ok'):
            ready=reprobe.get('ready') or {}
            self._inventory_grid=ready.get('grid') or self._inventory_grid
            lease=self._create_verified_grid_lease(hwnd,ready,reprobe,'BOUNDED_CLOSE_REOPEN',key)
            return {
                'ok':True,'reason':'INVENTORY_LAYOUT_RECOVERED','hotkey':key,
                'drop_tx_id':drop_tx_id,'queue_preserved':True,'transaction_preserved':True,
                'recovery_stage':'BOUNDED_CLOSE_REOPEN','ready':ready,'verified_grid_lease':lease,'steps':steps,
            }
        return {
            'ok':False,'reason':'INVENTORY_LAYOUT_RECOVERY_FAILED','hotkey':key,
            'safe_to_retry':False,'drop_tx_id':drop_tx_id,'queue_preserved':True,
            'transaction_preserved':True,'final_probe':reprobe,'steps':steps,
        }

    def inventory_calibrate(self, hwnd):
        try:
            ready = self._capture_inventory_ready(hwnd, try_open=True)
            if not ready.get("ok"):
                return ready

            self._inventory_grid = ready["grid"]
            snap = snapshot_inventory(ready["image"], self._inventory_grid)
            self._inventory_last = snap

            stamp = time.strftime("%Y%m%d_%H%M%S")
            result = {
                "ok": True,
                "grid": self._inventory_grid,
                "occupied_count": snap.get("occupied_count"),
                "free_count": snap.get("free_count"),
                "inventory_opened_by_auto": ready.get("opened", False),
            }
            (LOGDIR / f"{stamp}_inventory_calibration.json").write_text(
                json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return result
        except Exception as e:
            return {"ok": False, "error": str(e), "trace": traceback.format_exc(limit=5)}

    def inventory_snapshot(self, hwnd, set_baseline=False):
        try:
            ready = self._capture_inventory_ready(hwnd, try_open=True)
            if not ready.get("ok"):
                return ready

            self._inventory_grid = ready["grid"]
            snap = snapshot_inventory(ready["image"], self._inventory_grid)
            self._inventory_last = snap
            if set_baseline:
                self._inventory_baseline = snap

            stamp = time.strftime("%Y%m%d_%H%M%S")
            serial = json.loads(json.dumps(snap))
            # sensor signatures are intentionally internal only
            for c in serial.get("cells", []):
                c.pop("_sig", None)
            payload = {
                "ok": True,
                "baseline_set": bool(set_baseline),
                "occupied_count": snap.get("occupied_count"),
                "free_count": snap.get("free_count"),
                "grid": snap.get("grid"),
            }
            (LOGDIR / f"{stamp}_inventory_snapshot.json").write_text(
                json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return payload
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def inventory_detect_changes(self, hwnd):
        try:
            if self._inventory_baseline is None:
                return {"ok": False, "reason": "BASELINE_NOT_SET"}

            ready = self._capture_inventory_ready(hwnd, try_open=False)
            if not ready.get("ok"):
                return ready

            grid = ready["grid"]
            after = snapshot_inventory(ready["image"], grid)
            diff = diff_snapshots(self._inventory_baseline, after)
            self._inventory_last = after

            stamp = time.strftime("%Y%m%d_%H%M%S")
            (LOGDIR / f"{stamp}_inventory_diff.json").write_text(
                json.dumps(diff, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return diff
        except Exception as e:
            return {"ok": False, "error": str(e)}


    def _build_queue_from_candidates(self, candidates):
        queue = []
        for idx, raw in enumerate(candidates or [], 1):
            item = dict(raw)
            item["queue_id"] = f"Q{idx:02d}"
            item["status"] = "PENDING"
            item["group_id"] = None
            item["group_label"] = None
            item["group_confidence"] = 0.0
            item["decision"] = "PENDING"
            item["reason"] = None
            queue.append(item)
        self._new_item_queue = queue
        self._queue_read_results = []
        return queue

    def chest_get_queue(self):
        return {
            "ok": True,
            "count": len(self._new_item_queue),
            "items": [public_queue_item(x) for x in self._new_item_queue],
        }

    def _queue_item_by_index(self, item_index):
        try:
            idx = int(item_index)
        except Exception:
            return None
        if 0 <= idx < len(self._new_item_queue):
            return self._new_item_queue[idx]
        return None

    def _autoroll_popup_park_point(self):
        p=getattr(self,'_autoroll_popup_park_screen',None)
        if isinstance(p,(list,tuple)) and len(p)==2:
            try: return [int(p[0]),int(p[1])]
            except Exception: return None
        return None

    def _autoroll_restore_popup_park(self, old_cursor=None):
        park=self._autoroll_popup_park_point()
        if park:
            _set_cursor_screen(int(park[0]),int(park[1]))
            return
        if old_cursor:
            _set_cursor_screen(*old_cursor)

    def _autoroll_hover_capture_pulse(self, hwnd, cx, cy, settle_sec):
        """AutoRoll-only: expose tooltip, capture once, then park at Popup click."""
        park=self._autoroll_popup_park_point()
        if not park:
            time.sleep(float(settle_sec))
            return capture_client(hwnd)
        sp=_client_to_screen(hwnd,int(cx),int(cy))
        if not sp:
            self._autoroll_restore_popup_park()
            return None
        sx,sy=int(sp[0]),int(sp[1])
        _set_cursor_screen(max(0,sx-3),max(0,sy-3))
        time.sleep(.015)
        _set_cursor_screen(sx,sy)
        time.sleep(float(settle_sec))
        img=capture_client(hwnd)
        self._autoroll_restore_popup_park()
        return img

    def _capture_tooltip_at_candidate(self, hwnd, candidate, stamp_prefix, reuse_session=False):
        """Capture tooltip with an adaptive fast-first hover.

        v7.6: queue_read_all keeps one focused inventory session for the whole
        batch. In that session we skip the repeated activate + header click per
        item. We also try a short hover first and only wait longer when the
        tooltip is genuinely late.
        """
        if not self._inventory_grid:
            return {"ok": False, "reason": "GRID_NOT_READY"}

        points = hover_points_for_candidate(candidate, self._inventory_grid)
        if not points:
            return {"ok": False, "reason": "INVALID_ITEM_FOOTPRINT"}

        if reuse_session:
            activation = {"ok": True, "reused": True}
            focus = {"ok": True, "reused": True, "old_cursor": _cursor_screen()}
        else:
            activation = _activate_window(hwnd)
            time.sleep(.045)
            focus = _safe_inventory_header_click(hwnd, self._inventory_grid)
            if not focus.get("ok"):
                return {
                    "ok": False,
                    "reason": focus.get("reason", "CLIENT_AREA_HANDSHAKE_FAILED"),
                    "focus_handshake": focus,
                    "activation": activation,
                }

        old_cursor = focus.get("old_cursor") or _cursor_screen()
        autoroll_popup_park = self._autoroll_popup_park_point()
        chosen = None
        first_crop_path = None
        first_det = None

        try:
            hover_attempts = []
            for point_index, (cx, cy) in enumerate(points):
                sp = _client_to_screen(hwnd, cx, cy)
                if not sp:
                    continue
                sx, sy = int(sp[0]), int(sp[1])

                # Fast-first hover: most JX1 tooltips are already present well
                # before the old fixed 340 ms wait. If not, one delayed retry
                # preserves robustness without making every item pay the cost.
                _set_cursor_screen(max(0, sx-3), max(0, sy-3))
                time.sleep(.015)
                _set_cursor_screen(sx, sy)
                time.sleep(.060)

                point_found = False
                for sample_idx, extra_wait in enumerate((0.0, 0.075)):
                    if extra_wait:
                        time.sleep(extra_wait)
                    img = capture_client(hwnd)
                    if img is None:
                        hover_attempts.append({
                            "point_index": point_index,
                            "client": [cx,cy],
                            "sample": sample_idx+1,
                            "status": "CAPTURE_FAILED",
                        })
                        continue

                    det = detect_tooltip_near_cursor(img, (cx, cy))
                    hover_attempts.append({
                        "point_index": point_index,
                        "client": [cx,cy],
                        "sample": sample_idx+1,
                        "status": det.get("status"),
                        "candidate_lines": det.get("candidate_lines"),
                        "score": det.get("score"),
                        "crop_strategy": det.get("crop_strategy"),
                        "panel_tightened": det.get("panel_tightened"),
                        "reject_reason": det.get("reason"),
                    })

                    if det.get("status") == "FOUND":
                        crop = det["crop"]
                        crop_path = LOGDIR / f"{stamp_prefix}_hover{point_index+1}_frame1.png"
                        crop.save(crop_path)
                        chosen = (cx, cy)
                        first_crop_path = crop_path
                        first_det = det
                        point_found = True
                        if autoroll_popup_park:
                            self._autoroll_restore_popup_park()
                        break

                if point_found:
                    break

            if chosen is None:
                if autoroll_popup_park:
                    self._autoroll_restore_popup_park()
                elif old_cursor and not reuse_session:
                    _set_cursor_screen(*old_cursor)
                return {
                    "ok": False,
                    "reason": "TOOLTIP_NOT_FOUND_ON_ITEM",
                    "hover_points": [list(p) for p in points],
                    "hover_attempts": hover_attempts,
                    "focus_handshake": focus,
                    "activation": activation,
                }

            if autoroll_popup_park:
                self._autoroll_restore_popup_park()
            return {
                "ok": True,
                "hover_client": [int(chosen[0]), int(chosen[1])],
                "hover_attempts": hover_attempts,
                "first_crop": str(first_crop_path),
                "first_detector": {
                    "rect": first_det.get("rect"),
                    "candidate_lines": first_det.get("candidate_lines"),
                    "score": first_det.get("score"),
                    "soft_candidate": first_det.get("soft_candidate"),
                    "crop_strategy": first_det.get("crop_strategy"),
                    "panel_tightened": first_det.get("panel_tightened"),
                    "expanded_rect": first_det.get("expanded_rect"),
                },
                "old_cursor": old_cursor,
                "focus_handshake": focus,
                "activation": activation,
            }
        except Exception as e:
            if autoroll_popup_park:
                self._autoroll_restore_popup_park()
            elif old_cursor and not reuse_session:
                _set_cursor_screen(*old_cursor)
            return {
                "ok": False,
                "reason": "HOVER_EXCEPTION",
                "error": str(e),
                "focus_handshake": focus,
                "activation": activation,
            }

    def _read_queue_item_internal(self, hwnd, item_index, batch_session=False, execution_mode='READER_TEST'):
        # Execution mode is control-plane metadata only. It MUST NOT alter OCR,
        # Final6, Skill authority, registry, or filter semantics.
        execution_mode=str(execution_mode or 'READER_TEST').upper()
        live_actions_enabled=(execution_mode == 'LIVE_CHEST_TEST')
        global TESSERACT
        if not TESSERACT:
            TESSERACT = configure_tesseract() or TESSERACT
        if not TESSERACT:
            return {"ok": False, "reason": "OCR_NOT_READY"}

        item = self._queue_item_by_index(item_index)
        if item is None:
            return {"ok": False, "reason": "QUEUE_ITEM_NOT_FOUND"}

        if not batch_session:
            ready = self._capture_inventory_ready(hwnd, try_open=True)
            if not ready.get("ok"):
                return ready
            self._inventory_grid = ready["grid"]

        stamp = time.strftime("%Y%m%d_%H%M%S") + f"_{item.get('queue_id','Q')}"
        hover = self._capture_tooltip_at_candidate(hwnd, item, stamp, reuse_session=batch_session)
        if not hover.get("ok"):
            item["status"] = "UNCERTAIN"
            item["decision"] = "UNCERTAIN"
            item["reason"] = hover.get("reason")
            return {"ok": False, "item": public_queue_item(item), **hover}

        cx, cy = hover["hover_client"]
        old_cursor = hover.get("old_cursor")
        first_crop = Path(hover["first_crop"])

        # v7.4 FAST PATH ----------------------------------------------------
        # The user's active filter is the source of truth. Scan ONE whole
        # final-6 block first. Obvious trash can be rejected without the heavy
        # 3-frame general reader or full-tooltip group OCR.
        try:
            fast_cfg = getattr(self, '_batch_filter_cache', None) if batch_session else None
            if not isinstance(fast_cfg, dict):
                fast_cfg = _load_option_filter()
        except Exception:
            fast_cfg = _default_option_filter()

        if _filter_has_enabled_rules(fast_cfg):
            fast_crop_files = [str(first_crop)]
            fast_filter = _fast_evaluate_profiles(fast_crop_files, fast_cfg)

            # Only ambiguous wanted evidence earns ONE extra fast frame.
            if fast_filter.get("decision") == "UNCERTAIN":
                if self._autoroll_popup_park_point():
                    fast_img = self._autoroll_hover_capture_pulse(hwnd,cx,cy,.060)
                else:
                    time.sleep(.04)
                    fast_img = capture_client(hwnd)
                if fast_img is not None:
                    fast_det = detect_tooltip_near_cursor(fast_img, (cx, cy))
                    if fast_det.get("status") == "FOUND":
                        fast_crop2 = LOGDIR / f"{stamp}_fast_frame2.png"
                        fast_det["crop"].save(fast_crop2)
                        fast_crop_files.append(str(fast_crop2))
                        fast_filter = _fast_evaluate_profiles(fast_crop_files, fast_cfg)

            fast_decision = fast_filter.get("decision")
            fast_scope = str(fast_cfg.get("scope", "GLOBAL")).upper()
            fast_group_pick = None
            fast_anchor_scan = None

            # FAIL is final regardless of item group: the configured mandatory
            # options are absent/below threshold, so the item cannot qualify.
            # PASS is final immediately for GLOBAL filters.
            fast_final = None
            if fast_decision == "FAIL":
                fast_final = "FAIL"
            elif fast_decision == "PASS" and fast_scope == "GLOBAL":
                fast_final = "KEEP"
            elif fast_decision == "PASS" and fast_scope in ("GROUP", "FAMILY", "PROFILE"):
                # Stage 29.3 / v10.1: configured rule NAMES are requests, not
                # observations. Reuse only strong matches that were actually seen
                # in the CURRENT tooltip. If those actual matches do not establish
                # identity, fall back to the existing full-tooltip unique-anchor scan.
                observed_names,observed_evidence=_actual_fast_observed_names(fast_filter)
                # V12.2 scope truth: group identity consumes the complete canonical
                # V12 ObservedOptionSet, not only the configured rule's hit. This
                # lets weapon hard anchors (attack speed / elemental / physical
                # damage) establish Vũ khí without falling back to noisy tooltip OCR.
                v12_names,v12_evidence=_v122_all_canonical_observed_names(fast_filter)
                observed_names=list(dict.fromkeys(list(observed_names)+list(v12_names)))
                observed_evidence=list(observed_evidence)+list(v12_evidence)
                try:
                    fast_group_pick = classify_group_from_options(
                        observed_names, item.get("footprint"), OPTION_DB
                    )
                    fast_group_pick["anchor_scan"] = {
                        "source":"V12_CURRENT_TOOLTIP_CANONICAL_OBSERVED_SET",
                        "canonical_hits":observed_names,
                        "hits":observed_evidence,
                        "ocr_skipped":True,
                        "configured_filter_used_as_evidence":False,
                    }
                    # If actual fast observations cannot establish identity, use
                    # the existing unique-anchor scanner on the same captured tooltip.
                    if not fast_group_pick.get("identity_known"):
                        fast_anchor_scan = scan_full_tooltip_anchors(first_crop, final6_names=observed_names)
                        fast_group_pick = classify_group_from_options(
                            fast_anchor_scan.get("canonical_hits", []),
                            item.get("footprint"), OPTION_DB
                        )
                        fast_group_pick["anchor_scan"] = fast_anchor_scan
                    else:
                        fast_anchor_scan = fast_group_pick.get("anchor_scan")
                except Exception as e:
                    fast_group_pick = {
                        "group_id":None,"group_label":"Chưa xác định",
                        "family":"CHUNG","confidence":0.0,"ambiguous":True,
                        "identity_known":False,"reason":"FAST_GROUP_SCAN_FAILED",
                        "error":str(e)
                    }
                if _search_filter_applies(fast_cfg, fast_group_pick):
                    fast_final = "KEEP"
                elif fast_group_pick and (
                    (not fast_group_pick.get("ambiguous")) or
                    fast_group_pick.get("identity_known")
                ):
                    fast_final = "FAIL"
                # Unknown group remains UNCERTAIN and may fall through to the
                # heavy legacy reader for safety.

            if fast_final is not None:
                if fast_group_pick is None:
                    item["group_id"] = None
                    item["group_label"] = "Chưa xác định"
                    item["group_confidence"] = 0.0
                    item["group_reason"] = "GROUP_SCAN_SKIPPED_FAST_PATH"
                    item["group_family"] = None
                    item["group_identity_known"] = False
                else:
                    gid = fast_group_pick.get("group_id")
                    item["group_id"] = gid if not fast_group_pick.get("ambiguous") else None
                    item["group_label"] = fast_group_pick.get("group_label") or "Chưa xác định"
                    item["group_confidence"] = fast_group_pick.get("confidence",0.0)
                    item["group_reason"] = fast_group_pick.get("reason")
                    item["group_family"] = fast_group_pick.get("family")
                    item["group_identity_known"] = bool(fast_group_pick.get("identity_known"))

                item["hover_client"] = [cx,cy]
                item["reader_status"] = "FAST_SCAN"
                item["decision"] = fast_final
                item["status"] = "KEEP" if fast_final == "KEEP" else "NO_MATCH"
                item["reason"] = (
                    "FAST_CONFIGURED_CONDITIONS_MET" if fast_final == "KEEP"
                    else "FAST_CONFIGURED_CONDITIONS_NOT_MET"
                )
                result = {
                    "ok":True,
                    "queue_item":public_queue_item(item),
                    "possible_groups":possible_groups_for_footprint(item.get("footprint")),
                    "group_pick":fast_group_pick,
                    "anchor_scan":fast_anchor_scan,
                    "identity_rule_version":"FAST_ACTUAL_TOOLTIP_ANCHORS_V10_2",
                    "frames_captured":len(fast_crop_files),
                    "reader":{
                        "status":"FAST_SCAN",
                        "lines":[],
                        "pipeline":"MULTI_PROFILE_SHARED_EVIDENCE_V1",
                        "paddle_runtime_bridge":fast_filter.get("paddle_runtime_bridge"),
                        "paddle_runtime_used":bool((fast_filter.get("paddle_runtime_bridge") or {}).get("used")),
                    },
                    "fast_filter":fast_filter,
                    "filter":fast_filter,
                    "filter_result":("MATCH" if fast_final=="KEEP" else "REJECT"),
                    "reject_authority":((fast_filter or {}).get("reject_authority") if fast_final=="FAIL" else "NOT_APPLICABLE"),
                    "matched_profile_id":fast_filter.get("matched_profile_id") if fast_final=="KEEP" else None,
                    "disposition":("KEEP" if fast_final=="KEEP" else "DROP"),
                    "decision":fast_final,
                    "hover_client":[cx,cy],
                    "focus_handshake":hover.get("focus_handshake"),
                    "detector_debug":[hover.get("first_detector")],
                    "crop_files":fast_crop_files,
                    "performance_path":"MULTI_PROFILE_SHARED_EVIDENCE_V1",
                    "execution_mode":execution_mode,
                    "live_actions_enabled":live_actions_enabled,"sell":False,
                    "drop":bool(live_actions_enabled and fast_final == "FAIL"),
                    "keep":bool(live_actions_enabled and fast_final == "KEEP"),
                    "store":False,
                    "build_id":V107_BUILD_ID,"runtime_provenance":getattr(self,'_runtime_provenance',_v107_runtime_provenance()),
                    "filter_config_generation":int(getattr(self,'_filter_config_generation',0) or 0),
                    "ui_filter_snapshot":getattr(self,'_last_ui_filter_snapshot',None),
                    "ui_filter_hash":getattr(self,'_last_ui_filter_hash',None),
                    "backend_filter_snapshot":_v107_canonical_filter_snapshot(fast_cfg),
                    "backend_filter_hash":_v107_json_hash(_v107_canonical_filter_snapshot(fast_cfg)),
                }
                (LOGDIR / f"{stamp}_queue_read.json").write_text(
                    json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
                )
                self._autoroll_restore_popup_park(old_cursor)
                return result

        # V10.7: an unresolved scope/group identity or OCR ambiguity may NEVER
        # overwrite a proven profile MATCH with outer REJECT. This was the first
        # real divergence in logs(20261002-113325): nested MATCH -> outer REJECT -> DROP.
        # Keep the item non-destructive and let the caller perform one bounded reread.
        if _filter_has_enabled_rules(fast_cfg):
            item["hover_client"]=[cx,cy]
            item["reader_status"]="FAST_SCAN"
            item["decision"]="UNCERTAIN"
            item["status"]="UNCERTAIN"
            nested_match=bool((fast_filter or {}).get('filter_result')=='MATCH' or (fast_filter or {}).get('decision')=='PASS')
            unresolved_reason='PROFILE_MATCH_SCOPE_IDENTITY_UNRESOLVED' if nested_match else str((fast_filter or {}).get('unresolved_reason') or (fast_filter or {}).get('reason') or 'TRUE_TARGET_COMPATIBILITY_AMBIGUITY')
            item["reason"]=unresolved_reason
            snap=_v107_canonical_filter_snapshot(fast_cfg); bh=_v107_json_hash(snap)
            result={
                "ok":True,"safe_pause":False,"reason":unresolved_reason,
                "rejection_reason":None,"disposition":"BLOCK","queue_item":public_queue_item(item),
                "possible_groups":possible_groups_for_footprint(item.get("footprint")),
                "group_pick":fast_group_pick,"anchor_scan":fast_anchor_scan,
                "identity_rule_version":"V10_7_MATCH_CANNOT_DOWNGRADE_TO_REJECT",
                "frames_captured":len(fast_crop_files),
                "reader":{
                    "status":"FAST_SCAN",
                    "lines":[],
                    "pipeline":"FINAL6_DIRECT_ROW_ROI_V10_9_RUNTIME_TRUTH",
                    "paddle_runtime_bridge":fast_filter.get("paddle_runtime_bridge"),
                    "paddle_runtime_used":bool((fast_filter.get("paddle_runtime_bridge") or {}).get("used")),
                },
                "fast_filter":fast_filter,"filter":fast_filter,"filter_result":"UNRESOLVED","reject_authority":"UNRESOLVED","decision":"UNCERTAIN",
                "nested_filter_result":(fast_filter or {}).get('filter_result'),
                "matched_profile_id":(fast_filter or {}).get('matched_profile_id'),
                "hover_client":[cx,cy],"focus_handshake":hover.get("focus_handshake"),
                "detector_debug":[hover.get("first_detector")],"crop_files":fast_crop_files,
                "performance_path":"MULTI_PROFILE_SHARED_EVIDENCE_V10_9_RECOVERY_SAFE",
                "execution_mode":execution_mode,"live_actions_enabled":live_actions_enabled,
                "sell":False,"drop":False,"store":False,
                "build_id":V107_BUILD_ID,"runtime_provenance":getattr(self,'_runtime_provenance',_v107_runtime_provenance()),
                "filter_config_generation":int(getattr(self,'_filter_config_generation',0) or 0),
                "ui_filter_snapshot":getattr(self,'_last_ui_filter_snapshot',None),
                "ui_filter_hash":getattr(self,'_last_ui_filter_hash',None),
                "backend_filter_snapshot":snap,"backend_filter_hash":bh,
            }
            (LOGDIR/f"{stamp}_queue_read.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
            self._autoroll_restore_popup_park(old_cursor)
            return result

        # Legacy heavy reader remains available only when there is NO active
        # configured filter (diagnostic/general-reader mode).
        # Legacy heavy reader is now FALLBACK ONLY for genuinely unresolved
        # wanted evidence / incomplete tooltip geometry.

        # v4.8: OCR is independent from equipment-group classification.
        # Read the six option rows ONCE against the global option catalog.
        possible_groups = possible_groups_for_footprint(item.get("footprint"))
        frame1_global = read_single_tooltip(first_crop, "__all__")

        # Reuse global frame 1 result, then capture 2 more global frames.
        frames = [frame1_global]
        detector_debug = [hover.get("first_detector")]
        crop_files = [str(first_crop)]

        for fi in (2, 3):
            if self._autoroll_popup_park_point():
                img = self._autoroll_hover_capture_pulse(hwnd,cx,cy,.16)
            else:
                time.sleep(.16)
                img = capture_client(hwnd)
            if img is None:
                continue
            det = detect_tooltip_near_cursor(img, (cx, cy))
            if det.get("status") != "FOUND":
                detector_debug.append({
                    "frame": fi,
                    "status": "TOOLTIP_NOT_FOUND",
                    "candidates": det.get("candidates", []),
                })
                continue
            crop_path = LOGDIR / f"{stamp}_frame{fi}.png"
            det["crop"].save(crop_path)
            crop_files.append(str(crop_path))
            detector_debug.append({
                "frame": fi,
                "status": "FOUND",
                "rect": det.get("rect"),
                "candidate_lines": det.get("candidate_lines"),
                "score": det.get("score"),
                "crop_strategy": det.get("crop_strategy"),
                "panel_tightened": det.get("panel_tightened"),
                "expanded_rect": det.get("expanded_rect"),
            })
            frames.append(read_single_tooltip(crop_path, "__all__"))

        final_reader = consensus(frames)

        # v6.0: GROUP identity is completely separate from the final-6 filter.
        # Search the ENTIRE tooltip for user-confirmed UNIQUE anchors, because
        # an anchor such as "Thời gian phục hồi" may sit above the final six.
        final6_names = [
            x.get("name")
            for x in final_reader.get("lines", [])
            if x.get("name")
        ]
        # v6.1 HOTFIX: use the actual Path created above (`first_crop`).
        try:
            anchor_scan = scan_full_tooltip_anchors(
                first_crop,
                final6_names=[]  # v10.1: canonical reader labels are not classification evidence
            )
        except Exception as anchor_error:
            # Grouping is secondary metadata and must never abort final-6 reading.
            anchor_scan = {
                "ok": False,
                "canonical_hits": [],
                "groups": [],
                "hits": [],
                "ocr_lines": [],
                "line_count": 0,
                "conflict": False,
                "policy": "ANCHOR_SCAN_FAILED_NON_FATAL",
                "error": str(anchor_error),
            }

        # Only unique anchor names are allowed to classify. Other random options
        # do not vote and do not oppose the anchor.
        try:
            group_pick = classify_group_from_options(
                anchor_scan.get("canonical_hits", []),
                item.get("footprint"),
                OPTION_DB
            )
        except Exception as classify_error:
            group_pick = {
                "group_id": None,
                "group_label": "Chung",
                "family": "CHUNG",
                "confidence": 0.0,
                "ambiguous": True,
                "identity_known": False,
                "reason": "GROUP_CLASSIFIER_FAILED_NON_FATAL",
                "evidence": {},
                "ranking": [],
                "recognized_options": [],
                "error": str(classify_error),
            }
        group_pick["anchor_scan"] = anchor_scan

        chosen_group = group_pick.get("group_id")
        group_ambiguous = bool(group_pick.get("ambiguous"))
        possible_groups = possible_groups_for_footprint(item.get("footprint"))

        filter_result = None
        decision = "READ_OK" if final_reader.get("status") == "READY" else "UNCERTAIN"

        # v5.9: search wanted OPTs first; group is optional metadata.
        try:
            cfg = _load_option_filter()
            if _filter_has_enabled_rules(cfg) and _search_filter_applies(cfg, group_pick):
                filter_result = _evaluate_search_filter(final_reader, cfg, frames=frames)
                fd = filter_result.get("decision")
                if fd == "PASS":
                    decision = "KEEP"
                elif fd == "FAIL":
                    decision = "FAIL"
                else:
                    decision = "UNCERTAIN"
        except Exception:
            filter_result = None

        item["group_id"] = chosen_group if not group_ambiguous else None
        item["group_label"] = group_pick.get("group_label") or (
            GROUP_LABELS.get(chosen_group, chosen_group) if chosen_group else "Chưa xác định"
        )
        item["group_confidence"] = group_pick.get("confidence", 0.0)
        item["hover_client"] = [cx, cy]
        item["reader_status"] = final_reader.get("status", "UNCERTAIN")
        item["decision"] = decision
        # v6.8: queue status must show the action decision, not whole-reader OCR state.
        if decision == "KEEP":
            item["status"] = "KEEP"
        elif decision == "FAIL":
            item["status"] = "NO_MATCH"
        elif decision == "UNCERTAIN":
            item["status"] = "NEED_REVIEW"
        else:
            item["status"] = final_reader.get("status", "UNCERTAIN")

        # v5.8: group identity is optional metadata.
        # A successful 6-option read stays READY even when group_id is unknown.
        if decision == "KEEP":
            item["reason"] = "WANTED_OPTION_MATCH"
        elif decision == "FAIL":
            item["reason"] = "WANTED_OPTION_NOT_FOUND"
        elif filter_result is not None:
            item["reason"] = filter_result.get("reason") or "WANTED_SCAN_UNCERTAIN"
        elif final_reader.get("status") == "OCR_ENGINE_EMPTY":
            item["reason"] = "OCR_ENGINE_EMPTY"
        elif final_reader.get("status") == "IMAGE_READ_FAILED":
            item["reason"] = "IMAGE_READ_FAILED"
        elif final_reader.get("status") == "READY":
            item["reason"] = None
        else:
            item["reason"] = "READER_NOT_READY"

        item["group_reason"] = group_pick.get("reason")
        item["group_family"] = group_pick.get("family")
        item["group_identity_known"] = bool(group_pick.get("identity_known"))

        result = {
            "ok": True,
            "queue_item": public_queue_item(item),
            "possible_groups": possible_groups,
            "group_pick": group_pick,
            "anchor_scan": anchor_scan,
            "identity_rule_version": "FULL_TOOLTIP_ANCHORS_V6_0_TRUTH_GATE_V6_3",
            "frames_captured": len(frames),
            "reader": final_reader,
            "last6_debug": {
                "frame1_segmentation": frames[0].get("segmentation") if frames else None,
                "rule": "FINAL_6_OPTION_ROWS"
            },
            "filter": filter_result,
            "decision": decision,
            "hover_client": [cx, cy],
            "focus_handshake": hover.get("focus_handshake"),
            "detector_debug": detector_debug,
            "crop_files": crop_files,
            "execution_mode": execution_mode,
            "live_actions_enabled": live_actions_enabled,
            "sell": False,
            "drop": bool(live_actions_enabled and decision == "FAIL"),
            "keep": bool(live_actions_enabled and decision == "KEEP"),
            "store": False,
        }

        (LOGDIR / f"{stamp}_queue_read.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
        )

        self._autoroll_restore_popup_park(old_cursor)

        return result

    def queue_read_item(self, hwnd, item_index):
        try:
            return self._read_queue_item_internal(int(hwnd), int(item_index))
        except Exception as e:
            err = {
                "ok": False,
                "reason": "QUEUE_READ_EXCEPTION",
                "error": str(e),
                "trace": traceback.format_exc(limit=12),
            }
            try:
                stamp = time.strftime("%Y%m%d_%H%M%S")
                (LOGDIR / f"{stamp}_queue_read_exception.json").write_text(
                    json.dumps(err, ensure_ascii=False, indent=2),
                    encoding="utf-8"
                )
            except Exception:
                pass
            return err

    def queue_read_all(self, hwnd):
        try:
            hwnd = int(hwnd)
            if not self._new_item_queue:
                return {"ok": False, "reason": "QUEUE_EMPTY"}

            old_cursor = _cursor_screen()

            # v7.6 ULTRA-FAST READ SESSION: prepare inventory/focus exactly
            # once for the whole queue instead of repeating it per item.
            ready = self._capture_inventory_ready(hwnd, try_open=True)
            if not ready.get("ok"):
                return ready
            self._inventory_grid = ready["grid"]
            try:
                self._batch_filter_cache = _load_option_filter()
            except Exception:
                self._batch_filter_cache = _default_option_filter()
            activation = _activate_window(hwnd)
            time.sleep(.035)
            session_focus = _safe_inventory_header_click(hwnd, self._inventory_grid)
            if not session_focus.get("ok"):
                return {"ok":False,"reason":"BATCH_FOCUS_HANDSHAKE_FAILED",
                        "focus_handshake":session_focus,"activation":activation}

            results = []
            ready_count = 0
            uncertain_count = 0
            keep_count = 0
            fail_count = 0
            read_ok_count = 0

            for idx in range(len(self._new_item_queue)):
                r = self._read_queue_item_internal(hwnd, idx, batch_session=True)
                results.append(r)
                decision = r.get("decision") or r.get("queue_item",{}).get("decision")
                status = r.get("reader",{}).get("status") or r.get("queue_item",{}).get("status")

                # v7.4: a resolved FAST_SCAN (KEEP/FAIL) is a completed read,
                # not an uncertain item. Only unresolved decisions count toward
                # XEM XÉT/uncertain statistics.
                if status in ("READY", "FAST_SCAN") or decision in ("KEEP", "FAIL"):
                    ready_count += 1
                else:
                    uncertain_count += 1

                if decision == "KEEP":
                    keep_count += 1
                elif decision == "FAIL":
                    fail_count += 1
                elif decision == "READ_OK":
                    read_ok_count += 1

                # Safety: reader uncertainty does not stop the queue, because this is
                # Dry Run only. It remains forbidden from selling/dropping/storing.
                time.sleep(.005)

            if old_cursor:
                _set_cursor_screen(*old_cursor)

            summary = {
                "ok": True,
                "queue_count": len(self._new_item_queue),
                "ready_count": ready_count,
                "uncertain_count": uncertain_count,
                "keep_count": keep_count,
                "fail_count": fail_count,
                "read_ok_count": read_ok_count,
                "items": [public_queue_item(x) for x in self._new_item_queue],
                "results": results,
                "execution_mode": "READER_TEST",
                "live_actions_enabled": False,
                "sell": False,
                "drop": False,
                "store": False,
            }
            self._queue_read_results = results
            stamp = time.strftime("%Y%m%d_%H%M%S")
            (LOGDIR / f"{stamp}_queue_read_all.json").write_text(
                json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return summary
        except Exception as e:
            return {
                "ok": False,
                "reason": "QUEUE_READ_ALL_EXCEPTION",
                "error": str(e),
                "trace": traceback.format_exc(limit=6),
            }

    def _wait_for_new_item_after_open(self, hwnd, before_snapshot, timeout_sec=3.0, poll_sec=0.07):
        """Fast inventory confirmation after one chest open.

        v8.0 removes two expensive operations from every poll:
          * do NOT re-activate JX1 when it is already foreground;
          * validate the cached inventory grid first and run full grid detection
            only when that cached geometry is no longer valid.

        The safety contract stays exactly-once: this function never sends a key.
        It only confirms that one new inventory item appeared.
        """
        deadline = time.time() + float(timeout_sec)
        polls = 0
        detector_misses = 0
        best_diff = None
        best_after = None
        best_grid = None
        started = time.time()

        while time.time() < deadline:
            polls += 1
            time.sleep(float(poll_sec))

            # capture_client() is visible-screen capture.  Re-activate only if
            # focus was actually stolen; avoiding _activate_window() here saves
            # ~120 ms on every normal poll.
            try:
                if int(user32_bridge.GetForegroundWindow() or 0) != int(hwnd):
                    _activate_window(hwnd)
            except Exception:
                pass

            img = capture_client(hwnd)
            if img is None:
                continue

            g = {"ok": False}
            if self._inventory_grid:
                known = validate_known_grid(img, self._inventory_grid)
                if known.get("ok"):
                    g = dict(self._inventory_grid)
                    g["ok"] = True
                    g["known_grid_validation"] = known

            if not g.get("ok"):
                g = detect_inventory_grid(img)
                if g.get("ok"):
                    self._inventory_grid = g

            if not g.get("ok"):
                detector_misses += 1
                continue

            after = snapshot_inventory(img, g)
            d = diff_snapshots(before_snapshot, after)

            if best_diff is None or len(d.get("changed_cells", [])) > len(best_diff.get("changed_cells", [])):
                best_diff = d
                best_after = after
                best_grid = g

            if int(d.get("new_item_count", 0)) >= 1:
                return {
                    "ok": True,
                    "after": after,
                    "grid": g,
                    "diff": d,
                    "polls": polls,
                    "confirm_ms": int((time.time() - started) * 1000),
                    "detector_misses": detector_misses,
                    "fast_poll": True,
                }

        return {
            "ok": False,
            "after": best_after,
            "grid": best_grid,
            "diff": best_diff or {
                "new_item_count": 0,
                "new_item_candidates": [],
                "changed_cells": [],
                "new_item_detection_mode": "NONE",
            },
            "polls": polls,
            "confirm_ms": int((time.time() - started) * 1000),
            "detector_misses": detector_misses,
            "reason": "NEW_ITEM_CONFIRM_TIMEOUT",
            "fast_poll": True,
        }

    def _select_one_candidate_per_chest(self, candidates):
        arr = list(candidates or [])
        if not arr:
            return []
        arr.sort(
            key=lambda x: (
                float(x.get("confidence",0.0)),
                float(x.get("mean_pixel_diff",0.0)),
                int(x.get("cell_count",0)),
            ),
            reverse=True
        )
        return [arr[0]]

    def _send_chest_key_fast_once(self, hwnd, key="1", mode="Auto"):
        """Exactly-once chest key optimized for a sensor-confirmed batch.

        Unlike send_client_key_once(), this path does not spend ~580 ms taking
        three screen-change diagnostic captures.  The inventory sensor that runs
        immediately afterward is the authoritative confirmation, so the extra
        diagnostic probe was duplicate work.
        """
        hwnd = int(hwnd)
        vk = VK_MAP.get(str(key).upper())
        if vk is None:
            return {"ok": False, "error": f"Phím chưa hỗ trợ: {key}", "exactly_once": True}

        mode = str(mode or "Auto")
        if mode == "Background":
            sent, target = _post_key(hwnd, vk)
            return {
                "ok": bool(sent), "responded": None, "exactly_once": True,
                "attempt_count": 1, "requested_mode": mode,
                "used_mode": "Background/PostMessage/FastBatch",
                "target_hwnd": int(target), "sensor_confirmation": True,
            }

        # Auto / Foreground: keep the already prepared JX1 foreground session.
        # Only pay the activation cost if another window actually stole focus.
        activation = None
        if int(user32_bridge.GetForegroundWindow() or 0) != hwnd:
            activation = _activate_window(hwnd)
            if not activation.get("ok"):
                return {
                    "ok": False, "responded": False, "exactly_once": True,
                    "attempt_count": 0, "requested_mode": mode,
                    "used_mode": "Foreground/SendInputScanCode/FastBatch",
                    "error": "Không đưa được JX1 ra foreground.",
                }

        sent, scan = _sendinput_scancode(vk)
        return {
            "ok": bool(sent), "responded": None, "exactly_once": True,
            "attempt_count": 1, "requested_mode": mode,
            "used_mode": "Foreground/SendInputScanCode/FastBatch",
            "target_hwnd": int(_largest_child(hwnd)),
            "scan_code": int(scan), "activation": activation,
            "sensor_confirmation": True,
        }

    def chest_test_open_one(self, hwnd):
        try:
            hwnd = int(hwnd)
            self._new_item_queue=[]
            self._queue_read_results=[]
            pre=capture_client(hwnd)
            if pre is not None and detect_personal_storage_grid(pre).get('ok'):
                closed=_try_personal_bag_close_once(hwnd,pre,self._cfg.get('input_mode','Auto'))
                if not closed.get('ok'):
                    return {'ok':False,'safe_pause':True,'reason':'PERSONAL_BAG_CLOSE_BEFORE_TEST_FAILED','close':closed}
            ready = self._capture_source_grid_visible(hwnd)
            if not ready.get("ok"):
                return ready

            grid = ready["grid"]
            before = snapshot_inventory(ready["image"], grid)
            self._batch_preopen_snapshot = before

            # Current locked JX1 contract: key 1 opens one chest.
            input_mode = self._cfg.get("input_mode", "Auto")
            ir = self.send_client_key_once(hwnd, "1", input_mode)
            if not ir.get("ok"):
                return {
                    "ok": False,
                    "safe_pause": True,
                    "reason": "INPUT_BRIDGE_ERROR",
                    "input": ir,
                    "new_item_count": 0,
                    "new_item_candidates": [],
                    "changed_cells": [],
                    "polls": 0,
                    "confirm_ms": 0,
                    "detector_misses": 0,
                }

            wait = self._wait_for_new_item_after_open(
                hwnd, before, timeout_sec=3.0, poll_sec=0.16
            )
            diff = wait.get("diff", {})
            after = wait.get("after")
            after_grid = wait.get("grid")

            selected_candidates = self._select_one_candidate_per_chest(
                diff.get("new_item_candidates",[])
            )
            result = {
                "ok": bool(wait.get("ok")) and bool(selected_candidates),
                "input": ir,
                "grid_confidence": (after_grid or {}).get("confidence"),
                "raw_new_item_count": diff.get("new_item_count",0),
                "new_item_count": len(selected_candidates),
                "new_item_candidates": selected_candidates,
                "ignored_candidates": [
                    x for x in diff.get("new_item_candidates",[])
                    if x not in selected_candidates
                ],
                "changed_cells": diff.get("changed_cells",[]),
                "new_item_detection_mode": diff.get("new_item_detection_mode","NONE"),
                "polls": wait.get("polls",0),
                "confirm_ms": wait.get("confirm_ms",0),
                "detector_misses": wait.get("detector_misses",0),
                "safe_pause": not bool(wait.get("ok")),
                "reason": None if wait.get("ok") else "NO_NEW_ITEM_CONFIRMED_WITHIN_3S",
            }

            stamp = time.strftime("%Y%m%d_%H%M%S")
            (LOGDIR / f"{stamp}_chest_open_one.json").write_text(
                json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
            )

            # New stable snapshot becomes the next baseline.
            if after is not None and after_grid is not None:
                self._inventory_baseline = after
                self._inventory_last = after
                self._inventory_grid = after_grid

            if result.get("ok"):
                queue = self._build_queue_from_candidates([
                    {"open_index": 1, **x}
                    for x in result.get("new_item_candidates", [])
                ])
                result["queue"] = [public_queue_item(x) for x in queue]

            return result
        except Exception as e:
            return {"ok": False, "error": str(e), "trace": traceback.format_exc(limit=5)}

    def chest_open_batch5(self, hwnd):
        try:
            hwnd = int(hwnd)
            self._new_item_queue=[]
            self._queue_read_results=[]
            ready = self._capture_inventory_ready(hwnd, try_open=True)
            if not ready.get("ok"):
                return ready

            grid = ready["grid"]
            current = snapshot_inventory(ready["image"], grid)
            self._batch_preopen_snapshot = current
            events = []
            total_candidates = []

            for index in range(1, 6):
                ir = self._send_chest_key_fast_once(hwnd, "1", self._cfg.get("input_mode", "Auto"))
                if not ir.get("ok"):
                    event = {
                        "index": index,
                        "input": ir,
                        "new_item_count": 0,
                        "new_item_candidates": [],
                        "changed_cells": [],
                        "polls": 0,
                        "confirm_ms": 0,
                        "detector_misses": 0,
                    }
                    events.append(event)
                    result = {
                        "ok": False,
                        "safe_pause": True,
                        "reason": "INPUT_BRIDGE_ERROR",
                        "opened_attempts": index,
                        "confirmed_items": len(total_candidates),
                        "events": events,
                    }
                    stamp = time.strftime("%Y%m%d_%H%M%S")
                    (LOGDIR / f"{stamp}_chest_batch5_INPUT_ERROR.json").write_text(
                        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
                    )
                    return result

                wait = self._wait_for_new_item_after_open(
                    hwnd, current, timeout_sec=3.0, poll_sec=0.07
                )
                d = wait.get("diff", {})
                nxt = wait.get("after")
                g = wait.get("grid")
                selected = self._select_one_candidate_per_chest(
                    d.get("new_item_candidates",[])
                )
                count = len(selected)

                event = {
                    "index": index,
                    "input": ir,
                    "raw_new_item_count": int(d.get("new_item_count",0)),
                    "new_item_count": count,
                    "new_item_candidates": selected,
                    "ignored_candidates": [
                        x for x in d.get("new_item_candidates",[])
                        if x not in selected
                    ],
                    "new_item_detection_mode": d.get("new_item_detection_mode","NONE"),
                    "changed_cells": d.get("changed_cells",[]),
                    "polls": wait.get("polls",0),
                    "confirm_ms": wait.get("confirm_ms",0),
                    "detector_misses": wait.get("detector_misses",0),
                }
                events.append(event)

                # Safe contract: send key ONCE, then wait up to 3 seconds.
                # Never resend automatically because a delayed first open could
                # otherwise consume two chests.
                if not wait.get("ok") or count < 1 or nxt is None or g is None:
                    result = {
                        "ok": False,
                        "safe_pause": True,
                        "reason": "CHEST_ITEM_CONFIRM_TIMEOUT",
                        "opened_attempts": index,
                        "confirmed_items": len(total_candidates),
                        "events": events,
                    }
                    stamp = time.strftime("%Y%m%d_%H%M%S")
                    (LOGDIR / f"{stamp}_chest_batch5_PAUSE.json").write_text(
                        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
                    )
                    return result

                total_candidates.extend([
                    {"open_index": index, **x}
                    for x in selected
                ])
                current = nxt
                self._inventory_grid = g

            result = {
                "ok": True,
                "safe_pause": False,
                "opened_attempts": 5,
                "confirmed_items": len(total_candidates),
                "item_candidates": total_candidates,
                "performance_path": "CHEST_BATCH_FAST_SENSOR_V8_0",
                "events": events,
            }
            self._inventory_baseline = current
            self._inventory_last = current
            queue = self._build_queue_from_candidates(total_candidates)
            result["queue"] = [public_queue_item(x) for x in queue]

            stamp = time.strftime("%Y%m%d_%H%M%S")
            (LOGDIR / f"{stamp}_chest_batch5.json").write_text(
                json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return result
        except Exception as e:
            return {"ok": False, "safe_pause": True, "error": str(e), "trace": traceback.format_exc(limit=5)}


    def shop_guard_status(self, hwnd=None):
        desc=self._shop_guard_descriptor or {}
        try: selected=int(hwnd or 0)
        except Exception: selected=0
        armed=bool(self._shop_guard_armed_hwnd and (not selected or int(self._shop_guard_armed_hwnd)==selected))
        return {
            'ok':True,
            'calibrated':bool(desc and SHOP_GUARD_REFERENCE_PATH.exists()),
            'armed':armed,
            'armed_hwnd':self._shop_guard_armed_hwnd,
            'patch_count':len(desc.get('patches') or []),
            'created_at':desc.get('created_at'),
            'version':desc.get('version','SHOP_GUARD_V8_8'),
            'hint': 'Mở Shop + Hành Trang, bấm TEST GUARD; v8.8 tự ghi log chẩn đoán cả khi ARM thất bại.',
            'runtime_log': SHOP_RUNTIME_LOG_PATH.name,
        }

    def shop_calibrate_open(self, hwnd):
        """ARM Shop Guard and always emit diagnostics, including early failures."""
        try:
            hwnd = int(hwnd)
        except Exception:
            payload = {'ok': False, 'reason': 'INVALID_HWND'}
            _shop_diag_write('SHOP_ARM_FAIL', payload, hwnd=0)
            return payload

        def finish(payload):
            payload = dict(payload or {})
            payload.setdefault('diagnostic_log', SHOP_RUNTIME_LOG_PATH.name)
            _shop_diag_write('SHOP_ARM_PASS' if payload.get('ok') else 'SHOP_ARM_FAIL', payload, hwnd)
            return payload

        try:
            screen_diag = _shop_diag_capture(hwnd)
            _shop_diag_write('SHOP_ARM_BEGIN', {'screen': screen_diag}, hwnd)
            if not window_exists(hwnd):
                return finish({'ok': False, 'reason': 'CLIENT_UNAVAILABLE', 'screen': screen_diag})

            ready = self._capture_source_grid_visible(hwnd)
            if not ready.get('ok'):
                return finish({'ok': False, 'reason': 'SOURCE_GRID_NOT_VISIBLE', 'detail': ready, 'screen': screen_diag})
            self._inventory_grid = ready['grid']
            _park_cursor_on_inventory_header(hwnd, self._inventory_grid, .08)

            # v8.5: tolerate transient JX1 redraws. Try more frames and re-detect
            # the grid if validation flickers instead of failing with no useful log.
            frames = []
            attempts = []
            for i in range(7):
                img = capture_client(hwnd)
                attempt = {'index': i + 1, 'captured': bool(img is not None)}
                if img is not None:
                    valid = validate_known_grid(img, self._inventory_grid)
                    attempt['known_grid_ok'] = bool(valid.get('ok'))
                    if not valid.get('ok'):
                        redetect = detect_inventory_grid(img)
                        attempt['redetect_ok'] = bool(redetect.get('ok'))
                        if redetect.get('ok'):
                            self._inventory_grid = redetect
                            valid = {'ok': True}
                    if valid.get('ok'):
                        frames.append(img)
                        attempt['accepted'] = True
                    else:
                        attempt['accepted'] = False
                attempts.append(attempt)
                if len(frames) >= 4:
                    break
                if i < 6:
                    time.sleep(.085)

            if len(frames) < 3:
                return finish({
                    'ok': False, 'reason': 'SHOP_CALIBRATION_CAPTURE_FAILED',
                    'frames': len(frames), 'capture_attempts': attempts, 'screen': screen_diag
                })

            patches = _shop_guard_select_patches(frames, self._inventory_grid)
            if len(patches) < 3:
                return finish({
                    'ok': False, 'reason': 'SHOP_CALIBRATION_NO_STABLE_UI_PATCHES',
                    'patch_count': len(patches), 'capture_attempts': attempts, 'screen': screen_diag
                })

            frames[0].save(SHOP_GUARD_REFERENCE_PATH)
            desc = {
                'version': 'SHOP_GUARD_V8_8',
                'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                'client_size': [frames[0].width, frames[0].height],
                'grid_roi': list(self._inventory_grid.get('roi') or []),
                'patches': patches,
                'requires_session_arm': True,
            }
            SHOP_GUARD_PATH.write_text(json.dumps(desc, ensure_ascii=False, indent=2), encoding='utf-8')
            self._shop_guard_descriptor = desc
            self._shop_guard_armed_hwnd = hwnd
            chk = self._shop_guard_check(hwnd, require_armed=True)
            payload = {
                'ok': bool(chk.get('ok')), 'calibrated': True, 'armed': True,
                'patch_count': len(patches), 'guard': chk, 'matched': chk.get('matched'),
                'needed': chk.get('needed'), 'avg_score': chk.get('avg_score'),
                'capture_attempts': attempts, 'screen': screen_diag
            }
            stamp = time.strftime('%Y%m%d_%H%M%S')
            (LOGDIR / f'{stamp}_shop_guard_calibration.json').write_text(
                json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8'
            )
            return finish(payload)
        except Exception as e:
            return finish({
                'ok': False, 'reason': 'SHOP_CALIBRATION_EXCEPTION', 'error': str(e),
                'trace': traceback.format_exc(limit=8)
            })

    def _shop_guard_check(self, hwnd, require_armed=True):
        try:
            hwnd=int(hwnd)
            if require_armed and int(self._shop_guard_armed_hwnd or 0)!=hwnd:
                return {'ok':False,'reason':'SHOP_NOT_ARMED_FOR_THIS_SESSION','armed_hwnd':self._shop_guard_armed_hwnd,'can_arm_now':True,'hint':'Mở Shop + Hành Trang rồi ARM/TEST lại.'}
            if not self._shop_guard_descriptor or not SHOP_GUARD_REFERENCE_PATH.exists():
                return {'ok':False,'reason':'SHOP_GUARD_NOT_CALIBRATED'}
            img=capture_client(hwnd)
            if img is None:
                return {'ok':False,'reason':'SHOP_GUARD_CAPTURE_FAILED'}
            grid=self._inventory_grid
            valid=validate_known_grid(img,grid) if grid else {'ok':False}
            if not valid.get('ok'):
                grid=detect_inventory_grid(img)
                if not grid.get('ok'):
                    return {'ok':False,'reason':'INVENTORY_GRID_NOT_VISIBLE','grid':grid}
                self._inventory_grid=grid
            from PIL import Image
            ref=Image.open(SHOP_GUARD_REFERENCE_PATH).convert('RGB')
            cmp=_shop_guard_compare(img.convert('RGB'),ref,self._shop_guard_descriptor)
            cmp['armed']=bool(int(self._shop_guard_armed_hwnd or 0)==hwnd)
            cmp['client_size']=[img.width,img.height]
            return cmp
        except Exception as e:
            return {'ok':False,'reason':'SHOP_GUARD_CHECK_EXCEPTION','error':str(e)}

    def shop_test_guard(self, hwnd):
        try:
            hwnd = int(hwnd)
            screen_diag = _shop_diag_capture(hwnd)
            _shop_diag_write('SHOP_TEST_BEGIN', {'screen': screen_diag}, hwnd)
            if self._inventory_grid:
                _park_cursor_on_inventory_header(hwnd, self._inventory_grid, .08)
            r = self._shop_guard_check(hwnd, require_armed=True)
            r = dict(r or {})
            r['diagnostic_log'] = SHOP_RUNTIME_LOG_PATH.name
            r['screen'] = screen_diag
            stamp = time.strftime('%Y%m%d_%H%M%S')
            (LOGDIR / f'{stamp}_shop_guard_test.json').write_text(
                json.dumps(r, ensure_ascii=False, indent=2, default=str), encoding='utf-8'
            )
            _shop_diag_write('SHOP_TEST_PASS' if r.get('ok') else 'SHOP_TEST_FAIL', r, hwnd)
            return r
        except Exception as e:
            out = {'ok': False, 'reason': 'SHOP_GUARD_TEST_EXCEPTION', 'error': str(e), 'trace': traceback.format_exc(limit=8)}
            _shop_diag_write('SHOP_TEST_EXCEPTION', out, hwnd if 'hwnd' in locals() else 0)
            return out

    def shop_build_diagnostic_bundle(self):
        """Create one ZIP the user can attach back for Shop Guard debugging."""
        try:
            stamp = time.strftime('%Y%m%d_%H%M%S')
            out = LOGDIR / f'AutoProByEric_ShopDiagnostic_{stamp}.zip'
            candidates = [
                SHOP_RUNTIME_LOG_PATH, SHOP_LATEST_DIAG_PATH, SHOP_LATEST_SCREEN_PATH,
                SHOP_GUARD_PATH, SHOP_GUARD_REFERENCE_PATH, APP_CONFIG_PATH, USER_FILTER_PATH,
            ]
            recent = sorted(LOGDIR.glob('*_shop_guard_*.json'), key=lambda x: x.stat().st_mtime, reverse=True)[:20]
            recent += sorted(LOGDIR.glob('*_shop_*.json'), key=lambda x: x.stat().st_mtime, reverse=True)[:20]
            added = []
            seen = set()
            with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as z:
                for f in candidates + recent:
                    try:
                        f = Path(f)
                        if not f.exists():
                            continue
                        key = str(f.resolve())
                        if key in seen:
                            continue
                        seen.add(key)
                        z.write(f, arcname=f.name)
                        added.append(f.name)
                    except Exception:
                        pass
            payload = {'ok': True, 'filename': out.name, 'path': str(out), 'files': added}
            _shop_diag_write('SHOP_DIAGNOSTIC_BUNDLE_CREATED', payload, 0)
            return payload
        except Exception as e:
            payload = {'ok': False, 'reason': 'SHOP_DIAGNOSTIC_BUNDLE_FAILED', 'error': str(e)}
            _shop_diag_write('SHOP_DIAGNOSTIC_BUNDLE_FAILED', payload, 0)
            return payload


    def shop_npc_status(self, hwnd=None):
        """Return the saved Shop-NPC client point for the selected JX1 client."""
        cfg=self._cfg.setdefault("modules",{}).setdefault("shop",{})
        point=cfg.get("npc_point")
        try:
            point=[int(point[0]),int(point[1])] if isinstance(point,(list,tuple)) and len(point)>=2 else None
        except Exception:
            point=None
        return {
            'ok':True,
            'saved':bool(point),
            'point':point,
            'capture_delay_ms':SHOP_NPC_CAPTURE_DELAY_MS,
            'hint':'Bấm LƯU NPC SHOP rồi đưa chuột lên đúng NPC Bán Shop trong JX1 cho tới khi hết đếm.',
        }

    def shop_save_npc_position(self, hwnd, delay_ms=SHOP_NPC_CAPTURE_DELAY_MS):
        """After a short countdown, save the live OS cursor as a JX1 client coordinate."""
        try:
            hwnd=int(hwnd)
            if not window_exists(hwnd):
                return {'ok':False,'reason':'CLIENT_WINDOW_GONE'}
            try:
                delay_ms=max(1000,min(5000,int(delay_ms)))
            except Exception:
                delay_ms=SHOP_NPC_CAPTURE_DELAY_MS
            time.sleep(delay_ms/1000.0)
            img=capture_client(hwnd)
            cur=get_cursor_client(hwnd)
            if img is None or cur is None:
                return {'ok':False,'reason':'NPC_CAPTURE_FAILED'}
            x,y=int(cur[0]),int(cur[1])
            if x<0 or y<0 or x>=int(img.width) or y>=int(img.height):
                return {'ok':False,'reason':'CURSOR_NOT_INSIDE_JX1','cursor':[x,y],'client_size':[img.width,img.height]}
            # Avoid saving obvious Auto-unsafe UI areas on the right inventory/hotbar.
            if x>=int(img.width*0.76) and y>=int(img.height*0.70):
                return {'ok':False,'reason':'NPC_POINT_LOOKS_LIKE_INVENTORY_OR_HOTBAR','cursor':[x,y]}
            cfg=self._cfg.setdefault("modules",{}).setdefault("shop",{})
            cfg["npc_point"]=[x,y]
            cfg["npc_point_norm"]=[float(x)/max(1.0,float(img.width)),float(y)/max(1.0,float(img.height))]
            _save_app_config(self._cfg)
            out={'ok':True,'saved':True,'point':[x,y],'point_norm':cfg["npc_point_norm"],'client_size':[img.width,img.height],'delay_ms':delay_ms}
            _shop_diag_write('SHOP_NPC_POSITION_SAVED',out,hwnd)
            return out
        except Exception as e:
            out={'ok':False,'reason':'SHOP_NPC_SAVE_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=6)}
            _shop_diag_write('SHOP_NPC_POSITION_SAVE_EXCEPTION',out,hwnd if 'hwnd' in locals() else 0)
            return out

    def _shop_left_click_once(self, hwnd, cx, cy, purpose):
        """Exactly one left click using the configured input mode."""
        hwnd=int(hwnd); cx=int(cx); cy=int(cy)
        mode=str(self._cfg.get('input_mode','Auto') or 'Auto')
        pid=_window_pid(hwnd)
        auto_elevated=_is_current_process_elevated(); game_elevated=_process_elevated(pid)
        if game_elevated is True and not auto_elevated:
            return {'ok':False,'reason':'PRIVILEGE_MISMATCH','attempt_count':0,'exactly_once':True,'purpose':purpose}
        out={'ok':False,'attempt_count':1,'exactly_once':True,'purpose':purpose,'client_point':[cx,cy],'requested_mode':mode}
        if mode=='Background':
            ok,target,p=_post_left_click_client(hwnd,cx,cy)
            out.update({'ok':bool(ok),'used_mode':'Background/PostMessageLeftClick','target_hwnd':int(target),'target_point':list(p) if p else None})
            if not ok: out['reason']='BACKGROUND_LEFT_CLICK_FAILED'
            return out
        activation=None
        if int(user32_bridge.GetForegroundWindow() or 0)!=hwnd:
            activation=_activate_window(hwnd)
            if not activation.get('ok'):
                out.update({'reason':'FOREGROUND_ACTIVATION_FAILED','attempt_count':0,'activation':activation})
                return out
        sp=_client_to_screen(hwnd,cx,cy)
        if not sp:
            out.update({'reason':'CLIENT_TO_SCREEN_FAILED','activation':activation})
            return out
        ok,old=_send_left_click_screen(sp[0],sp[1])
        if old: _set_cursor_screen(old[0],old[1])
        out.update({'ok':bool(ok),'used_mode':'Foreground/SendInputLeftClick','screen_point':[int(sp[0]),int(sp[1])],'activation':activation})
        if not ok: out['reason']='FOREGROUND_LEFT_CLICK_FAILED'
        return out

    def _shop_close_once(self, hwnd):
        """v9.5 close sequence required by the real JX1 UI.

        Exactly once each: (1) Đóng CỬA HÀNG, then (2) Đóng TRANG BỊ/THUỘC TÍNH.
        Guard is intentionally NOT used to confirm the first click because the old
        guard contains patches from the character panel and therefore could still PASS
        after the Shop panel itself had already closed.
        """
        try:
            hwnd=int(hwnd)
            before=capture_client(hwnd)
            if before is None:
                return {'ok':False,'reason':'SHOP_CLOSE_CAPTURE_FAILED'}
            # Require the armed Shop at entry only.
            guard_before=self._shop_guard_check(hwnd,require_armed=True)
            if not guard_before.get('ok'):
                return {'ok':False,'reason':'SHOP_GUARD_NOT_OPEN_BEFORE_CLOSE','guard':guard_before}
            p1=(int(round(before.width*SHOP_CLOSE_CANONICAL[0])),int(round(before.height*SHOP_CLOSE_CANONICAL[1])))
            c1=self._shop_left_click_once(hwnd,p1[0],p1[1],'SHOP_CLOSE_BUTTON_STEP1')
            if not c1.get('ok'):
                return {'ok':False,'reason':'SHOP_CLOSE_STEP1_CLICK_FAILED','click1':c1}
            time.sleep(SHOP_TWO_PANEL_SETTLE_SEC)
            mid=capture_client(hwnd)
            if mid is None:
                return {'ok':False,'reason':'SHOP_CLOSE_STEP1_CAPTURE_FAILED','click1':c1}
            p2=(int(round(mid.width*SHOP_CHARACTER_CLOSE_CANONICAL[0])),int(round(mid.height*SHOP_CHARACTER_CLOSE_CANONICAL[1])))
            c2=self._shop_left_click_once(hwnd,p2[0],p2[1],'CHARACTER_CLOSE_BUTTON_STEP2')
            if not c2.get('ok'):
                return {'ok':False,'reason':'SHOP_CLOSE_STEP2_CLICK_FAILED','click1':c1,'click2':c2}
            time.sleep(SHOP_TWO_PANEL_SETTLE_SEC)
            after=capture_client(hwnd)
            if after is None:
                return {'ok':False,'reason':'SHOP_CLOSE_AFTER_CAPTURE_FAILED','click1':c1,'click2':c2}
            # Source inventory on the right must remain visible; personal popup must not be open yet.
            source=self._capture_source_grid_visible(hwnd)
            if not source.get('ok'):
                out={'ok':False,'reason':'SHOP_CLOSE_SOURCE_GRID_LOST','click1':c1,'click2':c2,'source':source}
                _shop_diag_write('SHOP_CLOSE_FAIL',out,hwnd); return out
            self._inventory_grid=source['grid']
            if detect_personal_storage_grid(after).get('ok'):
                out={'ok':False,'reason':'SHOP_CLOSE_UNEXPECTED_PERSONAL_BAG_OPEN','click1':c1,'click2':c2}
                _shop_diag_write('SHOP_CLOSE_FAIL',out,hwnd); return out
            out={'ok':True,'closed':True,'two_panel_sequence':True,'click1':c1,'click2':c2,
                 'sequence':['CLOSE_SHOP','CLOSE_CHARACTER_PANEL'],'source_grid_ok':True}
            _shop_diag_write('SHOP_CLOSE_TWO_PANEL_CONFIRMED',out,hwnd)
            return out
        except Exception as e:
            out={'ok':False,'reason':'SHOP_CLOSE_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=6)}
            _shop_diag_write('SHOP_CLOSE_EXCEPTION',out,hwnd if 'hwnd' in locals() else 0)
            return out

    def _shop_reopen_once(self, hwnd):
        """v9.5: click saved NPC once -> click 'Giao dịch' once -> require Shop Guard PASS."""
        try:
            hwnd=int(hwnd)
            cfg=self._cfg.setdefault("modules",{}).setdefault("shop",{})
            p=cfg.get("npc_point"); pn=cfg.get("npc_point_norm")
            if not (isinstance(p,(list,tuple)) and len(p)>=2):
                return {'ok':False,'reason':'SHOP_NPC_POSITION_NOT_SAVED','hint':'Vào NPC & Vị Trí → LƯU NPC SHOP.'}
            img=capture_client(hwnd)
            if img is None:
                return {'ok':False,'reason':'SHOP_REOPEN_CAPTURE_FAILED'}
            if isinstance(pn,(list,tuple)) and len(pn)>=2:
                cx=int(round(float(pn[0])*img.width)); cy=int(round(float(pn[1])*img.height))
            else:
                cx,cy=int(p[0]),int(p[1])
            if not (0<=cx<img.width and 0<=cy<img.height):
                return {'ok':False,'reason':'SHOP_NPC_POINT_OUT_OF_BOUNDS','point':[cx,cy],'client_size':[img.width,img.height]}
            npc_click=self._shop_left_click_once(hwnd,cx,cy,'SHOP_NPC_REOPEN_STEP1')
            if not npc_click.get('ok'):
                return {'ok':False,'reason':'SHOP_NPC_CLICK_FAILED','npc_click':npc_click}
            time.sleep(SHOP_DIALOG_SETTLE_SEC)
            # Some clients open Shop directly; accept that without an extra dialog click.
            direct=self._shop_guard_check(hwnd,require_armed=True)
            trade_click=None
            if not direct.get('ok'):
                dimg=capture_client(hwnd)
                if dimg is None:
                    return {'ok':False,'reason':'SHOP_DIALOG_CAPTURE_FAILED','npc_click':npc_click}
                tx=int(round(dimg.width*SHOP_DIALOG_TRADE_CANONICAL[0])); ty=int(round(dimg.height*SHOP_DIALOG_TRADE_CANONICAL[1]))
                trade_click=self._shop_left_click_once(hwnd,tx,ty,'SHOP_DIALOG_GIAO_DICH_STEP2')
                if not trade_click.get('ok'):
                    return {'ok':False,'reason':'SHOP_DIALOG_TRADE_CLICK_FAILED','npc_click':npc_click,'trade_click':trade_click}
            t0=time.time(); polls=0; last=None
            while time.time()-t0 <= max(2.8,SHOP_REOPEN_CONFIRM_TIMEOUT_SEC):
                time.sleep(SHOP_REOPEN_POLL_SEC); polls+=1
                ready=self._capture_source_grid_visible(hwnd)
                if ready.get('ok'):
                    self._inventory_grid=ready['grid']
                    _park_cursor_on_inventory_header(hwnd,self._inventory_grid,.02)
                    g=self._shop_guard_check(hwnd,require_armed=True); last=g
                    if g.get('ok'):
                        out={'ok':True,'reopened':True,'polls':polls,'npc_click':npc_click,'trade_click':trade_click,
                             'guard':g,'npc_point':[cx,cy],'sequence':['CLICK_NPC','CLICK_GIAO_DICH','GUARD_PASS']}
                        _shop_diag_write('SHOP_REOPEN_DIALOG_CONFIRMED',out,hwnd); return out
                else:
                    last={'source':ready}
            out={'ok':False,'reason':'SHOP_REOPEN_NOT_CONFIRMED_NO_RETRY','polls':polls,'npc_click':npc_click,
                 'trade_click':trade_click,'last':last,'npc_point':[cx,cy]}
            _shop_diag_write('SHOP_REOPEN_FAIL',out,hwnd); return out
        except Exception as e:
            out={'ok':False,'reason':'SHOP_REOPEN_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=6)}
            _shop_diag_write('SHOP_REOPEN_EXCEPTION',out,hwnd if 'hwnd' in locals() else 0)
            return out

    def shop_test_close_reopen(self, hwnd):
        """Manual diagnostic: close current Shop once, then reopen from saved NPC once."""
        try:
            hwnd=int(hwnd)
            closed=self._shop_close_once(hwnd)
            if not closed.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':closed.get('reason','SHOP_CLOSE_FAILED'),'close':closed}
            reopened=self._shop_reopen_once(hwnd)
            return {'ok':bool(reopened.get('ok')),'safe_pause':not bool(reopened.get('ok')),'close':closed,'reopen':reopened,'reason':None if reopened.get('ok') else reopened.get('reason')}
        except Exception as e:
            return {'ok':False,'safe_pause':True,'reason':'SHOP_TEST_REOPEN_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=6)}

    def _shop_send_sell_once(self, hwnd, item):
        """Exactly one right-click. No automatic retry/fallback."""
        hwnd=int(hwnd)
        point=_candidate_click_point(item,self._inventory_grid)
        if not point:
            return {'ok':False,'reason':'ITEM_CLICK_POINT_UNAVAILABLE','exactly_once':True,'attempt_count':0}
        cx,cy=point
        mode=str(self._cfg.get('input_mode','Auto') or 'Auto')
        pid=_window_pid(hwnd)
        auto_elevated=_is_current_process_elevated()
        game_elevated=_process_elevated(pid)
        if game_elevated is True and not auto_elevated:
            return {'ok':False,'reason':'PRIVILEGE_MISMATCH','exactly_once':True,'attempt_count':0}
        result={'ok':False,'exactly_once':True,'attempt_count':1,'requested_mode':mode,'client_point':[cx,cy]}
        if mode=='Background':
            sent,target,tpt=_post_right_click_client(hwnd,cx,cy)
            result.update({'ok':bool(sent),'used_mode':'Background/PostMessageRightClick','target_hwnd':int(target),'target_point':list(tpt) if tpt else None})
            if not sent: result['reason']='BACKGROUND_RIGHT_CLICK_SEND_FAILED'
            return result
        activation=_activate_window(hwnd)
        if not activation.get('ok'):
            result.update({'attempt_count':0,'reason':'FOREGROUND_ACTIVATION_FAILED','activation':activation})
            return result
        sp=_client_to_screen(hwnd,cx,cy)
        if not sp:
            result.update({'attempt_count':0,'reason':'CLIENT_TO_SCREEN_FAILED','activation':activation})
            return result
        sent,old=_send_right_click_screen(sp[0],sp[1])
        result.update({'ok':bool(sent),'used_mode':'Foreground/SendInputRightClick','activation':activation,'screen_point':[int(sp[0]),int(sp[1])],'old_cursor':list(old) if old else None})
        if not sent: result['reason']='FOREGROUND_RIGHT_CLICK_SEND_FAILED'
        return result

    def _shop_wait_sale_confirm(self, hwnd, candidate, before, timeout_sec=1.9, poll_sec=.08):
        deadline=time.time()+float(timeout_sec)
        polls=0
        last_metrics=None
        last_snap=None
        while time.time()<deadline:
            time.sleep(float(poll_sec)); polls+=1
            img=capture_client(hwnd)
            if img is None: continue
            grid=self._inventory_grid
            valid=validate_known_grid(img,grid) if grid else {'ok':False}
            if not valid.get('ok'):
                grid=detect_inventory_grid(img)
                if not grid.get('ok'): continue
                self._inventory_grid=grid
            snap=snapshot_inventory(img,self._inventory_grid)
            metrics=_candidate_clear_metrics(candidate,before,snap,self._batch_preopen_snapshot)
            last_metrics=metrics; last_snap=snap
            if metrics.get('confirmed'):
                return {'ok':True,'polls':polls,'confirm_ms':int((timeout_sec-(deadline-time.time()))*1000),'metrics':metrics,'snapshot':snap}
        return {'ok':False,'reason':'SELL_NOT_CONFIRMED_NO_RETRY','polls':polls,'metrics':last_metrics,'snapshot':last_snap}

    def shop_sell_queue_item(self, hwnd, item_index):
        try:
            hwnd=int(hwnd); item=self._queue_item_by_index(item_index)
            if item is None: return {'ok':False,'reason':'QUEUE_ITEM_NOT_FOUND'}
            if item.get('status')=='SOLD': return {'ok':True,'already_sold':True,'queue_item':public_queue_item(item)}
            if item.get('decision')!='FAIL':
                return {'ok':False,'reason':'SELL_BLOCKED_DECISION_NOT_FAIL','decision':item.get('decision')}
            if not self._inventory_grid:
                ready=self._capture_inventory_ready(hwnd,try_open=True)
                if not ready.get('ok'): return ready
                self._inventory_grid=ready['grid']
            # Dismiss tooltip before checking shop-open reference.
            _park_cursor_on_inventory_header(hwnd,self._inventory_grid,.07)
            guard=self._shop_guard_check(hwnd,require_armed=True)
            if not guard.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':'SHOP_GUARD_FAIL_BEFORE_SELL','guard':guard,'queue_item':public_queue_item(item)}
            img=capture_client(hwnd)
            if img is None: return {'ok':False,'safe_pause':True,'reason':'PRE_SELL_CAPTURE_FAILED'}
            grid=self._inventory_grid
            if not validate_known_grid(img,grid).get('ok'):
                grid=detect_inventory_grid(img)
                if not grid.get('ok'): return {'ok':False,'safe_pause':True,'reason':'INVENTORY_GRID_LOST_BEFORE_SELL'}
                self._inventory_grid=grid
            before=snapshot_inventory(img,self._inventory_grid)
            action=self._shop_send_sell_once(hwnd,item)
            if not action.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':'SELL_INPUT_FAILED','action':action,'guard':guard}
            confirm=self._shop_wait_sale_confirm(hwnd,item,before)
            if not confirm.get('ok'):
                item['status']='PAUSED'; item['reason']='SELL_NOT_CONFIRMED_NO_RETRY'
                return {'ok':False,'safe_pause':True,'reason':'SELL_NOT_CONFIRMED_NO_RETRY','action':action,'confirm':confirm,'guard':guard,'queue_item':public_queue_item(item)}
            item['status']='SOLD'; item['reason']='FAIL_SOLD_CONFIRMED'; item['action']='SELL'; item['action_status']='CONFIRMED'
            self._inventory_last=confirm.get('snapshot') or self._inventory_last
            result={'ok':True,'sold':True,'safe_pause':False,'action':action,'confirm':{k:v for k,v in confirm.items() if k!='snapshot'},'guard':guard,'queue_item':public_queue_item(item)}
            stamp=time.strftime('%Y%m%d_%H%M%S')
            (LOGDIR/f'{stamp}_shop_sell_{item_index+1:02d}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
            _shop_diag_write('SHOP_SELL_ITEM_PASS', {'item_index': item_index, 'result': result}, hwnd)
            return result
        except Exception as e:
            out={'ok':False,'safe_pause':True,'reason':'SHOP_SELL_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=8)}
            _shop_diag_write('SHOP_SELL_ITEM_EXCEPTION', out, hwnd if 'hwnd' in locals() else 0)
            return out

    def queue_process_shop(self, hwnd):
        """Read the current queue and immediately sell each conclusive FAIL."""
        try:
            hwnd=int(hwnd)
            if not self._new_item_queue:
                return {'ok':False,'safe_pause':True,'reason':'QUEUE_EMPTY'}
            ready=self._capture_source_grid_visible(hwnd)
            if not ready.get('ok'): return ready
            self._inventory_grid=ready['grid']
            _park_cursor_on_inventory_header(hwnd,self._inventory_grid,.07)
            guard=self._shop_guard_check(hwnd,require_armed=True)
            if not guard.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':'SHOP_GUARD_FAIL_AT_START','guard':guard}
            try: self._batch_filter_cache=_load_option_filter()
            except Exception: self._batch_filter_cache=_default_option_filter()
            activation=_activate_window(hwnd); time.sleep(.03)
            focus=_safe_inventory_header_click(hwnd,self._inventory_grid)
            if not focus.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':'SHOP_BATCH_FOCUS_FAILED','focus':focus}
            actions=[]; keep=0; sold=0; uncertain=0; scanned=0
            for idx,item in enumerate(self._new_item_queue):
                if item.get('status')=='SOLD':
                    sold+=1; continue
                if item.get('decision') not in ('KEEP','FAIL'):
                    r=self._read_queue_item_internal(hwnd,idx,batch_session=True)
                    scanned+=1
                else:
                    r={'ok':True,'decision':item.get('decision'),'queue_item':public_queue_item(item),'reused_decision':True}
                decision=r.get('decision') or item.get('decision')
                if decision == 'KEEP':
                    # v9.4: KEEP in Shop is not left sitting in the right bag.
                    # Close Shop once -> move to personal bag -> close personal bag ->
                    # click the saved Shop NPC once -> Guard must PASS -> continue queue.
                    closed=self._shop_close_once(hwnd)
                    if not closed.get('ok'):
                        actions.append({'index':idx,'decision':decision,'action':'CLOSE_SHOP','result':closed})
                        return {'ok':False,'safe_pause':True,'reason':closed.get('reason','SHOP_CLOSE_FAILED'),'processed':idx+1,'keep_count':keep,'sold_count':sold,'uncertain_count':uncertain,'actions':actions,'items':[public_queue_item(x) for x in self._new_item_queue]}
                    sr=self.chest_store_queue_item(hwnd,idx)
                    actions.append({'index':idx,'decision':decision,'action':'STORE_PERSONAL_BAG','result':sr})
                    if not sr.get('ok'):
                        return {'ok':False,'safe_pause':True,'reason':sr.get('reason','STORE_KEEP_FAILED'),'processed':idx+1,'keep_count':keep,'sold_count':sold,'uncertain_count':uncertain,'actions':actions,'items':[public_queue_item(x) for x in self._new_item_queue]}
                    reopened=self._shop_reopen_once(hwnd)
                    actions.append({'index':idx,'decision':decision,'action':'REOPEN_SHOP_NPC','result':reopened})
                    if not reopened.get('ok'):
                        return {'ok':False,'safe_pause':True,'reason':reopened.get('reason','SHOP_REOPEN_FAILED'),'processed':idx+1,'keep_count':keep+1,'sold_count':sold,'uncertain_count':uncertain,'actions':actions,'items':[public_queue_item(x) for x in self._new_item_queue]}
                    keep+=1
                    continue
                if decision=='FAIL':
                    sr=self.shop_sell_queue_item(hwnd,idx)
                    actions.append({'index':idx,'decision':'FAIL','action':'SELL','result':sr})
                    if not sr.get('ok'):
                        return {'ok':False,'safe_pause':True,'reason':sr.get('reason','SELL_FAILED'),'processed':idx+1,'keep_count':keep,'sold_count':sold,'uncertain_count':uncertain,'actions':actions,'items':[public_queue_item(x) for x in self._new_item_queue]}
                    sold+=1
                    continue
                uncertain+=1
                item['status']='PAUSED'; item['reason']='UNRESOLVED_NOT_SAFE_TO_SELL'
                actions.append({'index':idx,'decision':decision or 'UNCERTAIN','action':'PAUSE','result':r})
                return {'ok':False,'safe_pause':True,'reason':'UNRESOLVED_ITEM_NOT_SAFE_TO_SELL','processed':idx+1,'keep_count':keep,'sold_count':sold,'uncertain_count':uncertain,'actions':actions,'items':[public_queue_item(x) for x in self._new_item_queue]}
            out={'ok':True,'safe_pause':False,'queue_count':len(self._new_item_queue),'scanned_count':scanned,'keep_count':keep,'sold_count':sold,'uncertain_count':uncertain,'actions':actions,'items':[public_queue_item(x) for x in self._new_item_queue],'live_actions_enabled':True,'sell':True,'store':True,'pipeline':'SHOP_SAFE_SELL_STORE_REOPEN_V9_4'}
            self._queue_read_results=actions
            stamp=time.strftime('%Y%m%d_%H%M%S')
            (LOGDIR/f'{stamp}_shop_process_queue.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            _shop_diag_write('SHOP_PROCESS_QUEUE_PASS', out, hwnd)
            return out
        except Exception as e:
            out={'ok':False,'safe_pause':True,'reason':'SHOP_QUEUE_PROCESS_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=8)}
            _shop_diag_write('SHOP_PROCESS_QUEUE_EXCEPTION', out, hwnd if 'hwnd' in locals() else 0)
            return out

    def shop_run_batch5(self, hwnd):
        """One safe Stage-21 cycle: verify shop -> open 5 -> read -> sell FAIL."""
        try:
            hwnd=int(hwnd)
            if self._inventory_grid:
                _park_cursor_on_inventory_header(hwnd,self._inventory_grid,.06)
            guard=self._shop_guard_check(hwnd,require_armed=True)
            if not guard.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':'SHOP_GUARD_FAIL_BEFORE_BATCH','guard':guard}
            opened=self.chest_open_batch5(hwnd)
            if not opened.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':opened.get('reason','CHEST_BATCH_FAILED'),'open_result':opened,'guard':guard}
            _park_cursor_on_inventory_header(hwnd,self._inventory_grid,.06)
            guard2=self._shop_guard_check(hwnd,require_armed=True)
            if not guard2.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':'SHOP_GUARD_LOST_AFTER_OPEN','open_result':opened,'guard':guard2}
            processed=self.queue_process_shop(hwnd)
            return {'ok':bool(processed.get('ok')),'safe_pause':bool(processed.get('safe_pause')),'open_result':opened,'process_result':processed,'guard_before':guard,'guard_after_open':guard2,'pipeline':'STAGE24_ONE_BATCH_SHOP_V8_8'}
        except Exception as e:
            return {'ok':False,'safe_pause':True,'reason':'SHOP_BATCH_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=8)}

    def _store_save_physical_proof(self, proof_dir, filename, image, point=None, label=None):
        """Write Store physical proof without changing gameplay state."""
        try:
            if image is None:
                return None
            from PIL import ImageDraw
            d=Path(proof_dir); d.mkdir(parents=True,exist_ok=True)
            out=image.copy()
            if point:
                draw=ImageDraw.Draw(out)
                x,y=int(point[0]),int(point[1]); r=8
                draw.ellipse((x-r,y-r,x+r,y+r),outline=(255,0,0),width=2)
                draw.line((x-r-5,y,x+r+5,y),fill=(255,0,0),width=2)
                draw.line((x,y-r-5,x,y+r+5),fill=(255,0,0),width=2)
                if label:
                    draw.text((x+12,max(0,y-14)),str(label),fill=(255,255,0))
            path=d/filename
            out.save(path)
            return str(path)
        except Exception:
            return None

    def _store_verify_source_pick_v125(self, hwnd, item, source_before, source_grid, cursor_reference_image, cursor_probe_point=None):
        """Verify SOURCE_PICK before any destination click. MOVE/READ only."""
        fingerprint=_build_source_item_fingerprint(item,source_before,self._batch_preopen_snapshot)
        frames=[]; last_img=None; last_snap=None; states=[]; known_grid=source_grid
        t0=time.time()
        while time.time()-t0 <= 0.58 and len(frames)<4:
            time.sleep(.065 if frames else .11)
            img=capture_client(int(hwnd))
            if img is None:
                continue
            last_img=img
            gv=validate_known_grid(img,known_grid) if known_grid else {'ok':False}
            sg=known_grid if gv.get('ok') else detect_inventory_grid(img)
            if not sg.get('ok'):
                frames.append({'state':'SOURCE_GRID_UNRESOLVED'}); continue
            known_grid=sg
            snap=snapshot_inventory(img,sg)
            if not snap.get('ok'):
                frames.append({'state':'SOURCE_SNAPSHOT_FAILED'}); continue
            last_snap=snap
            st=_source_item_fingerprint_state(fingerprint,source_before,snap,self._batch_preopen_snapshot)
            states.append(st)
            frames.append({'state':st.get('state'),'source_state':st})

        source_gone=bool(states and any(x.get('state')=='ITEM_GONE' for x in states) and not any(x.get('state')=='ITEM_STILL_IN_SOURCE' for x in states))
        source_present=bool(states and any(x.get('state')=='ITEM_STILL_IN_SOURCE' for x in states) and not any(x.get('state')=='ITEM_GONE' for x in states))
        cursor=self._drop_probe_cursor_carry_reprobe(
            int(hwnd),cursor_reference_image,initial_probe_point=cursor_probe_point,
            motion_image=last_img,max_zones=3,samples_per_zone=2
        ) if cursor_reference_image is not None else {'state':'CURSOR_AMBIGUOUS','reason':'NO_CURSOR_REFERENCE'}
        cursor_image=capture_client(int(hwnd))
        cursor_state=str(cursor.get('state') or 'CURSOR_AMBIGUOUS')
        holding=cursor_state=='CURSOR_HOLDING_ITEM_CONFIRMED'
        empty=cursor_state=='CURSOR_EMPTY_CONFIRMED'

        if source_gone and holding:
            state='STORE_ITEM_ON_CURSOR'; ok=True; reason='SOURCE_CLEAR_PLUS_CURSOR_HOLDING'
        elif source_present and empty:
            state='STORE_SOURCE_PICK_NOT_COMMITTED'; ok=False; reason='SOURCE_PRESENT_CURSOR_EMPTY'
        elif holding and not source_present:
            state='STORE_ITEM_ON_CURSOR'; ok=True; reason='CURSOR_HOLDING_WITHOUT_SOURCE_PRESENT_PROOF'
        else:
            state='STORE_SOURCE_PICK_CONFIRMATION_FAILED'; ok=False; reason='SOURCE_CURSOR_EVIDENCE_NOT_CONCLUSIVE'
        return {
            'ok':bool(ok),'state':state,'reason':reason,
            'source_state':('SOURCE_CLEAR_CONFIRMED' if source_gone else ('SOURCE_PRESENT_CONFIRMED' if source_present else 'SOURCE_AMBIGUOUS')),
            'cursor_state':cursor_state,'cursor_probe':cursor,'source_frames':frames,
            '_last_image':cursor_image or last_img,'_last_source_snapshot':last_snap,'_source_grid':known_grid,
        }

    def _store_revalidate_destination_v126(self, hwnd, item, target_grid, target_before, target_anchor,
                                           cycle_id=0, store_tx_id=None, max_attempts=3):
        """V12.8 destination-only convergence with explicit panel/grid ownership."""
        hwnd=int(hwnd); attempts=[]; last_reason='DESTINATION_REVALIDATE_UNRESOLVED'
        current_target=target_anchor; current_before=target_before or {}
        for attempt in range(1,max(1,int(max_attempts or 1))+1):
            self._persist_store_trace(cycle_id,item,state='DESTINATION_REVALIDATE',store_tx_id=store_tx_id,
                                      attempt=attempt,cursor_holding=True,source_click_forbidden=True)
            img=capture_client(hwnd)
            if img is None:
                last_reason='STORE_DESTINATION_REVALIDATE_CAPTURE_FAILED'
                attempts.append({'attempt':attempt,'reason':last_reason})
                time.sleep(.055); continue

            owners=detect_jx1_panel_identities(img)
            bound=_bind_storage_grid_owner_identity(self,hwnd,owners)
            if not bound.get('ok'):
                last_reason=bound.get('reason') or owners.get('reason') or 'STORAGE_OWNER_IDENTITY_NOT_PROVEN'
                attempts.append({'attempt':attempt,'reason':last_reason,'owner_identity':owners})
                time.sleep(.055); continue
            tg=bound['grid']
            if str(tg.get('lease_owner') or '')!=GridOwner.PERSONAL_STORAGE.value:
                last_reason='STORAGE_LEASE_OWNER_VIOLATION'
                attempts.append({'attempt':attempt,'reason':last_reason,'lease_owner':tg.get('lease_owner')})
                time.sleep(.055); continue

            snap=snapshot_inventory(img,tg)
            if not snap.get('ok'):
                last_reason='STORE_DESTINATION_REVALIDATE_SNAPSHOT_FAILED'
                attempts.append({'attempt':attempt,'reason':last_reason})
                time.sleep(.055); continue

            blocked=_personal_snapshot_blocked_cells(snap,self._personal_bag_reserved_cells)
            old_cells={tuple(x) for x in ((current_target or {}).get('cells') or [])}
            overlap=old_cells & blocked
            stable=_target_cells_signature_stable(current_before,snap,(current_target or {}).get('cells') or [],max_mae=7.0)
            if old_cells and not overlap and stable.get('ok'):
                self._persist_store_trace(
                    cycle_id,item,state='DESTINATION_REVALIDATE_PASS',store_tx_id=store_tx_id,
                    attempt=attempt,replanned=False,
                    destination_anchor=[int(current_target.get('row',0)),int(current_target.get('col',0))],
                    destination_cells=[list(x) for x in (current_target.get('cells') or [])],
                    source_owner=GridOwner.PLAYER_INVENTORY.value,
                    destination_owner=GridOwner.PERSONAL_STORAGE.value,
                    storage_panel_rect=tg.get('panel_rect'),
                    storage_grid_rect=tg.get('grid_rect'),
                    player_inventory_grid_rect=tg.get('player_inventory_grid_rect'),
                    storage_lease_generation=tg.get('lease_generation'),
                )
                return {'ok':True,'replanned':False,'target':current_target,'target_grid':tg,
                        'target_before':snap,'image':img,'blocked_overlap':[],'attempts':attempts,
                        'attempt_count':attempt,'owner_identity':owners}

            candidate=_compact_personal_block(
                snap,item.get('footprint') or [1,1],self._personal_bag_reserved_cells,
                getattr(self,'_personal_bag_placement_history',{}),
                item_group=(item.get('group_id') or item.get('group_label'))
            )
            if not candidate:
                last_reason='STORE_DESTINATION_CHANGED_NO_REPLAN_AVAILABLE'
                attempts.append({'attempt':attempt,'reason':last_reason,'blocked_overlap':[list(x) for x in sorted(overlap)]})
                current_before=snap
                time.sleep(.055); continue
            cand_cells={tuple(x) for x in (candidate.get('cells') or [])}
            cand_overlap=cand_cells & blocked
            if cand_overlap:
                last_reason='STORE_DESTINATION_REPLAN_CONFLICT'
                attempts.append({'attempt':attempt,'reason':last_reason,'blocked_overlap':[list(x) for x in sorted(cand_overlap)]})
                current_before=snap; current_target=candidate
                time.sleep(.055); continue

            self._persist_store_trace(
                cycle_id,item,state='DESTINATION_REVALIDATE_PASS',store_tx_id=store_tx_id,
                attempt=attempt,replanned=True,
                destination_anchor=[int(candidate.get('row',0)),int(candidate.get('col',0))],
                destination_cells=[list(x) for x in (candidate.get('cells') or [])],
                source_owner=GridOwner.PLAYER_INVENTORY.value,
                destination_owner=GridOwner.PERSONAL_STORAGE.value,
                storage_panel_rect=tg.get('panel_rect'),
                storage_header_rect=tg.get('header_rect'),
                storage_grid_rect=tg.get('grid_rect'),
                storage_footer_rect=tg.get('footer_rect'),
                player_inventory_grid_rect=tg.get('player_inventory_grid_rect'),
                storage_inner_grid_verified=bool(tg.get('inner_grid_verified')),
                storage_grid_authority=tg.get('grid_authority'),
                storage_lease_generation=tg.get('lease_generation'),
            )
            return {'ok':True,'replanned':True,'target':candidate,'target_grid':tg,'target_before':snap,'image':img,
                    'previous_target':current_target,'blocked_overlap':[list(x) for x in sorted(overlap)],
                    'attempts':attempts,'attempt_count':attempt,'owner_identity':owners}

        self._persist_store_trace(cycle_id,item,state='DESTINATION_RECOVERY_PENDING',store_tx_id=store_tx_id,
                                  failure_reason=last_reason,cursor_holding=True,source_click_forbidden=True,
                                  attempts=attempts)
        return {'ok':False,'state':'DESTINATION_RECOVERY_PENDING','reason':last_reason,'cursor_holding':True,
                'recoverable_known_state':True,'attempts':attempts,'attempt_count':len(attempts)}

    def _store_send_pair_once(self, hwnd, item, source_grid, target_grid, target_anchor,
                              source_before=None, target_before=None, cursor_reference_image=None,
                              cursor_probe_point=None, cycle_id=0, store_tx_id=None, proof_dir=None):
        """V12.5 physical Store: PICK -> prove cursor hold -> revalidate -> PLACE.

        Uses the existing canonical click primitive. A destination click is forbidden
        until source pick is physically confirmed. If the destination changes while
        the item is held, only destination is replanned; source is never clicked again.
        """
        hwnd=int(hwnd)
        src=_candidate_click_point(item,source_grid)
        if not src:
            return {'ok':False,'reason':'STORE_SOURCE_POINT_UNAVAILABLE','attempt_count':0,'exactly_once':True}
        sx,sy=int(src[0]),int(src[1])
        item_anchor_policy=_derive_item_placement_anchor_policy(item,source_grid,(sx,sy))
        mode=str(self._cfg.get('input_mode','Auto') or 'Auto')
        pid=_window_pid(hwnd)
        auto_elevated=_is_current_process_elevated(); game_elevated=_process_elevated(pid)
        if game_elevated is True and not auto_elevated:
            return {'ok':False,'reason':'PRIVILEGE_MISMATCH','attempt_count':0,'exactly_once':True}

        result={
            'ok':False,'exactly_once':True,'attempt_count':1,'requested_mode':mode,
            'source_client':[sx,sy],'source_click_sent':False,'source_pick_confirmed':False,
            'cursor_holding_confirmed':False,'destination_click_sent':False,
            'destination_place_confirmed':False,'store_tx_id':store_tx_id,
            'target':target_anchor,'target_grid':target_grid,
            'item_placement_anchor_policy':item_anchor_policy,
        }
        pre_img=cursor_reference_image if cursor_reference_image is not None else capture_client(hwnd)
        if proof_dir and pre_img is not None:
            self._store_save_physical_proof(proof_dir,'01_store_source_before.png',pre_img)
            self._store_save_physical_proof(proof_dir,'02_source_click_point.png',pre_img,(sx,sy),'SOURCE_PICK')

        source_action=_left_click_client_once(hwnd,sx,sy,mode)
        result['source_action']=source_action
        result['source_click_sent']=bool(source_action.get('ok'))
        if result['source_click_sent']:
            self._persist_store_trace(cycle_id,item,state='STORE_SOURCE_PICK_SENT',store_tx_id=store_tx_id,
                                      click_sequence_number=1,logical_item_id=item.get('queue_id') or item.get('item_id'),
                                      source_anchor=item.get('anchor'),source_footprint=item.get('footprint'),
                                      source_client_x=sx,source_client_y=sy,source_input=source_action)
        if not source_action.get('ok'):
            result['reason']='STORE_SOURCE_PICK_DISPATCH_FAILED'
            return result
        time.sleep(STORE_PICK_SETTLE_BACKGROUND_SEC if mode=='Background' else STORE_PICK_SETTLE_FOREGROUND_SEC)

        pick=self._store_verify_source_pick_v125(
            hwnd,item,source_before or {},source_grid,pre_img,cursor_probe_point=cursor_probe_point
        )
        result['source_pick_verification']={k:v for k,v in pick.items() if not str(k).startswith('_')}
        result['source_pick_confirmed']=bool(pick.get('ok'))
        result['cursor_holding_confirmed']=bool(pick.get('cursor_state')=='CURSOR_HOLDING_ITEM_CONFIRMED')
        if proof_dir and pick.get('_last_image') is not None:
            self._store_save_physical_proof(proof_dir,'03_item_on_cursor.png',pick.get('_last_image'))
        if not pick.get('ok'):
            result['reason']=pick.get('state') or 'STORE_SOURCE_PICK_CONFIRMATION_FAILED'
            result['recoverable_known_state']=bool(pick.get('state')=='STORE_SOURCE_PICK_NOT_COMMITTED')
            result['cursor_holding']=bool(pick.get('cursor_state')=='CURSOR_HOLDING_ITEM_CONFIRMED')
            return result
        self._persist_store_trace(cycle_id,item,state='STORE_SOURCE_PICK_CONFIRMED',store_tx_id=store_tx_id,
                                  source_state=pick.get('source_state'),cursor_state=pick.get('cursor_state'),item_placement_anchor_policy=item_anchor_policy)
        self._persist_store_trace(cycle_id,item,state='STORE_CURSOR_HOLDING_ITEM',store_tx_id=store_tx_id,
                                  cursor_state=pick.get('cursor_state'))

        rv=self._store_revalidate_destination_v126(
            hwnd,item,target_grid,target_before or {},target_anchor,
            cycle_id=cycle_id,store_tx_id=store_tx_id,max_attempts=3
        )
        result['destination_revalidation']={k:v for k,v in rv.items() if not str(k).startswith('_') and k not in ('image','target_before')}
        if not rv.get('ok'):
            result['reason']='DESTINATION_RECOVERY_PENDING'
            result['destination_recovery_reason']=rv.get('reason') or 'STORE_DESTINATION_REVALIDATION_FAILED'
            result['recoverable_known_state']=True
            result['cursor_holding']=True
            result['source_click_forbidden']=True
            result['state']='DESTINATION_RECOVERY_PENDING'
            return result
        final_target=rv.get('target') or target_anchor
        final_grid=rv.get('target_grid') or target_grid
        final_before=rv.get('target_before') or target_before
        result['target']=final_target; result['target_grid']=final_grid; result['_target_before']=final_before
        result['destination_replanned']=bool(rv.get('replanned'))

        coord=_storage_destination_coordinate_contract(hwnd,final_grid,final_target,item_anchor_policy)
        result['destination_coordinate']={k:v for k,v in coord.items()}
        self._persist_store_trace(
            cycle_id,item,state='DESTINATION_COORDINATE_RESOLVE',store_tx_id=store_tx_id,
            coordinate_result=coord,planned_anchor=[int(final_target.get('row',0)),int(final_target.get('col',0))],
            footprint=list(final_target.get('footprint') or item.get('footprint') or [1,1]),
            input_mode=mode
        )
        if not coord.get('ok'):
            result['reason']='DESTINATION_RECOVERY_PENDING'
            result['destination_recovery_reason']=coord.get('reason') or 'DESTINATION_COORDINATE_INVALID'
            result['recoverable_known_state']=True
            result['cursor_holding']=True
            result['source_click_forbidden']=True
            result['state']='DESTINATION_RECOVERY_PENDING'
            self._persist_store_trace(cycle_id,item,state='DESTINATION_RECOVERY_PENDING',store_tx_id=store_tx_id,
                                      failure_reason=result['destination_recovery_reason'],cursor_holding=True,source_click_forbidden=True)
            return result
        dx,dy=[int(v) for v in coord.get('client_point')]
        result['target_client']=[dx,dy]
        result['target_screen']=None
        result['target_anchor']=[int(final_target['row']),int(final_target['col'])]
        result['footprint']=list(final_target.get('footprint') or item.get('footprint') or [1,1])
        source_owner=str((source_grid or {}).get('owner') or (source_grid or {}).get('kind') or '')
        destination_owner=str((final_grid or {}).get('lease_owner') or (final_grid or {}).get('owner') or (final_grid or {}).get('kind') or '')
        owner_trace={
            'store_tx_id':store_tx_id,
            'source_owner':source_owner,
            'destination_owner':destination_owner,
            'player_inventory_panel_rect':final_grid.get('player_inventory_panel_rect'),
            'player_inventory_grid_rect':final_grid.get('player_inventory_grid_rect'),
            'storage_panel_rect':final_grid.get('panel_rect'),
            'storage_header_rect':final_grid.get('header_rect'),
            'storage_grid_rect':final_grid.get('grid_rect'),
            'storage_footer_rect':final_grid.get('footer_rect'),
            'storage_inner_grid_verified':bool(final_grid.get('inner_grid_verified')),
            'storage_grid_authority':final_grid.get('grid_authority'),
            'planned_col':int(final_target.get('col',0)),
            'planned_row':int(final_target.get('row',0)),
            'click_x':dx,'click_y':dy,
            'coordinate_space':'CLIENT',
            'lease_generation':final_grid.get('lease_generation'),
        }
        self._persist_store_trace(cycle_id,item,state='STORE_GRID_OWNER_TRACE',store_tx_id=store_tx_id,**owner_trace)
        if source_owner!=GridOwner.PLAYER_INVENTORY.value or destination_owner!=GridOwner.PERSONAL_STORAGE.value:
            result['reason']='STORAGE_DESTINATION_OWNER_VIOLATION'
            result['owner_trace']=owner_trace
            result['cursor_holding']=True
            result['source_click_forbidden']=True
            result['recoverable_known_state']=True
            return result

        if proof_dir and rv.get('image') is not None:
            self._write_store_owner_overlay_path=_write_store_owner_overlay(
                proof_dir,rv.get('image'),final_grid,final_target,(dx,dy)
            )
            # CLIENT proof remains tied to the 800x600 capture. This is NOT the
            # coordinate passed to Foreground SendInput.
            self._store_save_physical_proof(proof_dir,'04_destination_click_point.png',rv.get('image'),(dx,dy),'DESTINATION CLIENT')
            self._store_save_physical_proof(proof_dir,'04_destination_click_point_CLIENT.png',rv.get('image'),(dx,dy),'DESTINATION CLIENT')

        # Prepare the ACTUAL destructive coordinate once.  Foreground converts
        # CLIENT -> SCREEN here and nowhere else.
        prepared=INPUT_COORDINATE_ADAPTER.prepare_client_point(
            hwnd,ClientPoint(dx,dy),mode,purpose='STORE_DESTINATION_PLACE',require_foreground=True
        )
        result['destination_input_prepared']={k:v for k,v in prepared.items() if not str(k).startswith('_')}
        if not prepared.get('ok'):
            result['reason']=prepared.get('reason') or 'DESTINATION_INPUT_COORDINATE_PREPARE_FAILED'
            result['cursor_holding']=True; result['recoverable_known_state']=True
            return result
        screen_safety=_storage_screen_dispatch_safety(final_grid,prepared)
        result['destination_screen_safety']=screen_safety
        if not screen_safety.get('ok'):
            result['reason']=screen_safety.get('reason') or 'CLIENT_SCREEN_TRANSFORM_VIOLATION'
            result['cursor_holding']=True; result['recoverable_known_state']=True
            self._persist_store_trace(cycle_id,item,state='CLIENT_SCREEN_TRANSFORM_VIOLATION',store_tx_id=store_tx_id,
                                      destination_client=[dx,dy],input_prepared=result['destination_input_prepared'],
                                      screen_safety=screen_safety)
            return result
        result['target_screen']=prepared.get('screen_point')
        if proof_dir:
            try:
                d=Path(proof_dir); d.mkdir(parents=True,exist_ok=True)
                screen_payload={
                    'store_tx_id':store_tx_id,'logical_item_id':item.get('queue_id') or item.get('item_id'),
                    'planned_col':int(final_target.get('col',0)),'planned_row':int(final_target.get('row',0)),
                    'destination_client_x':dx,'destination_client_y':dy,
                    'client_origin_screen_x':(prepared.get('client_origin_screen') or [None,None])[0],
                    'client_origin_screen_y':(prepared.get('client_origin_screen') or [None,None])[1],
                    'destination_screen_x':(prepared.get('screen_point') or [None,None])[0],
                    'destination_screen_y':(prepared.get('screen_point') or [None,None])[1],
                    'conversion_count':prepared.get('conversion_count'),'conversion_function':prepared.get('conversion_function'),
                    'input_mode':mode,'dpi':prepared.get('dpi'),'window_rect':prepared.get('window_rect'),
                    'client_rect':prepared.get('client_rect'),'screen_storage_grid_rect':screen_safety.get('screen_storage_grid_rect'),
                    'coordinate_contract':'CLIENT_POINT -> InputCoordinateAdapter -> SCREEN_POINT -> SendInput',
                }
                (d/'04b_destination_click_point_SCREEN.json').write_text(
                    json.dumps(screen_payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8'
                )
            except Exception:
                pass

        # QA-only calibration mode. The item remains on cursor and no destructive
        # destination click is sent until the owner/geometry proof is reviewed.
        if bool(self._cfg.get('storage_place_calibration',False)):
            result['reason']='STORAGE_PLACE_CALIBRATION_READY'
            result['state']='DESTINATION_RECOVERY_PENDING'
            result['cursor_holding']=True
            result['source_click_forbidden']=True
            result['recoverable_known_state']=True
            result['owner_trace']=owner_trace
            return result

        # Dispatch the exact ScreenPoint prepared/proved above. No conversion here.
        dest_action=INPUT_COORDINATE_ADAPTER.dispatch_prepared_left_click(prepared,verify_cursor=True)
        result['destination_action']=dest_action
        result['destination_click_sent']=bool(dest_action.get('ok'))
        if result['destination_click_sent']:
            self._persist_store_trace(cycle_id,item,state='STORE_DESTINATION_PLACE_SENT',store_tx_id=store_tx_id,
                                      click_sequence_number=2,destination_anchor=result['target_anchor'],
                                      destination_client_x=dx,destination_client_y=dy,
                                      destination_screen_x=(dest_action.get('screen_point') or [None,None])[0],
                                      destination_screen_y=(dest_action.get('screen_point') or [None,None])[1],
                                      client_origin_screen=dest_action.get('client_origin_screen'),
                                      conversion_count=dest_action.get('conversion_count'),
                                      coordinate_adapter=dest_action.get('adapter_version'),
                                      destination_input=dest_action,
                                      destination_replanned=bool(rv.get('replanned')))
        if not dest_action.get('ok'):
            result['reason']='STORE_DESTINATION_PLACE_DISPATCH_FAILED'; result['cursor_holding']=True
            result['recoverable_known_state']=True
            return result
        time.sleep(STORE_PLACE_SETTLE_SEC)
        after=capture_client(hwnd)
        result['_after_destination_image']=after
        if proof_dir and after is not None:
            self._store_save_physical_proof(proof_dir,'05_after_destination_click.png',after)
        result['ok']=True
        result['reason']='STORE_PICK_PLACE_INPUT_SENT'
        return result

    def _store_send_destination_only_once(self, hwnd, target_grid, target_anchor, anchor_policy=None):
        """V10.8 partial Store recovery: place cursor-held item only. Never source-clicks."""
        hwnd=int(hwnd)
        coord=_storage_destination_coordinate_contract(hwnd,target_grid,target_anchor,anchor_policy)
        if not coord.get('ok'):
            return {'ok':False,'reason':coord.get('reason') or 'STORE_DESTINATION_ONLY_POINT_UNAVAILABLE',
                    'source_click_sent':False,'destination_click_sent':False,'exactly_once':True,
                    'destination_coordinate':coord,'cursor_holding':True}
        dx,dy=[int(v) for v in coord.get('client_point')]; mode=str(self._cfg.get('input_mode','Auto') or 'Auto')
        result={'ok':False,'exactly_once':True,'source_click_sent':False,'destination_click_sent':False,
                'requested_mode':mode,'target_client':[dx,dy],'target_screen':None,
                'target_anchor':[int(target_anchor['row']),int(target_anchor['col'])],
                'footprint':list(target_anchor.get('footprint') or [1,1]),'destination_coordinate':coord}
        prepared=INPUT_COORDINATE_ADAPTER.prepare_client_point(
            hwnd,ClientPoint(dx,dy),mode,purpose='STORE_DESTINATION_ONLY_RECOVERY',require_foreground=True
        )
        result['destination_input_prepared']={k:v for k,v in prepared.items() if not str(k).startswith('_')}
        if not prepared.get('ok'):
            result['reason']=prepared.get('reason') or 'DESTINATION_INPUT_COORDINATE_PREPARE_FAILED'
            return result
        screen_safety=_storage_screen_dispatch_safety(target_grid,prepared)
        result['destination_screen_safety']=screen_safety
        if not screen_safety.get('ok'):
            result['reason']=screen_safety.get('reason') or 'CLIENT_SCREEN_TRANSFORM_VIOLATION'
            return result
        action=INPUT_COORDINATE_ADAPTER.dispatch_prepared_left_click(prepared,verify_cursor=True)
        if action.get('ok'): time.sleep(STORE_PLACE_SETTLE_SEC)
        result.update({
            'ok':bool(action.get('ok')),'destination_click_sent':bool(action.get('ok')),
            'used_mode':action.get('used_mode'),'target_screen':action.get('screen_point'),
            'destination_action':action,'conversion_count':action.get('conversion_count'),
            'client_origin_screen':action.get('client_origin_screen'),
        })
        if not action.get('ok'): result['reason']=action.get('reason') or 'STORE_DESTINATION_ONLY_FAILED'
        return result

    def _store_wait_confirm(self, hwnd, item, source_before, target_before, target_anchor, source_grid=None, target_grid=None):
        source_cells=set(_candidate_cells(item))
        target_cells={tuple(x) for x in (target_anchor.get('cells') or [])}
        t0=time.time(); polls=0; last={}
        known_sg=source_grid
        known_tg=target_grid
        while time.time()-t0 <= STORE_CONFIRM_TIMEOUT_SEC:
            time.sleep(STORE_CONFIRM_POLL_SEC); polls+=1
            img=capture_client(int(hwnd))
            if img is None: continue

            # v9.2: while the center popup is open, do not force both grids
            # through fresh global detection every poll. Reuse the exact grids
            # already verified immediately before the move, and only redetect
            # if their borders are no longer visible.
            sv=validate_known_grid(img,known_sg) if known_sg else {'ok':False}
            if sv.get('ok'):
                sg=known_sg
            else:
                sg=detect_inventory_grid(img)
                if sg.get('ok'):
                    known_sg=sg

            owners=detect_jx1_panel_identities(img)
            bound=_bind_storage_grid_owner_identity(self,hwnd,owners)
            tg=bound.get('grid') if bound.get('ok') else {'ok':False,'reason':bound.get('reason')}
            tv={'ok':bool(bound.get('ok')),'reason':bound.get('reason'),'owner_identity':owners}
            if bound.get('ok'):
                known_tg=tg

            if not sg.get('ok') or not tg.get('ok'):
                last={
                    'source_grid_ok':bool(sg.get('ok')),
                    'target_grid_ok':bool(tg.get('ok')),
                    'source_known_validation':sv,
                    'target_owner_validation':tv,
                }
                continue
            sa=snapshot_inventory(img,sg); ta=snapshot_inventory(img,tg)
            if not sa.get('ok') or not ta.get('ok'): continue
            sd=diff_snapshots(source_before,sa); td=diff_snapshots(target_before,ta)
            src_changed=set()
            for rec in sd.get('changed_cells',[]):
                if float(rec.get('pixel_diff',0) or 0)>=8.0:
                    src_changed.add((int(rec['row']),int(rec['col'])))
            tgt_changed=set()
            for rec in td.get('changed_cells',[]):
                if float(rec.get('pixel_diff',0) or 0)>=8.0:
                    tgt_changed.add((int(rec['row']),int(rec['col'])))
            src_need=max(1,int(len(source_cells)*0.60+0.999)) if source_cells else 1
            tgt_need=max(1,int(len(target_cells)*0.45+0.999)) if target_cells else 1
            src_hits=len(source_cells & src_changed)
            tgt_hits=len(target_cells & tgt_changed)
            last={'source_changed':src_hits,'source_needed':src_need,'target_changed':tgt_hits,'target_needed':tgt_need,'source_grid':sg,'target_grid':tg}
            if src_hits>=src_need and tgt_hits>=tgt_need:
                return {'ok':True,'polls':polls,'confirm_ms':int((time.time()-t0)*1000),'metrics':last,'source_snapshot':sa,'target_snapshot':ta,'image':img}
        return {'ok':False,'reason':'STORE_NOT_CONFIRMED_NO_RETRY','polls':polls,'metrics':last}

    def _store_destination_reprobe(self, hwnd, target_before, target, target_grid, max_frames=3):
        """V10.8 bounded MOVE/READ-ONLY destination reprobe. Never clicks.

        Used only after destructive Store input when source/cursor evidence is known
        but destination evidence conflicts or is weak.  This prevents a single
        destination false-negative from becoming Store TRUE_UNKNOWN immediately.
        """
        cells=target.get('cells') or []
        frames=[]; occupied_votes=0; empty_votes=0; ambiguous_votes=0
        last_grid=target_grid
        for i in range(max(1,int(max_frames or 3))):
            time.sleep(.055 if i else .035)
            img=capture_client(int(hwnd))
            if img is None:
                frames.append({'frame':i+1,'state':'CAPTURE_FAILED'}); ambiguous_votes+=1; continue
            owners=detect_jx1_panel_identities(img)
            bound=_bind_storage_grid_owner_identity(self,hwnd,owners)
            tg=bound.get('grid') if bound.get('ok') else {'ok':False,'reason':bound.get('reason')}
            if not tg or not tg.get('ok'):
                frames.append({'frame':i+1,'state':'OWNER_GRID_UNRESOLVED','owner_identity':owners}); ambiguous_votes+=1; continue
            last_grid=tg
            snap=snapshot_inventory(img,tg)
            if not snap.get('ok'):
                frames.append({'frame':i+1,'state':'SNAPSHOT_FAILED'}); ambiguous_votes+=1; continue
            check=_target_cells_signature_stable(target_before,snap,cells,max_mae=7.0)
            details=check.get('details') or []
            # Existing strict evidence: any target cell no longer definitely empty
            # or materially changed means destination was affected by the place.
            changed=not bool(check.get('ok'))
            all_empty=bool(details) and all(bool(d.get('empty_now')) for d in details)
            if changed:
                state='DESTINATION_OCCUPIED_OR_CHANGED'; occupied_votes+=1
            elif all_empty:
                state='DESTINATION_EMPTY_CONFIRMED'; empty_votes+=1
            else:
                state='DESTINATION_AMBIGUOUS'; ambiguous_votes+=1
            frames.append({'frame':i+1,'state':state,'check':check})
        if occupied_votes>=2 or (occupied_votes>=1 and empty_votes==0 and ambiguous_votes==0):
            state='DESTINATION_OCCUPIED_CONFIRMED'
        elif empty_votes>=2 and occupied_votes==0:
            state='DESTINATION_EMPTY_CONFIRMED'
        else:
            state='DESTINATION_AMBIGUOUS'
        return {'state':state,'frames':frames,'occupied_votes':occupied_votes,'empty_votes':empty_votes,
                'ambiguous_votes':ambiguous_votes,'target_grid':last_grid,'reprobe_count':len(frames)}

    def _store_reconcile_noncommit_for_auto_resume(self, hwnd, item, source_before, target_before, target, source_grid, target_grid, cursor_reference_image, cursor_probe_point):
        """V10.8 Store reconciliation matrix. Diagnostic/recovery only; never source-reclicks.

        TRUE_UNKNOWN is reserved for the state where source/cursor/destination
        remain unresolved after bounded reprobe. Known states route to commit,
        same-tx retry, or destination-only recovery.
        """
        fingerprint=_build_source_item_fingerprint(item,source_before,self._batch_preopen_snapshot)
        source_states=[]; target_checks=[]; fresh_source=None; fresh_target=None
        cursor={'state':'CURSOR_UNCERTAIN'}; last_img=None
        destination_reprobe=None; cursor_reprobe=None
        try:
            _park_cursor_personal_bag_header(hwnd,target_grid,.055)
            for _ in range(2):
                time.sleep(.050)
                img=capture_client(int(hwnd))
                if img is None: continue
                last_img=img
                sg=source_grid if (source_grid and validate_known_grid(img,source_grid).get('ok')) else detect_inventory_grid(img)
                if sg.get('ok'):
                    sg=dict(sg); sg['kind']=GridOwner.PLAYER_INVENTORY.value; sg['owner']=GridOwner.PLAYER_INVENTORY.value; sg['coordinate_space']='CLIENT'
                owners=detect_jx1_panel_identities(img)
                bound=_bind_storage_grid_owner_identity(self,hwnd,owners)
                tg=bound.get('grid') if bound.get('ok') else {'ok':False,'reason':bound.get('reason')}
                if not sg.get('ok') or not tg.get('ok'): continue
                ss=snapshot_inventory(img,sg); ts=snapshot_inventory(img,tg)
                if not ss.get('ok') or not ts.get('ok'): continue
                fresh_source=ss; fresh_target=ts
                source_states.append(_source_item_fingerprint_state(fingerprint,source_before,ss,self._batch_preopen_snapshot))
                target_checks.append(_target_cells_signature_stable(target_before,ts,target.get('cells') or [],max_mae=7.0))
            if last_img is not None and cursor_reference_image is not None and cursor_probe_point:
                cursor=_probe_cursor_attachment(cursor_reference_image,last_img,cursor_probe_point)
            source_present=bool(source_states and all(x.get('state')=='ITEM_STILL_IN_SOURCE' for x in source_states))
            source_clear=bool(source_states and all(x.get('state')=='ITEM_GONE' for x in source_states))
            target_empty=bool(target_checks and all(x.get('ok') for x in target_checks))
            target_changed=bool(target_checks and any(not x.get('ok') for x in target_checks))
            cursor_empty=cursor.get('state')=='CURSOR_CLEAR'
            cursor_holding=cursor.get('state') in ('ITEM_ON_CURSOR_SUSPECT','CURSOR_HOLDING_ITEM_CONFIRMED')
            if cursor.get('state')=='CURSOR_UNCERTAIN' and last_img is not None and cursor_reference_image is not None:
                cursor_reprobe=self._drop_probe_cursor_carry_reprobe(
                    hwnd,cursor_reference_image,initial_probe_point=cursor_probe_point,
                    motion_image=last_img,max_zones=3,samples_per_zone=3)
                rs=str((cursor_reprobe or {}).get('state') or '')
                if rs=='CURSOR_EMPTY_CONFIRMED': cursor_empty=True; cursor={'state':'CURSOR_EMPTY_CONFIRMED','reprobe':cursor_reprobe}
                elif rs=='CURSOR_HOLDING_ITEM_CONFIRMED': cursor_holding=True; cursor={'state':'CURSOR_HOLDING_ITEM_CONFIRMED','reprobe':cursor_reprobe}

            # Matrix B: source is still present + cursor empty -> source pick did not commit.
            if source_present and cursor_empty:
                reason='STORE_NOT_COMMITTED_SOURCE_PRESENT_CURSOR_EMPTY'; safe=True; committed=False; recovery='SAME_STORE_RETRY'
            # Matrix C: source clear + cursor holding -> partial commit; destination only.
            elif source_clear and cursor_holding:
                reason='STORE_PARTIAL_COMMIT_CURSOR_HOLDING'; safe=True; committed=False; recovery='DESTINATION_ONLY_RECOVERY'
            # Matrix A/E: destination changed + cursor empty + source gone => committed.
            elif source_clear and target_changed and cursor_empty:
                reason='STORE_COMMITTED_RECONCILED'; safe=True; committed=True; recovery='FINALIZE'
            else:
                # V10.8 root fix for Store #38: conflicting source-clear/cursor-empty
                # evidence does NOT jump straight to TRUE_UNKNOWN. Reprobe only the
                # destination footprint first, without clicking.
                if source_clear and cursor_empty:
                    destination_reprobe=self._store_destination_reprobe(hwnd,target_before,target,target_grid,max_frames=3)
                    ds=str((destination_reprobe or {}).get('state') or 'DESTINATION_AMBIGUOUS')
                    if ds=='DESTINATION_OCCUPIED_CONFIRMED':
                        reason='STORE_COMMITTED_RECONCILED'; safe=True; committed=True; recovery='FINALIZE'
                    elif ds=='DESTINATION_EMPTY_CONFIRMED':
                        # Source gone + cursor empty + destination proven empty is a
                        # contradictory post-action state: item location is genuinely unknown.
                        reason='STORE_TRANSACTION_TRUE_UNKNOWN'; safe=False; committed=False; recovery='TRUE_SAFE_PAUSE'
                    else:
                        reason='STORE_DESTINATION_REPROBE_UNRESOLVED'; safe=False; committed=False; recovery='PRE_SAFE_PAUSE_REPROBE'
                elif source_present and not cursor_holding:
                    reason='STORE_NOT_COMMITTED_SOURCE_PRESENT'; safe=True; committed=False; recovery='SAME_STORE_RETRY'
                else:
                    reason='STORE_TRANSACTION_TRUE_UNKNOWN'; safe=False; committed=False; recovery='TRUE_SAFE_PAUSE'
            return {
                'safe':safe,'committed':bool(committed),'reason':reason,'recovery':recovery,
                'source_state':('SOURCE_PRESENT_CONFIRMED' if source_present else ('SOURCE_CLEAR_CONFIRMED' if source_clear else 'SOURCE_AMBIGUOUS')),
                'destination_state':(('DESTINATION_OCCUPIED_CONFIRMED' if target_changed else ('DESTINATION_EMPTY_CONFIRMED' if target_empty else 'DESTINATION_AMBIGUOUS')) if not destination_reprobe else destination_reprobe.get('state')),
                'cursor_state':('CURSOR_HOLDING_ITEM_CONFIRMED' if cursor_holding else ('CURSOR_EMPTY_CONFIRMED' if cursor_empty else 'CURSOR_AMBIGUOUS')),
                'source_item_fingerprint':fingerprint,'source_states':source_states,'destination_checks':target_checks,
                'destination_reprobe':destination_reprobe,'cursor_item_state':cursor.get('state'),'cursor_probe':cursor,
                'cursor_reprobe':cursor_reprobe,'fresh_frames_used':len(source_states),
                '_fresh_source_snapshot':fresh_source,'_fresh_target_snapshot':fresh_target,
                '_cursor_clear_reference_image':last_img if cursor_empty else None,
            }
        except Exception as e:
            return {'safe':False,'committed':False,'reason':'STORE_TRANSACTION_TRUE_UNKNOWN','recovery':'TRUE_SAFE_PAUSE',
                    'error':str(e),'source_item_fingerprint':fingerprint,'source_states':source_states,
                    'destination_checks':target_checks,'destination_reprobe':destination_reprobe,
                    'cursor_item_state':cursor.get('state'),'cursor_probe':cursor,'fresh_frames_used':len(source_states),
                    'source_state':'SOURCE_AMBIGUOUS','destination_state':'DESTINATION_AMBIGUOUS','cursor_state':'CURSOR_AMBIGUOUS'}

    def chest_store_queue_item(self, hwnd, item_index=0):
        """KEEP path: open personal bag by the shown bottom icon, place item, verify, close."""
        try:
            hwnd=int(hwnd); idx=int(item_index)
            item=self._queue_item_by_index(idx)
            if not item: return {'ok':False,'safe_pause':True,'reason':'STORE_ITEM_NOT_FOUND'}
            if item.get('decision') != 'KEEP':
                return {'ok':False,'safe_pause':True,'reason':'STORE_BLOCKED_DECISION_NOT_KEEP','decision':item.get('decision')}
            cycle_id=int(getattr(self,'_chest_cycle_seq',0) or 0)
            store_tx_id=f"STORE-{cycle_id:06d}-{str(item.get('queue_id') or 'Q01')}"
            self._persist_store_trace(cycle_id,item,state='STORE_CONTROLLER_ENTER',store_tx_id=store_tx_id)

            self._persist_store_trace(cycle_id,item,state='SOURCE_GRID_CAPTURE_BEGIN')
            source=self._capture_source_grid_visible(hwnd)
            if not source.get('ok'):
                self._persist_store_trace(cycle_id,item,state='SOURCE_GRID_CAPTURE_FAILED',failure_reason='STORE_SOURCE_GRID_NOT_VISIBLE',source=source)
                return {'ok':False,'safe_pause':True,'reason':'STORE_SOURCE_GRID_NOT_VISIBLE','source':source}
            self._inventory_grid=source['grid']
            _park_cursor_on_inventory_header(hwnd,self._inventory_grid,.055)
            clean_source=capture_client(hwnd)
            if clean_source is None:
                self._persist_store_trace(cycle_id,item,state='SOURCE_GRID_CAPTURE_FAILED',failure_reason='STORE_SOURCE_CLEAN_CAPTURE_FAILED')
                return {'ok':False,'safe_pause':True,'reason':'STORE_SOURCE_CLEAN_CAPTURE_FAILED'}

            # v10.4.5 root fix: the clean recapture must NOT throw away a source
            # grid that was already proven moments earlier. The generic edge detector
            # can report GRID_CONFIDENCE_LOW while the canonical/known 6x10 borders
            # are still valid (real cycle 000015 reproduction). Revalidate the known
            # grid first, then generic detect, then canonical validated recovery.
            sg=None
            source_grid_recovery={'method':None}
            preferred=source.get('grid') or self._inventory_grid
            known=validate_known_grid(clean_source,preferred) if preferred else {'ok':False,'reason':'NO_PREFERRED_GRID'}
            if known.get('ok'):
                sg=dict(preferred); sg['ok']=True; sg['known_grid_validation']=known
                source_grid_recovery={'method':'KNOWN_GRID_REVALIDATED','known':known}
            else:
                generic=detect_inventory_grid(clean_source)
                if generic.get('ok'):
                    sg=generic
                    source_grid_recovery={'method':'GENERIC_DETECTOR','generic':generic}
                else:
                    canon=_canonical_source_grid_candidate(clean_source)
                    if canon.get('ok'):
                        sg=canon.get('grid')
                        source_grid_recovery={'method':'CANONICAL_VALIDATED_RECOVERY','generic':generic,'canonical':canon.get('validation')}
                    else:
                        fail_diag={'known':known,'generic':generic,'canonical':canon}
                        self._persist_store_trace(
                            cycle_id,item,state='SOURCE_GRID_CAPTURE_FAILED',
                            failure_reason='STORE_SOURCE_GRID_LOST_BEFORE_MOVE',
                            source_grid_recovery=fail_diag
                        )
                        return {'ok':False,'safe_pause':True,'reason':'STORE_SOURCE_GRID_LOST_BEFORE_MOVE','grid':generic,'source_grid_recovery':fail_diag}
            sg=dict(sg); sg['kind']=GridOwner.PLAYER_INVENTORY.value; sg['owner']=GridOwner.PLAYER_INVENTORY.value; sg['coordinate_space']='CLIENT'
            self._inventory_grid=sg
            self._persist_store_trace(cycle_id,item,state='SOURCE_GRID_CAPTURE_CONFIRMED',source_grid_recovery=source_grid_recovery)
            source_before=snapshot_inventory(clean_source,sg)
            if not source_before.get('ok'):
                self._persist_store_trace(cycle_id,item,state='SOURCE_GRID_SNAPSHOT_FAILED',failure_reason='STORE_SOURCE_SNAPSHOT_FAILED',source_grid_recovery=source_grid_recovery)
                return {'ok':False,'safe_pause':True,'reason':'STORE_SOURCE_SNAPSHOT_FAILED','source_grid_recovery':source_grid_recovery}

            self._persist_store_trace(cycle_id,item,state='STORAGE_OPEN_REQUESTED')
            opened=_try_personal_bag_open_once(hwnd,clean_source,self._cfg.get('input_mode','Auto'))
            if not opened.get('ok'):
                return {'ok':False,'safe_pause':True,'reason':opened.get('reason','PERSONAL_BAG_OPEN_FAILED'),'personal_bag':opened}
            self._persist_store_trace(cycle_id,item,state='STORAGE_OPEN_CONFIRMED')
            # v9.7: opening the center bag restores the old mouse position, which
            # can be the source item itself. Park on the personal-bag header and
            # recapture a CLEAN frame before deciding where to place the item.
            target_grid=opened['grid']
            cursor_park=_park_cursor_personal_bag_header(hwnd,target_grid,.085)
            clean_target_img=None
            clean_target_grid=None
            clean_owner_identity=None
            for _ in range(3):
                img2=capture_client(hwnd)
                if img2 is None:
                    time.sleep(.045); continue
                owners2=detect_jx1_panel_identities(img2)
                bound2=_bind_storage_grid_owner_identity(self,hwnd,owners2)
                if bound2.get('ok'):
                    clean_target_grid=bound2['grid']
                    clean_target_img=img2
                    clean_owner_identity=owners2
                    break
                time.sleep(.045)
            if clean_target_img is None or clean_target_grid is None:
                return {
                    'ok':False,'safe_pause':True,
                    'reason':'PERSONAL_STORAGE_OWNER_RECAPTURE_FAILED',
                    'personal_bag':opened,'cursor_park':cursor_park,
                    'owner_identity':clean_owner_identity,
                }
            target_grid=clean_target_grid
            self._persist_store_trace(
                cycle_id,item,state='STORAGE_GEOMETRY_DETECTED',
                grid_origin_x=int((target_grid.get('x_lines') or [0])[0]),
                grid_origin_y=int((target_grid.get('y_lines') or [0])[0]),
                cell_width=int(round(sum(target_grid.get('spacing_x') or [28])/max(1,len(target_grid.get('spacing_x') or [28])))),
                cell_height=int(round(sum(target_grid.get('spacing_y') or [28])/max(1,len(target_grid.get('spacing_y') or [28])))),
                rows=int(target_grid.get('rows') or 10),columns=int(target_grid.get('cols') or 6),
                total_cells=int((target_grid.get('rows') or 10)*(target_grid.get('cols') or 6)),
                source_owner=GridOwner.PLAYER_INVENTORY.value,
                destination_owner=GridOwner.PERSONAL_STORAGE.value,
                storage_panel_rect=target_grid.get('panel_rect'),
                storage_header_rect=target_grid.get('header_rect'),
                storage_grid_rect=target_grid.get('grid_rect'),
                storage_footer_rect=target_grid.get('footer_rect'),
                storage_inner_grid_verified=bool(target_grid.get('inner_grid_verified')),
                storage_grid_authority=target_grid.get('grid_authority'),
                player_inventory_grid_rect=target_grid.get('player_inventory_grid_rect'),
                coordinate_space=target_grid.get('coordinate_space'),
                storage_lease_generation=target_grid.get('lease_generation')
            )
            self._persist_store_trace(cycle_id,item,state='OCCUPANCY_SCAN_BEGIN')
            target_before=snapshot_inventory(clean_target_img,target_grid)
            if not target_before.get('ok'):
                self._persist_store_trace(cycle_id,item,state='OCCUPANCY_SCAN_FAILED',failure_reason='PERSONAL_BAG_SNAPSHOT_FAILED')
                return {'ok':False,'safe_pause':True,'reason':'PERSONAL_BAG_SNAPSHOT_FAILED','personal_bag':opened}
            # v10.4.5: reservations are advisory between stores and MUST be
            # revalidated against the fresh current storage snapshot. This prevents
            # stale reservations/ghost occupancy from accumulating across cycles.
            if self._personal_bag_reserved_hwnd != hwnd:
                self._personal_bag_reserved_hwnd=hwnd
                self._personal_bag_reserved_cells=set()
            fresh_visual_blocked=_personal_snapshot_blocked_cells(target_before,set())
            previous_reserved=set(self._personal_bag_reserved_cells)
            self._personal_bag_reserved_cells={rc for rc in previous_reserved if rc in fresh_visual_blocked}
            released_reserved=sorted(previous_reserved-self._personal_bag_reserved_cells)
            initial_blocked_cells=sorted(_personal_snapshot_blocked_cells(target_before,self._personal_bag_reserved_cells))
            strict_free_cells=[]
            cmap={(int(c['row']),int(c['col'])):c for c in (target_before.get('cells') or [])}
            blocked_set=set(initial_blocked_cells)
            for rr in range(10):
                for cc in range(6):
                    if (rr,cc) not in blocked_set and _personal_cell_strict_empty(cmap.get((rr,cc))):
                        strict_free_cells.append((rr,cc))
            planner_footprint=list(item.get('footprint') or [1,1])
            source_footprint=list(item.get('footprint') or [1,1])
            if source_footprint != planner_footprint:
                self._persist_store_trace(cycle_id,item,state='DESTINATION_SEARCH_FAILED',failure_reason='STORE_FOOTPRINT_MISMATCH',source_footprint=source_footprint,planner_footprint=planner_footprint)
                return {'ok':False,'safe_pause':True,'reason':'STORE_FOOTPRINT_MISMATCH','source_footprint':source_footprint,'planner_footprint':planner_footprint}
            self._persist_store_trace(
                cycle_id,item,state='OCCUPANCY_SCAN_COMPLETE',
                occupied_cells=len(initial_blocked_cells),free_cells=len(strict_free_cells),
                reserved_cells=len(self._personal_bag_reserved_cells),
                reservation_released_cells=[list(x) for x in released_reserved],
                source_footprint=source_footprint,planner_footprint=planner_footprint
            )
            # Existing V9_8 planner already scans the entire 6x10 grid row-major.
            # v10.4.5 makes that invariant explicit in the trace and never labels a
            # local miss as STORAGE_FULL.
            self._persist_store_trace(cycle_id,item,state='DESTINATION_SEARCH_BEGIN',footprint=planner_footprint,full_grid_scan_used=True)
            target=None
            plan_snapshot=target_before
            placement_checks=[]
            for plan_idx in range(3):
                candidate=_compact_personal_block(
                    plan_snapshot,item.get('footprint') or [1,1],
                    self._personal_bag_reserved_cells,
                    getattr(self,'_personal_bag_placement_history',{}),
                    item_group=(item.get('group_id') or item.get('group_label'))
                )
                if not candidate:
                    break
                time.sleep(.055 if plan_idx==0 else .040)
                guard_img=capture_client(hwnd)
                if guard_img is None:
                    placement_checks.append({'plan':plan_idx+1,'ok':False,'reason':'CAPTURE_FAILED'})
                    continue
                guard_owners=detect_jx1_panel_identities(guard_img)
                guard_bound=_bind_storage_grid_owner_identity(self,hwnd,guard_owners)
                guard_grid=guard_bound.get('grid') if guard_bound.get('ok') else {'ok':False,'reason':guard_bound.get('reason')}
                if not guard_grid.get('ok'):
                    placement_checks.append({'plan':plan_idx+1,'ok':False,'reason':'TARGET_OWNER_LOST','grid':guard_grid,'owner_identity':guard_owners})
                    continue
                guard_snap=snapshot_inventory(guard_img,guard_grid)
                if not guard_snap.get('ok'):
                    placement_checks.append({'plan':plan_idx+1,'ok':False,'reason':'SNAPSHOT_FAILED'})
                    continue
                blocked_now=_personal_snapshot_blocked_cells(guard_snap,self._personal_bag_reserved_cells)
                target_cells={tuple(x) for x in (candidate.get('cells') or [])}
                overlap=target_cells & blocked_now
                stable=_target_cells_signature_stable(plan_snapshot,guard_snap,candidate.get('cells') or [],max_mae=7.0)
                check={
                    'plan':plan_idx+1,'ok':bool(not overlap and stable.get('ok')),
                    'candidate':candidate,
                    'blocked_overlap':[list(x) for x in sorted(overlap)],
                    'stability':stable,
                    'blocked_count':len(blocked_now),
                }
                placement_checks.append(check)
                plan_snapshot=guard_snap
                target_grid=guard_grid
                if check['ok']:
                    target=candidate
                    target_before=guard_snap
                    break

            if not target:
                # Full-grid planner exhausted every legal anchor. Distinguish
                # "no fitting region" from a truly full grid; never collapse this
                # to STORAGE_FULL merely because no target was returned.
                occupancy_diag=_write_personal_bag_occupancy_diag(
                    clean_target_img,target_grid,target_before,self._personal_bag_reserved_cells,
                    target=None,note='FULL_GRID_NO_DESTINATION'
                )
                free_count=len(strict_free_cells)
                failure_reason='PERSONAL_BAG_NO_FITTING_SPACE' if free_count>0 else 'PERSONAL_BAG_CONFIRMED_FULL'
                self._persist_store_trace(
                    cycle_id,item,state='DESTINATION_SEARCH_FAILED',
                    failure_reason=failure_reason,
                    rows=10,columns=6,total_cells=60,
                    occupied_cells=len(initial_blocked_cells),free_cells=free_count,
                    reserved_cells=len(self._personal_bag_reserved_cells),
                    source_footprint=source_footprint,planner_footprint=planner_footprint,
                    all_candidate_regions_checked=True,full_grid_scan_used=True,destination_found=False,
                    occupancy_diag=occupancy_diag
                )
                close=_try_personal_storage_close_owner_once_v1211(hwnd,clean_target_img,self._cfg.get('input_mode','Auto'),proof_dir=None)
                return {
                    'ok':False,'safe_pause':True,
                    'reason':failure_reason,
                    'footprint':item.get('footprint'),'close':close,
                    'placement_checks':placement_checks,
                    'reserved_count':len(self._personal_bag_reserved_cells),
                    'free_count':free_count,
                    'occupied_cells_before':[list(x) for x in initial_blocked_cells],
                    'full_grid_scan_used':True,
                    'all_candidate_regions_checked':True,
                    'occupancy_diag':occupancy_diag,
                }

            self._persist_store_trace(cycle_id,item,state='DESTINATION_FOUND',destination_cells=[list(x) for x in (target.get('cells') or [])],valid_candidate_count=target.get('valid_candidate_count'),affinity_score=target.get('affinity_score'),compactness_score=target.get('compactness_score'),fragmentation_penalty=target.get('fragmentation_penalty'),packing_final_score=target.get('final_score'),placement_policy=target.get('placement_policy'))
            occupancy_diag=_write_personal_bag_occupancy_diag(
                clean_target_img,target_grid,target_before,self._personal_bag_reserved_cells,
                target=target,note='PRECLICK_TARGET_PROVEN_EMPTY'
            )

            # V12.4 StorageTruthHarness: measure reality first. The planner and
            # destination policy above are unchanged from V12.2. No click is allowed
            # until a human-reviewed truth_id explicitly authorizes ONE Store.
            cmap_truth={(int(c.get('row',-1)),int(c.get('col',-1))):c for c in (target_before.get('cells') or [])}
            blocked_truth=_personal_snapshot_blocked_cells(target_before,self._personal_bag_reserved_cells)
            occupancy_states={}
            for rr in range(10):
                for cc in range(6):
                    rc=(rr,cc); cell=cmap_truth.get(rc)
                    if rc in blocked_truth:
                        occupancy_states[rc]='OCCUPIED'
                    elif _personal_cell_strict_empty(cell):
                        occupancy_states[rc]='EMPTY'
                    else:
                        occupancy_states[rc]='UNKNOWN'
            fp=list(item.get('footprint') or [1,1])
            orientation=('HORIZONTAL' if int(fp[0])>int(fp[1]) else ('VERTICAL' if int(fp[1])>int(fp[0]) else 'SQUARE'))
            truth_dir=LOG_PROOF_STORAGE_DIR/'truth'/f'{int(cycle_id or 0):06d}_{str(item.get("queue_id") or item.get("item_id") or "ITEM")}'
            source_preview=_candidate_click_point(item,self._inventory_grid)
            preview_anchor_policy=_derive_item_placement_anchor_policy(item,self._inventory_grid,source_preview) if source_preview else {'ok':False,'reason':'SOURCE_PICK_CELL_UNRESOLVED'}
            intended_coord=_storage_destination_coordinate_contract(hwnd,target_grid,target,preview_anchor_policy)
            intended_click=tuple(int(x) for x in intended_coord.get('client_point')) if intended_coord.get('ok') else None
            truth_pre=write_pre_store_truth(
                truth_dir,storage_image=clean_target_img,storage_grid=target_grid,occupancy_states=occupancy_states,
                source_image=clean_source,source_grid=sg,source_cells=_candidate_cells(item),
                item_id=item.get('queue_id') or item.get('item_id'),footprint=fp,orientation=orientation,
                target=target,click_point=intended_click,cycle_id=cycle_id,planner_reason=target.get('placement_policy')
            )
            target_cells_truth={tuple(x) for x in (target.get('cells') or [])}
            truth_all_empty=bool(target_cells_truth) and all(occupancy_states.get(rc)=='EMPTY' for rc in target_cells_truth)
            execution_guard={
                'truth_id':truth_pre.get('truth_id'),'all_planned_cells_empty':truth_all_empty,
                'click_point_available':bool(intended_click),'grid_ok':bool(target_grid.get('ok')),'item_placement_anchor_policy':preview_anchor_policy,'destination_coordinate':intended_coord,
                'footprint':fp,'destination_cells':[list(x) for x in sorted(target_cells_truth)],
            }
            self._persist_store_trace(cycle_id,item,state='STORAGE_TRUTH_DRYRUN',truth_id=truth_pre.get('truth_id'),
                                      truth_dir=str(truth_dir),execution_guard=execution_guard,no_destructive_input_sent=True)
            if not all(execution_guard[k] for k in ('all_planned_cells_empty','click_point_available','grid_ok')):
                close_truth=_try_personal_storage_close_owner_once_v1211(hwnd,clean_target_img,self._cfg.get('input_mode','Auto'),proof_dir=None)
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'STORAGE_TRUTH_EXECUTION_GUARD_FAILED',
                        'no_destructive_input_sent':True,'truth_id':truth_pre.get('truth_id'),'truth_dir':str(truth_dir),
                        'storage_truth_pre':truth_pre,'execution_guard':execution_guard,'personal_bag_close':close_truth,
                        'target':target,'queue_item':public_queue_item(item)}

            self._persist_store_trace(cycle_id,item,state='SOURCE_ITEM_CONFIRMED',store_tx_id=store_tx_id,
                                      logical_item_id=item.get('queue_id') or item.get('item_id'),
                                      source_anchor=item.get('anchor'),source_footprint=item.get('footprint'))
            self._persist_store_trace(cycle_id,item,state='DESTINATION_PLAN_CONFIRMED',store_tx_id=store_tx_id,
                                      destination_anchor=[int(target.get('row',0)),int(target.get('col',0))],
                                      destination_cells=[list(x) for x in (target.get('cells') or [])],execution_guard=execution_guard)
            proof_dir=LOG_PROOF_STORAGE_DIR/'physical'/f'{int(cycle_id or 0):06d}_{str(item.get("queue_id") or item.get("item_id") or "ITEM")}'
            action=self._store_send_pair_once(
                hwnd,item,self._inventory_grid,target_grid,target,
                source_before=source_before,target_before=target_before,cursor_reference_image=clean_target_img,
                cursor_probe_point=(cursor_park or {}).get('client_point'),cycle_id=cycle_id,store_tx_id=store_tx_id,
                proof_dir=proof_dir
            )
            target=action.get('target') or target
            target_grid=action.get('target_grid') or target_grid
            if action.get('_target_before') is not None:
                target_before=action.get('_target_before')
            if not action.get('ok'):
                reason=str(action.get('reason') or 'STORE_INPUT_FAILED_NO_RETRY')
                return {'ok':False,'safe_pause':False,'recoverable_known_state':bool(action.get('recoverable_known_state')),
                        'cursor_holding':bool(action.get('cursor_holding')),'store_tx_id':store_tx_id,
                        'reason':reason,'action':{k:v for k,v in action.items() if not str(k).startswith('_')},
                        'target':target,'queue_item':public_queue_item(item),'truth_id':truth_pre.get('truth_id'),'truth_dir':str(truth_dir)}
            confirm=self._store_wait_confirm(hwnd,item,source_before,target_before,target,self._inventory_grid,target_grid)
            if not confirm.get('ok'):
                reconcile=self._store_reconcile_noncommit_for_auto_resume(
                    hwnd,item,source_before,target_before,target,self._inventory_grid,target_grid,
                    clean_target_img,(cursor_park or {}).get('client_point')
                )
                precise=str(reconcile.get('reason') or 'STORE_TRANSACTION_TRUE_UNKNOWN')
                public_reconcile={k:v for k,v in reconcile.items() if not str(k).startswith('_')}
                if precise=='STORE_COMMITTED_RECONCILED' and reconcile.get('committed'):
                    # Physical truth is already proven by fresh source+destination+cursor
                    # reconciliation. Route into the SAME common commit path; never
                    # return before chest_store_item is written.
                    self._persist_store_trace(cycle_id,item,state='STORE_COMMITTED_RECONCILED',transaction_reconcile=public_reconcile)
                    src_cells=set(_candidate_cells(item)); dst_cells={tuple(x) for x in (target.get('cells') or [])}
                    confirm={
                        'ok':True,'polls':0,'confirm_ms':0,'reconciled':True,
                        'metrics':{
                            'source_changed':max(1,len(src_cells)),'source_needed':1,
                            'target_changed':max(1,len(dst_cells)),'target_needed':1,
                            'source_grid':self._inventory_grid,'target_grid':target_grid,
                        },
                        'source_snapshot':reconcile.get('_fresh_source_snapshot'),
                        'target_snapshot':reconcile.get('_fresh_target_snapshot'),
                        'image':reconcile.get('_cursor_clear_reference_image') or capture_client(int(hwnd)),
                        'transaction_reconcile':public_reconcile,
                    }
                elif precise in ('STORE_NOT_COMMITTED_SOURCE_PRESENT_CURSOR_EMPTY','STORE_NOT_COMMITTED_SOURCE_PRESENT'):
                    item['status']='MATCH_PENDING_STORE'; item['reason']=precise
                    self._clear_auto_resume_action_lag_context(uncertain=False)
                    self._persist_store_trace(cycle_id,item,state=precise,failure_reason=precise,transaction_reconcile=public_reconcile)
                    return {'ok':False,'safe_pause':False,'recoverable_known_state':True,'recovery_policy':'SAME_STORE_RETRY',
                            'store_tx_id':store_tx_id,'reason':precise,'action':{k:v for k,v in action.items() if not str(k).startswith('_')},'confirm':confirm,
                            'transaction_reconcile':public_reconcile,'target':target,'queue_item':public_queue_item(item)}
                elif precise=='STORE_PARTIAL_COMMIT_CURSOR_HOLDING':
                    item['status']='ACTION_IN_FLIGHT'; item['reason']=precise
                    self._clear_auto_resume_action_lag_context(uncertain=False)
                    self._persist_store_trace(cycle_id,item,state=precise,failure_reason=precise,transaction_reconcile=public_reconcile)
                    # Same transaction, cursor already holds item: destination only.
                    rv2=self._store_revalidate_destination_v126(hwnd,item,target_grid,target_before,target, cycle_id=cycle_id, store_tx_id=store_tx_id, max_attempts=3)
                    if rv2.get('ok'):
                        target=rv2.get('target') or target
                        target_grid=rv2.get('target_grid') or target_grid
                        target_before=rv2.get('target_before') or target_before
                    else:
                        return {'ok':False,'safe_pause':False,'recoverable_known_state':True,'cursor_holding':True,
                                'recovery_policy':'DESTINATION_ONLY_RECOVERY','store_tx_id':store_tx_id,
                                'reason':rv2.get('reason') or 'STORE_DESTINATION_REVALIDATION_FAILED_WHILE_HOLDING',
                                'action':{k:v for k,v in action.items() if not str(k).startswith('_')},
                                'confirm':confirm,'transaction_reconcile':public_reconcile,'target':target,'queue_item':public_queue_item(item)}
                    dest_only=self._store_send_destination_only_once(hwnd,target_grid,target,anchor_policy=action.get('item_placement_anchor_policy'))
                    self._persist_store_trace(cycle_id,item,state='STORE_DESTINATION_ONLY_RECOVERY_SENT',
                                              destination_only_action=dest_only,source_click_sent=False,
                                              destination_click_sent=bool(dest_only.get('destination_click_sent')))
                    if not dest_only.get('ok'):
                        return {'ok':False,'safe_pause':False,'recoverable_known_state':True,'cursor_holding':True,
                                'recovery_policy':'DESTINATION_ONLY_RECOVERY','store_tx_id':store_tx_id,'reason':'STORE_DESTINATION_ONLY_DISPATCH_FAILED',
                                'action':{k:v for k,v in action.items() if not str(k).startswith('_')},'destination_only_action':dest_only,
                                'confirm':confirm,'transaction_reconcile':public_reconcile,'target':target,'queue_item':public_queue_item(item)}
                    action['destination_only_recovery']=dest_only
                    confirm2=self._store_wait_confirm(hwnd,item,source_before,target_before,target,self._inventory_grid,target_grid)
                    if confirm2.get('ok'):
                        self._persist_store_trace(cycle_id,item,state='STORE_COMMITTED_DESTINATION_ONLY',store_confirmed=True)
                        confirm=confirm2
                    else:
                        reconcile2=self._store_reconcile_noncommit_for_auto_resume(
                            hwnd,item,source_before,target_before,target,self._inventory_grid,target_grid,
                            clean_target_img,(cursor_park or {}).get('client_point'))
                        pub2={k:v for k,v in reconcile2.items() if not str(k).startswith('_')}
                        if reconcile2.get('committed'):
                            self._persist_store_trace(cycle_id,item,state='STORE_COMMITTED_RECONCILED',transaction_reconcile=pub2)
                            src_cells=set(_candidate_cells(item)); dst_cells={tuple(x) for x in (target.get('cells') or [])}
                            confirm={
                                'ok':True,'polls':0,'confirm_ms':0,'reconciled':True,
                                'metrics':{'source_changed':max(1,len(src_cells)),'source_needed':1,
                                           'target_changed':max(1,len(dst_cells)),'target_needed':1,
                                           'source_grid':self._inventory_grid,'target_grid':target_grid},
                                'source_snapshot':reconcile2.get('_fresh_source_snapshot'),
                                'target_snapshot':reconcile2.get('_fresh_target_snapshot'),
                                'image':reconcile2.get('_cursor_clear_reference_image') or capture_client(int(hwnd)),
                                'transaction_reconcile':pub2,
                            }
                        else:
                            return {'ok':False,'safe_pause':False,'recoverable_known_state':True,
                                    'cursor_holding':bool(pub2.get('cursor_state')=='CURSOR_HOLDING_ITEM_CONFIRMED'),
                                    'recovery_policy':'DESTINATION_ONLY_RECOVERY','store_tx_id':store_tx_id,
                                    'reason':pub2.get('reason') or 'STORE_DESTINATION_ONLY_NOT_CONFIRMED',
                                    'action':{k:v for k,v in action.items() if not str(k).startswith('_')},'destination_only_action':dest_only,
                                    'confirm':confirm2,'transaction_reconcile':pub2,'target':target,'queue_item':public_queue_item(item)}
                else:
                    item['status']='PAUSED'; item['reason']=precise
                    self._clear_auto_resume_action_lag_context(uncertain=True)
                    self._persist_store_trace(cycle_id,item,state=precise,failure_reason=precise,transaction_reconcile=public_reconcile)
                    return {'ok':False,'safe_pause':bool(precise=='STORE_TRANSACTION_TRUE_UNKNOWN'),'store_tx_id':store_tx_id,
                            'reason':precise,'action':{k:v for k,v in action.items() if not str(k).startswith('_')},'confirm':confirm,
                            'transaction_reconcile':public_reconcile,'target':target,'queue_item':public_queue_item(item)}

            self._clear_auto_resume_action_lag_context(uncertain=False)
            cursor_post=self._drop_probe_cursor_carry_reprobe(
                hwnd,clean_target_img,initial_probe_point=(cursor_park or {}).get('client_point'),
                motion_image=confirm.get('image'),max_zones=3,samples_per_zone=2
            )
            if str(cursor_post.get('state') or '')!='CURSOR_EMPTY_CONFIRMED':
                reason='STORE_PARTIAL_COMMIT_CURSOR_HOLDING' if str(cursor_post.get('state') or '')=='CURSOR_HOLDING_ITEM_CONFIRMED' else 'STORE_CURSOR_EMPTY_NOT_CONFIRMED'
                self._persist_store_trace(cycle_id,item,state=reason,failure_reason=reason,cursor_post=cursor_post)
                return {'ok':False,'safe_pause':False,'recoverable_known_state':True,
                        'cursor_holding':bool(str(cursor_post.get('state') or '')=='CURSOR_HOLDING_ITEM_CONFIRMED'),
                        'store_tx_id':store_tx_id,'reason':reason,'action':{k:v for k,v in action.items() if not str(k).startswith('_')},
                        'confirm':{k:v for k,v in confirm.items() if k not in ('source_snapshot','target_snapshot','image')},
                        'transaction_reconcile':{'source_state':'SOURCE_CLEAR_CONFIRMED','destination_state':'DESTINATION_OCCUPIED_CONFIRMED','cursor_state':cursor_post.get('state')},
                        'target':target,'queue_item':public_queue_item(item)}
            self._persist_store_trace(cycle_id,item,state='STORE_DESTINATION_PLACE_CONFIRMED',store_tx_id=store_tx_id)
            self._persist_store_trace(cycle_id,item,state='SOURCE_CLEAR_CONFIRMED',store_tx_id=store_tx_id)
            self._persist_store_trace(cycle_id,item,state='DESTINATION_OCCUPIED_CONFIRMED',store_tx_id=store_tx_id)
            self._persist_store_trace(cycle_id,item,state='CURSOR_EMPTY_CONFIRMED',store_tx_id=store_tx_id,cursor_post=cursor_post)
            action['destination_place_confirmed']=True
            action['cursor_empty_confirmed']=True
            try:
                sar,sac=[int(x) for x in (item.get('anchor') or [0,0])[:2]]
                source_visual_offsets=[]
                for raw in (item.get('cells') or []):
                    rr,cc=int(raw[0]),int(raw[1]); off=(rr-sar,cc-sac)
                    if off not in source_visual_offsets: source_visual_offsets.append(off)
            except Exception:
                source_visual_offsets=[]
            truth_post=write_post_store_truth(
                truth_dir,storage_image=confirm.get('image'),storage_grid=(confirm.get('metrics') or {}).get('target_grid') or target_grid,
                before_snapshot=target_before,after_snapshot=confirm.get('target_snapshot') or {},
                planned_anchor=[int(target.get('row',0)),int(target.get('col',0))],planned_cells=target.get('cells') or [],
                diff_func=diff_snapshots,source_visual_offsets=source_visual_offsets
            )
            self._persist_store_trace(cycle_id,item,state='STORAGE_POST_TRUTH',storage_truth_post=truth_post)
            if confirm.get('image') is not None:
                self._store_save_physical_proof(proof_dir,'06_storage_post.png',confirm.get('image'))
            if not truth_post.get('planned_anchor_equals_actual_anchor'):
                self._persist_store_trace(cycle_id,item,state='STORE_PLACEMENT_NOT_CONFIRMED',store_tx_id=store_tx_id,
                                          planned_anchor=truth_post.get('planned_anchor'),actual_anchor=truth_post.get('actual_anchor'),
                                          storage_truth_post=truth_post,source_click_forbidden=True)
                return {'ok':False,'safe_pause':True,'stored':False,'physical_move_detected':True,
                        'recoverable_known_state':False,'source_click_forbidden':True,'cursor_holding':False,
                        'store_tx_id':store_tx_id,'reason':'STORE_PLACEMENT_NOT_CONFIRMED',
                        'action':{k:v for k,v in action.items() if not str(k).startswith('_')},
                        'confirm':{k:v for k,v in confirm.items() if k not in ('source_snapshot','target_snapshot','image')},
                        'target':target,'queue_item':public_queue_item(item),'storage_truth_pre':truth_pre,
                        'storage_truth_post':truth_post,'truth_id':truth_pre.get('truth_id'),'truth_dir':str(truth_dir),
                        'physical_proof_dir':str(proof_dir),'cursor_empty_confirmed':True,
                        'source_pick_confirmed':bool(action.get('source_pick_confirmed')),'destination_place_confirmed':True}
            self._persist_store_trace(cycle_id,item,state='SOURCE_CLEARED',source_cleared=True)
            self._persist_store_trace(cycle_id,item,state='DESTINATION_OCCUPIED',destination_occupied=True)
            self._persist_store_trace(cycle_id,item,state='STORE_CONFIRMED',store_confirmed=True)
            self._persist_store_trace(cycle_id,item,state='STORE_COMMITTED',store_tx_id=store_tx_id,store_confirmed=True,
                                      source_clear_confirmed=True,destination_occupied_confirmed=True,cursor_empty_confirmed=True)
            item['status']='STORED'; item['reason']='KEEP_MOVED_TO_PERSONAL_BAG'; item['action']='STORE_PERSONAL_BAG'; item['action_status']='CONFIRMED'
            for rc in (target.get('cells') or []):
                try:
                    key=(int(rc[0]),int(rc[1]))
                    self._personal_bag_reserved_cells.add(key)
                    self._personal_bag_placement_history[key]={
                        'group': item.get('group_id') or item.get('group_label'),
                        'footprint': list(item.get('footprint') or [1,1]),
                        'cycle_id': cycle_id,
                    }
                except Exception:
                    pass
            # v10.4.5 reservation lifecycle: only the destination cells owned by
            # this Store are reserved. The next Store revalidates them against a
            # fresh storage snapshot. Do NOT permanently convert every visually
            # occupied cell into a session reservation.
            self._persist_store_trace(cycle_id,item,state='STORAGE_CLOSE',store_tx_id=store_tx_id,close_owner='PERSONAL_STORAGE_FOOTER_CLOSE')
            close=_try_personal_storage_close_owner_once_v1211(
                hwnd,confirm.get('image'),self._cfg.get('input_mode','Auto'),proof_dir=proof_dir
            )
            self._persist_store_trace(cycle_id,item,state='STORAGE_CLOSE_CONFIRM',store_tx_id=store_tx_id,
                                      storage_closed=bool(close.get('storage_closed_confirmed') or close.get('closed')),
                                      close_owner=close.get('close_owner'),personal_storage_close=close)
            if close.get('ok') and (close.get('storage_closed_confirmed') or close.get('closed')):
                self._persist_store_trace(cycle_id,item,state='STORAGE_CLOSED_CONFIRMED',storage_closed=True,
                                          source_inventory_still_open=bool(close.get('source_inventory_still_open')))
            storage_closed_ok=bool(close.get('ok') and (close.get('storage_closed_confirmed') or close.get('closed')))
            out={'ok':storage_closed_ok,'safe_pause':not storage_closed_ok,'stored':True,'action':{k:v for k,v in action.items() if not str(k).startswith('_')},'confirm':{k:v for k,v in confirm.items() if k not in ('source_snapshot','target_snapshot','image')},'target':target,'personal_bag_close':close,'queue_item':public_queue_item(item),'placement_checks':placement_checks,'occupied_cells_before':[list(x) for x in initial_blocked_cells],'occupancy_diag':occupancy_diag,'storage_truth_pre':truth_pre,'storage_truth_post':truth_post,'truth_id':truth_pre.get('truth_id'),'truth_dir':str(truth_dir),'physical_proof_dir':str(proof_dir),'cursor_empty_confirmed':True,'source_pick_confirmed':bool(action.get('source_pick_confirmed')),'destination_place_confirmed':True}
            if not storage_closed_ok:
                out['reason']='STORED_BUT_PERSONAL_STORAGE_CLOSE_NOT_CONFIRMED'
            else:
                # Stage 29 / v9.8: after closing the center storage bag, actively
                # restore/confirm the RIGHT source inventory before returning. This
                # removes the old timing hole where STORE succeeded but the next JS
                # iteration started while JX1 was still repainting the UI.
                post_ready=None
                post_polls=0
                t_ready=time.time()
                while time.time()-t_ready <= 1.35:
                    post_polls += 1
                    time.sleep(.085 if post_polls>1 else .14)
                    rr=self._capture_source_grid_visible(hwnd)
                    if rr.get('ok'):
                        post_ready=rr
                        break
                if not post_ready:
                    # One self-heal only: use the configured Q/F4 opener exactly once.
                    rr=self._capture_inventory_ready(hwnd,try_open=True)
                    if rr.get('ok'):
                        post_ready=rr
                self._inventory_baseline=None
                self._inventory_last=None
                self._batch_preopen_snapshot=None
                if post_ready and post_ready.get('ok'):
                    self._inventory_grid=post_ready.get('grid')
                    out['loop_ready']={
                        'ok':True,'deferred_recapture':False,
                        'post_store_polls':post_polls,
                        'opened_by_auto':bool(post_ready.get('opened')),
                        'reason':'RIGHT_SOURCE_GRID_CONFIRMED_AFTER_STORE',
                    }
                    out['next_cycle_ready']=True
                    out['resume_policy']='STORE_CLOSE_SOURCE_READY_THEN_NEXT_V9_8'
                else:
                    self._inventory_grid=None
                    out['ok']=False
                    out['safe_pause']=True
                    out['next_cycle_ready']=False
                    out['reason']='POST_STORE_SOURCE_GRID_NOT_READY'
                    out['loop_ready']={'ok':False,'post_store_polls':post_polls,'reason':'POST_STORE_SOURCE_GRID_NOT_READY'}
            out.update({
                'cycle_id': int(getattr(self,'_chest_cycle_seq',0) or 0),
                'item_id': item.get('queue_id') or item.get('item_id'),
                'filter_result': item.get('filter_result') or ('MATCH' if item.get('decision')=='KEEP' else None),
                'matched_profile_id': item.get('matched_profile_id'),
                'source_cells': [list(x) for x in _candidate_cells(item)],
                'footprint': item.get('footprint'),
                'destination_cells': [list(x) for x in (target.get('cells') or [])] if target else [],
                'storage_id': 'PERSONAL_BAG',
                'action_sent': bool((out.get('action') or {}).get('ok')),
                'exactly_once': bool((out.get('action') or {}).get('exactly_once', True)),
                'source_confirm': bool(((out.get('confirm') or {}).get('metrics') or {}).get('source_changed',0) >= ((out.get('confirm') or {}).get('metrics') or {}).get('source_needed',1)),
                'destination_confirm': bool(((out.get('confirm') or {}).get('metrics') or {}).get('target_changed',0) >= ((out.get('confirm') or {}).get('metrics') or {}).get('target_needed',1)),
                'store_dispatched': True,
                'storage_open_requested': True,
                'storage_open_confirmed': bool(opened.get('ok')),
                'source_click_sent': bool((out.get('action') or {}).get('source_click_sent')),
                'destination_click_sent': bool((out.get('action') or {}).get('destination_click_sent')),
                'source_cleared': bool(((out.get('confirm') or {}).get('metrics') or {}).get('source_changed',0) >= ((out.get('confirm') or {}).get('metrics') or {}).get('source_needed',1)),
                'destination_occupied': bool(((out.get('confirm') or {}).get('metrics') or {}).get('target_changed',0) >= ((out.get('confirm') or {}).get('metrics') or {}).get('target_needed',1)),
                'cursor_empty_confirmed': bool(out.get('cursor_empty_confirmed')),
                'source_pick_confirmed': bool(out.get('source_pick_confirmed')),
                'destination_place_confirmed': bool(out.get('destination_place_confirmed')),
                # Physical placement truth is independent from the subsequent
                # UI-close/finalizer gate.  A placed item can be committed while
                # the transaction still remains NOT FINALIZED because the center
                # Personal Storage window failed to close.
                'physical_truth': 'STORE_COMMITTED' if bool(out.get('cursor_empty_confirmed') and out.get('stored')) else 'STORE_UNCONFIRMED',
                'store_confirmed': bool(out.get('stored') and out.get('cursor_empty_confirmed')),
                'transaction_finalized': bool(out.get('ok') and storage_closed_ok and out.get('next_cycle_ready')),
                'storage_close_requested': True,
                'storage_close_owner': close.get('close_owner'),
                'storage_closed': bool(storage_closed_ok),
                'storage_closed_confirmed': bool(storage_closed_ok),
            })
            stamp=time.strftime('%Y%m%d_%H%M%S')
            try:
                payload=json.dumps(out,ensure_ascii=False,indent=2,default=str)
                (LOGDIR/f'{stamp}_chest_store_item.json').write_text(payload,encoding='utf-8')
                (LOGDIR/'chest_store_item.json').write_text(payload,encoding='utf-8')
                terminal_state='STORE_TERMINAL_WRITTEN' if (out.get('ok') and out.get('storage_closed_confirmed') and out.get('next_cycle_ready')) else 'STORE_TERMINAL_DIAGNOSTIC_NOT_FINALIZED'
                self._persist_store_trace(cycle_id,item,state=terminal_state,store_tx_id=store_tx_id,
                                          terminal_file='chest_store_item.json',physical_truth=out.get('physical_truth'),
                                          storage_closed=bool(out.get('storage_closed_confirmed')),next_cycle_ready=bool(out.get('next_cycle_ready')))
                if out.get('ok') and out.get('storage_closed_confirmed') and out.get('next_cycle_ready'):
                    self._persist_store_trace(cycle_id,item,state='STORE_FINALIZED',store_tx_id=store_tx_id,
                                              storage_closed=True,next_cycle_ready=True)
            except Exception:
                # Logging must never turn a confirmed STORE into a stopped automation.
                pass
            return out
        except Exception as e:
            return {'ok':False,'safe_pause':True,'reason':'CHEST_STORE_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=8)}

    def _drop_send_pair_once(self, hwnd, item, ground_point):
        """Pick one FAIL item, then place it on map ground. No retries."""
        hwnd=int(hwnd)
        src=_candidate_click_point(item,self._inventory_grid)
        if not src:
            return {'ok':False,'reason':'DROP_SOURCE_POINT_UNAVAILABLE','attempt_count':0,'exactly_once':True}
        gx,gy=int(ground_point[0]),int(ground_point[1])
        sx,sy=int(src[0]),int(src[1])
        mode=str(self._cfg.get('input_mode','Auto') or 'Auto')
        pid=_window_pid(hwnd)
        auto_elevated=_is_current_process_elevated()
        game_elevated=_process_elevated(pid)
        if game_elevated is True and not auto_elevated:
            return {'ok':False,'reason':'PRIVILEGE_MISMATCH','attempt_count':0,'exactly_once':True}

        result={
            'ok':False,'exactly_once':True,'attempt_count':1,'requested_mode':mode,
            'source_client':[sx,sy],'ground_client':[gx,gy],
            'pick_settle_ms': int(round((DROP_PICK_SETTLE_BACKGROUND_SEC if mode=='Background' else DROP_PICK_SETTLE_FOREGROUND_SEC)*1000)),
            'ground_settle_ms': int(round(DROP_AFTER_GROUND_SETTLE_SEC*1000))
        }
        if mode=='Background':
            ok1,target,p1=_post_left_click_client(hwnd,sx,sy)
            time.sleep(DROP_PICK_SETTLE_BACKGROUND_SEC)
            ok2,target2,p2=_post_left_click_client(hwnd,gx,gy) if ok1 else (False,target,None)
            if ok2:
                time.sleep(DROP_AFTER_GROUND_SETTLE_SEC)
            result.update({
                'ok':bool(ok1 and ok2),'used_mode':'Background/PostMessageLeftClickPair',
                'target_hwnd':int(target2 or target),'source_target_point':list(p1) if p1 else None,
                'ground_target_point':list(p2) if p2 else None,'source_sent':bool(ok1),'ground_sent':bool(ok2),
            })
            if not result['ok']:
                result['reason']='BACKGROUND_DROP_CLICK_PAIR_FAILED'
            return result

        activation=None
        if int(user32_bridge.GetForegroundWindow() or 0)!=hwnd:
            activation=_activate_window(hwnd)
            if not activation.get('ok'):
                return {'ok':False,'reason':'FOREGROUND_ACTIVATION_FAILED','attempt_count':0,'exactly_once':True,'activation':activation}
        ssp=_client_to_screen(hwnd,sx,sy); gsp=_client_to_screen(hwnd,gx,gy)
        if not ssp or not gsp:
            return {'ok':False,'reason':'CLIENT_TO_SCREEN_FAILED','attempt_count':0,'exactly_once':True,'activation':activation}
        old=_cursor_screen()
        ok1,_=_send_left_click_screen(ssp[0],ssp[1])
        time.sleep(DROP_PICK_SETTLE_FOREGROUND_SEC)
        ok2=False
        if ok1:
            ok2,_=_send_left_click_screen(gsp[0],gsp[1])
            if ok2:
                time.sleep(DROP_AFTER_GROUND_SETTLE_SEC)
        if old:
            _set_cursor_screen(old[0],old[1])
        result.update({
            'ok':bool(ok1 and ok2),'used_mode':'Foreground/SendInputLeftClickPair','activation':activation,
            'source_screen':[int(ssp[0]),int(ssp[1])],'ground_screen':[int(gsp[0]),int(gsp[1])],
            'source_sent':bool(ok1),'ground_sent':bool(ok2),'old_cursor':list(old) if old else None,
        })
        if not result['ok']:
            result['reason']='FOREGROUND_DROP_CLICK_PAIR_FAILED'
        return result

    def _select_drop_ground_target(self, hwnd, image, grid, exclude_points=None):
        """Pick one approved client-relative ground point using cheap motion sampling.

        Motion is only a pre-action preference. It is never transaction truth.
        """
        points=_safe_ground_drop_points(image,grid)
        if not points:
            return {'ok':False,'reason':'NO_SAFE_GROUND_DROP_POINT','ranked_points':[]}
        excluded={tuple(int(v) for v in p) for p in (exclude_points or []) if p and len(p)>=2}
        start=int(getattr(self,'_drop_point_cursor',0) or 0) % max(1,len(points))
        rotated=points[start:]+points[:start]
        available=[p for p in rotated if tuple(p) not in excluded]
        if not available:
            return {'ok':False,'reason':'NO_ALTERNATE_SAFE_GROUND_POINT','ranked_points':[]}
        time.sleep(DROP_GROUND_MOTION_SAMPLE_SEC)
        sample=capture_client(int(hwnd))
        ranked=_rank_ground_drop_points_by_motion(image,sample,available) if sample is not None else [
            {'point':[int(p[0]),int(p[1])],'motion_mae':None,'original_index':i} for i,p in enumerate(available)
        ]
        if not ranked:
            return {'ok':False,'reason':'NO_SAFE_GROUND_DROP_POINT','ranked_points':[]}
        pick=ranked[0]
        point=(int(pick['point'][0]),int(pick['point'][1]))
        try:
            original_index=points.index(point)
            self._drop_point_cursor=(int(original_index)+1) % max(1,len(points))
        except Exception:
            self._drop_point_cursor=(start+1) % max(1,len(points))
        motion=pick.get('motion_mae')
        return {
            'ok':True,'point':point,'ranked_points':ranked,
            'world_occlusion_detected':bool(motion is not None and float(motion)>=DROP_GROUND_OCCLUSION_MAE),
            'selected_motion_mae':motion,
        }

    def _drop_probe_cursor_confirmed(self, hwnd, reference_image, probe_point, samples=DROP_CURSOR_REPROBE_SAMPLES):
        """Bounded cursor-local probe on the stable inventory header.

        Foreign players/NPCs in the world ROI cannot affect this probe because
        its reference point is on the inventory header, not on the ground target.
        """
        if reference_image is None or not probe_point:
            return {'state':'CURSOR_AMBIGUOUS','probe_point':list(probe_point) if probe_point else None,'samples':[]}
        sp=_client_to_screen(int(hwnd),int(probe_point[0]),int(probe_point[1]))
        if not sp:
            return {'state':'CURSOR_AMBIGUOUS','probe_point':list(probe_point),'samples':[],'reason':'CLIENT_TO_SCREEN_FAILED'}
        _set_cursor_screen(int(sp[0]),int(sp[1])); time.sleep(.045)
        probes=[]; last_image=None
        for _ in range(max(1,int(samples or 1))):
            time.sleep(.035)
            ci=capture_client(int(hwnd))
            if ci is None:
                continue
            last_image=ci
            probes.append(_probe_cursor_attachment(reference_image,ci,probe_point))
        raw=[str(x.get('state') or 'CURSOR_UNCERTAIN') for x in probes]
        if raw and all(x=='CURSOR_CLEAR' for x in raw):
            state='CURSOR_EMPTY_CONFIRMED'
        elif len(raw)>=2 and all(x=='ITEM_ON_CURSOR_SUSPECT' for x in raw):
            state='CURSOR_HOLDING_ITEM_CONFIRMED'
        else:
            state='CURSOR_AMBIGUOUS'
        return {
            'state':state,'probe_point':[int(probe_point[0]),int(probe_point[1])],
            'samples':probes,'sample_count':len(probes),'_last_image':last_image,
        }

    def _drop_probe_cursor_carry_reprobe(self, hwnd, reference_image, initial_probe_point=None,
                                          motion_image=None, max_zones=2, samples_per_zone=3):
        """Bounded MOVE-ONLY multi-zone reprobe for SOURCE_CLEAR + cursor ambiguous.

        No click is sent. The normal cursor glyph is center-masked by
        _probe_cursor_attachment; only an outer carried-sprite region votes.
        """
        hwnd=int(hwnd)
        if reference_image is None:
            return {'state':'CURSOR_AMBIGUOUS','reason':'CURSOR_REPROBE_NO_REFERENCE','zones':[]}
        points=_cursor_carry_reprobe_points(reference_image,self._inventory_grid,primary=initial_probe_point)
        ranked=_rank_cursor_reprobe_points(reference_image,motion_image or reference_image,points)
        zones=[]
        for ent in ranked[:max(1,int(max_zones or 1))]:
            pt=tuple(ent['point'])
            sp=_client_to_screen(hwnd,int(pt[0]),int(pt[1]))
            if not sp:
                zones.append({'point':list(pt),'state':'CURSOR_AMBIGUOUS','reason':'CLIENT_TO_SCREEN_FAILED','samples':[]})
                continue
            # MOVE ONLY. Never click during ambiguity resolution.
            _set_cursor_screen(int(sp[0]),int(sp[1])); time.sleep(.045)
            probes=[]
            for _ in range(max(2,int(samples_per_zone or 2))):
                time.sleep(.035)
                ci=capture_client(hwnd)
                if ci is None:
                    continue
                probes.append(_probe_cursor_attachment(reference_image,ci,pt))
            raw=[str(x.get('state') or 'CURSOR_UNCERTAIN') for x in probes]
            if len(raw)>=2 and all(x=='CURSOR_CLEAR' for x in raw):
                zstate='CURSOR_EMPTY_CONFIRMED'
            elif len(raw)>=2 and all(x=='ITEM_ON_CURSOR_SUSPECT' for x in raw):
                zstate='CURSOR_HOLDING_ITEM_CONFIRMED'
            else:
                zstate='CURSOR_AMBIGUOUS'
            zones.append({'point':list(pt),'motion_mae':ent.get('motion_mae'),'state':zstate,'samples':probes})
        empty=sum(1 for z in zones if z.get('state')=='CURSOR_EMPTY_CONFIRMED')
        holding=sum(1 for z in zones if z.get('state')=='CURSOR_HOLDING_ITEM_CONFIRMED')
        if empty>=1 and holding==0:
            state='CURSOR_EMPTY_CONFIRMED'; reason='CURSOR_CARRY_REPROBE_EMPTY'
        elif holding>=2 and empty==0:
            state='CURSOR_HOLDING_ITEM_CONFIRMED'; reason='CURSOR_CARRY_REPROBE_HOLDING_MULTI_ZONE'
        else:
            state='CURSOR_AMBIGUOUS'; reason='CURSOR_CARRY_REPROBE_STILL_AMBIGUOUS'
        return {
            'state':state,'reason':reason,'zones':zones,'zone_count':len(zones),
            'empty_zone_votes':empty,'holding_zone_votes':holding,
            'no_click':True,'same_transaction':True,
        }

    def _drop_send_ground_once(self, hwnd, ground_point):
        """Continue the SAME Drop transaction when the item is proven on cursor."""
        hwnd=int(hwnd); gx,gy=int(ground_point[0]),int(ground_point[1])
        mode=str(self._cfg.get('input_mode','Auto') or 'Auto')
        result={'ok':False,'exactly_once':True,'attempt_count':1,'requested_mode':mode,'ground_client':[gx,gy],'ground_only':True}
        if mode=='Background':
            ok,target,p=_post_left_click_client(hwnd,gx,gy)
            if ok: time.sleep(DROP_AFTER_GROUND_SETTLE_SEC)
            result.update({'ok':bool(ok),'used_mode':'Background/PostMessageGroundOnly','target_hwnd':int(target),'ground_target_point':list(p) if p else None,'ground_sent':bool(ok),'source_sent':False})
            if not ok: result['reason']='BACKGROUND_DROP_GROUND_CLICK_FAILED'
            return result
        activation=None
        if int(user32_bridge.GetForegroundWindow() or 0)!=hwnd:
            activation=_activate_window(hwnd)
            if not activation.get('ok'):
                return {'ok':False,'reason':'FOREGROUND_ACTIVATION_FAILED','attempt_count':0,'exactly_once':True,'ground_only':True,'activation':activation}
        gsp=_client_to_screen(hwnd,gx,gy)
        if not gsp:
            return {'ok':False,'reason':'CLIENT_TO_SCREEN_FAILED','attempt_count':0,'exactly_once':True,'ground_only':True,'activation':activation}
        old=_cursor_screen(); ok,_=_send_left_click_screen(gsp[0],gsp[1])
        if ok: time.sleep(DROP_AFTER_GROUND_SETTLE_SEC)
        if old: _set_cursor_screen(old[0],old[1])
        result.update({'ok':bool(ok),'used_mode':'Foreground/SendInputGroundOnly','activation':activation,'ground_screen':[int(gsp[0]),int(gsp[1])],'ground_sent':bool(ok),'source_sent':False,'old_cursor':list(old) if old else None})
        if not ok: result['reason']='FOREGROUND_DROP_GROUND_CLICK_FAILED'
        return result

    def _reacquire_source_evidence_preaction(self, hwnd, candidate, cycle_id, drop_tx_id,
                                            before=None, before_image=None, max_attempts=2):
        """Bounded PRE-ACTION source-evidence reacquire; never sends a Drop click.

        A weak item does not trigger F4/Q.  InventoryLayoutRecovery is invoked
        only if the canonical source grid itself becomes invalid during this
        reacquire path.
        """
        hwnd=int(hwnd); cycle_id=int(cycle_id or 0); attempts=[]; layout_recovery_used=False
        for attempt_no in range(1,max(1,int(max_attempts or 1))+1):
            if self._chest_is_stop_requested():
                return {'ok':False,'reason':'SOURCE_EVIDENCE_REACQUIRE_ABORTED_USER_STOP','attempts':attempts}
            park=_park_cursor_on_inventory_header(hwnd,self._inventory_grid,.035)
            time.sleep(.035)
            fi=capture_client(hwnd)
            if fi is None:
                attempts.append({'attempt_no':attempt_no,'reason':'CAPTURE_FAILED'})
                continue
            grid=self._inventory_grid
            valid=validate_known_grid(fi,grid) if grid else {'ok':False}
            if not valid.get('ok'):
                ng=detect_inventory_grid(fi)
                if ng.get('ok'):
                    self._inventory_grid=ng; grid=ng
                elif not layout_recovery_used:
                    layout_recovery_used=True
                    layout=self._recover_source_grid_preaction(
                        hwnd,cycle_id,drop_tx_id,destructive_input_started=False
                    )
                    attempts.append({'attempt_no':attempt_no,'layout_recovery':{k:v for k,v in layout.items() if k!='ready'}})
                    if not layout.get('ok'):
                        continue
                    ready=layout.get('ready') or {}
                    self._inventory_grid=ready.get('grid') or self._inventory_grid
                    fi=capture_client(hwnd) or ready.get('image') or fi
                    grid=self._inventory_grid
                else:
                    attempts.append({'attempt_no':attempt_no,'reason':'GRID_NOT_REACQUIRED'})
                    continue
            snap=snapshot_inventory(fi,self._inventory_grid)
            if not snap.get('ok'):
                attempts.append({'attempt_no':attempt_no,'reason':'SNAPSHOT_FAILED'})
                continue
            bundle=_build_source_evidence_bundle(
                candidate,snap,self._batch_preopen_snapshot,self._inventory_grid,
                capture_timestamp=time.time(),reacquire_count=attempt_no,
            )
            attempts.append({'attempt_no':attempt_no,'evidence':_public_source_evidence(bundle)})
            if _source_evidence_precommit_confirmed(bundle):
                return {
                    'ok':True,'reason':'SOURCE_EVIDENCE_REACQUIRED','source_evidence':bundle,
                    'snapshot':snap,'image':fi,'grid':self._inventory_grid,
                    'cursor_probe_point':(park or {}).get('client') or _inventory_header_client_point(self._inventory_grid),
                    'attempts':attempts,
                }
            time.sleep(.045)
        return {
            'ok':False,'reason':'SOURCE_EVIDENCE_REACQUIRE_FAILED','attempts':attempts,
            'queue_preserved':True,'transaction_preserved':True,'drop_tx_id':drop_tx_id,
        }


    def _source_hover_presence_probe(self, hwnd, candidate, samples=2):
        """Presence-only source hover probe. MOVE ONLY, no OCR, no click.

        This is a bounded rescue for weak-source visual ambiguity.  A FOUND
        tooltip at the SAME source cell is positive presence evidence.  Tooltip
        absence is never treated as source-clear authority.
        """
        hwnd=int(hwnd)
        points=hover_points_for_candidate(candidate or {}, self._inventory_grid or {})
        if not points:
            return {'ok':False,'state':'SOURCE_HOVER_UNRESOLVED','reason':'SOURCE_HOVER_POINT_UNAVAILABLE','no_click':True,'samples':[]}
        cx,cy=int(points[0][0]),int(points[0][1])
        sp=_client_to_screen(hwnd,cx,cy)
        if not sp:
            return {'ok':False,'state':'SOURCE_HOVER_UNRESOLVED','reason':'CLIENT_TO_SCREEN_FAILED','no_click':True,'samples':[],'client_point':[cx,cy]}
        _set_cursor_screen(int(sp[0]),int(sp[1])); time.sleep(.055)
        rows=[]
        for sample_no in range(1,max(1,int(samples or 1))+1):
            if sample_no>1: time.sleep(.055)
            im=capture_client(hwnd)
            if im is None:
                rows.append({'sample':sample_no,'status':'CAPTURE_FAILED'})
                continue
            try:
                det=detect_tooltip_near_cursor(im,(cx,cy)) or {}
            except Exception as e:
                det={'status':'ERROR','reason':str(e)}
            rows.append({
                'sample':sample_no,'status':det.get('status'),'score':det.get('score'),
                'candidate_lines':det.get('candidate_lines'),'reason':det.get('reason'),
            })
        found=sum(1 for r in rows if str(r.get('status') or '').upper()=='FOUND')
        # One positive tooltip detection is presence evidence; absence is not
        # source-clear evidence and remains unresolved.
        if found>=1:
            state='SOURCE_PRESENT_CONFIRMED'; reason='SOURCE_HOVER_TOOLTIP_PRESENT'
        else:
            state='SOURCE_HOVER_UNRESOLVED'; reason='SOURCE_HOVER_TOOLTIP_NOT_CONFIRMED'
        return {
            'ok':bool(found>=1),'state':state,'reason':reason,'found_votes':found,
            'sample_count':len(rows),'client_point':[cx,cy],'no_click':True,
            'final6_ocr_rerun':False,'filter_rerun':False,'samples':rows,
        }

    def _reacquire_source_evidence_retry(self, hwnd, candidate, cycle_id, drop_tx_id,
                                         previous_confirm, next_attempt_no, max_attempts=2):
        """Refresh source evidence before a destructive NOT_COMMITTED retry.

        Preconditions are strict: the previous attempt proved SOURCE present and
        cursor empty.  The helper never sends source/ground clicks and never
        reruns Filter.  It produces a fresh per-attempt SourceEvidenceBundle.
        """
        hwnd=int(hwnd); cycle_id=int(cycle_id or 0); next_attempt_no=max(2,int(next_attempt_no or 2))
        prev=previous_confirm if isinstance(previous_confirm,dict) else {}
        if str(prev.get('source_state_after') or '') not in ('SOURCE_STILL_PRESENT','SOURCE_PRESENT_CONFIRMED'):
            return {'ok':False,'reason':'SOURCE_RETRY_REACQUIRE_REQUIRES_CONFIRMED_SOURCE_PRESENT','no_click':True}
        if str(prev.get('cursor_item_state') or '')!='CURSOR_EMPTY_CONFIRMED':
            return {'ok':False,'reason':'SOURCE_RETRY_REACQUIRE_REQUIRES_CURSOR_EMPTY','no_click':True}

        attempts=[]
        # Preserve Attempt N post-source evidence as diagnostic continuity input;
        # it is not discarded when constructing Attempt N+1's fresh template.
        prior_post_snapshot=prev.get('snapshot') if isinstance(prev.get('snapshot'),dict) else None
        # Preserve cumulative count from the transaction rather than resetting it.
        prior_count=int(prev.get('source_evidence_reacquire_count',0) or 0)
        for local_attempt in range(1,max(1,int(max_attempts or 1))+1):
            if self._chest_is_stop_requested():
                return {'ok':False,'reason':'SOURCE_RETRY_REACQUIRE_ABORTED_USER_STOP','attempts':attempts,'no_click':True}

            park=_park_cursor_on_inventory_header(hwnd,self._inventory_grid,.035)
            time.sleep(.030)
            fi=capture_client(hwnd)
            if fi is None:
                attempts.append({'attempt':local_attempt,'reason':'CAPTURE_FAILED'})
                continue
            grid=self._inventory_grid
            valid=validate_known_grid(fi,grid) if grid else {'ok':False}
            if not valid.get('ok'):
                ng=detect_inventory_grid(fi)
                if not ng.get('ok'):
                    attempts.append({'attempt':local_attempt,'reason':'CANONICAL_GRID_NOT_VALID'})
                    continue
                self._inventory_grid=ng; grid=ng

            snap=snapshot_inventory(fi,self._inventory_grid)
            if not snap.get('ok'):
                attempts.append({'attempt':local_attempt,'reason':'SNAPSHOT_FAILED'})
                continue

            # Same queue anchor/footprint must still map to actual current grid cells.
            candidate_cells=_candidate_cells(candidate)
            current_cells=_snapshot_cell_map(snap)
            anchor_revalidated=bool(candidate_cells and all(tuple(rc) in current_cells for rc in candidate_cells))
            if not anchor_revalidated:
                attempts.append({'attempt':local_attempt,'reason':'RETRY_SOURCE_ANCHOR_NOT_REVALIDATED'})
                continue

            # Compare the freshly captured retry-pre frame with the validated
            # post-source frame from the previous attempt.  This is diagnostic
            # continuity evidence only; no new threshold is introduced here.
            prior_post_to_fresh=[]
            if prior_post_snapshot:
                pm=_snapshot_cell_map(prior_post_snapshot)
                cm=_snapshot_cell_map(snap)
                for rc in candidate_cells:
                    a=pm.get(tuple(rc)); b=cm.get(tuple(rc))
                    if a and b and (a.get('_sig') or []) and (b.get('_sig') or []):
                        prior_post_to_fresh.append(float(_sig_mae(a.get('_sig'),b.get('_sig'))))
            reacquire_count=prior_count+local_attempt
            bundle=_build_source_evidence_bundle(
                candidate,snap,self._batch_preopen_snapshot,self._inventory_grid,
                capture_timestamp=time.time(),reacquire_count=reacquire_count,
            )
            template_id=f'{drop_tx_id}:attempt:{next_attempt_no}:reacquire:{reacquire_count}'
            bundle.update({
                'source_reacquire_reason':'DROP_NOT_COMMITTED_SOURCE_PRESENT_CURSOR_EMPTY',
                'retry_pre_template_id':template_id,
                'retry_pre_vs_empty_mae':bundle.get('pre_vs_empty_mae'),
                'retry_anchor_revalidated':bool(anchor_revalidated and bundle.get('source_anchor_revalidated')),
                'attempt_source_template_age_ms':0.0,
                'template_fresh':True,
                'attempt_no':next_attempt_no,
                'retry_prior_post_snapshot_used':bool(prior_post_snapshot),
                'retry_prior_post_vs_fresh_mae':None if not prior_post_to_fresh else round(sum(prior_post_to_fresh)/len(prior_post_to_fresh),3),
            })

            # Strong/ordinary weak evidence can authorize the retry immediately.
            if _source_evidence_precommit_confirmed(bundle):
                attempts.append({'attempt':local_attempt,'reason':'FRESH_SOURCE_EVIDENCE_CONFIRMED','evidence':_public_source_evidence(bundle)})
                return {
                    'ok':True,'reason':'SOURCE_RETRY_REACQUIRED','source_evidence':bundle,
                    'snapshot':snap,'image':fi,'grid':self._inventory_grid,
                    'cursor_probe_point':(park or {}).get('client') or _inventory_header_client_point(self._inventory_grid),
                    'attempts':attempts,'source_hover_probe_used':False,'source_hover_probe_result':None,
                }

            # Previous attempt already proved the item stayed in source.  Preserve
            # the new post-attempt visual cell as the per-attempt template instead
            # of reusing Attempt N-1's template. This is retry-only authority.
            bm=_snapshot_cell_map(snap)
            rm=_snapshot_cell_map(self._batch_preopen_snapshot) if self._batch_preopen_snapshot else {}
            pre_templates={}; empty_templates={}; weak_cells=[]; vals=[]
            for rc in candidate_cells:
                b=bm.get(tuple(rc)); ref=rm.get(tuple(rc))
                if not b or not ref: continue
                ps=b.get('_sig') or []; es=ref.get('_sig') or []
                if not ps or not es: continue
                key=f'{int(rc[0])},{int(rc[1])}'
                pre_templates[key]=ps; empty_templates[key]=es; weak_cells.append([int(rc[0]),int(rc[1])])
                vals.append(float(_sig_mae(ps,es)))
            if weak_cells:
                bundle['_weak_cells']=weak_cells
                bundle['_pre_templates']=pre_templates
                bundle['_empty_templates']=empty_templates
                bundle['_before_snapshot']=snap
                bundle['_fingerprint']=_build_source_item_fingerprint(candidate,snap,self._batch_preopen_snapshot)
                bundle.update({
                    'source_evidence_mode':'WEAK_VISUAL_TEMPLATE',
                    'weak_template_count':len(weak_cells),
                    'source_pre_template_valid':True,
                    'pre_vs_empty_mae':None if not vals else round(sum(vals)/len(vals),3),
                    'retry_pre_vs_empty_mae':None if not vals else round(sum(vals)/len(vals),3),
                    'source_state_decision_reason':'RETRY_TEMPLATE_PROMOTED_FROM_CONFIRMED_SOURCE_PRESENT',
                    'retry_anchor_revalidated':True,
                    'source_anchor_revalidated':True,
                    'template_fresh':True,
                })
                attempts.append({'attempt':local_attempt,'reason':'CONFIRMED_PRESENT_PROMOTED_TO_FRESH_RETRY_TEMPLATE','evidence':_public_source_evidence(bundle)})
                return {
                    'ok':True,'reason':'SOURCE_RETRY_REACQUIRED_FROM_CONFIRMED_PRESENT','source_evidence':bundle,
                    'snapshot':snap,'image':fi,'grid':self._inventory_grid,
                    'cursor_probe_point':(park or {}).get('client') or _inventory_header_client_point(self._inventory_grid),
                    'attempts':attempts,'source_hover_probe_used':False,'source_hover_probe_result':None,
                }

            # Last bounded rescue is presence-only hover.  It never calls Reader.
            hover=self._source_hover_presence_probe(hwnd,candidate,samples=2)
            attempts.append({'attempt':local_attempt,'reason':'SOURCE_HOVER_PROBE','hover':hover})
            _park_cursor_on_inventory_header(hwnd,self._inventory_grid,.035)
            if hover.get('state')=='SOURCE_PRESENT_CONFIRMED':
                # Capture again AFTER clearing tooltip so the promoted template is clean.
                fi2=capture_client(hwnd)
                if fi2 is None: continue
                snap2=snapshot_inventory(fi2,self._inventory_grid)
                if not snap2.get('ok'): continue
                bm2=_snapshot_cell_map(snap2); rm2=_snapshot_cell_map(self._batch_preopen_snapshot) if self._batch_preopen_snapshot else {}
                pre_templates={}; empty_templates={}; weak_cells=[]; vals=[]
                for rc in candidate_cells:
                    b=bm2.get(tuple(rc)); ref=rm2.get(tuple(rc))
                    if not b or not ref: continue
                    ps=b.get('_sig') or []; es=ref.get('_sig') or []
                    if not ps or not es: continue
                    key=f'{int(rc[0])},{int(rc[1])}'
                    pre_templates[key]=ps; empty_templates[key]=es; weak_cells.append([int(rc[0]),int(rc[1])])
                    vals.append(float(_sig_mae(ps,es)))
                if weak_cells:
                    bundle=_build_source_evidence_bundle(
                        candidate,snap2,self._batch_preopen_snapshot,self._inventory_grid,
                        capture_timestamp=time.time(),reacquire_count=reacquire_count,
                    )
                    bundle['_weak_cells']=weak_cells; bundle['_pre_templates']=pre_templates; bundle['_empty_templates']=empty_templates
                    bundle['_before_snapshot']=snap2; bundle['_fingerprint']=_build_source_item_fingerprint(candidate,snap2,self._batch_preopen_snapshot)
                    bundle.update({
                        'source_evidence_mode':'WEAK_VISUAL_TEMPLATE','weak_template_count':len(weak_cells),
                        'source_pre_template_valid':True,'source_anchor_revalidated':True,
                        'source_reacquire_reason':'DROP_NOT_COMMITTED_HOVER_CONFIRMED_PRESENT',
                        'retry_pre_template_id':template_id,'retry_pre_vs_empty_mae':None if not vals else round(sum(vals)/len(vals),3),
                        'retry_anchor_revalidated':True,'source_hover_probe_used':True,'source_hover_probe_result':'SOURCE_PRESENT_CONFIRMED',
                        'attempt_source_template_age_ms':0.0,'template_fresh':True,'attempt_no':next_attempt_no,
                        'source_state_decision_reason':'SOURCE_HOVER_CONFIRMED_RETRY_TEMPLATE',
                    })
                    return {
                        'ok':True,'reason':'SOURCE_RETRY_REACQUIRED_AFTER_HOVER','source_evidence':bundle,
                        'snapshot':snap2,'image':fi2,'grid':self._inventory_grid,
                        'cursor_probe_point':_inventory_header_client_point(self._inventory_grid),
                        'attempts':attempts,'source_hover_probe_used':True,'source_hover_probe_result':hover,
                    }
            time.sleep(.035)

        return {
            'ok':False,'reason':'SOURCE_RETRY_REACQUIRE_FAILED','attempts':attempts,
            'queue_preserved':True,'transaction_preserved':True,'drop_tx_id':drop_tx_id,
            'source_hover_probe_used':any(bool((x.get('hover') or {})) for x in attempts),
        }

    def _drop_wait_confirm(self, hwnd, candidate, before, before_image=None, ground_point=None,
                           cursor_reference_image=None, cursor_probe_point=None,
                           drop_tx_id=None, source_evidence=None,
                           timeout_sec=DROP_CONFIRM_TIMEOUT_SEC, poll_sec=DROP_CONFIRM_POLL_SEC):
        """Reconcile one Drop attempt from source/cursor/inventory state.

        Ground pixels are diagnostics only and never commit authority.
        """
        deadline=time.time()+float(timeout_sec)
        polls=0; last_metrics=None; last_snap=None; last_img=None; primary_seen=False
        evidence=source_evidence or _build_source_evidence_bundle(
            candidate,before,self._batch_preopen_snapshot,self._inventory_grid,capture_timestamp=time.time()
        )
        fingerprint=evidence.get('_fingerprint') or _build_source_item_fingerprint(candidate,before,self._batch_preopen_snapshot)
        while time.time()<deadline:
            time.sleep(float(poll_sec)); polls+=1
            img=capture_client(int(hwnd))
            if img is None:
                continue
            last_img=img
            grid=self._inventory_grid
            valid=validate_known_grid(img,grid) if grid else {'ok':False}
            if not valid.get('ok'):
                grid=detect_inventory_grid(img)
                if not grid.get('ok'):
                    continue
                self._inventory_grid=grid
            snap=snapshot_inventory(img,self._inventory_grid)
            metrics=_candidate_clear_metrics(candidate,before,snap,self._batch_preopen_snapshot)
            last_metrics=metrics; last_snap=snap
            if metrics.get('confirmed'):
                primary_seen=True
                break

        probe_point=cursor_probe_point or _inventory_header_client_point(self._inventory_grid)
        cursor=self._drop_probe_cursor_confirmed(hwnd,cursor_reference_image or before_image,probe_point)
        cursor_last=cursor.pop('_last_image',None)

        # Revalidate the SAME source item from two fresh frames after the cursor
        # is parked on the stable inventory header. This removes tooltip noise.
        fresh=[]; states=[]; images=[]
        for _ in range(2):
            time.sleep(.045)
            fi=capture_client(int(hwnd))
            if fi is None: continue
            last_img=fi
            grid=self._inventory_grid
            valid=validate_known_grid(fi,grid) if grid else {'ok':False}
            if not valid.get('ok'):
                ng=detect_inventory_grid(fi)
                if not ng.get('ok'): continue
                self._inventory_grid=ng
            fs=snapshot_inventory(fi,self._inventory_grid)
            st=_source_evidence_state(evidence,fs,self._batch_preopen_snapshot)
            fresh.append(fs); states.append(st); images.append(fi)

        gone_all=bool(states and all(x.get('state')=='ITEM_GONE' for x in states))
        present_all=bool(states and all(x.get('state')=='ITEM_STILL_IN_SOURCE' for x in states))
        if gone_all:
            source_state='SOURCE_CLEAR_CONFIRMED'
        elif present_all:
            source_state='SOURCE_STILL_PRESENT'
        else:
            source_state='SOURCE_AMBIGUOUS'
        cursor_state=str(cursor.get('state') or 'CURSOR_AMBIGUOUS')
        cursor_reprobe=None
        if source_state=='SOURCE_CLEAR_CONFIRMED' and cursor_state=='CURSOR_AMBIGUOUS':
            # The source is already authoritative ITEM_GONE. A noisy fixed cursor
            # ROI must not immediately convert that resolved transaction into TRUE
            # UNKNOWN. Reprobe several neutral zones by MOVE ONLY, same drop_tx_id.
            cursor_reprobe=self._drop_probe_cursor_carry_reprobe(
                hwnd,cursor_reference_image or before_image,initial_probe_point=probe_point,
                motion_image=(images[-1] if images else (cursor_last or last_img)),
                max_zones=2,samples_per_zone=3,
            )
            reprobe_state=str((cursor_reprobe or {}).get('state') or 'CURSOR_AMBIGUOUS')
            if reprobe_state in ('CURSOR_EMPTY_CONFIRMED','CURSOR_HOLDING_ITEM_CONFIRMED'):
                cursor_state=reprobe_state

        source_hover_probe=None
        # Weak-source rescue: SOURCE_AMBIGUOUS + cursor-empty is not TRUE UNKNOWN
        # until a bounded, non-destructive presence probe is exhausted.  FOUND at
        # the same source cell confirms presence; absence alone never proves clear.
        if source_state=='SOURCE_AMBIGUOUS' and cursor_state=='CURSOR_EMPTY_CONFIRMED'                 and str(evidence.get('source_evidence_mode') or '').startswith('WEAK_VISUAL_TEMPLATE'):
            source_hover_probe=self._source_hover_presence_probe(hwnd,candidate,samples=2)
            if (source_hover_probe or {}).get('state')=='SOURCE_PRESENT_CONFIRMED':
                source_state='SOURCE_STILL_PRESENT'

        state_matrix=_drop_reconcile_source_cursor(source_state,cursor_state)
        reconciliation=state_matrix['reconciliation']; reason=state_matrix['reason']; ok=bool(state_matrix['ok'])

        evidence_image=images[-1] if images else (cursor_last or last_img)
        evidence_states=[x for x in states if isinstance(x,dict)]
        post_pre_vals=[float(x.get('post_vs_pre_mae')) for x in evidence_states if x.get('post_vs_pre_mae') is not None]
        post_empty_vals=[float(x.get('post_vs_empty_mae')) for x in evidence_states if x.get('post_vs_empty_mae') is not None]
        state_reasons=[str(x.get('source_state_decision_reason')) for x in evidence_states if x.get('source_state_decision_reason')]
        ground_motion=_ground_roi_mae(before_image,evidence_image,ground_point)
        world_occ=bool(ground_motion is not None and float(ground_motion)>=DROP_GROUND_OCCLUSION_MAE)
        return {
            'ok':bool(ok),'reason':reason,'polls':polls,'metrics':last_metrics,
            'snapshot':fresh[-1] if fresh else last_snap,
            'drop_tx_id':drop_tx_id,
            'source_item_owned_cells':fingerprint.get('source_item_owned_cells',[]),
            'source_item_fingerprint':fingerprint,
            'post_drop_fingerprint_match':states,
            'source_evidence_mode':evidence.get('source_evidence_mode'),
            'strong_owned_count':int(evidence.get('strong_owned_count',0) or 0),
            'weak_template_count':int(evidence.get('weak_template_count',0) or 0),
            'source_pre_template_valid':bool(evidence.get('source_pre_template_valid')),
            'pre_vs_empty_mae':evidence.get('pre_vs_empty_mae'),
            'post_vs_pre_mae':None if not post_pre_vals else round(sum(post_pre_vals)/len(post_pre_vals),3),
            'post_vs_empty_mae':None if not post_empty_vals else round(sum(post_empty_vals)/len(post_empty_vals),3),
            'source_evidence_reacquire_count':int(evidence.get('source_evidence_reacquire_count',0) or 0),
            'source_anchor_revalidated':bool(evidence.get('source_anchor_revalidated')),
            'source_state_decision_reason':('SOURCE_HOVER_TOOLTIP_PRESENT' if source_hover_probe and source_hover_probe.get('state')=='SOURCE_PRESENT_CONFIRMED' else (state_reasons[-1] if state_reasons else ('STRONG_OCCUPANCY_FINGERPRINT' if int(evidence.get('strong_owned_count',0) or 0)>0 else 'SOURCE_EVIDENCE_UNRESOLVED'))),
            'source_reacquire_reason':evidence.get('source_reacquire_reason'),
            'retry_pre_template_id':evidence.get('retry_pre_template_id'),
            'retry_pre_vs_empty_mae':evidence.get('retry_pre_vs_empty_mae'),
            'retry_anchor_revalidated':bool(evidence.get('retry_anchor_revalidated')),
            'source_hover_probe_used':bool(source_hover_probe is not None or evidence.get('source_hover_probe_used')),
            'source_hover_probe_result':(source_hover_probe or {}).get('state') if source_hover_probe is not None else evidence.get('source_hover_probe_result'),
            'attempt_source_template_age_ms':round(max(0.0,(time.time()-float(evidence.get('capture_timestamp') or time.time()))*1000.0),3),
            'template_fresh':bool(evidence.get('template_fresh',True)),
            'source_state_before':'SOURCE_PRESENT_CONFIRMED' if _source_evidence_precommit_confirmed(evidence) else 'SOURCE_AMBIGUOUS',
            'source_state_after':source_state,
            'cursor_item_state':cursor_state,'cursor_probe':cursor,
            'cursor_carry_reprobe':cursor_reprobe,
            'cursor_reprobe_count':0 if not cursor_reprobe else int(cursor_reprobe.get('zone_count',0) or 0),
            'cursor_reprobe_points':[] if not cursor_reprobe else [z.get('point') for z in (cursor_reprobe.get('zones') or [])],
            'cursor_reprobe_reason':None if not cursor_reprobe else cursor_reprobe.get('reason'),
            'reconciliation_state':reconciliation,
            'primary_confirm_result':'PASS_SOURCE_ONLY' if primary_seen else 'FAIL',
            'secondary_confirm_result':reason,
            'partial_clear_detected':bool(last_metrics and int(last_metrics.get('before_occupied',0) or 0)>0 and 0<int(last_metrics.get('after_occupied',0) or 0)<int(last_metrics.get('before_occupied',0) or 0)),
            'hover_cleared_before_recheck':True,'fresh_frames_used':len(fresh),
            'world_occlusion_detected':world_occ,'ground_motion_mae':ground_motion,
            'world_occlusion_reason':'WORLD_OCCLUSION_TRANSIENT' if world_occ else None,
            'final_commit_state':'COMMITTED' if ok else reconciliation,
            '_source_before_snapshot':before,'_baseline_snapshot':self._batch_preopen_snapshot,
            '_cursor_clear_reference_image':cursor_reference_image or before_image,
        }

    def chest_drop_queue_item(self, hwnd, item_index=0):
        """Drop one FAIL item as a bounded, reconciled, exactly-once transaction."""
        try:
            hwnd=int(hwnd); item=self._queue_item_by_index(item_index)
            cycle_id=int(getattr(self,'_chest_cycle_seq',0) or 0)
            self._persist_drop_trace(cycle_id,item,state='DROP_CONTROLLER_ENTER')
            if item is None:
                return {'ok':False,'safe_pause':False,'normal_stop':True,'reason':'QUEUE_ITEM_NOT_FOUND'}
            if item.get('status')=='DROPPED':
                return {'ok':True,'dropped':True,'already_dropped':True,'queue_item':public_queue_item(item)}
            if item.get('decision')!='FAIL':
                return {'ok':False,'safe_pause':False,'normal_stop':True,'reason':'DROP_BLOCKED_DECISION_NOT_FAIL','decision':item.get('decision')}

            queue_id=str(item.get('queue_id') or item.get('item_id') or 'Q01')
            drop_tx_id=f'DROP-{cycle_id:06d}-{queue_id}'
            self._persist_drop_trace(cycle_id,item,state='DROP_PRECHECK_BEGIN',drop_tx_id=drop_tx_id)
            raw=capture_client(hwnd)
            if raw is not None and detect_personal_storage_grid(raw).get('ok'):
                closed=_try_personal_bag_close_once(hwnd,raw,self._cfg.get('input_mode','Auto'))
                if not closed.get('ok'):
                    return self._drop_preaction_recoverable_result('PERSONAL_BAG_MUST_CLOSE_BEFORE_DROP',drop_tx_id,close=closed)
            ready=self._capture_source_grid_visible(hwnd)
            layout_recovery_used=False
            verified_grid_lease=None
            if not ready.get('ok'):
                # SOURCE_GRID_NOT_VISIBLE is a recoverable PRE-ACTION layout condition.
                # No source/ground input has been sent yet. Use only the user's selected
                # F4/Q source-inventory hotkey and preserve this queue item/drop_tx_id.
                source_reason=str(ready.get('reason') or 'SOURCE_GRID_NOT_VISIBLE')
                if source_reason in ('SOURCE_GRID_NOT_VISIBLE','SOURCE_GRID_NOT_VISIBLE_NO_HOTKEY','INVENTORY_GRID_NOT_FOUND_FAST','INVENTORY_GRID_NOT_FOUND'):
                    self._persist_drop_trace(
                        cycle_id,item,state='INVENTORY_LAYOUT_RECOVERY_BEGIN',drop_tx_id=drop_tx_id,
                        layout_failure_reason=source_reason,inventory_hotkey=self.get_inventory_hotkey(),
                        pre_action_only=True,destructive_input_started=False,
                    )
                    recovery=self._recover_source_grid_preaction(
                        hwnd,cycle_id,drop_tx_id,destructive_input_started=False
                    )
                    layout_recovery_used=True
                    if recovery.get('ok'):
                        ready=recovery.get('ready') or {}
                        verified_grid_lease=recovery.get('verified_grid_lease')
                        self._persist_drop_trace(
                            cycle_id,item,state='INVENTORY_LAYOUT_RECOVERED',drop_tx_id=drop_tx_id,
                            inventory_hotkey=recovery.get('hotkey'),recovery_stage=recovery.get('recovery_stage'),
                            queue_preserved=True,transaction_preserved=True,
                            verified_grid_lease_id=(verified_grid_lease or {}).get('lease_id'),
                            verified_grid_generation=(verified_grid_lease or {}).get('generation'),
                        )
                    else:
                        self._persist_drop_trace(
                            cycle_id,item,state='INVENTORY_LAYOUT_RECOVERY_FAILED',drop_tx_id=drop_tx_id,
                            inventory_hotkey=recovery.get('hotkey'),layout_recovery=recovery,
                        )
                        return self._drop_preaction_recoverable_result(
                            'TEMPORARY_SENSOR_LAG',drop_tx_id,
                            sensor_reason='INVENTORY_LAYOUT_RECOVERY_FAILED',inventory=ready,layout_recovery=recovery
                        )
                else:
                    return self._drop_preaction_recoverable_result(source_reason,drop_tx_id,inventory=ready)
            self._inventory_grid=ready['grid']
            park=_park_cursor_on_inventory_header(hwnd,self._inventory_grid,.045)
            img=capture_client(hwnd)
            if img is None:
                return self._drop_preaction_recoverable_result('PRE_DROP_CAPTURE_FAILED',drop_tx_id)
            lease_check=(self._consume_verified_grid_lease(hwnd,verified_grid_lease,item=item,current_image=img) if verified_grid_lease else None)
            if lease_check and lease_check.get('ok'):
                self._inventory_grid=lease_check.get('grid') or self._inventory_grid
                ready={'ok':True,'image':img,'grid':self._inventory_grid,'capture_mode':'VERIFIED_GRID_LEASE_HANDOFF'}
                self._persist_drop_trace(cycle_id,item,state='VERIFIED_GRID_LEASE_CONSUMED',drop_tx_id=drop_tx_id,
                                         verified_grid_lease_id=lease_check.get('lease_id'),
                                         verified_grid_generation=lease_check.get('generation'),
                                         lease_age_ms=lease_check.get('lease_age_ms'),
                                         full_grid_rediscovery=False)
            elif not validate_known_grid(img,self._inventory_grid).get('ok'):
                g=detect_inventory_grid(img)
                if not g.get('ok'):
                    # Still PRE-ACTION: permit exactly one layout recovery if the
                    # initial source-grid check did not already consume it.
                    if not layout_recovery_used:
                        self._persist_drop_trace(
                            cycle_id,item,state='INVENTORY_LAYOUT_RECOVERY_BEGIN',drop_tx_id=drop_tx_id,
                            layout_failure_reason='INVENTORY_GRID_LOST_BEFORE_DROP',
                            inventory_hotkey=self.get_inventory_hotkey(),
                            pre_action_only=True,destructive_input_started=False,
                        )
                        recovery=self._recover_source_grid_preaction(
                            hwnd,cycle_id,drop_tx_id,destructive_input_started=False
                        )
                        layout_recovery_used=True
                        if recovery.get('ok'):
                            ready=recovery.get('ready') or {}
                            verified_grid_lease=recovery.get('verified_grid_lease')
                            self._inventory_grid=ready.get('grid') or self._inventory_grid
                            park=_park_cursor_on_inventory_header(hwnd,self._inventory_grid,.045)
                            img=capture_client(hwnd) or ready.get('image') or img
                            lease_check=self._consume_verified_grid_lease(hwnd,verified_grid_lease,item=item,current_image=img) if verified_grid_lease else None
                            if lease_check and lease_check.get('ok'):
                                self._inventory_grid=lease_check.get('grid') or self._inventory_grid
                                ready={'ok':True,'image':img,'grid':self._inventory_grid,'capture_mode':'VERIFIED_GRID_LEASE_HANDOFF'}
                            self._persist_drop_trace(
                                cycle_id,item,state='INVENTORY_LAYOUT_RECOVERED',drop_tx_id=drop_tx_id,
                                inventory_hotkey=recovery.get('hotkey'),recovery_stage=recovery.get('recovery_stage'),
                                queue_preserved=True,transaction_preserved=True,
                            )
                        else:
                            self._persist_drop_trace(
                                cycle_id,item,state='INVENTORY_LAYOUT_RECOVERY_FAILED',drop_tx_id=drop_tx_id,
                                inventory_hotkey=recovery.get('hotkey'),layout_recovery=recovery,
                            )
                            return self._drop_preaction_recoverable_result(
                                'TEMPORARY_SENSOR_LAG',drop_tx_id,
                                sensor_reason='INVENTORY_LAYOUT_RECOVERY_FAILED',layout_recovery=recovery
                            )
                    else:
                        return self._drop_preaction_recoverable_result(
                            'TEMPORARY_SENSOR_LAG',drop_tx_id,
                            sensor_reason='INVENTORY_GRID_LOST_BEFORE_DROP_AFTER_RECOVERY'
                        )
                else:
                    self._inventory_grid=g
                    park=_park_cursor_on_inventory_header(hwnd,self._inventory_grid,.045)
                    img=capture_client(hwnd) or img
            before=snapshot_inventory(img,self._inventory_grid)
            if not before.get('ok'):
                return self._drop_preaction_recoverable_result('PRE_DROP_SOURCE_SNAPSHOT_FAILED',drop_tx_id)

            # SOURCE FINGERPRINT PRECOMMIT GATE: destructive Drop input is legal
            # only when the queue item has strong occupancy evidence OR a validated
            # weak visual template against the pre-open empty baseline.
            source_evidence=_build_source_evidence_bundle(
                item,before,self._batch_preopen_snapshot,self._inventory_grid,capture_timestamp=time.time()
            )
            source_evidence.update({
                'retry_pre_template_id':f'{drop_tx_id}:attempt:1:initial',
                'retry_pre_vs_empty_mae':source_evidence.get('pre_vs_empty_mae'),
                'retry_anchor_revalidated':bool(source_evidence.get('source_anchor_revalidated')),
                'attempt_no':1,'template_fresh':True,'source_reacquire_reason':'INITIAL_PRECOMMIT',
            })
            if not _source_evidence_precommit_confirmed(source_evidence):
                self._persist_drop_trace(
                    cycle_id,item,state='SOURCE_PRESENT_WITHOUT_EVIDENCE',drop_tx_id=drop_tx_id,
                    source_evidence_mode=source_evidence.get('source_evidence_mode'),
                    strong_owned_count=source_evidence.get('strong_owned_count'),
                    weak_template_count=source_evidence.get('weak_template_count'),
                    source_pre_template_valid=source_evidence.get('source_pre_template_valid'),
                    pre_vs_empty_mae=source_evidence.get('pre_vs_empty_mae'),
                    source_anchor_revalidated=source_evidence.get('source_anchor_revalidated'),
                )
                reacquire=self._reacquire_source_evidence_preaction(
                    hwnd,item,cycle_id,drop_tx_id,before=before,before_image=img,max_attempts=2
                )
                if not reacquire.get('ok'):
                    self._persist_drop_trace(
                        cycle_id,item,state='SOURCE_EVIDENCE_REACQUIRE_FAILED',drop_tx_id=drop_tx_id,
                        source_evidence_reacquire_count=len(reacquire.get('attempts') or []),
                        source_state_decision_reason='PREACTION_SOURCE_EVIDENCE_UNRESOLVED',
                        source_evidence_reacquire=reacquire,
                    )
                    return self._drop_preaction_recoverable_result(
                        'TEMPORARY_SENSOR_LAG',drop_tx_id,
                        drop_reason='SOURCE_EVIDENCE_REACQUIRE_FAILED',queue_preserved=True,transaction_preserved=True,
                        no_destructive_action_started=True,source_evidence_reacquire=reacquire
                    )
                source_evidence=reacquire.get('source_evidence') or source_evidence
                source_evidence.update({
                    'retry_pre_template_id':f'{drop_tx_id}:attempt:1:preaction-reacquire',
                    'retry_pre_vs_empty_mae':source_evidence.get('pre_vs_empty_mae'),
                    'retry_anchor_revalidated':bool(source_evidence.get('source_anchor_revalidated')),
                    'attempt_no':1,'template_fresh':True,'source_reacquire_reason':'INITIAL_PREACTION_REACQUIRE',
                })
                before=reacquire.get('snapshot') or before
                img=reacquire.get('image') or img
                self._inventory_grid=reacquire.get('grid') or self._inventory_grid
                park={'client':reacquire.get('cursor_probe_point')} if reacquire.get('cursor_probe_point') else park

            cursor_probe_point=(park or {}).get('client') or _inventory_header_client_point(self._inventory_grid)
            cursor_reference_image=img
            self._persist_drop_trace(
                cycle_id,item,state='SOURCE_EVIDENCE_PRECOMMIT_OK',drop_tx_id=drop_tx_id,
                source_evidence_mode=source_evidence.get('source_evidence_mode'),
                strong_owned_count=source_evidence.get('strong_owned_count'),
                weak_template_count=source_evidence.get('weak_template_count'),
                source_pre_template_valid=source_evidence.get('source_pre_template_valid'),
                pre_vs_empty_mae=source_evidence.get('pre_vs_empty_mae'),
                source_evidence_reacquire_count=source_evidence.get('source_evidence_reacquire_count'),
                source_anchor_revalidated=source_evidence.get('source_anchor_revalidated'),
                source_state_decision_reason='PREACTION_SOURCE_EVIDENCE_AUTHORITATIVE',
            )

            selector=self._select_drop_ground_target(hwnd,img,self._inventory_grid,exclude_points=[])
            if not selector.get('ok'):
                return self._drop_preaction_recoverable_result(selector.get('reason','NO_SAFE_GROUND_DROP_POINT'),drop_tx_id)
            point=tuple(selector['point']); initial_point=point; used_points=[point]; alternate_points=[]
            recovery_count=0; next_action='PAIR'; attempts=[]; final_confirm=None; final_action=None
            self._persist_drop_trace(
                cycle_id,item,state='DROP_PRECHECK_OK',drop_tx_id=drop_tx_id,
                ground_point=list(initial_point),initial_ground_point=list(initial_point),selected_ground_point=list(point),
                alternate_ground_points=[],world_occlusion_detected=bool(selector.get('world_occlusion_detected')),
                world_occlusion_reason='WORLD_OCCLUSION_TRANSIENT' if selector.get('world_occlusion_detected') else None,
                source_evidence_mode=source_evidence.get('source_evidence_mode'),
                strong_owned_count=source_evidence.get('strong_owned_count'),
                weak_template_count=source_evidence.get('weak_template_count'),
                source_pre_template_valid=source_evidence.get('source_pre_template_valid'),
                pre_vs_empty_mae=source_evidence.get('pre_vs_empty_mae'),
                source_evidence_reacquire_count=source_evidence.get('source_evidence_reacquire_count'),
                source_anchor_revalidated=source_evidence.get('source_anchor_revalidated'),
            )

            while True:
                attempt_no=len(attempts)+1
                # STALE WEAK TEMPLATE GUARD: a destructive PAIR retry may never
                # reuse Attempt N-1 weak evidence.  Reacquire must have stamped the
                # evidence for this exact attempt first.
                if attempt_no>1 and next_action=='PAIR' and str(source_evidence.get('source_evidence_mode') or '').startswith('WEAK_VISUAL_TEMPLATE'):
                    if int(source_evidence.get('attempt_no',0) or 0)!=attempt_no or not bool(source_evidence.get('template_fresh')):
                        self._persist_drop_trace(
                            cycle_id,item,state='STALE_WEAK_SOURCE_TEMPLATE',drop_tx_id=drop_tx_id,
                            retry_count=recovery_count,attempt_no=attempt_no,
                            retry_pre_template_id=source_evidence.get('retry_pre_template_id'),
                            template_fresh=False,
                        )
                        guard_reacquire=self._reacquire_source_evidence_retry(
                            hwnd,item,cycle_id,drop_tx_id,final_confirm or {},attempt_no,max_attempts=2
                        )
                        if not guard_reacquire.get('ok'):
                            # The previous attempt already established the known
                            # NOT_COMMITTED state. A failed refresh blocks another
                            # destructive click, but does not erase that known state.
                            return {
                                'ok':False,'safe_pause':False,'recoverable_known_state':True,
                                'reason':'TEMPORARY_ACTION_LAG',
                                'drop_reason':'STALE_WEAK_SOURCE_TEMPLATE_REACQUIRE_FAILED',
                                'drop_tx_id':drop_tx_id,'action_attempts':attempts,
                                'source_retry_reacquire':guard_reacquire,
                                'queue_preserved':True,'transaction_preserved':True,
                            }
                        source_evidence=guard_reacquire['source_evidence']; before=guard_reacquire['snapshot']; img=guard_reacquire['image']
                        cursor_probe_point=guard_reacquire.get('cursor_probe_point') or cursor_probe_point
                        cursor_reference_image=img
                source_evidence['attempt_source_template_age_ms']=round(max(0.0,(time.time()-float(source_evidence.get('capture_timestamp') or time.time()))*1000.0),3)
                self._persist_drop_trace(
                    cycle_id,item,state='DROP_INPUT_BEGIN',drop_tx_id=drop_tx_id,selected_ground_point=list(point),retry_count=recovery_count,
                    attempt_no=attempt_no,retry_pre_template_id=source_evidence.get('retry_pre_template_id'),
                    retry_pre_vs_empty_mae=source_evidence.get('retry_pre_vs_empty_mae'),
                    retry_anchor_revalidated=source_evidence.get('retry_anchor_revalidated'),
                    attempt_source_template_age_ms=source_evidence.get('attempt_source_template_age_ms'),
                    template_fresh=bool(source_evidence.get('template_fresh')),
                    source_evidence_reacquire_count=source_evidence.get('source_evidence_reacquire_count'),
                )
                if next_action=='GROUND_ONLY':
                    action=self._drop_send_ground_once(hwnd,point)
                else:
                    action=self._drop_send_pair_once(hwnd,item,point)
                final_action=action
                if action.get('source_sent'):
                    self._persist_drop_trace(cycle_id,item,state='DROP_SOURCE_SENT',drop_tx_id=drop_tx_id,retry_count=recovery_count)
                if action.get('ground_sent'):
                    self._persist_drop_trace(cycle_id,item,state='DROP_GROUND_SENT',drop_tx_id=drop_tx_id,retry_count=recovery_count)

                # Even a failed input API call is reconciled before any retry.
                self._persist_drop_trace(cycle_id,item,state='DROP_CONFIRM_BEGIN',drop_tx_id=drop_tx_id,retry_count=recovery_count)
                confirm=self._drop_wait_confirm(
                    hwnd,item,before,before_image=img,ground_point=point,
                    cursor_reference_image=cursor_reference_image,cursor_probe_point=cursor_probe_point,
                    drop_tx_id=drop_tx_id,source_evidence=source_evidence,
                )
                final_confirm=confirm
                recon=str(confirm.get('reconciliation_state') or 'UNKNOWN')
                public_confirm={k:v for k,v in confirm.items() if not str(k).startswith('_') and k!='snapshot'}
                attempt_rec={
                    'attempt_no':attempt_no,'recovery_count':recovery_count,'action_kind':next_action,
                    'ground_point':list(point),'action_ok':bool(action.get('ok')),
                    'source_sent':bool(action.get('source_sent')),'ground_sent':bool(action.get('ground_sent')),
                    'reconciliation_state':recon,'reason':confirm.get('reason'),
                    'source_state_after':confirm.get('source_state_after'),
                    'cursor_state_after':confirm.get('cursor_item_state'),
                    'world_occlusion_detected':bool(confirm.get('world_occlusion_detected')),
                    'source_evidence_reacquire_count':confirm.get('source_evidence_reacquire_count'),
                    'source_reacquire_reason':confirm.get('source_reacquire_reason'),
                    'retry_pre_template_id':confirm.get('retry_pre_template_id'),
                    'retry_pre_vs_empty_mae':confirm.get('retry_pre_vs_empty_mae'),
                    'retry_anchor_revalidated':confirm.get('retry_anchor_revalidated'),
                    'source_hover_probe_used':confirm.get('source_hover_probe_used'),
                    'source_hover_probe_result':confirm.get('source_hover_probe_result'),
                    'attempt_source_template_age_ms':confirm.get('attempt_source_template_age_ms'),
                    'template_fresh':confirm.get('template_fresh'),
                }
                attempts.append(attempt_rec)
                self._persist_drop_trace(
                    cycle_id,item,state=str(confirm.get('reason') or 'DROP_CONFIRM_TRULY_UNCERTAIN'),
                    drop_tx_id=drop_tx_id,selected_ground_point=list(point),
                    alternate_ground_points=[list(x) for x in alternate_points],attempts=attempts,
                    source_state_after=confirm.get('source_state_after'),cursor_state_after=confirm.get('cursor_item_state'),
                    reconciliation_state=recon,retry_count=recovery_count,
                    world_occlusion_detected=bool(confirm.get('world_occlusion_detected')),
                    world_occlusion_reason=confirm.get('world_occlusion_reason'),
                    final_commit_state=confirm.get('final_commit_state'),confirm=public_confirm,
                    source_evidence_mode=confirm.get('source_evidence_mode'),
                    strong_owned_count=confirm.get('strong_owned_count'),
                    weak_template_count=confirm.get('weak_template_count'),
                    source_pre_template_valid=confirm.get('source_pre_template_valid'),
                    pre_vs_empty_mae=confirm.get('pre_vs_empty_mae'),
                    post_vs_pre_mae=confirm.get('post_vs_pre_mae'),
                    post_vs_empty_mae=confirm.get('post_vs_empty_mae'),
                    source_evidence_reacquire_count=confirm.get('source_evidence_reacquire_count'),
                    source_anchor_revalidated=confirm.get('source_anchor_revalidated'),
                    source_state_decision_reason=confirm.get('source_state_decision_reason'),
                    source_reacquire_reason=confirm.get('source_reacquire_reason'),
                    retry_pre_template_id=confirm.get('retry_pre_template_id'),
                    retry_pre_vs_empty_mae=confirm.get('retry_pre_vs_empty_mae'),
                    retry_anchor_revalidated=confirm.get('retry_anchor_revalidated'),
                    source_hover_probe_used=confirm.get('source_hover_probe_used'),
                    source_hover_probe_result=confirm.get('source_hover_probe_result'),
                    attempt_source_template_age_ms=confirm.get('attempt_source_template_age_ms'),
                    template_fresh=confirm.get('template_fresh'),
                )

                decision=_drop_recovery_decision(recon,recovery_count)

                # V1.7.12 ROOTFIX: UNKNOWN is not immediately a stop when one axis
                # is already known.  The live log showed SOURCE_AMBIGUOUS +
                # CURSOR_EMPTY_CONFIRMED under transient world occlusion after a
                # correctly sent Drop pair.  Perform bounded fresh observation only,
                # on the SAME transaction, before considering Safe Pause.
                if decision=='SAFE_PAUSE' and str(confirm.get('source_state_after') or '').upper()=='SOURCE_AMBIGUOUS' \
                        and str(confirm.get('cursor_item_state') or '').upper()=='CURSOR_EMPTY_CONFIRMED':
                    self._persist_drop_trace(
                        cycle_id,item,state='DROP_TRANSIENT_AMBIGUITY_SETTLE_BEGIN',drop_tx_id=drop_tx_id,
                        retry_count=recovery_count,reconciliation_state=recon,
                        world_occlusion_detected=bool(confirm.get('world_occlusion_detected')),
                    )
                    settle=self._drop_settle_reconcile_without_input(
                        hwnd,item,before,img,point,cursor_reference_image,cursor_probe_point,
                        drop_tx_id,source_evidence,max_rounds=3,
                    )
                    settled=settle.get('confirm') if isinstance(settle,dict) else None
                    if isinstance(settled,dict):
                        confirm=settled; final_confirm=settled
                        recon=str(settled.get('reconciliation_state') or 'UNKNOWN').upper()
                        public_confirm={k:v for k,v in settled.items() if not str(k).startswith('_') and k!='snapshot'}
                    # Settle observations are diagnostics, not destructive
                    # attempts.  Keep them out of `attempts` so exactly-once action
                    # numbering and the retry template generation remain unchanged.
                    self._persist_drop_trace(
                        cycle_id,item,state='DROP_TRANSIENT_AMBIGUITY_SETTLE_RESULT',drop_tx_id=drop_tx_id,
                        retry_count=recovery_count,reconciliation_state=recon,attempts=attempts,
                        settle_reconcile_count=int((settle or {}).get('rounds_used',0) or 0),
                        settle_observations=(settle or {}).get('observations') or [],confirm=public_confirm,
                        source_state_after=public_confirm.get('source_state_after'),
                        cursor_state_after=public_confirm.get('cursor_item_state'),
                    )
                    if recon=='COMMITTED':
                        decision='FINALIZE'
                    elif recon=='NOT_COMMITTED':
                        decision='RETRY_PAIR' if recovery_count < DROP_RECOVERY_MAX_ATTEMPTS else 'TEMPORARY_ACTION_LAG'
                    elif recon=='PARTIAL':
                        decision='RETRY_GROUND_ONLY' if recovery_count < DROP_RECOVERY_MAX_ATTEMPTS else 'KNOWN_PARTIAL_RECOVERY_EXHAUSTED'
                    else:
                        decision='SAFE_PAUSE'

                # FINAL NO-PAUSE POLICY: once the bounded action retry budget is
                # consumed, do not infer failure from retry_count. Reconcile the
                # SAME drop_tx_id once more without sending any source/ground input.
                # Known state remains known; only a genuinely UNKNOWN re-probe may
                # enter Safe Pause.
                if decision=='FINAL_RECONCILE':
                    self._persist_drop_trace(
                        cycle_id,item,state='DROP_RETRY_LIMIT_RECONCILE_BEGIN',drop_tx_id=drop_tx_id,
                        selected_ground_point=list(point),retry_count=recovery_count,
                        reconciliation_state=recon,attempts=attempts,
                    )
                    # Retry budget exhaustion is not evidence of UNKNOWN. For a
                    # known NOT_COMMITTED state, refresh source evidence one final
                    # time (no destructive input) before the final reconcile.
                    if recon=='NOT_COMMITTED' and str(confirm.get('cursor_item_state') or '')=='CURSOR_EMPTY_CONFIRMED':
                        final_reacquire=self._reacquire_source_evidence_retry(
                            hwnd,item,cycle_id,drop_tx_id,confirm,len(attempts)+1,max_attempts=2
                        )
                        if final_reacquire.get('ok'):
                            source_evidence=final_reacquire.get('source_evidence') or source_evidence
                            before=final_reacquire.get('snapshot') or before
                            img=final_reacquire.get('image') or img
                            self._inventory_grid=final_reacquire.get('grid') or self._inventory_grid
                            cursor_probe_point=final_reacquire.get('cursor_probe_point') or cursor_probe_point
                            cursor_reference_image=img
                            self._persist_drop_trace(
                                cycle_id,item,state='DROP_RETRY_LIMIT_SOURCE_REACQUIRED',drop_tx_id=drop_tx_id,
                                retry_count=recovery_count,
                                source_evidence_reacquire_count=source_evidence.get('source_evidence_reacquire_count'),
                                retry_pre_template_id=source_evidence.get('retry_pre_template_id'),
                                retry_pre_vs_empty_mae=source_evidence.get('retry_pre_vs_empty_mae'),
                                retry_anchor_revalidated=source_evidence.get('retry_anchor_revalidated'),
                                source_reacquire_reason='FINAL_RECONCILE_NOT_COMMITTED',
                                template_fresh=True,
                            )
                        else:
                            # The last action was already authoritatively
                            # NOT_COMMITTED. A sensor refresh failure does not erase
                            # that known state or justify TRUE_UNKNOWN.
                            self._persist_drop_trace(
                                cycle_id,item,state='DROP_RETRY_LIMIT_SOURCE_REACQUIRE_FAILED',drop_tx_id=drop_tx_id,
                                retry_count=recovery_count,source_retry_reacquire=final_reacquire,
                                known_state_preserved='NOT_COMMITTED',
                            )
                            decision='TEMPORARY_ACTION_LAG'
                    if decision=='FINAL_RECONCILE':
                        reconfirm=self._drop_wait_confirm(
                            hwnd,item,before,before_image=img,ground_point=point,
                            cursor_reference_image=cursor_reference_image,cursor_probe_point=cursor_probe_point,
                            drop_tx_id=drop_tx_id,source_evidence=source_evidence,
                            timeout_sec=min(.45,DROP_CONFIRM_TIMEOUT_SEC),poll_sec=min(.06,DROP_CONFIRM_POLL_SEC),
                        )
                    else:
                        reconfirm=confirm
                    confirm=reconfirm; final_confirm=reconfirm
                    recon=str(reconfirm.get('reconciliation_state') or 'UNKNOWN')
                    public_confirm={k:v for k,v in reconfirm.items() if not str(k).startswith('_') and k!='snapshot'}
                    attempts.append({
                        'attempt_no':len(attempts)+1,'recovery_count':recovery_count,'action_kind':'RECONCILE_ONLY',
                        'ground_point':list(point),'action_ok':True,'source_sent':False,'ground_sent':False,
                        'reconciliation_state':recon,'reason':reconfirm.get('reason'),
                        'source_state_after':reconfirm.get('source_state_after'),
                        'cursor_state_after':reconfirm.get('cursor_item_state'),
                        'world_occlusion_detected':bool(reconfirm.get('world_occlusion_detected')),
                    })
                    self._persist_drop_trace(
                        cycle_id,item,state='DROP_RETRY_LIMIT_RECONCILE_RESULT',drop_tx_id=drop_tx_id,
                        selected_ground_point=list(point),retry_count=recovery_count,
                        source_state_after=reconfirm.get('source_state_after'),cursor_state_after=reconfirm.get('cursor_item_state'),
                        reconciliation_state=recon,attempts=attempts,
                        world_occlusion_detected=bool(reconfirm.get('world_occlusion_detected')),
                        world_occlusion_reason=reconfirm.get('world_occlusion_reason'),
                        final_commit_state=reconfirm.get('final_commit_state'),confirm=public_confirm,
                    )
                    if recon=='COMMITTED':
                        decision='FINALIZE'
                    elif recon=='NOT_COMMITTED':
                        decision='TEMPORARY_ACTION_LAG'
                    elif recon=='PARTIAL':
                        # Location is still known: item is on the cursor. Never
                        # mislabel this as TRUE UNKNOWN / Safe Pause solely because
                        # the bounded ground-click retry budget was consumed.
                        decision='KNOWN_PARTIAL_RECOVERY_EXHAUSTED'
                    else:
                        decision='SAFE_PAUSE'

                if decision=='FINALIZE':
                    self._clear_auto_resume_action_lag_context(uncertain=False)
                    resume_ctx=getattr(self,'_v113_resume_drop_context',None)
                    resume_pending=bool(isinstance(resume_ctx,dict) and resume_ctx.get('active'))
                    item['status']='DROP_PROVISIONAL' if resume_pending else 'DROPPED'
                    item['reason']=str(confirm.get('reason') or 'DROP_COMMITTED_SOURCE_CLEAR_CURSOR_EMPTY')
                    item['action']='DROP'; item['action_status']='PROVISIONAL' if resume_pending else 'CONFIRMED'
                    self._persist_drop_trace(
                        cycle_id,item,
                        state=('DROP_SOURCE_CURSOR_CONFIRMED_AWAITING_PHYSICAL_TRUTH' if resume_pending else 'DROP_CONFIRMED'),
                        drop_tx_id=drop_tx_id,final_commit_state=('PROVISIONAL_COMMITTED' if resume_pending else 'COMMITTED'),
                        attempts=attempts,retry_count=recovery_count,logical_item_id=(resume_ctx or {}).get('logical_item_id') if resume_pending else _logical_item_id(item),
                        resume_event_id=(resume_ctx or {}).get('resume_event_id') if resume_pending else None,
                    )
                    self._inventory_last=confirm.get('snapshot') or self._inventory_last
                    out={
                        'ok':True,'safe_pause':False,'dropped':True,'ground_point':list(point),
                        'initial_ground_point':list(initial_point),'alternate_ground_points':[list(x) for x in alternate_points],
                        'drop_tx_id':drop_tx_id,'recovery_count':recovery_count,'logical_exactly_once':True,
                        'action':action,'action_attempts':attempts,'confirm':public_confirm,
                        'queue_item':public_queue_item(item),
                    }
                    if resume_pending:
                        # V11.3: low-level source-clear/cursor-empty is provisional for
                        # a resumed pending item. Whole-bag same-instance absence must
                        # be proven by the resume owner before any terminal file exists.
                        out['_v113_terminal_deferred']=True
                        out['resume_pending_drop']=True
                        out['requires_physical_drop_truth']=True
                        out['logical_item_id']=resume_ctx.get('logical_item_id')
                        out['resume_event_id']=resume_ctx.get('resume_event_id')
                        out['originating_cycle_id']=resume_ctx.get('originating_cycle_id')
                        return out
                    stamp=time.strftime('%Y%m%d_%H%M%S')
                    (LOGDIR/f'{stamp}_chest_drop_item.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
                    return out

                if decision in ('RETRY_PAIR','RETRY_GROUND_ONLY'):
                    # NOT_COMMITTED means the item is still in source and cursor is
                    # empty.  Before another destructive PAIR retry, refresh source
                    # evidence so weak templates are per-attempt, never transaction-wide.
                    retry_reacquire=None
                    if decision=='RETRY_PAIR':
                        self._persist_drop_trace(
                            cycle_id,item,state='SOURCE_RETRY_REACQUIRE_BEGIN',drop_tx_id=drop_tx_id,
                            retry_count=recovery_count,next_attempt_no=len(attempts)+1,
                            source_reacquire_reason='DROP_NOT_COMMITTED_SOURCE_PRESENT_CURSOR_EMPTY',
                            previous_retry_pre_template_id=source_evidence.get('retry_pre_template_id'),
                        )
                        retry_reacquire=self._reacquire_source_evidence_retry(
                            hwnd,item,cycle_id,drop_tx_id,confirm,len(attempts)+1,max_attempts=2
                        )
                        if retry_reacquire.get('ok'):
                            source_evidence=retry_reacquire.get('source_evidence') or source_evidence
                            before=retry_reacquire.get('snapshot') or before
                            img=retry_reacquire.get('image') or img
                            self._inventory_grid=retry_reacquire.get('grid') or self._inventory_grid
                            cursor_probe_point=retry_reacquire.get('cursor_probe_point') or cursor_probe_point
                            cursor_reference_image=img
                            self._persist_drop_trace(
                                cycle_id,item,state='SOURCE_RETRY_REACQUIRED',drop_tx_id=drop_tx_id,
                                retry_count=recovery_count,source_evidence_reacquire_count=source_evidence.get('source_evidence_reacquire_count'),
                                source_reacquire_reason=source_evidence.get('source_reacquire_reason'),
                                retry_pre_template_id=source_evidence.get('retry_pre_template_id'),
                                retry_pre_vs_empty_mae=source_evidence.get('retry_pre_vs_empty_mae'),
                                retry_anchor_revalidated=source_evidence.get('retry_anchor_revalidated'),
                                source_hover_probe_used=bool(retry_reacquire.get('source_hover_probe_used')),
                                source_hover_probe_result=(retry_reacquire.get('source_hover_probe_result') or {}).get('state') if isinstance(retry_reacquire.get('source_hover_probe_result'),dict) else retry_reacquire.get('source_hover_probe_result'),
                                template_fresh=True,queue_preserved=True,transaction_preserved=True,
                            )
                        else:
                            # Do not send another click with stale weak evidence.
                            # The known NOT_COMMITTED state remains known; defer to
                            # existing temporary-action-lag recovery rather than
                            # fabricating TRUE_UNKNOWN solely from reacquire failure.
                            self._persist_drop_trace(
                                cycle_id,item,state='SOURCE_RETRY_REACQUIRE_FAILED',drop_tx_id=drop_tx_id,
                                retry_count=recovery_count,source_reacquire_reason=retry_reacquire.get('reason'),
                                source_retry_reacquire=retry_reacquire,queue_preserved=True,transaction_preserved=True,
                            )
                            decision='TEMPORARY_ACTION_LAG'

                    if decision in ('RETRY_PAIR','RETRY_GROUND_ONLY'):
                        fresh_img=capture_client(hwnd) or img
                        selector=self._select_drop_ground_target(hwnd,fresh_img,self._inventory_grid,exclude_points=used_points)
                        if selector.get('ok'):
                            recovery_count += 1
                            point=tuple(selector['point']); used_points.append(point); alternate_points.append(point)
                            next_action='GROUND_ONLY' if decision=='RETRY_GROUND_ONLY' else 'PAIR'
                            self._persist_drop_trace(
                                cycle_id,item,state='DROP_RECOVERY_ALTERNATE_GROUND',drop_tx_id=drop_tx_id,
                                selected_ground_point=list(point),alternate_ground_points=[list(x) for x in alternate_points],
                                retry_reason=confirm.get('reason'),retry_count=recovery_count,
                                reconciliation_state=recon,attempts=attempts,
                                retry_pre_template_id=source_evidence.get('retry_pre_template_id'),
                                source_evidence_reacquire_count=source_evidence.get('source_evidence_reacquire_count'),
                                template_fresh=bool(source_evidence.get('template_fresh')),
                            )
                            continue
                    # No alternate target is not transaction uncertainty.
                    # Preserve the known state: source-present/cursor-empty may defer
                    # to the existing Action-Lag Auto Resume contract; cursor-held is
                    # a known PARTIAL state and must not be mislabeled Safe Pause.
                    decision='TEMPORARY_ACTION_LAG' if recon=='NOT_COMMITTED' else 'KNOWN_PARTIAL_RECOVERY_EXHAUSTED'

                if decision=='TEMPORARY_ACTION_LAG':
                    item['status']='RECOVERY_WAIT'; item['reason']='TEMPORARY_ACTION_LAG'
                    self._arm_auto_resume_action_lag_context(
                        hwnd,action='DROP',cycle_id=cycle_id,item=item,
                        source_grid=self._inventory_grid,
                        source_before=confirm.get('_source_before_snapshot') or before,
                        fingerprint=confirm.get('source_item_fingerprint') or _build_source_item_fingerprint(item,before,self._batch_preopen_snapshot),
                        baseline_snapshot=confirm.get('_baseline_snapshot') or self._batch_preopen_snapshot,
                        cursor_probe_point=cursor_probe_point,
                        cursor_clear_reference_image=confirm.get('_cursor_clear_reference_image') or cursor_reference_image,
                    )
                    self._persist_drop_trace(
                        cycle_id,item,state='TEMPORARY_ACTION_LAG',drop_tx_id=drop_tx_id,
                        drop_reason='DROP_NOT_COMMITTED_SOURCE_PRESENT_CURSOR_EMPTY',
                        retry_reason=confirm.get('reason'),retry_count=recovery_count,attempts=attempts,
                        final_commit_state='NOT_COMMITTED',
                    )
                    return {
                        'ok':False,'safe_pause':False,'recoverable_known_state':True,'recovery_policy':'AUTO_RESUME_ACTION_LAG',
                        'reason':'TEMPORARY_ACTION_LAG','drop_reason':'DROP_NOT_COMMITTED_SOURCE_PRESENT_CURSOR_EMPTY',
                        'drop_tx_id':drop_tx_id,'recovery_count':recovery_count,'logical_exactly_once':True,
                        'action':final_action,'action_attempts':attempts,'confirm':public_confirm,'queue_item':public_queue_item(item),
                    }

                if decision=='KNOWN_PARTIAL_RECOVERY_EXHAUSTED':
                    # The item location is known (cursor), so this is explicitly NOT
                    # a Safe Pause / UNKNOWN condition. Do not source-click and do not
                    # create a new logical Drop. Stop this cycle non-destructively so
                    # diagnostics preserve the same drop_tx_id for live investigation.
                    self._clear_auto_resume_action_lag_context(uncertain=False)
                    precise='DROP_KNOWN_CURSOR_HOLDING_RECOVERY_EXHAUSTED'
                    item['status']='RECOVERY_WAIT'; item['reason']=precise
                    self._persist_drop_trace(
                        cycle_id,item,state=precise,drop_tx_id=drop_tx_id,drop_reason=precise,
                        retry_count=recovery_count,attempts=attempts,final_commit_state='PARTIAL',
                    )
                    return {
                        'ok':False,'safe_pause':False,'recoverable_known_state':True,'recovery_policy':'GROUND_ONLY_BUDGET_EXHAUSTED',
                        'reason':precise,'drop_reason':'DROP_PARTIAL_CURSOR_HOLDING',
                        'drop_tx_id':drop_tx_id,'recovery_count':recovery_count,'logical_exactly_once':True,
                        'action':final_action,'action_attempts':attempts,'confirm':public_confirm,'queue_item':public_queue_item(item),
                    }

                # TRUE UNKNOWN after bounded neutral re-probe: final safety brake.
                self._clear_auto_resume_action_lag_context(uncertain=True)
                precise='DROP_TRANSACTION_TRULY_UNKNOWN'
                item['status']='PAUSED'; item['reason']=precise
                self._persist_drop_trace(
                    cycle_id,item,state='DROP_TRANSACTION_TRULY_UNKNOWN',
                    drop_tx_id=drop_tx_id,drop_reason=precise,retry_count=recovery_count,
                    attempts=attempts,final_commit_state=recon,
                )
                gate=self._safe_pause_v2(
                    precise,destructive_input_started=True,
                    source_state=public_confirm.get('source_state_after'),
                    cursor_state=public_confirm.get('cursor_item_state')
                )
                return {
                    'ok':False,'safe_pause':bool(gate.get('safe_pause')),'reason':gate.get('reason'),'requested_reason':precise,
                    'safe_pause_allowed_by_registry':bool(gate.get('allowed')),'drop_tx_id':drop_tx_id,
                    'recovery_count':recovery_count,'logical_exactly_once':True,
                    'action':final_action,'action_attempts':attempts,'confirm':public_confirm,'queue_item':public_queue_item(item),
                }
        except Exception as e:
            try: self._persist_drop_trace(locals().get('cycle_id',0),locals().get('item'),state='DROP_CONTROLLER_ERROR',error=str(e),drop_tx_id=locals().get('drop_tx_id'))
            except Exception: pass
            destructive=bool(locals().get('final_action'))
            if not destructive:
                return {'ok':False,'safe_pause':False,'recoverable_known_state':True,'reason':'PRE_ACTION_RUNTIME_RECOVERABLE',
                    'error':str(e),'trace':traceback.format_exc(limit=8),'drop_tx_id':locals().get('drop_tx_id'),
                    'destructive_input_started':False,'recovery_policy':'REBUILD_SENSOR_DTO_REACQUIRE'}
            gate=self._safe_pause_v2('DROP_TRANSACTION_TRULY_UNKNOWN',destructive_input_started=True)
            return {'ok':False,'safe_pause':bool(gate.get('safe_pause')),'reason':gate.get('reason'),'requested_reason':'DROP_TRANSACTION_TRULY_UNKNOWN',
                    'safe_pause_allowed_by_registry':bool(gate.get('allowed')),'error':str(e),'trace':traceback.format_exc(limit=8),'drop_tx_id':locals().get('drop_tx_id')}

    def _drop_trace_path(self, cycle_id):
        return LOGDIR / f"chest_drop_trace_{int(cycle_id or 0):06d}.json"

    def _persist_drop_trace(self, cycle_id, item=None, filter_result='REJECT', disposition='DROP', state=None, **extra):
        """Stage 29.6.3 durable REJECT->DROP lifecycle evidence.

        This logger is deliberately best-effort and isolated from control flow:
        diagnostics may never turn a valid terminal action into a failure.
        """
        try:
            cid=int(cycle_id or getattr(self,'_chest_cycle_seq',0) or 0)
            trace=dict(self._chest_action_trace.get(cid) or {})
            trace.setdefault('cycle_id',cid)
            trace.setdefault('item_id', str((item or {}).get('queue_id') or (item or {}).get('id') or 'Q01'))
            trace.setdefault('filter_result', str(filter_result or 'REJECT'))
            trace.setdefault('disposition', str(disposition or 'DROP'))
            trace.setdefault('timestamps',{})
            if state:
                now=time.time()
                trace['last_state']=str(state)
                trace['timestamps'][str(state)]=now
                trace['updated_epoch']=now
            for k,v in extra.items():
                trace[k]=v
            self._chest_action_trace[cid]=trace
            self._drop_trace_path(cid).write_text(json.dumps(trace,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            return trace
        except Exception:
            return None

    def _drop_trace_timing(self, cycle_id, start_state, end_state):
        try:
            tr=self._chest_action_trace.get(int(cycle_id or 0)) or {}
            ts=tr.get('timestamps') or {}
            a=float(ts.get(start_state,0) or 0); b=float(ts.get(end_state,0) or 0)
            return round(max(0.0,b-a)*1000.0,3) if a and b else None
        except Exception:
            return None

    def _store_trace_path(self, cycle_id):
        return LOGDIR / f"chest_store_trace_{int(cycle_id or 0):06d}.json"

    def _persist_store_trace(self, cycle_id, item=None, state=None, **extra):
        """Stage 29.6.4 durable MATCH->STORE lifecycle evidence.

        Trace writes are best-effort presentation/diagnostic work and never own
        control flow. Physical PASS still requires source clear + destination
        occupancy + storage close + common finalizer continuation.
        """
        try:
            cid=int(cycle_id or getattr(self,'_chest_cycle_seq',0) or 0)
            trace=dict(self._chest_store_action_trace.get(cid) or {})
            trace.setdefault('cycle_id',cid)
            trace.setdefault('item_id',str((item or {}).get('queue_id') or (item or {}).get('id') or 'Q01'))
            trace.setdefault('filter_result','MATCH')
            trace.setdefault('disposition','STORE')
            trace.setdefault('timestamps',{})
            if state:
                now=time.time(); trace['last_state']=str(state); trace['timestamps'][str(state)]=now; trace['updated_epoch']=now
            for k,v in extra.items(): trace[k]=v
            self._chest_store_action_trace[cid]=trace
            self._store_trace_path(cid).write_text(json.dumps(trace,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            return trace
        except Exception:
            return None

    def _confirm_chest_supply_exhausted(self, input_result=None, **evidence):
        """Return True only for explicit authoritative exhaustion evidence.

        Current key-1 input success + zero inventory delta is NOT proof of chest
        exhaustion. This hook intentionally rejects inference from a timeout.
        """
        ir=input_result if isinstance(input_result,dict) else {}
        if ir.get('chest_supply_exhausted') is True:
            return True
        try:
            if ir.get('chest_supply_remaining') is not None and int(ir.get('chest_supply_remaining')) <= 0:
                return True
        except Exception:
            pass
        return bool(evidence.get('authoritative_exhausted') is True)

    def _store_terminal_barrier_v125(self, cycle_id, store_result):
        """Hard Store completion gate. Diagnostic/transaction-only; sends no input.

        Stage22 STORE completion is forbidden unless the physical Store result proves
        source clear + destination occupied + STORE_COMMITTED and the canonical
        chest_store_item terminal artifact exists for the same cycle.
        """
        sr=store_result if isinstance(store_result,dict) else {}
        checks={
            'store_committed': bool(sr.get('store_confirmed') and sr.get('stored') and sr.get('ok')),
            'source_clear_confirmed': bool(sr.get('source_confirm') or sr.get('source_cleared')),
            'destination_occupied_confirmed': bool(sr.get('destination_confirm') or sr.get('destination_occupied')),
            'cursor_empty_confirmed': bool(sr.get('cursor_empty_confirmed')),
        }
        post=sr.get('storage_truth_post') if isinstance(sr.get('storage_truth_post'),dict) else {}
        checks['planned_anchor_equals_actual_anchor']=bool(post.get('planned_anchor_equals_actual_anchor'))
        checks['storage_closed_confirmed']=bool(sr.get('storage_closed_confirmed') or sr.get('storage_closed'))
        checks['ready_next_after_storage_close']=bool(sr.get('next_cycle_ready'))
        terminal_path=LOGDIR/'chest_store_item.json'
        terminal=None; terminal_error=None
        try:
            if terminal_path.exists():
                terminal=json.loads(terminal_path.read_text(encoding='utf-8'))
        except Exception as e:
            terminal_error=str(e)
        checks['terminal_artifact_exists']=bool(isinstance(terminal,dict))
        checks['terminal_cycle_matches']=bool(isinstance(terminal,dict) and int(terminal.get('cycle_id',-1))==int(cycle_id or 0))
        checks['terminal_store_confirmed']=bool(isinstance(terminal,dict) and terminal.get('store_confirmed'))
        checks['terminal_source_confirmed']=bool(isinstance(terminal,dict) and (terminal.get('source_confirm') or terminal.get('source_cleared')))
        checks['terminal_destination_confirmed']=bool(isinstance(terminal,dict) and (terminal.get('destination_confirm') or terminal.get('destination_occupied')))
        checks['terminal_cursor_empty_confirmed']=bool(isinstance(terminal,dict) and terminal.get('cursor_empty_confirmed'))
        checks['terminal_physical_truth_committed']=bool(isinstance(terminal,dict) and terminal.get('physical_truth')=='STORE_COMMITTED')
        checks['terminal_storage_closed_confirmed']=bool(isinstance(terminal,dict) and (terminal.get('storage_closed_confirmed') or terminal.get('storage_closed')))
        checks['terminal_ready_next_after_close']=bool(isinstance(terminal,dict) and terminal.get('next_cycle_ready'))
        ok=all(checks.values())
        return {
            'ok':ok,
            'reason':'STORE_TERMINAL_BARRIER_PASS' if ok else 'STORE_TERMINAL_BARRIER_DENIED',
            'checks':checks,
            'terminal_path':str(terminal_path),
            'terminal_error':terminal_error,
            'harness_version':STORAGE_TRUTH_HARNESS_VERSION,
        }

    def _recover_no_new_item_after_open(self, hwnd, before_snapshot, first_wait, input_result, cycle_id):
        """Bounded, state-driven recovery after one sent chest input.

        No input is resent inside this recovery. We refresh inventory geometry and
        perform one short secondary delta observation. One miss continues to the
        next atomic cycle; repeated unresolved misses become an explicit runtime
        SafePause, never a fabricated CHESTS_EXHAUSTED result.
        """
        # Fresh snapshot/geometry first.
        img=capture_client(int(hwnd))
        fresh_grid=None; fresh_after=None; fresh_diff=None
        if img is not None:
            if self._inventory_grid:
                known=validate_known_grid(img,self._inventory_grid)
                if known.get('ok'): fresh_grid=self._inventory_grid
            if fresh_grid is None:
                g=detect_inventory_grid(img)
                if g.get('ok'): fresh_grid=g; self._inventory_grid=g
            if fresh_grid is not None:
                fresh_after=snapshot_inventory(img,fresh_grid)
                if fresh_after.get('ok'):
                    fresh_diff=diff_snapshots(before_snapshot,fresh_after)
                    selected=self._select_one_candidate_per_chest(fresh_diff.get('new_item_candidates',[]))
                    if int(fresh_diff.get('new_item_count',0) or 0)>=1 and selected:
                        self._chest_no_new_item_streak=0
                        return {'ok':True,'recovered':True,'after':fresh_after,'grid':fresh_grid,'diff':fresh_diff,'selected':selected,'recovery':'FRESH_SNAPSHOT'}

        # One bounded secondary observation, still without sending another chest input.
        second=self._wait_for_new_item_after_open(int(hwnd),before_snapshot,timeout_sec=1.25,poll_sec=.07)
        sd=second.get('diff') or {}
        selected=self._select_one_candidate_per_chest(sd.get('new_item_candidates',[]))
        if second.get('ok') and selected and second.get('after') is not None and second.get('grid') is not None:
            self._chest_no_new_item_streak=0
            return {'ok':True,'recovered':True,'after':second.get('after'),'grid':second.get('grid'),'diff':sd,'selected':selected,'recovery':'BOUNDED_SECONDARY_POLL','second_wait':second}

        if self._confirm_chest_supply_exhausted(input_result):
            self._chest_no_new_item_streak=0
            return {'ok':False,'confirmed_exhausted':True,'state':'CONFIRMED_CHESTS_EXHAUSTED','stop_loop':True}

        self._chest_no_new_item_streak=int(getattr(self,'_chest_no_new_item_streak',0) or 0)+1
        streak=self._chest_no_new_item_streak
        if streak < 2:
            return {'ok':False,'confirmed_exhausted':False,'state':'NO_NEW_ITEM_UNCONFIRMED','stop_loop':False,'retry_next_cycle':True,'streak':streak,'second_wait':second}
        return {'ok':False,'confirmed_exhausted':False,'state':'NO_NEW_ITEM_UNCONFIRMED','safe_pause':True,'stop_loop':True,'reason':'CHEST_SUPPLY_STATE_UNCONFIRMED','streak':streak,'second_wait':second}

    def _chest_control_snapshot(self):
        with self._chest_control_lock:
            return {
                'stop_requested': bool(self._chest_stop_requested),
                'stop_reason': self._chest_stop_reason,
                'stop_requested_at': float(self._chest_stop_requested_at or 0.0),
                'action_in_flight': bool(self._chest_action_in_flight),
                'action_name': self._chest_action_name,
                'action_owner_cycle': self._chest_action_owner_cycle,
                'action_age_ms': round(max(0.0,time.time()-float(self._chest_action_started_at or 0.0))*1000.0,3) if self._chest_action_in_flight and self._chest_action_started_at else 0.0,
                'cycle_id': int(getattr(self, '_chest_cycle_seq', 0) or 0),
            }

    def _chest_clear_stop(self):
        with self._chest_control_lock:
            self._chest_stop_requested = False
            self._chest_stop_reason = None
            self._chest_stop_requested_at = 0.0
            self._chest_action_in_flight = False
            self._chest_action_name = None
            self._chest_action_owner_cycle = None
            self._chest_action_started_at = 0.0
        return self._chest_control_snapshot()

    def _chest_is_stop_requested(self):
        with self._chest_control_lock:
            return bool(self._chest_stop_requested)

    def _chest_set_action_in_flight(self, active, action_name=None):
        # Never allow an internal diagnostic/control lock to create an unexplained
        # ~15s wait. 250 ms is far above the expected micro-critical-section time.
        acquired=self._chest_control_lock.acquire(timeout=.25)
        if not acquired:
            return {'ok':False,'reason':'CONTROL_LOCK_TIMEOUT','action_in_flight':bool(self._chest_action_in_flight),'action_name':self._chest_action_name}
        try:
            self._chest_action_in_flight = bool(active)
            self._chest_action_name = str(action_name) if active and action_name else None
            if active:
                self._chest_action_owner_cycle=int(getattr(self,'_chest_cycle_seq',0) or 0)
                self._chest_action_started_at=time.time()
            else:
                self._chest_action_owner_cycle=None
                self._chest_action_started_at=0.0
        finally:
            self._chest_control_lock.release()
        return self._chest_control_snapshot()

    def _chest_begin_atomic_action(self, action_name):
        """Bounded gate: stale/busy ownership is observable, never a silent wait."""
        acquired=self._chest_control_lock.acquire(timeout=.25)
        if not acquired:
            return {
                'started':False,'stop_requested':False,'reason':'ACTION_DISPATCH_BLOCKED',
                'guard_name':'chest_control_lock','guard_value':'LOCKED','owner_cycle_id':self._chest_action_owner_cycle,
                'age_ms':round(max(0.0,time.time()-float(self._chest_action_started_at or 0.0))*1000.0,3) if self._chest_action_started_at else None,
            }
        try:
            if self._chest_stop_requested:
                return {
                    'started': False,'stop_requested': True,
                    'stop_reason': self._chest_stop_reason or 'USER_UI_STOP',
                    'action_in_flight': bool(self._chest_action_in_flight),'action_name': self._chest_action_name,
                }
            if self._chest_action_in_flight:
                return {
                    'started':False,'stop_requested':False,'reason':'ACTION_DISPATCH_BLOCKED',
                    'guard_name':'action_in_flight','guard_value':True,
                    'owner_cycle_id':self._chest_action_owner_cycle,
                    'age_ms':round(max(0.0,time.time()-float(self._chest_action_started_at or 0.0))*1000.0,3) if self._chest_action_started_at else None,
                    'action_in_flight':True,'action_name':self._chest_action_name,
                }
            self._chest_action_in_flight=True
            self._chest_action_name=str(action_name or 'ACTION')
            self._chest_action_owner_cycle=int(getattr(self,'_chest_cycle_seq',0) or 0)
            self._chest_action_started_at=time.time()
            return {'started':True,'stop_requested':False,'action_in_flight':True,'action_name':self._chest_action_name,
                    'owner_cycle_id':self._chest_action_owner_cycle,'age_ms':0.0}
        finally:
            self._chest_control_lock.release()

    def _chest_end_atomic_action(self):
        return self._chest_set_action_in_flight(False)

    def _usage_timer_transition(self, new_state):
        """Accounting-only state transition. Never owns/schedules the chest loop.

        SESSION is wall-clock time from explicit Start until terminal/manual Stop.
        ACTIVE and RECOVERY are mutually exclusive sub-buckets of that session.
        """
        now=time.monotonic(); old=str(getattr(self,'_usage_timer_state','STOPPED') or 'STOPPED').upper()
        new_state=str(new_state or 'STOPPED').upper()
        if old=='ACTIVE' and self._usage_active_started_mono:
            self._usage_active_accum += max(0.0,now-self._usage_active_started_mono); self._usage_active_started_mono=0.0
        if old=='RECOVERY' and self._usage_recovery_started_mono:
            self._usage_recovery_accum += max(0.0,now-self._usage_recovery_started_mono); self._usage_recovery_started_mono=0.0
        if new_state=='STOPPED':
            if self._usage_session_started_mono:
                self._usage_session_accum += max(0.0,now-self._usage_session_started_mono)
                self._usage_session_started_mono=0.0
        else:
            # Recovery/Safe-Pause remains part of the current session. Auto-resume
            # therefore does not reset the session clock.
            if not self._usage_session_started_mono:
                self._usage_session_started_mono=now
        if new_state=='ACTIVE' and old!='ACTIVE': self._usage_active_started_mono=now
        if new_state=='RECOVERY' and old!='RECOVERY': self._usage_recovery_started_mono=now
        self._usage_timer_state=new_state
        return new_state

    def _persist_lifetime_usage(self):
        try:
            now=time.monotonic(); active=float(self._usage_active_accum)
            if self._usage_timer_state=='ACTIVE' and self._usage_active_started_mono:
                active += max(0.0,now-self._usage_active_started_mono)
            delta=max(0.0,active-float(getattr(self,'_usage_last_persisted_active',0.0) or 0.0))
            if delta>0:
                self._usage_lifetime_seconds += delta
                self._usage_last_persisted_active=active
            mods=self._cfg.setdefault('modules',{}); chest=mods.setdefault('chest',{})
            chest['lifetime_usage_seconds']=round(float(self._usage_lifetime_seconds),3)
            _save_app_config(self._cfg)
        except Exception:
            pass

    def _runtime_lifecycle_snapshot_internal(self):
        with self._runtime_lifecycle_lock:
            return {
                'ok':True,
                'state':str(self._runtime_lifecycle_state),
                'lifecycle_generation':int(self._runtime_lifecycle_generation),
                'start_request_id':self._runtime_lifecycle_start_request_id,
                'resume_event_id':self._runtime_lifecycle_resume_event_id,
                'stop_generation':int(self._runtime_lifecycle_stop_generation),
                'scheduler_owner':self._runtime_lifecycle_scheduler_owner,
            }

    def _runtime_lifecycle_transition(self, next_state, reason='', start_request_id=None, resume_event_id=None, scheduler_owner=None, increment_generation=False):
        allowed={'STOPPED','STARTING','RUNNING','RECOVERY_WAIT','RECOVERY_RUNNING','STOPPING'}
        ns=str(next_state or 'STOPPED').upper()
        if ns not in allowed: ns='STOPPED'
        with self._runtime_lifecycle_lock:
            prev=str(self._runtime_lifecycle_state)
            if increment_generation:
                self._runtime_lifecycle_generation+=1
            if start_request_id is not None:
                self._runtime_lifecycle_start_request_id=str(start_request_id) if start_request_id else None
            if resume_event_id is not None:
                self._runtime_lifecycle_resume_event_id=str(resume_event_id) if resume_event_id else None
            if scheduler_owner is not None:
                self._runtime_lifecycle_scheduler_owner=str(scheduler_owner) if scheduler_owner else None
            self._runtime_lifecycle_state=ns
            if ns=='STOPPED':
                self._runtime_lifecycle_start_request_id=None
                self._runtime_lifecycle_resume_event_id=None
                self._runtime_lifecycle_scheduler_owner=None
            elif ns=='RECOVERY_WAIT':
                self._runtime_lifecycle_start_request_id=None
                self._runtime_lifecycle_scheduler_owner=None
            snap=self._runtime_lifecycle_snapshot_internal()
        _runtime_lifecycle_log({
            'previous_state':prev,'next_state':ns,'reason':str(reason or ''),
            **{k:v for k,v in snap.items() if k!='ok'}
        })
        return snap

    @_public_api_boundary
    def runtime_lifecycle_snapshot(self):
        return self._runtime_lifecycle_snapshot_internal()

    @_public_api_boundary
    def runtime_lifecycle_begin_start(self, start_request_id, source='USER_START', resume_event_id=None):
        mode_guard=self.automation_mode_guard('CHEST')
        if not mode_guard.get('ok'):
            return {'ok':False,'approved':False,'reason':mode_guard.get('reason','ACTIVE_AUTOMATION_MODE_UNKNOWN'),
                    'mode_guard':mode_guard,**self._runtime_lifecycle_snapshot_internal()}
        with self._runtime_lifecycle_lock:
            cur=str(self._runtime_lifecycle_state)
            if cur in ('STARTING','RUNNING','RECOVERY_RUNNING','STOPPING'):
                return {'ok':False,'approved':False,'reason':'LIFECYCLE_START_DENIED_'+cur,**self._runtime_lifecycle_snapshot_internal()}
        src=str(source or 'USER_START').upper()
        ns='RECOVERY_RUNNING' if src.startswith('AUTO_RESUME') else 'STARTING'
        out=self._runtime_lifecycle_transition(ns,'BEGIN_'+src,start_request_id=start_request_id,resume_event_id=resume_event_id,scheduler_owner=start_request_id,increment_generation=True)
        return {'approved':True,**out}

    @_public_api_boundary
    def runtime_lifecycle_mark_running(self, start_request_id, source='USER_START', expected_generation=None):
        rid=str(start_request_id or '')
        with self._runtime_lifecycle_lock:
            if expected_generation is not None and int(expected_generation)!=int(self._runtime_lifecycle_generation):
                return {'ok':False,'approved':False,'reason':'STALE_START_GENERATION',**self._runtime_lifecycle_snapshot_internal()}
            if rid and str(self._runtime_lifecycle_start_request_id or '')!=rid:
                return {'ok':False,'approved':False,'reason':'STALE_START_CALLBACK',**self._runtime_lifecycle_snapshot_internal()}
        out=self._runtime_lifecycle_transition('RUNNING','START_COMMITTED_'+str(source or 'USER_START').upper(),start_request_id=rid,scheduler_owner=rid)
        return {'approved':True,**out}

    @_public_api_boundary
    def runtime_lifecycle_mark_recovery_wait(self, reason='FILTER_RECHECK_PENDING', resume_event_id=None):
        out=self._runtime_lifecycle_transition('RECOVERY_WAIT',reason,resume_event_id=resume_event_id,scheduler_owner=None)
        return {'approved':True,**out}

    @_public_api_boundary
    def runtime_lifecycle_abort_start(self, start_request_id, reason='START_ABORTED', expected_generation=None):
        rid=str(start_request_id or '')
        with self._runtime_lifecycle_lock:
            if expected_generation is not None and int(expected_generation)!=int(self._runtime_lifecycle_generation):
                return {'ok':True,'stale_ignored':True,'reason':'STALE_START_GENERATION',**self._runtime_lifecycle_snapshot_internal()}
            if rid and self._runtime_lifecycle_start_request_id and str(self._runtime_lifecycle_start_request_id)!=rid:
                return {'ok':True,'stale_ignored':True,'reason':'STALE_START_CALLBACK',**self._runtime_lifecycle_snapshot_internal()}
        out=self._runtime_lifecycle_transition('STOPPED',reason,start_request_id=None,resume_event_id=None,scheduler_owner=None)
        return {'aborted':True,**out}

    @_public_api_boundary
    def runtime_lifecycle_loop_stopped(self, reason='LOOP_STOPPED'):
        out=self._runtime_lifecycle_transition('STOPPED',reason,start_request_id=None,resume_event_id=None,scheduler_owner=None)
        return {'stopped':True,**out}

    @_public_api_boundary
    def usage_timer_snapshot(self, hwnd=0):
        now=time.monotonic(); session=float(getattr(self,'_usage_session_accum',0.0) or 0.0)
        if self._usage_session_started_mono:
            session += max(0.0,now-self._usage_session_started_mono)
        active=float(self._usage_active_accum); recovery=float(self._usage_recovery_accum)
        if self._usage_timer_state=='ACTIVE' and self._usage_active_started_mono:
            active += max(0.0,now-self._usage_active_started_mono)
        if self._usage_timer_state=='RECOVERY' and self._usage_recovery_started_mono:
            recovery += max(0.0,now-self._usage_recovery_started_mono)
        return {'ok':True,'hwnd':int(hwnd or 0),'state':self._usage_timer_state,
                'session_elapsed_seconds':round(session,3),'active_runtime_seconds':round(active,3),
                'recovery_pause_seconds':round(recovery,3),'lifetime_usage_seconds':round(float(self._usage_lifetime_seconds),3)}

    @_public_api_boundary
    def chest_request_stop(self, hwnd=0, reason='USER_UI_STOP'):
        """Canonical user-stop request.

        If an atomic action is already in flight it is allowed to finish and
        confirm, then the finalized cycle is converted to STOP. If no action
        has started, chest_process_one_live sees the flag at the next safe
        boundary and starts no new DROP/STORE.
        """
        reason = str(reason or 'USER_UI_STOP').upper()
        if reason not in ('USER_SPACE_STOP', 'USER_UI_STOP', 'FATAL_CONTROL_ERROR'):
            reason = 'USER_UI_STOP'
        # V11.6: Stop owns lifecycle generation. Any stale Start callback from
        # the previous generation is forbidden from restoring STARTING/RUNNING.
        lifecycle_before_stop=None
        try:
            with self._runtime_lifecycle_lock:
                lifecycle_before_stop=str(self._runtime_lifecycle_state)
                self._runtime_lifecycle_stop_generation+=1
            self._runtime_lifecycle_transition('STOPPING',reason,scheduler_owner=self._runtime_lifecycle_scheduler_owner,increment_generation=True)
        except Exception:
            pass
        # Any explicit Stop/fatal-control event invalidates an already queued auto-resume.
        try:
            self._auto_resume.invalidate(reason)
        except Exception:
            pass
        with self._chest_control_lock:
            first = not bool(self._chest_stop_requested)
            if first:
                self._chest_stop_requested = True
                self._chest_stop_reason = reason
                self._chest_stop_requested_at = time.time()
            snap = {
                'ok': True,
                'stop_requested': bool(self._chest_stop_requested),
                'stop_reason': self._chest_stop_reason,
                'first_request': bool(first),
                'action_in_flight': bool(self._chest_action_in_flight),
                'action_name': self._chest_action_name,
                'cycle_id': int(getattr(self, '_chest_cycle_seq', 0) or 0),
                'hwnd': int(hwnd or 0),
            }
        self._usage_timer_transition('STOPPED')
        self._persist_lifetime_usage()
        try:
            ls=self._runtime_lifecycle_snapshot_internal()
            if (not bool(snap.get('action_in_flight'))) and str(lifecycle_before_stop or '') in ('STARTING','RECOVERY_WAIT','RECOVERY_RUNNING'):
                ls=self._runtime_lifecycle_transition('STOPPED','STOP_BEFORE_RUN_COMMIT',scheduler_owner=None)
            snap['runtime_lifecycle']=ls
        except Exception:
            pass
        return snap

    @_public_api_boundary
    def chest_stop_status(self, hwnd=0):
        snap = self._chest_control_snapshot()
        return {'ok': True, 'hwnd': int(hwnd or 0), **snap}

    def _chest_user_stop_result(self, cycle_id=None, stage='SAFE_BOUNDARY', **extra):
        snap = self._chest_control_snapshot()
        reason = snap.get('stop_reason') or 'USER_UI_STOP'
        out = {
            'ok': True,
            'safe_pause': False,
            'stop_loop': True,
            'stop_reason': reason,
            'reason': reason,
            'loop_result': 'STOP',
            'loop_state': 'USER_STOP',
            'next_cycle_ready': False,
            'cycle_complete': False,
            'action_confirmed': False,
            'continuation_reason': str(stage or 'USER_STOP'),
            'user_stop_requested': True,
            'action_in_flight': bool(snap.get('action_in_flight')),
            'cycle_id': int(cycle_id or getattr(self, '_chest_cycle_seq', 0) or 0),
        }
        out.update(extra)
        return out

    def _apply_chest_user_stop_after_terminal(self, finalized):
        """Convert a confirmed item completion into an AUTO-session stop.

        The item action remains COMPLETE/confirmed; only the session transition
        changes from CONTINUE to STOP. Exactly-once action semantics are intact.
        """
        if not self._chest_is_stop_requested():
            return finalized
        out = dict(finalized or {})
        if not (out.get('cycle_complete') and out.get('action_confirmed')):
            return out
        snap = self._chest_control_snapshot()
        out.update({
            'next_cycle_ready': False,
            'loop_result': 'STOP',
            'loop_state': 'USER_STOP',
            'stop_loop': True,
            'stop_reason': snap.get('stop_reason') or 'USER_UI_STOP',
            'continuation_reason': 'USER_STOP_AFTER_ITEM_COMPLETE',
            'user_stop_requested': True,
        })
        return out

    def _finalize_chest_cycle(self, hwnd, terminal_action, action_result, queue_item=None):
        """Stage 29.5 / v10.3 common ITEM_COMPLETE -> READY_NEXT gateway.

        A filter FAIL is an item decision, not an automation failure. STORE and DROP
        converge here only *after* their exactly-once action has been confirmed.
        This method never repeats a destructive action. It only validates the
        already-completed terminal action, clears per-cycle transient state, and
        returns an explicit CONTINUE/STOP transition for the single frontend loop
        owner.
        """
        action=str(terminal_action or '').upper()
        ar=action_result if isinstance(action_result,dict) else {}
        confirmed=False
        ready_reason=None

        if action in ('STORE','STORE_PERSONAL_BAG','KEEP_STORED'):
            confirmed=bool(ar.get('ok') and ar.get('stored'))
            # STORE closes the personal bag, therefore it must additionally prove
            # that the right source inventory is ready again before continuing.
            source_ready=bool(ar.get('next_cycle_ready')) and bool((ar.get('loop_ready') or {}).get('ok'))
            confirmed=bool(confirmed and source_ready)
            ready_reason=(ar.get('loop_ready') or {}).get('reason') or ('STORE_SOURCE_READY' if source_ready else 'POST_STORE_SOURCE_GRID_NOT_READY')
            canonical_action='STORE_PERSONAL_BAG'
        elif action in ('DROP','FAIL_DROPPED'):
            conf=ar.get('confirm') or {}
            confirmed=bool(ar.get('ok') and ar.get('dropped') and conf.get('ok'))
            # V11.3 resumed pending Drops require the stronger physical-truth layer:
            # same logical item + whole-bag absence + cursor empty. Normal Drop keeps
            # the established low-level confirmation contract.
            if ar.get('requires_physical_drop_truth') or ar.get('resume_pending_drop'):
                confirmed=bool(confirmed and ar.get('physical_drop_confirmed') and ar.get('item_absent_confirmed') and ar.get('cursor_empty_confirmed'))
                ready_reason='PHYSICAL_DROP_CONFIRMED' if confirmed else 'PHYSICAL_DROP_CONFIRMATION_MISSING'
            else:
                ready_reason='DROP_CONFIRM_SOURCE_GRID_CURRENT' if confirmed else 'DROP_CONFIRMATION_MISSING'
            source_ready=confirmed
            canonical_action='DROP'
        elif action in ('SELL','FAIL_SOLD'):
            # Auto Shop is disabled in the current production build. Keep semantic
            # support in the common finalizer without re-enabling the feature.
            conf=ar.get('confirm') or {}
            confirmed=bool(ar.get('ok') and ar.get('sold') and (conf.get('ok') or ar.get('next_cycle_ready')))
            source_ready=bool(ar.get('next_cycle_ready') or conf.get('ok'))
            ready_reason='SELL_CONFIRM_SOURCE_READY' if confirmed and source_ready else 'SELL_CONFIRMATION_MISSING'
            canonical_action='SELL'
        else:
            return {
                'cycle_complete':False,'next_cycle_ready':False,
                'loop_result':'STOP','loop_state':'SAFE_PAUSE','stop_loop':True,
                'stop_reason':'CYCLE_TERMINAL_ACTION_UNKNOWN','continuation_reason':'CYCLE_TERMINAL_ACTION_UNKNOWN',
                'cycle_terminal_action':action or None,'action_confirmed':False,
            }

        if not confirmed:
            return {
                'cycle_complete':False,'next_cycle_ready':False,
                'loop_result':'STOP','loop_state':'SAFE_PAUSE','stop_loop':True,
                'stop_reason':'CYCLE_ACTION_NOT_CONFIRMED','continuation_reason':ready_reason or 'CYCLE_ACTION_NOT_CONFIRMED',
                'cycle_terminal_action':canonical_action,'action_confirmed':False,
            }

        # Current item is terminal and confirmed. Clear only transient observation
        # state so the next cycle must recapture a fresh chest/source/tooltip state.
        # Do NOT clear the proven source grid geometry or storage reservation map.
        self._new_item_queue=[]
        self._queue_read_results=[]
        self._inventory_baseline=None
        self._inventory_last=None
        self._batch_preopen_snapshot=None

        return {
            'cycle_complete':True,
            'cycle_terminal_action':canonical_action,
            'action_confirmed':True,
            'next_cycle_ready':True,
            'loop_result':'CONTINUE',
            'loop_state':'READY_NEXT',
            'stop_loop':False,
            'stop_reason':None,
            'continuation_reason':'NORMAL_ITEM_COMPLETE',
            'loop_ready':{'ok':True,'reason':ready_reason or 'NORMAL_ITEM_COMPLETE'},
            'fresh_state_required':True,
            'batch_size':int(getattr(self,'_chest_batch_size',5) or 5),
        }

    def chest_prepare_loop(self, hwnd, start_source='USER_START', auto_resume_claim_token=None, auto_resume_generation=None):
        """Canonical start handshake for both manual Start and approved lag auto-resume.

        USER_START may clear an earlier user-stop latch. AUTO_RESUME_AFTER_LAG never
        clears it; it must present a valid race-safe claim and user Stop always wins.
        """
        try:
            hwnd=int(hwnd)
            start_source=str(start_source or 'USER_START').upper()
            if start_source=='USER_START':
                self._chest_session_generation=int(getattr(self,'_chest_session_generation',0) or 0)+1
                # New explicit Start resets only current-session counters. Lifetime
                # usage remains persisted across sessions/restarts.
                self._usage_session_started_mono=time.monotonic()
                self._usage_session_accum=0.0
                self._usage_active_accum=0.0; self._usage_recovery_accum=0.0
                self._usage_active_started_mono=0.0; self._usage_recovery_started_mono=0.0
                self._usage_last_persisted_active=0.0
                self._usage_timer_state='STOPPED'
                self._usage_timer_transition('ACTIVE')
            elif start_source in ('AUTO_RESUME_AFTER_LAG','AUTO_RESUME_AFTER_ACTION_LAG','AUTO_RESUME_FILTER_RECHECK'):
                self._usage_timer_transition('ACTIVE')
            _v1711_resume_recovery_noop=False
            if start_source in ('AUTO_RESUME_AFTER_LAG','AUTO_RESUME_AFTER_ACTION_LAG','AUTO_RESUME_FILTER_RECHECK'):
                if self._chest_is_stop_requested():
                    return {'ok':False,'safe_pause':False,'reason':'AUTO_RESUME_ABORTED_USER_PRIORITY','no_input_sent':True}
                try:
                    consume=self._auto_resume.consume_claim(
                        claim_token=str(auto_resume_claim_token or ''),
                        expected_generation=int(auto_resume_generation),
                    )
                except Exception as e:
                    consume={'approved':False,'reason':'AUTO_RESUME_CLAIM_EXCEPTION','error':str(e)}
                if not consume.get('approved'):
                    return {'ok':False,'safe_pause':False,'reason':consume.get('reason','AUTO_RESUME_CLAIM_INVALID'),'auto_resume':consume,'no_input_sent':True}
                self._v109_resume_schedule_snapshot=consume.get('consumed_pending') if isinstance(consume,dict) else None
                self._v121_active_resume_owner_binding=None
                if start_source=='AUTO_RESUME_FILTER_RECHECK':
                    consumed_pending=self._v109_resume_schedule_snapshot if isinstance(self._v109_resume_schedule_snapshot,dict) else {}
                    pause_id=consumed_pending.get('pause_id')
                    binding=self._v121_resume_owner_bindings.pop(str(pause_id),None) if pause_id is not None else None
                    rec_claim=self._v1711_reconcile_autochest_recovery_state('AUTO_RESUME_FILTER_RECHECK_CLAIM')
                    if not rec_claim.get('ok'):
                        return {'ok':False,'safe_pause':False,'reason':rec_claim.get('reason','AUTO_CHEST_RECOVERY_STATE_INVALID'),
                                'recovery_pending':False,'recovery_hard_failure':True,'no_input_sent':True,'pause_id':pause_id,
                                'recovery_reconcile':rec_claim}
                    current_binding=self._v121_owner_binding_snapshot(require_blocking=True)
                    if not isinstance(binding,dict) or not binding.get('ok'):
                        # A timer may legitimately fire after its item was already
                        # finalized/retired by a newer valid path. With no live
                        # blocking ledger entry this is a stale no-op, not a fatal
                        # owner-entry lookup error.
                        if not current_binding.get('ok') and not rec_claim.get('blocking'):
                            _v1711_resume_recovery_noop=True
                            self._v121_recovery_owner_log('AUTO_RESUME_STALE_BINDING_NOOP',{'pause_id':pause_id,'binding':binding,'reconcile':rec_claim})
                        else:
                            return {'ok':False,'safe_pause':False,'reason':'AUTO_RESUME_OWNER_BINDING_MISSING',
                                    'recovery_pending':False,'recovery_hard_failure':True,'no_input_sent':True,'pause_id':pause_id,
                                    'current_owner':current_binding}
                    elif not current_binding.get('ok') and not rec_claim.get('blocking'):
                        _v1711_resume_recovery_noop=True
                        self._v121_recovery_owner_log('AUTO_RESUME_STALE_BINDING_NOOP',{'pause_id':pause_id,'binding':binding,'reconcile':rec_claim})
                    elif (
                        str(binding.get('logical_item_id') or '')!=str(current_binding.get('logical_item_id') or '') or
                        (int(binding.get('owner_generation',0) or 0)>0 and int(current_binding.get('owner_generation',0) or 0)>0 and
                         int(binding.get('owner_generation',0) or 0)!=int(current_binding.get('owner_generation',0) or 0))):
                        self._v121_recovery_owner_log('AUTO_RESUME_OWNER_BINDING_MISMATCH',{'scheduled':binding,'current':current_binding,'pause_id':pause_id})
                        return {'ok':False,'safe_pause':False,'reason':'AUTO_RESUME_OWNER_BINDING_MISMATCH',
                                'recovery_pending':False,'recovery_hard_failure':True,'no_input_sent':True,'scheduled_owner':binding,'current_owner':current_binding}
                    else:
                        self._v121_active_resume_owner_binding=dict(binding)
                        self._v121_recovery_owner_log('AUTO_RESUME_OWNER_BINDING_CLAIMED',binding)
                # Re-check Stop immediately after consuming the one-shot claim.
                if self._chest_is_stop_requested():
                    return {'ok':False,'safe_pause':False,'reason':'AUTO_RESUME_ABORTED_USER_PRIORITY','no_input_sent':True}
                # Clean-new-cycle contract: discard only stale observation/scheduler state.
                # Never clear unresolved exactly-once destructive evidence.
                self._new_item_queue=[]
                self._queue_read_results=[]
                self._inventory_baseline=None
                self._inventory_last=None
                self._batch_preopen_snapshot=None
                self._hover_stable_hits=0
                self._hover_last_rect=None
                self._hover_last_signature=None
                # The action-lag transaction was revalidated safe before this clean
                # Start. Do not replay it; forget only this resolved non-commit context.
                self._clear_auto_resume_action_lag_context(uncertain=False)
                _auto_resume_log('AUTO_RESUME_STALE_CYCLE_CLEARED',{'hwnd':hwnd,'generation':auto_resume_generation,'start_source':start_source})
            else:
                # Explicit manual Start begins a new session and is the only operation
                # that clears a prior user stop. SPACE itself never toggles/restarts Auto.
                try:
                    self._auto_resume.invalidate('USER_MANUAL_START')
                except Exception:
                    pass
                self._chest_clear_stop()
            registry_guard=self.filter_runtime_guard('AUTO_CHEST',require_enabled_rules=True)
            if not registry_guard.get('ok'):
                if start_source=='USER_START':
                    self._usage_timer_transition('STOPPED'); self._persist_lifetime_usage()
                return {'ok':False,'safe_pause':False,'normal_stop':True,
                        'reason':registry_guard.get('reason','AUTO_CHEST_FILTER_STARTUP_FAILED'),
                        'registry_guard':registry_guard,'no_input_sent':True}
            # Use the exact config snapshot that passed this Auto Chest preflight.
            # Do not reload a second copy between validation and loop ownership.
            self._batch_filter_cache=dict(registry_guard.get('config') or {})

            recovery_reconcile=self._v1711_reconcile_autochest_recovery_state(f'{start_source}_PREPARE')
            if not recovery_reconcile.get('ok'):
                return {'ok':False,'safe_pause':False,'normal_stop':True,
                        'reason':recovery_reconcile.get('reason','AUTO_CHEST_RECOVERY_STATE_INVALID'),
                        'recovery_reconcile':recovery_reconcile,'no_input_sent':True}

            filter_recovery=None
            # Manual Start may also recover a blocking pending owner. This gives
            # the operator a deterministic way to continue after a hard sensor
            # failure without creating a new Q01 over the old logical item.
            if start_source=='USER_START':
                blocked,owner,entry=self._v114_has_blocking_pending_owner()
                if blocked:
                    owner_lid=str((owner or {}).get('logical_item_id') or (entry or {}).get('logical_item_id') or '')
                    filter_recovery=self._resume_coordinator.resolve_pending_item(hwnd, logical_item_id=owner_lid)
                    if not filter_recovery.get('ok'):
                        return {'ok':False,'safe_pause':False,'reason':filter_recovery.get('reason','PENDING_OWNER_COMMIT_BARRIER'),
                                'recovery_pending':bool(filter_recovery.get('recovery_pending')),
                                'recovery_hard_failure':bool(filter_recovery.get('recovery_hard_failure')),
                                'filter_recovery':filter_recovery,'no_input_sent':bool(filter_recovery.get('no_input_sent')),
                                'inventory_hotkey':self.get_inventory_hotkey()}
            if start_source=='AUTO_RESUME_FILTER_RECHECK' and _v1711_resume_recovery_noop:
                filter_recovery={
                    'ok':True,'reason':'STALE_RECOVERY_OWNER_RETIRED',
                    'filter_recovery_resolved':True,'stale_recovery_noop':True,
                    'resume_commit_gate':{'ok':True,'allows_producer':True,'reason':'STALE_RECOVERY_ALREADY_RESOLVED'},
                }
            if start_source=='AUTO_RESUME_FILTER_RECHECK' and not _v1711_resume_recovery_noop:
                # Recovery owns the pending item first. It must finish/defer that
                # exact logical item before normal chest opening is re-armed.
                bound_lid=str((self._v121_active_resume_owner_binding or {}).get('logical_item_id') or '')
                filter_recovery=self._resume_coordinator.resolve_pending_item(hwnd, logical_item_id=bound_lid)
                self._v121_active_resume_owner_binding=None
                if not filter_recovery.get('ok'):
                    return {
                        'ok':False,'safe_pause':False,
                        'reason':filter_recovery.get('reason','FILTER_RECHECK_PENDING'),
                        'recovery_pending':bool(filter_recovery.get('recovery_pending') or filter_recovery.get('reason')=='FILTER_RECHECK_PENDING'),
                        'filter_recovery':filter_recovery,
                        'no_input_sent':bool(filter_recovery.get('no_input_sent')),
                        'inventory_hotkey':self.get_inventory_hotkey(),
                    }
                # V11.4: only a committed terminal action or explicit retained
                # defer may re-arm the producer.
                rcg=filter_recovery.get('resume_commit_gate') if isinstance(filter_recovery,dict) else None
                if not isinstance(rcg,dict) or not rcg.get('ok') or not rcg.get('allows_producer'):
                    return {'ok':False,'safe_pause':False,'reason':'RESUME_COMMIT_GATE_FAIL',
                            'recovery_pending':True,'filter_recovery':filter_recovery,
                            'resume_commit_gate':rcg,'no_input_sent':True,
                            'inventory_hotkey':self.get_inventory_hotkey()}
                self._v109_resume_event_waiting_next_chest=filter_recovery.get('resume_event_id')

            # Auto Chest KEEP/DROP no longer owns any Personal Storage reservation state.
            self._chest_batch_item_index=0
            self._chest_batch_seq=0
            self._chest_no_new_item_streak=0
            ready=self._capture_inventory_ready(hwnd,try_open=True)
            if not ready.get('ok'):
                if start_source=='USER_START':
                    self._usage_timer_transition('STOPPED'); self._persist_lifetime_usage()
                return {'ok':False,'safe_pause':False,'normal_stop':True,'reason':ready.get('reason','CHEST_PREPARE_INVENTORY_FAILED'),'inventory':ready,'inventory_hotkey':self.get_inventory_hotkey()}
            self._inventory_grid=ready.get('grid')
            return {
                'ok':True,'safe_pause':False,'inventory_hotkey':self.get_inventory_hotkey(),
                'opened_by_auto':bool(ready.get('opened')),
                'open_method':ready.get('open_method') or ready.get('capture_mode'),
                'grid_confidence':(ready.get('grid') or {}).get('confidence'),
                'reservation_reset':True,
                'policy':'START_ENSURE_Q_OR_F4_SOURCE_GRID_V10_9',
                'recovery_reconcile':recovery_reconcile,
                'filter_recovery':filter_recovery,
                'filter_recovery_resolved':bool(isinstance(filter_recovery,dict) and filter_recovery.get('filter_recovery_resolved')),
                'filter_recheck_deferred':bool(isinstance(filter_recovery,dict) and filter_recovery.get('filter_recheck_deferred')),
            }
        except Exception as e:
            try:
                if str(locals().get('start_source') or 'USER_START').upper()=='USER_START':
                    self._usage_timer_transition('STOPPED'); self._persist_lifetime_usage()
            except Exception:
                pass
            return {'ok':False,'safe_pause':False,'normal_stop':True,'reason':'CHEST_PREPARE_EXCEPTION','error':str(e)}


    def _chest_process_one_live_impl(self, hwnd):
        self._usage_timer_transition('ACTIVE')
        """
        V12.11 KEEP/DROP Master atomic chest cycle:
          open ONE chest -> detect ONE new item -> read/filter ->
          KEEP = leave the item exactly where it appeared in Player Inventory;
          FAIL = use the preserved V12.11 physical Drop pipeline.
        The UI repeats this atomic call, so STOP remains responsive between items.
        """
        try:
            hwnd=int(hwnd)
            producer_gate=self._v114_can_produce_new_item()
            if not producer_gate.get('ok'):
                return {'ok':False,'safe_pause':False,'stop_loop':True,'normal_stop':False,
                        'recovery_in_progress':True,'reason':'PENDING_OWNER_COMMIT_BARRIER',
                        'stop_reason':'PENDING_OWNER_COMMIT_BARRIER','pending_owner':producer_gate,
                        'opened':0,'scanned':0,'destructive_input_count':0}
            self._chest_cycle_seq=int(getattr(self,'_chest_cycle_seq',0) or 0)+1
            cycle_id=int(self._chest_cycle_seq)
            if int(getattr(self,'_chest_batch_item_index',0) or 0)<=0:
                self._chest_batch_seq=int(getattr(self,'_chest_batch_seq',0) or 0)+1
            batch_id=int(self._chest_batch_seq)
            batch_item_index=int(getattr(self,'_chest_batch_item_index',0) or 0)+1
            cycle_t0=time.perf_counter()
            # Safe boundary before any new OPEN/action.
            if self._chest_is_stop_requested():
                return self._chest_user_stop_result(cycle_id,'USER_STOP_BEFORE_OPEN',no_chest_input_sent=True)
            if not window_exists(hwnd):
                return {'ok':True,'stop_loop':True,'stop_reason':'CLIENT_WINDOW_GONE','connected':False}
            if is_minimized(hwnd):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'stop_reason':'CLIENT_MINIMIZED','reason':'CLIENT_MINIMIZED'}

            # Stage 29.2 / v10.0 ROOT FIX:
            # Load the active filter BEFORE pressing chest key 1. In v9.9 an
            # unsaved/empty backend filter let Auto enter the legacy 3-frame
            # reader, producing slow OCR + UNCERTAIN, then no DROP and loop stop.
            # A continuous live chest cycle now requires an active persisted filter.
            try:
                self._batch_filter_cache=_load_option_filter()
            except Exception:
                self._batch_filter_cache=_default_option_filter()
            if not _filter_has_enabled_rules(self._batch_filter_cache):
                return {
                    'ok':False,'safe_pause':False,'stop_loop':True,'normal_stop':True,
                    'reason':'CHEST_FILTER_NOT_CONFIGURED','enabled_rules':0,'no_chest_input_sent':True,
                }
            cfg_state=self._v107_filter_snapshot_state(self._batch_filter_cache)
            if self._last_ui_filter_hash and cfg_state.get('hash')!=self._last_ui_filter_hash:
                return {'ok':False,'safe_pause':False,'stop_loop':True,'normal_stop':True,
                        'reason':'FILTER_CONFIG_DESYNC','ui_filter_hash':self._last_ui_filter_hash,
                        'backend_filter_hash':cfg_state.get('hash'),'filter_config_generation':self._filter_config_generation,
                        'no_chest_input_sent':True,'destructive_input_count':0}

            self._new_item_queue=[]; self._queue_read_results=[]
            # V12.11 KEEP/DROP Master: Auto Chest never opens/closes/scans Personal Storage.
            ready=self._capture_source_grid_visible(hwnd)
            if not ready.get('ok'):
                # v9.7: BẮT ĐẦU owns Q/F4 and each later cycle may self-heal once
                # with the same proven opener if the right source grid disappears.
                ready=self._capture_inventory_ready(hwnd,try_open=True)
            if not ready.get('ok'):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':ready.get('reason','INVENTORY_NOT_READY'),'inventory':ready}
            self._inventory_grid=ready['grid']
            before=snapshot_inventory(ready['image'],self._inventory_grid)
            self._batch_preopen_snapshot=before
            capacity_before=self._auto_chest_capacity_guard(before)
            if not capacity_before.get('safe'):
                return {'ok':True,'safe_pause':False,'normal_stop':True,'stop_loop':True,
                        'stop_reason':'STOPPED_INVENTORY_FULL','reason':'STOPPED_INVENTORY_FULL',
                        'free_count':int(before.get('free_count',0) or 0),'capacity':capacity_before,
                        'no_chest_input_sent':True,'opened':0,'scanned':0}

            open_gate=self._chest_begin_atomic_action('OPEN_CHEST')
            if not open_gate.get('started'):
                if open_gate.get('stop_requested'):
                    return self._chest_user_stop_result(cycle_id,'USER_STOP_BEFORE_OPEN_INPUT',no_chest_input_sent=True)
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':open_gate.get('reason','OPEN_ACTION_GATE_FAILED'),'action_gate':open_gate}
            try:
                ir=self._send_chest_key_fast_once(hwnd,'1',self._cfg.get('input_mode','Auto'))
            finally:
                self._chest_end_atomic_action()
            if not ir.get('ok'):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'INPUT_BRIDGE_ERROR','input':ir}
            self._v109_mark_resume_next_chest_started()

            wait=self._wait_for_new_item_after_open(hwnd,before,timeout_sec=3.25,poll_sec=.06)
            d=wait.get('diff',{})
            selected=self._select_one_candidate_per_chest(d.get('new_item_candidates',[]))
            if not wait.get('ok') or not selected or wait.get('after') is None or wait.get('grid') is None:
                health=self.probe_client(hwnd)
                if not health.get('connected',True) or not window_exists(hwnd):
                    return {'ok':True,'stop_loop':True,'stop_reason':'CLIENT_DISCONNECTED','reason':'CLIENT_DISCONNECTED','opened_attempts':1,'confirmed_items':0,'input':ir,'health':health}
                if not health.get('capture_ok',False):
                    return {'ok':False,'safe_pause':True,'stop_loop':True,'stop_reason':'CLIENT_CAPTURE_LOST','reason':'CLIENT_CAPTURE_LOST','opened_attempts':1,'confirmed_items':0,'input':ir,'health':health}
                recovery=self._recover_no_new_item_after_open(hwnd,before,wait,ir,cycle_id)
                if recovery.get('ok'):
                    wait={'ok':True,'after':recovery.get('after'),'grid':recovery.get('grid'),'diff':recovery.get('diff'),'polls':wait.get('polls',0),'confirm_ms':wait.get('confirm_ms',0),'recovery':recovery.get('recovery')}
                    d=wait.get('diff') or {}; selected=recovery.get('selected') or self._select_one_candidate_per_chest(d.get('new_item_candidates',[]))
                elif recovery.get('confirmed_exhausted'):
                    out={'ok':True,'safe_pause':False,'stop_loop':True,'stop_reason':'CONFIRMED_CHESTS_EXHAUSTED','reason':'CONFIRMED_CHESTS_EXHAUSTED','opened_attempts':1,'confirmed_items':0,'input':ir,'wait':{'polls':wait.get('polls',0),'confirm_ms':wait.get('confirm_ms',0)},'recovery':recovery,'health':health}
                    stamp=time.strftime('%Y%m%d_%H%M%S'); (LOGDIR/f'{stamp}_stage22_loop_stop.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8'); return out
                elif recovery.get('safe_pause'):
                    return {'ok':False,'safe_pause':True,'stop_loop':True,'stop_reason':'CHEST_SUPPLY_STATE_UNCONFIRMED','reason':'CHEST_SUPPLY_STATE_UNCONFIRMED','opened_attempts':1,'confirmed_items':0,'input':ir,'wait':{'polls':wait.get('polls',0),'confirm_ms':wait.get('confirm_ms',0)},'recovery':recovery,'health':health}
                else:
                    # One temporary no-new-item observation is a normal bounded
                    # recovery outcome, not chest exhaustion and not a terminal stop.
                    return {'ok':True,'safe_pause':False,'stop_loop':False,'stop_reason':None,'reason':'NO_NEW_ITEM_UNCONFIRMED','opened_attempts':1,'confirmed_items':0,'input':ir,'wait':{'polls':wait.get('polls',0),'confirm_ms':wait.get('confirm_ms',0)},'recovery':recovery,'health':health,'cycle_id':cycle_id,'cycle_complete':True,'action_confirmed':True,'next_cycle_ready':True,'loop_result':'CONTINUE','loop_state':'READY_NEXT','continuation_reason':'NO_NEW_ITEM_UNCONFIRMED_RETRY_NEXT_CYCLE'}

            self._chest_no_new_item_streak=0
            current=wait.get('after'); self._inventory_grid=wait.get('grid')
            self._inventory_baseline=current; self._inventory_last=current
            queue=self._build_queue_from_candidates([{'open_index':1,**selected[0]}])
            if not queue:
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'NEW_ITEM_QUEUE_BUILD_FAILED'}

            # STOP may have arrived while OPEN/detection was already in progress.
            # No destructive item action has started yet.
            if self._chest_is_stop_requested():
                return self._chest_user_stop_result(
                    cycle_id,'USER_STOP_AFTER_ITEM_DETECTED',
                    opened=1,scanned=0,queue_item=public_queue_item(queue[0]),
                    no_destructive_action_started=True,
                )

            # Filter cache was loaded and validated before chest input above.
            activation=_activate_window(hwnd); time.sleep(.025)
            focus=_safe_inventory_header_click(hwnd,self._inventory_grid)
            if not focus.get('ok'):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'LOOP_FOCUS_HANDSHAKE_FAILED','focus':focus}
            read=self._read_queue_item_internal(hwnd,0,batch_session=True,execution_mode='LIVE_CHEST_TEST')
            item=self._queue_item_by_index(0)
            if item:
                item['session_generation']=int(getattr(self,'_chest_session_generation',0) or 0)
                item['originating_cycle_id']=int(cycle_id)
                item['original_anchor']=list(item.get('original_anchor') or item.get('anchor') or [0,0])
                if not str(item.get('logical_item_id') or '').startswith('ITEM-'):
                    item.pop('logical_item_id',None)
                    item['logical_item_id']=_logical_item_id(item)
            decision=(read.get('decision') if isinstance(read,dict) else None) or (item or {}).get('decision')
            # Stage29.6.2 strict semantics: filter outcomes never create an artificial
            # wait. MATCH keeps in Player Inventory, REJECT drops, and bounded UNRESOLVED safely
            # retains the uncertain item. SafePause is reserved for real runtime
            # failures reported independently by the reader/control plane.
            try:
                active_filter=_filter_has_enabled_rules(self._batch_filter_cache)
            except Exception:
                active_filter=False
            if active_filter and isinstance(read,dict):
                if read.get('safe_pause'):
                    return {
                        'ok':False,'safe_pause':True,'stop_loop':True,
                        'reason':read.get('reason') or 'FILTER_READER_RUNTIME_FAILURE',
                        'opened':1,'scanned':1,'decision':decision or 'UNCERTAIN','reader':read,
                        'queue_item':public_queue_item(item) if item else None,
                        'cycle_id':cycle_id,
                    }
                if decision=='UNCERTAIN':
                    # V10.6: one fresh logical Final6 reread for non-authoritative
                    # evidence, never an infinite OCR loop.
                    if item:
                        item['tooltip_option_signature']=_v113_read_option_signature(read) or item.get('tooltip_option_signature')
                        self._ledger_upsert(item,None,None,'NEW',None,authoritative=False)
                    reread=self._recovery_filter_reread_once(hwnd,item,read) if item else {'ok':False}
                    rr=(reread.get('reader') or {}) if isinstance(reread,dict) else {}
                    rr_dec=(rr.get('decision') if isinstance(rr,dict) else None) or (item or {}).get('decision')
                    if rr_dec in ('KEEP','FAIL'):
                        read=rr; decision=rr_dec
                    else:
                        # V10.9 keeps the fresh reread diagnostics instead of replacing
                        # them with the old generic terminal reason. Exact unresolved
                        # cause is classified below and persisted in the recovery ledger.
                        if isinstance(rr,dict) and rr:
                            read=rr
                        decision='UNCERTAIN'
                        if isinstance(read,dict):
                            read['decision']='UNCERTAIN'
                            read['filter_result']='UNRESOLVED'
                            read['disposition']='FILTER_RECHECK_PENDING'
                            read['rejection_reason']=None
                        if item:
                            item['decision']='UNCERTAIN'
                if decision not in ('KEEP','FAIL'):
                    # V1.7.14: pure reader instability is NEVER a whole-Auto stop.
                    # Keep this item physically untouched, finalize it as a safe
                    # unresolved/deferred item, then continue opening the next chest
                    # when fresh inventory capacity allows it.
                    unresolved_reason=self._v109_classify_unresolved_reason(read)
                    if isinstance(read,dict):
                        read['decision']='UNCERTAIN'
                        read['filter_result']='UNRESOLVED'
                        read['disposition']='UNRESOLVED_DEFERRED_SAFE_KEEP'
                        read['rejection_reason']=None
                        read['reason']=unresolved_reason
                        read['recovery_state']='NONBLOCKING_CONTINUE'
                    if item:
                        item['tooltip_option_signature']=_v113_read_option_signature(read) or item.get('tooltip_option_signature')
                    deferred=self._auto_chest_uncertain_continue_finalize(hwnd,item,unresolved_reason,cycle_id=cycle_id,reader=read)
                    deferred.update({'opened':1,'scanned':1,'decision':'UNCERTAIN',
                                     'queue_item':public_queue_item(item) if item else None,
                                     'pipeline':'V1_7_14_READ_UNSTABLE_CONTINUE'})
                    return deferred

            # V10.7 immutable decision provenance. Any nested/top-level or
            # UI/backend generation contradiction blocks destructive input.
            decision_envelope=self._v107_decision_envelope(cycle_id,item,read)
            if isinstance(read,dict): read['decision_envelope']=decision_envelope
            if decision_envelope.get('conflict'):
                return {'ok':False,'safe_pause':False,'stop_loop':True,'normal_stop':True,
                        'reason':'DECISION_PROVENANCE_MISMATCH','detail':decision_envelope.get('conflict_reason'),
                        'decision_envelope':decision_envelope,'reader':read,'cycle_id':cycle_id,'destructive_input_count':0}

            # Safe STOP during OCR/filter: do not begin DROP or any item action afterward.
            if self._chest_is_stop_requested():
                return self._chest_user_stop_result(
                    cycle_id,'USER_STOP_AFTER_SCAN_BEFORE_ACTION',
                    opened=1,scanned=1,decision=decision or 'UNCERTAIN',
                    queue_item=public_queue_item(item) if item else None,
                    reader=read,no_destructive_action_started=True,
                )

            if decision=='KEEP':
                # V12.11 KEEP/DROP Master: MATCH has ZERO physical item actions.
                matched_profile_id=(read.get('matched_profile_id') or (read.get('fast_filter') or {}).get('matched_profile_id') or (read.get('filter') or {}).get('matched_profile_id'))
                if not (str(decision_envelope.get('filter_result') or '').upper()=='MATCH' and matched_profile_id is not None):
                    return {'ok':False,'safe_pause':False,'stop_loop':True,'normal_stop':True,
                            'reason':'KEEP_AUTHORIZATION_DENIED_NOT_MATCHED_N_OF_N','decision_envelope':decision_envelope,
                            'reader':read,'cycle_id':cycle_id,'destructive_input_count':0}
                if item:
                    item['filter_result']='MATCH'; item['matched_profile_id']=matched_profile_id
                qpub=public_queue_item(item)
                keep_final=self._auto_chest_keep_finalize(hwnd,item,cycle_id=cycle_id)
                self._chest_batch_item_index=batch_item_index % int(getattr(self,'_chest_batch_size',5) or 5)
                keep_final.update({
                    'batch_id':batch_id,'batch_item_index':batch_item_index,
                    'batch_size':int(getattr(self,'_chest_batch_size',5) or 5),
                    'batch_complete':bool(batch_item_index>=int(getattr(self,'_chest_batch_size',5) or 5)),
                    'timings':{'total_item_ms':round((time.perf_counter()-cycle_t0)*1000.0,3),
                               'filter':(read.get('fast_filter') or {}).get('timings',{}) if isinstance(read,dict) else {}},
                })
                keep_final=self._apply_chest_user_stop_after_terminal(keep_final)
                out={
                    'ok':True,'safe_pause':False,'opened':1,'scanned':1,
                    'keep_count':1,'dropped_count':0,'decision':'KEEP','action':'KEEP_IN_INVENTORY',
                    'queue_item':qpub,'reader':read,'cycle_id':cycle_id,
                    'inventory_opened_by_auto':bool(ready.get('opened')),
                    'pipeline':'V12_11_AUTO_CHEST_KEEP_DROP_MASTER',
                    'destructive_input_count':0,'item_click_count':0,'storage_call_count':0,
                    **keep_final,
                }
            elif decision=='FAIL':
                drop_auth=self._v107_drop_authorization_gate(decision_envelope)
                if not drop_auth.get('ok'):
                    return {'ok':False,'safe_pause':False,'stop_loop':True,'normal_stop':True,
                            'reason':drop_auth.get('reason'),'authorization':drop_auth,'decision_envelope':decision_envelope,
                            'reader':read,'cycle_id':cycle_id,'destructive_input_count':0}
                if item:
                    self._ledger_upsert(item,'REJECT','DROP','FILTERED_REJECT',None,authoritative=True)
                self._persist_drop_trace(cycle_id,item,filter_result='REJECT',disposition='DROP',state='FILTER_COMPLETE')
                self._persist_drop_trace(cycle_id,item,state='DISPATCH_REQUESTED')
                dispatch_t0=time.perf_counter()
                action_gate=self._chest_begin_atomic_action('DROP')
                if not action_gate.get('started'):
                    if action_gate.get('stop_requested'):
                        return self._chest_user_stop_result(
                            cycle_id,'USER_STOP_BEFORE_DROP',
                            opened=1,scanned=1,decision='FAIL',
                            queue_item=public_queue_item(item) if item else None,
                            reader=read,no_destructive_action_started=True,
                        )
                    self._persist_drop_trace(cycle_id,item,state='ACTION_DISPATCH_BLOCKED',guard=action_gate)
                    return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':action_gate.get('reason','DROP_ACTION_GATE_FAILED'),'action_gate':action_gate}
                self._persist_drop_trace(cycle_id,item,state='DISPATCH_ACCEPTED',action_gate=action_gate)
                try:
                    dr=self.chest_drop_queue_item(hwnd,0)
                finally:
                    self._chest_end_atomic_action()
                if not dr.get('ok'):
                    recoverable_known=bool(dr.get('recoverable_known_state')) and not bool(dr.get('safe_pause'))
                    if recoverable_known:
                        # V10.6: action failure does not erase the authoritative REJECT.
                        # Keep the item in a pending ledger and return loop ownership to
                        # READY_NEXT when cursor is not holding an item and capacity is safe.
                        tx=dr.get('drop_tx_id')
                        le=self._ledger_upsert(item,'REJECT','DROP','REJECT_PENDING_DROP',tx,authoritative=True)
                        cur_state=str(((dr.get('confirm') or {}).get('cursor_item_state') or 'CURSOR_EMPTY_CONFIRMED'))
                        self._persist_drop_trace(cycle_id,item,state='PENDING_DEFERRED',drop_reason=dr.get('reason'),
                            pending_state='REJECT_PENDING_DROP',logical_item_id=le.get('logical_item_id'),
                            cursor_state=cur_state,drop_result={k:v for k,v in dr.items() if k not in ('snapshot','image')})
                        if cur_state=='CURSOR_HOLDING_ITEM_CONFIRMED':
                            return {'ok':False,'safe_pause':False,'stop_loop':True,'reason':'CURSOR_HOLDING_BLOCKS_NEXT_CHEST',
                                'recoverable_known_state':True,'pending_state':'REJECT_PENDING_DROP','drop_result':dr,'reader':read}
                        if self._pending_capacity_safe():
                            pending_out={'ok':True,'safe_pause':False,'stop_loop':False,'reason':'PENDING_DEFERRED',
                                'loop_state':'READY_NEXT','loop_result':'CONTINUE','next_cycle_ready':True,'cycle_complete':True,
                                'opened':1,'scanned':1,'keep_count':0,'dropped_count':0,'decision':'FAIL',
                                'pending_state':'REJECT_PENDING_DROP','drop_result':dr,'reader':read,
                                'items':[public_queue_item(x) for x in self._new_item_queue]}
                            try:
                                stamp=time.strftime('%Y%m%d_%H%M%S'); (LOGDIR/f'{stamp}_stage22_cycle.json').write_text(json.dumps({'cycle_id':cycle_id,**pending_out},ensure_ascii=False,indent=2,default=str),encoding='utf-8')
                            except Exception: pass
                            return pending_out
                        return {'ok':True,'safe_pause':False,'stop_loop':True,'stop_reason':'INVENTORY_CAPACITY_BLOCKED',
                            'reason':'INVENTORY_CAPACITY_BLOCKED','pending_state':'REJECT_PENDING_DROP','drop_result':dr,'reader':read}
                    source_state=str(((dr.get('confirm') or {}).get('source_state_after') or '')).upper()
                    cursor_state=str(((dr.get('confirm') or {}).get('cursor_item_state') or '')).upper()
                    gate=self._safe_pause_v2(dr.get('reason'),destructive_input_started=True,
                        source_state=source_state,cursor_state=cursor_state)
                    if not gate.get('allowed') and source_state in ('SOURCE_PRESENT_CONFIRMED','SOURCE_STILL_PRESENT','SOURCE_PRESENT') and cursor_state=='CURSOR_EMPTY_CONFIRMED':
                        # Registry denied a false pause because the item is still known
                        # in source. Preserve the authoritative REJECT and continue the
                        # chest owner with a tracked pending disposition.
                        le=self._ledger_upsert(item,'REJECT','DROP','REJECT_PENDING_DROP',dr.get('drop_tx_id'),authoritative=True)
                        pending_out={'ok':True,'safe_pause':False,'stop_loop':False,'reason':'PENDING_DEFERRED',
                            'loop_state':'READY_NEXT','loop_result':'CONTINUE','next_cycle_ready':True,'cycle_complete':True,
                            'opened':1,'scanned':1,'keep_count':0,'dropped_count':0,'decision':'FAIL',
                            'pending_state':'REJECT_PENDING_DROP','pre_safe_pause_recovery_used':True,
                            'logical_item_id':le.get('logical_item_id'),'drop_result':dr,'reader':read}
                        self._persist_drop_trace(cycle_id,item,state='PENDING_DEFERRED',drop_reason=dr.get('reason'),
                            pre_safe_pause_recovery_used=True,item_reidentified=True,source_state=source_state,cursor_state=cursor_state,
                            safe_pause_requested=True,safe_pause_allowed_by_registry=False,pending_state='REJECT_PENDING_DROP')
                        try:
                            stamp=time.strftime('%Y%m%d_%H%M%S'); (LOGDIR/f'{stamp}_stage22_cycle.json').write_text(json.dumps({'cycle_id':cycle_id,**pending_out},ensure_ascii=False,indent=2,default=str),encoding='utf-8')
                        except Exception: pass
                        return pending_out
                    self._persist_drop_trace(cycle_id,item,state='TRUE_SAFE_PAUSE' if gate.get('safe_pause') else 'PRE_SAFE_PAUSE_RECOVERY',
                        drop_reason=dr.get('reason'),safe_pause_allowed_by_registry=gate.get('allowed'),
                        source_state=source_state,cursor_state=cursor_state,
                        drop_result={k:v for k,v in dr.items() if k not in ('snapshot','image')})
                    return {'ok':False,'safe_pause':bool(gate.get('safe_pause')),'stop_loop':True,
                        'reason':gate.get('reason'),'requested_reason':dr.get('reason'),'recoverable_known_state':False,
                        'recovery_in_progress':not bool(gate.get('safe_pause')),
                        'opened':1,'scanned':1,'keep_count':0,'dropped_count':0,'decision':'FAIL','drop_result':dr,'reader':read}
                qpub=public_queue_item(item)
                self._persist_drop_trace(cycle_id,item,state='FINALIZER_ENTER')
                final=self._finalize_chest_cycle(hwnd,'DROP',dr,qpub)
                self._persist_drop_trace(cycle_id,item,state='FINALIZER_COMPLETE',
                    reject_to_dispatch_ms=self._drop_trace_timing(cycle_id,'FILTER_COMPLETE','DISPATCH_ACCEPTED'),
                    dispatch_to_input_ms=self._drop_trace_timing(cycle_id,'DISPATCH_ACCEPTED','DROP_SOURCE_SENT'),
                    input_to_confirm_ms=self._drop_trace_timing(cycle_id,'DROP_GROUND_SENT','DROP_CONFIRMED'),
                    total_drop_ms=self._drop_trace_timing(cycle_id,'FILTER_COMPLETE','DROP_CONFIRMED'))
                self._chest_batch_item_index=batch_item_index % int(getattr(self,'_chest_batch_size',5) or 5)
                final.update({'batch_id':batch_id,'batch_item_index':batch_item_index,'batch_size':int(getattr(self,'_chest_batch_size',5) or 5),'batch_complete':bool(batch_item_index>=int(getattr(self,'_chest_batch_size',5) or 5)),'timings':{'total_item_ms':round((time.perf_counter()-cycle_t0)*1000.0,3),'filter':(read.get('fast_filter') or {}).get('timings',{}) if isinstance(read,dict) else {}}})
                final=self._apply_chest_user_stop_after_terminal(final)
                if final.get('stop_loop') and final.get('stop_reason') in ('USER_SPACE_STOP','USER_UI_STOP'):
                    return {
                        'ok':True,'safe_pause':False,'opened':1,'scanned':1,
                        'keep_count':0,'dropped_count':1,'decision':'FAIL','action':'DROP',
                        'drop_result':dr,'queue_item':qpub,'reader':read,'cycle_id':cycle_id,
                        'inventory_opened_by_auto':bool(ready.get('opened')),
                        'pipeline':'V12_11_AUTO_CHEST_KEEP_DROP_MASTER',**final,
                    }
                capacity_after_drop=self._auto_chest_refresh_capacity(hwnd)
                if capacity_after_drop.get('ok') and not capacity_after_drop.get('safe'):
                    final.update({
                        'next_cycle_ready':False,'loop_result':'STOP','loop_state':'STOPPED_INVENTORY_FULL',
                        'stop_loop':True,'stop_reason':'STOPPED_INVENTORY_FULL',
                        'continuation_reason':'STOPPED_INVENTORY_FULL','normal_stop':True,'safe_pause':False,
                        'capacity':capacity_after_drop,
                    })
                elif not capacity_after_drop.get('ok'):
                    final.update({
                        'next_cycle_ready':False,'loop_result':'STOP','loop_state':'INVENTORY_CAPACITY_UNVERIFIED',
                        'stop_loop':True,'stop_reason':'INVENTORY_CAPACITY_UNVERIFIED',
                        'continuation_reason':'INVENTORY_CAPACITY_UNVERIFIED','normal_stop':False,'safe_pause':True,
                        'capacity':capacity_after_drop,
                    })
                if not final.get('next_cycle_ready'):
                    return {
                        'ok':bool(final.get('normal_stop')),'safe_pause':bool(final.get('safe_pause')),'stop_loop':True,
                        'stop_reason':final.get('stop_reason') or 'CYCLE_CONTINUATION_NOT_CONFIRMED',
                        'reason':final.get('continuation_reason') or 'CYCLE_CONTINUATION_NOT_CONFIRMED',
                        'opened':1,'scanned':1,'keep_count':0,'dropped_count':1,
                        'decision':'FAIL','action':'DROP','drop_result':dr,'queue_item':qpub,
                        'reader':read,'cycle_id':cycle_id,**final,
                    }
                out={
                    'ok':True,'safe_pause':False,'opened':1,'scanned':1,
                    'keep_count':0,'dropped_count':1,'decision':'FAIL','action':'DROP',
                    'drop_result':dr,'queue_item':qpub,'reader':read,'cycle_id':cycle_id,
                    'inventory_opened_by_auto':bool(ready.get('opened')),
                    'pipeline':'V12_11_AUTO_CHEST_KEEP_DROP_MASTER',**final,
                }
            else:
                # V1.7.14 fallback: unresolved reader evidence remains non-destructive
                # and non-blocking. Leave the physical item in Player Inventory and
                # continue the next chest instead of stopping the entire Auto.
                unresolved_reason=self._v109_classify_unresolved_reason(read)
                deferred=self._auto_chest_uncertain_continue_finalize(hwnd,item,unresolved_reason,cycle_id=cycle_id,reader=read)
                deferred.update({'opened':1,'scanned':1,'keep_count':0,'dropped_count':0,
                                 'decision':'UNCERTAIN','items':[public_queue_item(item)] if item else [],
                                 'pipeline':'V1_7_14_READ_UNSTABLE_CONTINUE'})
                return deferred
            stamp=time.strftime('%Y%m%d_%H%M%S')
            try:
                (LOGDIR/f'{stamp}_stage22_cycle.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            except Exception:
                # A log-write problem must not break a successful chest cycle.
                pass
            return out
        except Exception as e:
            return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'STAGE22_CYCLE_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=8)}


    def _chest_apply_safe_pause_boundary(self, result):
        """Final Auto-Mở-Rương safety gate.

        No chest submodule may surface SAFE_PAUSE directly. A result already
        authorized by SafePauseReasonRegistryV2 is preserved; every other request
        is downgraded to classified recovery/normal-stop semantics.
        """
        if not isinstance(result,dict) or not result.get('safe_pause'):
            return result
        if result.get('safe_pause_allowed_by_registry') is True:
            return result
        reason=str(result.get('requested_reason') or result.get('reason') or result.get('stop_reason') or 'UNKNOWN').upper()
        dr=result.get('drop_result') if isinstance(result.get('drop_result'),dict) else {}
        confirm=dr.get('confirm') if isinstance(dr.get('confirm'),dict) else {}
        source_state=str(confirm.get('source_state_after') or result.get('source_state') or '').upper()
        cursor_state=str(confirm.get('cursor_item_state') or result.get('cursor_state') or '').upper()
        destructive=bool(result.get('destructive_input_started'))
        # A true-unknown Drop result carries explicit destructive evidence/tx.
        if reason in CHEST_SAFE_PAUSE_REASON_REGISTRY_V2 and (dr.get('drop_tx_id') or result.get('drop_tx_id')):
            destructive=True
        gate=self._safe_pause_v2(reason,destructive_input_started=destructive,source_state=source_state,cursor_state=cursor_state)
        out=dict(result)
        out['safe_pause']=bool(gate.get('safe_pause'))
        out['safe_pause_requested']=True
        out['safe_pause_allowed_by_registry']=bool(gate.get('allowed'))
        if not gate.get('allowed'):
            out['requested_reason']=reason
            out['reason']=gate.get('reason') or 'PRE_SAFE_PAUSE_RECOVERY'
            out['recovery_in_progress']=True
            # Keep stop_loop if the caller cannot safely continue immediately, but
            # never mislabel that classified recovery/normal stop as SAFE_PAUSE.
        return out

    @_public_api_boundary
    def chest_process_one_live(self, hwnd):
        out=self._chest_apply_safe_pause_boundary(self._chest_process_one_live_impl(hwnd))
        if isinstance(out,dict):
            reason=str(out.get('stop_reason') or out.get('reason') or '').upper()
            normal_terminal={
                'CONFIRMED_CHESTS_EXHAUSTED','CHESTS_CONFIRMED_EXHAUSTED','CLIENT_WINDOW_GONE','CLIENT_DISCONNECTED',
                'INVENTORY_FULL','INVENTORY_CAPACITY_BLOCKED','STOPPED_INVENTORY_FULL'
            }
            if reason in ('FILTER_RECHECK_PENDING','FILTER_RECHECK_DEFERRED') or out.get('recovery_in_progress'):
                self._usage_timer_transition('RECOVERY')
            elif out.get('stop_loop') and reason in normal_terminal:
                self._usage_timer_transition('STOPPED'); self._persist_lifetime_usage()
            elif out.get('safe_pause'):
                self._usage_timer_transition('RECOVERY')
        return out


    def shop_process_one_live(self, hwnd):
        # Stage 27: Auto Bán Shop cancelled. Keep the legacy implementation below
        # only for rollback/reference, but hard-disable live entry before any click.
        return {'ok':False,'safe_pause':True,'stop_loop':True,'disabled':True,'reason':'SHOP_FEATURE_CANCELLED_STAGE27'}

    def _shop_process_one_live_legacy_v9_5(self, hwnd):
        """
        Legacy Stage 26 / v9.5 atomic Shop cycle (disabled in Stage 27):
          Shop Guard PASS -> open ONE chest -> scan one item ->
          FAIL: sell immediately;
          KEEP: close Shop -> store in personal bag -> close bag -> click saved Shop NPC -> Guard PASS;
          then return with stop_loop=False so the UI immediately starts the next chest.
        """
        try:
            hwnd=int(hwnd)
            if not window_exists(hwnd):
                return {'ok':True,'stop_loop':True,'stop_reason':'CLIENT_WINDOW_GONE','connected':False}
            if is_minimized(hwnd):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'stop_reason':'CLIENT_MINIMIZED','reason':'CLIENT_MINIMIZED'}

            # Shop must be visibly open at each cycle boundary.
            ready=self._capture_source_grid_visible(hwnd)
            if not ready.get('ok'):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':ready.get('reason','SOURCE_GRID_NOT_VISIBLE'),'inventory':ready}
            self._inventory_grid=ready['grid']
            _park_cursor_on_inventory_header(hwnd,self._inventory_grid,.035)
            guard=self._shop_guard_check(hwnd,require_armed=True)
            if not guard.get('ok'):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'SHOP_GUARD_FAIL_AT_CYCLE_START','guard':guard}

            self._new_item_queue=[]; self._queue_read_results=[]
            before=snapshot_inventory(ready['image'],self._inventory_grid)
            self._batch_preopen_snapshot=before
            if int(before.get('free_count',0) or 0)<=0:
                return {'ok':True,'stop_loop':True,'stop_reason':'INVENTORY_FULL','reason':'INVENTORY_FULL','free_count':0}

            ir=self._send_chest_key_fast_once(hwnd,'1',self._cfg.get('input_mode','Auto'))
            if not ir.get('ok'):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'INPUT_BRIDGE_ERROR','input':ir}

            wait=self._wait_for_new_item_after_open(hwnd,before,timeout_sec=3.25,poll_sec=.06)
            d=wait.get('diff',{})
            selected=self._select_one_candidate_per_chest(d.get('new_item_candidates',[]))
            if not wait.get('ok') or not selected or wait.get('after') is None or wait.get('grid') is None:
                health=self.probe_client(hwnd)
                if not health.get('connected',True) or not window_exists(hwnd):
                    stop='CLIENT_DISCONNECTED'
                elif not health.get('capture_ok',False):
                    stop='CLIENT_CAPTURE_LOST'
                else:
                    stop='CHESTS_EXHAUSTED_OR_NO_NEW_ITEM'
                out={'ok':True,'stop_loop':True,'stop_reason':stop,'reason':stop,'opened_attempts':1,'confirmed_items':0,'input':ir,'health':health}
                stamp=time.strftime('%Y%m%d_%H%M%S')
                (LOGDIR/f'{stamp}_shop_loop_stop.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
                return out

            current=wait.get('after'); self._inventory_grid=wait.get('grid')
            self._inventory_baseline=current; self._inventory_last=current
            queue=self._build_queue_from_candidates([{'open_index':1,**selected[0]}])
            if not queue:
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'NEW_ITEM_QUEUE_BUILD_FAILED'}

            try: self._batch_filter_cache=_load_option_filter()
            except Exception: self._batch_filter_cache=_default_option_filter()
            activation=_activate_window(hwnd); time.sleep(.02)
            focus=_safe_inventory_header_click(hwnd,self._inventory_grid)
            if not focus.get('ok'):
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'SHOP_LOOP_FOCUS_HANDSHAKE_FAILED','focus':focus}

            read=self._read_queue_item_internal(hwnd,0,batch_session=True)
            item=self._queue_item_by_index(0)
            decision=(read.get('decision') if isinstance(read,dict) else None) or (item or {}).get('decision')

            if decision=='FAIL':
                sold=self.shop_sell_queue_item(hwnd,0)
                if not sold.get('ok'):
                    return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':sold.get('reason','SELL_FAILED'),'opened':1,'scanned':1,'decision':'FAIL','sell_result':sold,'reader':read,'items':[public_queue_item(x) for x in self._new_item_queue]}
                out={'ok':True,'safe_pause':False,'stop_loop':False,'opened':1,'scanned':1,'sold_count':1,'keep_count':0,'decision':'FAIL','action':'SELL','sell_result':sold,'queue_item':public_queue_item(item),'reader':read,'pipeline':'SHOP_CONTINUOUS_OPEN_SCAN_SELL_OR_STORE_V9_5'}
            elif decision=='KEEP':
                closed=self._shop_close_once(hwnd)
                if not closed.get('ok'):
                    return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':closed.get('reason','SHOP_CLOSE_FAILED'),'opened':1,'scanned':1,'decision':'KEEP','close_result':closed,'reader':read,'items':[public_queue_item(x) for x in self._new_item_queue]}
                stored=self.chest_store_queue_item(hwnd,0)
                if not stored.get('ok'):
                    return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':stored.get('reason','STORE_KEEP_FAILED'),'opened':1,'scanned':1,'decision':'KEEP','store_result':stored,'reader':read,'items':[public_queue_item(x) for x in self._new_item_queue]}
                reopened=self._shop_reopen_once(hwnd)
                if not reopened.get('ok'):
                    return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':reopened.get('reason','SHOP_REOPEN_FAILED'),'opened':1,'scanned':1,'decision':'KEEP','keep_count':1,'store_result':stored,'reopen_result':reopened,'reader':read,'items':[public_queue_item(x) for x in self._new_item_queue]}
                out={'ok':True,'safe_pause':False,'stop_loop':False,'opened':1,'scanned':1,'sold_count':0,'keep_count':1,'decision':'KEEP','action':'STORE_THEN_REOPEN_SHOP','store_result':stored,'reopen_result':reopened,'queue_item':public_queue_item(item),'reader':read,'pipeline':'SHOP_CONTINUOUS_OPEN_SCAN_SELL_OR_STORE_V9_5'}
            else:
                if item:
                    item['status']='PAUSED'; item['reason']='UNRESOLVED_NOT_SAFE_TO_SELL'
                return {'ok':False,'safe_pause':True,'stop_loop':True,'reason':'UNRESOLVED_ITEM_NOT_SAFE_TO_SELL','opened':1,'scanned':1,'decision':decision or 'UNCERTAIN','reader':read,'items':[public_queue_item(x) for x in self._new_item_queue]}

            stamp=time.strftime('%Y%m%d_%H%M%S')
            (LOGDIR/f'{stamp}_shop_cycle.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            _shop_diag_write('SHOP_CONTINUOUS_CYCLE_PASS',out,hwnd)
            return out
        except Exception as e:
            out={'ok':False,'safe_pause':True,'stop_loop':True,'reason':'SHOP_CONTINUOUS_CYCLE_EXCEPTION','error':str(e),'trace':traceback.format_exc(limit=8)}
            _shop_diag_write('SHOP_CONTINUOUS_CYCLE_EXCEPTION',out,hwnd if 'hwnd' in locals() else 0)
            return out

    def probe_client(self, hwnd):
        try:
            hwnd = int(hwnd)
            if not window_exists(hwnd):
                return {'ok': False, 'connected': False, 'error': 'HWND không tồn tại.'}

            pid = _window_pid(hwnd)
            auto_elevated = _is_current_process_elevated()
            game_elevated = _process_elevated(pid)
            privilege_mismatch = bool(game_elevated is True and not auto_elevated)

            if is_minimized(hwnd):
                return {
                    'ok': True, 'connected': True, 'capture_ok': False, 'minimized': True,
                    'pid': pid, 'auto_elevated': auto_elevated,
                    'game_elevated': game_elevated,
                    'privilege_mismatch': privilege_mismatch,
                }

            img = capture_client(hwnd)
            if img is None:
                return {
                    'ok': True, 'connected': True, 'capture_ok': False,
                    'error': 'Bắt được HWND nhưng capture thất bại.',
                    'pid': pid, 'auto_elevated': auto_elevated,
                    'game_elevated': game_elevated,
                    'privilege_mismatch': privilege_mismatch,
                }

            import numpy as np
            arr = np.asarray(img.resize((80, 60))).astype('float32')
            variance = float(arr.var())
            nonblack = float((arr.mean(axis=2) > 6).mean())

            return {
                'ok': True,
                'connected': True,
                'capture_ok': bool(nonblack > 0.20 and variance > 8.0),
                'width': int(img.width),
                'height': int(img.height),
                'variance': round(variance, 2),
                'nonblack_ratio': round(nonblack, 3),
                'title': _window_title(hwnd),
                'pid': pid,
                'input_target_hwnd': int(_largest_child(hwnd)),
                'auto_elevated': auto_elevated,
                'game_elevated': game_elevated,
                'privilege_mismatch': privilege_mismatch,
            }
        except Exception as e:
            return {'ok': False, 'connected': False, 'error': str(e)}

    def send_inventory_hotkey_once(self, hwnd, key=None, mode='Auto', context='INVENTORY'):
        """Exactly-once Q/F4 gateway with the JX1 physical-focus contract.

        Inventory toggles are special on this client: foreground activation alone
        is not sufficient.  We first perform one safe in-client top-HUD click,
        then delegate the actual key dispatch to send_client_key_once in Foreground
        mode.  No automatic second toggle is ever sent here.
        """
        try:
            hwnd=int(hwnd)
            selected=str(key or self.get_inventory_hotkey() or '').upper()
            if selected not in ('Q','F4'):
                return {
                    'ok':False,'responded':False,'exactly_once':True,'attempt_count':0,
                    'error':f'Inventory hotkey không hợp lệ: {selected}',
                    'reason':'INVENTORY_HOTKEY_INVALID','inventory_hotkey':selected,
                    'context':str(context or 'INVENTORY'),
                }
            focus=_safe_game_hud_focus_click(hwnd)
            if not focus.get('ok'):
                return {
                    'ok':False,'responded':False,'exactly_once':True,'attempt_count':0,
                    'reason':focus.get('reason') or 'INVENTORY_FOCUS_FAILED',
                    'error':'Không tạo được mouse-focus thật bên trong JX1 trước Q/F4.',
                    'inventory_hotkey':selected,'requested_mode':str(mode or 'Auto'),
                    'used_mode':None,'context':str(context or 'INVENTORY'),'focus':focus,
                }
            sent=self.send_client_key_once(hwnd,selected,'Foreground')
            out=dict(sent or {})
            out.update({
                'inventory_hotkey':selected,
                'inventory_focus_required':True,
                'inventory_focus':focus,
                'requested_inventory_mode':str(mode or 'Auto'),
                'context':str(context or 'INVENTORY'),
            })
            if not out.get('ok'):
                out.setdefault('reason','INVENTORY_HOTKEY_SEND_FAILED')
            return out
        except Exception as e:
            return {
                'ok':False,'responded':False,'exactly_once':True,'attempt_count':0,
                'reason':'INVENTORY_HOTKEY_GATEWAY_EXCEPTION','error':str(e),
                'inventory_hotkey':str(key or ''),'context':str(context or 'INVENTORY'),
            }

    def send_client_key_once(self, hwnd, key='F9', mode='Auto'):
        """
        EXACTLY-ONCE input for state-changing actions.

        Auto/Foreground: activate JX1 and send one ScanCode event only.
        Background: send one PostMessage event only.
        There is NO automatic fallback that repeats the same key.
        """
        try:
            hwnd = int(hwnd)
            if not window_exists(hwnd):
                return {
                    'ok': False, 'responded': False,
                    'exactly_once': True, 'attempt_count': 0,
                    'error': 'Client không còn tồn tại.'
                }

            vk = VK_MAP.get(str(key).upper())
            if vk is None:
                return {
                    'ok': False, 'responded': False,
                    'exactly_once': True, 'attempt_count': 0,
                    'error': f'Phím chưa hỗ trợ: {key}'
                }

            pid = _window_pid(hwnd)
            auto_elevated = _is_current_process_elevated()
            game_elevated = _process_elevated(pid)
            privilege_mismatch = bool(
                game_elevated is True and not auto_elevated
            )

            result = {
                'ok': False,
                'responded': False,
                'exactly_once': True,
                'requested_mode': str(mode or 'Auto'),
                'used_mode': None,
                'target_hwnd': int(_largest_child(hwnd)),
                'screen_change': 0.0,
                'auto_elevated': auto_elevated,
                'game_elevated': game_elevated,
                'privilege_mismatch': privilege_mismatch,
                'attempts': [],
                'attempt_count': 0,
            }

            if privilege_mismatch:
                result['error'] = (
                    'Game đang chạy quyền Admin nhưng Auto chưa chạy Admin.'
                )
                return result

            mode = str(mode or 'Auto')

            if mode == 'Background':
                before = capture_client(hwnd)
                sent, target = _post_key(hwnd, vk)
                change = _max_screen_change(hwnd, before)
                result['attempts'].append({
                    'mode': 'Background/PostMessage',
                    'sent': bool(sent),
                    'target_hwnd': int(target),
                    'screen_change': round(change, 3),
                })
                result['attempt_count'] = 1
                result['used_mode'] = 'Background/PostMessage'
                result['target_hwnd'] = int(target)
                result['screen_change'] = round(change, 3)
                result['ok'] = bool(sent)
                result['responded'] = bool(change >= 0.65)
                if not sent:
                    result['error'] = 'PostMessage gửi thất bại.'
                return result

            activation = _activate_window(hwnd)
            result['activation'] = activation
            if not activation.get('ok'):
                result['error'] = 'Không đưa được JX1 ra foreground.'
                return result

            before = capture_client(hwnd)
            sent, scan = _sendinput_scancode(vk)
            change = _max_screen_change(hwnd, before)

            result['attempts'].append({
                'mode': 'Foreground/SendInputScanCode',
                'sent': bool(sent),
                'scan_code': int(scan),
                'screen_change': round(change, 3),
                'foreground_ok': bool(activation.get('ok')),
            })
            result['attempt_count'] = 1
            result['used_mode'] = 'Foreground/SendInputScanCode'
            result['screen_change'] = round(change, 3)
            result['ok'] = bool(sent)
            result['responded'] = bool(change >= 0.65)

            if not sent:
                result['error'] = 'SendInput ScanCode gửi thất bại.'
            elif not result['responded']:
                result['note'] = (
                    'Đã gửi đúng 1 lần; không fallback gửi lại. '
                    'Sensor của action sẽ xác nhận kết quả.'
                )
            return result

        except Exception as e:
            return {
                'ok': False,
                'responded': False,
                'exactly_once': True,
                'attempt_count': 0,
                'error': str(e),
            }

    def send_client_key(self, hwnd, key='F9', mode='Auto'):
        try:
            hwnd = int(hwnd)
            if not window_exists(hwnd):
                return {'ok': False, 'error': 'Client không còn tồn tại.'}

            vk = VK_MAP.get(str(key).upper())
            if vk is None:
                return {'ok': False, 'error': f'Phím chưa hỗ trợ: {key}'}

            pid = _window_pid(hwnd)
            auto_elevated = _is_current_process_elevated()
            game_elevated = _process_elevated(pid)
            privilege_mismatch = bool(game_elevated is True and not auto_elevated)

            result = {
                'ok': False,
                'responded': False,
                'requested_mode': str(mode or 'Auto'),
                'used_mode': None,
                'target_hwnd': int(_largest_child(hwnd)),
                'screen_change': 0.0,
                'auto_elevated': auto_elevated,
                'game_elevated': game_elevated,
                'privilege_mismatch': privilege_mismatch,
                'attempts': [],
            }

            if privilege_mismatch:
                result['error'] = 'Game đang chạy quyền Admin nhưng Auto chưa chạy Admin.'
                return result

            mode = str(mode or 'Auto')
            before = capture_client(hwnd)

            # 1) Background path: useful only for clients that consume window messages.
            if mode in ('Auto', 'Background'):
                sent, target = _post_key(hwnd, vk)
                change = _max_screen_change(hwnd, before)
                result['attempts'].append({
                    'mode': 'Background/PostMessage',
                    'sent': bool(sent),
                    'target_hwnd': int(target),
                    'screen_change': round(change, 3),
                })
                result['used_mode'] = 'Background'
                result['target_hwnd'] = int(target)
                result['screen_change'] = round(change, 3)

                if sent and change >= 0.65:
                    result['ok'] = True
                    result['responded'] = True
                    return result

                if mode == 'Background':
                    result['ok'] = bool(sent)
                    result['responded'] = False
                    result['error'] = 'Client không phản hồi PostMessage; có thể game dùng DirectInput/keyboard state.'
                    return result

            # 2) Foreground path: activate the real top-level/child HWND and inject scan code.
            activation = _activate_window(hwnd)
            result['activation'] = activation

            before_fg = capture_client(hwnd)
            sent_scan, scan = _sendinput_scancode(vk)
            change_scan = _max_screen_change(hwnd, before_fg)
            result['attempts'].append({
                'mode': 'Foreground/SendInputScanCode',
                'sent': bool(sent_scan),
                'scan_code': int(scan),
                'screen_change': round(change_scan, 3),
                'foreground_ok': bool(activation.get('ok')),
            })

            result['used_mode'] = 'ForegroundScanCode'
            result['screen_change'] = round(change_scan, 3)
            if sent_scan and change_scan >= 0.65:
                result['ok'] = True
                result['responded'] = True
                return result

            # 3) Final fallback: virtual-key SendInput after focus.
            before_vk = capture_client(hwnd)
            sent_vk = _sendinput_vk(vk)
            change_vk = _max_screen_change(hwnd, before_vk)
            result['attempts'].append({
                'mode': 'Foreground/SendInputVK',
                'sent': bool(sent_vk),
                'screen_change': round(change_vk, 3),
            })
            result['used_mode'] = 'ForegroundVK'
            result['screen_change'] = round(max(change_scan, change_vk), 3)
            result['ok'] = bool(sent_scan or sent_vk)
            result['responded'] = bool(max(change_scan, change_vk) >= 0.65)

            if not result['responded']:
                result['error'] = (
                    'Đã gửi input foreground nhưng chưa thấy UI client thay đổi. '
                    'Nếu bấm F9 vật lý trong game cũng không mở Túi Đồ thì F9 không phải hotkey của client này.'
                )
            return result
        except Exception as e:
            return {'ok': False, 'responded': False, 'error': str(e)}

    def input_bridge_selftest(self):
        try:
            result = {
                "ok": True,
                "token_elevation_defined": "TOKEN_ELEVATION" in globals(),
                "admin_probe": _is_current_process_elevated(),
                "process_probe_safe": True,
            }
            # Probe own process only; this must never raise.
            try:
                result["self_process_elevated"] = _process_elevated(SELF_PID)
            except Exception as e:
                result["ok"] = False
                result["process_probe_safe"] = False
                result["error"] = str(e)
            return result
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def input_diagnostic(self, hwnd, mode='Auto'):
        key = self.get_inventory_hotkey()
        result = self.send_client_key(hwnd, key, mode)
        result['inventory_hotkey'] = key
        result['shortcut_mode'] = self.get_shortcut_mode()
        return result

    def refresh_windows(self):
        wins = enumerate_windows()
        payload = []
        for w in wins:
            score = jx1_score(w)
            if score <= -900:
                continue
            payload.append({
                'hwnd': int(w.hwnd), 'title': str(w.title),
                'width': int(w.client_width), 'height': int(w.client_height),
                'left': int(w.left), 'top': int(w.top),
                'pid': int(getattr(w, 'pid', 0) or 0),
                'process_name': str(getattr(w, 'process_name', '') or ''),
                'jx1_score': int(score),
                'likely_jx1': bool(score >= 70),
            })
        payload.sort(key=lambda x: (-x['jx1_score'], x['title'].lower()))
        strong = [x for x in payload if x['jx1_score'] >= 70]

        auto_hwnd = None

        # Keep the user's previously locked HWND if it is still alive.
        if self._locked_client_hwnd:
            for x in payload:
                if int(x['hwnd']) == int(self._locked_client_hwnd):
                    auto_hwnd = int(x['hwnd'])
                    x['locked'] = True
                    break

        # Otherwise probe strong candidates by actual capture health.
        if auto_hwnd is None:
            for x in strong[:4]:
                p = self.probe_client(x['hwnd'])
                x['capture_ok'] = bool(p.get('capture_ok'))
                if p.get('capture_ok'):
                    auto_hwnd = int(x['hwnd'])
                    break

        return {
            'windows': payload,
            'likely_count': len(strong),
            'auto_hwnd': auto_hwnd,
            'client_detection': 'HWND_TITLE_PROCESS_PLUS_CAPTURE_HEALTH',
            **self.runtime_status(),
        }

    def test_capture(self, hwnd):
        try:
            hwnd = int(hwnd)
            if not window_exists(hwnd):
                return {'ok': False, 'error': 'Cửa sổ không còn tồn tại.'}
            if is_minimized(hwnd):
                return {'ok': False, 'error': 'Cửa sổ đang thu nhỏ.'}
            img = capture_client(hwnd)
            if img is None:
                return {'ok': False, 'error': 'Capture client thất bại.'}
            stamp = time.strftime('%Y%m%d_%H%M%S')
            p = LOGDIR / f'{stamp}_TEST_CLIENT_CAPTURE.png'
            img.save(p)
            return {'ok': True, 'width': int(img.width), 'height': int(img.height), 'file': p.name}
        except Exception as e:
            return {'ok': False, 'error': str(e)}

    def test_tooltip(self, hwnd):
        try:
            hwnd = int(hwnd)
            img = capture_client(hwnd)
            cur = get_cursor_client(hwnd)
            if img is None or cur is None:
                return {'ok': False, 'stage': 'CAPTURE', 'error': 'Không capture được client/con trỏ.'}
            if not _cursor_inside(img, cur):
                return {
                    'ok': False, 'stage': 'CURSOR', 'error': 'Con trỏ đang ở ngoài cửa sổ JX1.',
                    'cursor': list(cur), 'client_size': [img.width, img.height]
                }
            det = detect_tooltip_near_cursor(img, cur)
            stamp = time.strftime('%Y%m%d_%H%M%S')
            client_path = LOGDIR / f'{stamp}_TEST_CLIENT.png'
            img.save(client_path)
            if det.get('status') != 'FOUND':
                result = {
                    'ok': False, 'stage': 'TOOLTIP_DETECTOR',
                    'error': 'Capture OK nhưng chưa tìm thấy tooltip.',
                    'cursor': list(cur), 'candidates': det.get('candidates', []),
                    'client_file': client_path.name
                }
                (LOGDIR / f'{stamp}_TEST_TOOLTIP_RESULT.json').write_text(
                    json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8'
                )
                return result
            crop = det['crop']
            crop_path = LOGDIR / f'{stamp}_TEST_TOOLTIP_CROP.png'
            crop.save(crop_path)
            return {
                'ok': True, 'stage': 'TOOLTIP_DETECTOR', 'cursor': list(cur),
                'rect': list(det.get('rect') or []),
                'candidate_lines': int(det.get('candidate_lines') or 0),
                'score': float(det.get('score') or 0),
                'soft_candidate': bool(det.get('soft_candidate', False)),
                'client_file': client_path.name, 'crop_file': crop_path.name,
            }
        except Exception as e:
            return {'ok': False, 'error': str(e), 'stage': 'TOOLTIP_DETECTOR'}

    def poll_auto_hover(self):
        # Called by JavaScript timer. No Python background callback into the UI.
        if not self._hover_enabled:
            return {'event': 'off'}
        hwnd = self._active_hwnd
        if not hwnd:
            return {'event': 'wait', 'reason': 'NO_CLIENT'}
        try:
            if not window_exists(hwnd) or is_minimized(hwnd):
                self._hover_stable_hits = 0
                self._hover_last_rect = None
                return {'event': 'wait', 'reason': 'CLIENT_UNAVAILABLE'}

            now = time.time()
            if now - self._poll_last_time < 0.08:
                return {'event': 'wait', 'reason': 'THROTTLED'}
            self._poll_last_time = now

            img = capture_client(hwnd)
            cur = get_cursor_client(hwnd)
            if img is None or cur is None or not _cursor_inside(img, cur):
                self._hover_stable_hits = 0
                self._hover_last_rect = None
                return {'event': 'wait', 'reason': 'CURSOR_OUTSIDE'}

            det = detect_tooltip_near_cursor(img, cur)
            if det.get('status') != 'FOUND':
                self._hover_stable_hits = 0
                self._hover_last_rect = None
                return {'event': 'wait', 'reason': 'NO_TOOLTIP'}

            rect = tuple(int(x) for x in (det.get('rect') or ()))
            if rect and rect == self._hover_last_rect:
                self._hover_stable_hits += 1
            else:
                self._hover_stable_hits = 1
                self._hover_last_rect = rect

            if self._hover_stable_hits < 3:
                return {
                    'event': 'detecting',
                    'stable_hits': self._hover_stable_hits,
                    'candidate_lines': int(det.get('candidate_lines') or 0),
                    'score': float(det.get('score') or 0),
                }

            sig = (int(hwnd), str(self._active_group), rect)
            if sig == self._hover_last_signature and (now - self._hover_last_read_time) < 2.5:
                return {'event': 'cooldown'}

            self._hover_last_signature = sig
            self._hover_last_read_time = now
            self._hover_stable_hits = 0
            result = self.read_tooltip(hwnd, self._active_group)
            return {'event': 'result', 'result': result}
        except Exception as e:
            return {'event': 'error', 'error': str(e)}

    def read_tooltip(self, hwnd, group_id):
        global TESSERACT
        try:
            TESSERACT = configure_tesseract()
            if not TESSERACT:
                return {'ok': False, 'stage': 'OCR', 'error': 'Tesseract OCR chưa được tìm thấy.'}
            langs = get_languages()
            if 'vie' not in langs and 'eng' not in langs:
                return {'ok': False, 'stage': 'OCR', 'error': "Tesseract chưa có language data 'vie' hoặc 'eng'."}

            hwnd = int(hwnd)
            if not window_exists(hwnd):
                return {'ok': False, 'error': 'Cửa sổ JX1 không còn tồn tại.'}
            if is_minimized(hwnd):
                return {'ok': False, 'error': 'Cửa sổ JX1 đang thu nhỏ.'}

            stamp = time.strftime('%Y%m%d_%H%M%S')
            captured = []
            debug = []

            # IMPORTANT v2.8: capture all 3 frames FIRST, before any OCR.
            # Old code OCRed frame 1 before capturing frame 2, which could leave
            # several seconds between screenshots and break hover stability.
            for fi in range(3):
                img = capture_client(hwnd)
                cur = get_cursor_client(hwnd)
                if img is None or cur is None:
                    debug.append({'frame': fi + 1, 'status': 'CAPTURE_FAILED'})
                    time.sleep(.12)
                    continue
                if not _cursor_inside(img, cur):
                    debug.append({
                        'frame': fi + 1, 'status': 'CURSOR_OUTSIDE_CLIENT',
                        'cursor': list(cur), 'client_size': [img.width, img.height]
                    })
                    time.sleep(.12)
                    continue

                det = detect_tooltip_near_cursor(img, cur)
                if det.get('status') != 'FOUND':
                    debug.append({
                        'frame': fi + 1, 'status': 'TOOLTIP_NOT_FOUND',
                        'cursor': list(cur), 'candidates': det.get('candidates', [])
                    })
                    time.sleep(.12)
                    continue

                crop = det['crop']
                cpath = LOGDIR / f'{stamp}_frame{fi+1}_tooltip.png'
                crop.save(cpath)
                captured.append({
                    'frame': fi + 1, 'cursor': list(cur), 'path': cpath,
                    'tooltip_rect': list(det.get('rect') or []),
                    'candidate_lines': int(det.get('candidate_lines') or 0),
                    'soft_candidate': bool(det.get('soft_candidate', False)),
                    'detector_score': float(det.get('score') or 0),
                    'crop_strategy': det.get('crop_strategy'),
                })
                time.sleep(.12)

            # OCR only AFTER all 3 screenshots are safely captured. Keep OCR
            # sequential: multiple simultaneous Tesseract instances can saturate
            # lower-end player PCs and become less predictable.
            frame_results = {}
            for c in captured:
                try:
                    frame_results[c['frame']] = read_single_tooltip(c['path'], group_id)
                except Exception as e:
                    frame_results[c['frame']] = {
                        'status': 'UNCERTAIN', 'reason': 'OCR_EXCEPTION',
                        'error': str(e), 'lines': []
                    }

            frames = []
            captured_by_frame = {c['frame']: c for c in captured}
            existing_debug = {d.get('frame'): d for d in debug}
            debug = []
            for fi in range(1, 4):
                if fi in captured_by_frame:
                    c = captured_by_frame[fi]
                    result = frame_results.get(fi, {'status':'UNCERTAIN','reason':'NO_OCR_RESULT','lines':[]})
                    frames.append(result)
                    debug.append({
                        'frame': fi, 'status': 'OK', 'cursor': c['cursor'],
                        'tooltip_rect': c['tooltip_rect'],
                        'candidate_lines': c['candidate_lines'],
                        'soft_candidate': c['soft_candidate'],
                        'detector_score': c['detector_score'],
                        'crop_strategy': c['crop_strategy'],
                        'reader_status': result.get('status'),
                        'segmentation': result.get('segmentation'),
                        'crop': c['path'].name,
                    })
                elif fi in existing_debug:
                    debug.append(existing_debug[fi])

            final = consensus(frames)
            payload = {
                'ok': True, 'stage': '17', 'version': '2.8', 'group_id': group_id,
                'frames_captured': len(frames), 'reader': final,
                'frames': frames, 'debug': debug, 'ocr_languages': langs,
                'live_actions_enabled': False, 'sell': False, 'drop': False, 'store': False,
                'pipeline': {
                    'capture_policy': 'CAPTURE_3_BEFORE_OCR',
                    'ocr_policy': 'CAPTURE_FIRST_THEN_SEQUENTIAL_OCR',
                    'last6': 'MULTI_THRESHOLD_CONSENSUS',
                },
            }
            cfg = _load_option_filter()
            if _filter_has_enabled_rules(cfg):
                manual_group_pick = {
                    "group_id": None if group_id == "__all__" else group_id,
                    "family": None,
                    "ambiguous": group_id == "__all__",
                    "identity_known": group_id != "__all__",
                }
                if _search_filter_applies(cfg, manual_group_pick):
                    payload['filter'] = _evaluate_search_filter(final, cfg)

            p = LOGDIR / f'{stamp}_result.json'
            p.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
            payload['result_log'] = p.name
            return payload
        except Exception as e:
            return {'ok': False, 'error': str(e), 'trace': traceback.format_exc(limit=6)}

    def clear_all_logs(self):
        """Clear runtime diagnostics only; never mutates scheduler/filter/queue state."""
        try:
            return LOG_LIFECYCLE.clear_all_logs()
        except Exception as e:
            return {'ok':False,'reason':'CLEAR_LOG_EXCEPTION','error':str(e),'log_generation':getattr(LOG_LIFECYCLE,'generation',0)}

    def open_logs(self):
        try:
            LOG_LIFECYCLE.ensure_root()
            os.startfile(LOGDIR)
            return True
        except Exception:
            return False

    def minimize(self):
        try:
            win = webview.active_window()
            if win:
                win.minimize()
            return True
        except Exception:
            return False

    def close(self):
        try:
            win = webview.active_window()
            if win:
                win.destroy()
            return True
        except Exception:
            return False
