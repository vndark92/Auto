from __future__ import annotations

import threading
import time
import uuid


TEMPORARY_LAG_REASONS = {
    "LAG_SAFE_PAUSE",
    "GAME_TEMPORARY_TIMEOUT",
    "TEMPORARY_STATE_CHANGE_TIMEOUT",
    "CHEST_ITEM_CONFIRM_TIMEOUT",
    "NEW_ITEM_CONFIRM_TIMEOUT",
    "TEMPORARY_SENSOR_LAG",
}
TEMPORARY_ACTION_LAG_REASONS = {
    "TEMPORARY_ACTION_LAG",
    "DROP_REJECTED_ITEM_RETURNED",
    "STORE_REJECTED_ITEM_RETURNED",
}
FILTER_RECOVERY_REASONS = {
    "FILTER_RECHECK_PENDING",
    "FILTER_UNRESOLVED_AFTER_ONE_REREAD",
    "RECOVERABLE_FILTER_SENSOR_STATE",
}
AUTO_RESUME_ELIGIBLE_CATEGORIES = {"TEMPORARY_LAG", "TEMPORARY_ACTION_LAG", "RECOVERABLE_FILTER_SENSOR_STATE"}
USER_STOP_REASONS = {
    "USER_STOP", "USER_SPACE_STOP", "USER_UI_STOP", "UI_STOP_BUTTON",
    "USER_STOP_REQUESTED", "USER_DISABLED_AUTO", "SPACE_STOP",
}
CONNECTION_LOSS_REASONS = {
    "INTERNET_DISCONNECTED", "GAME_DISCONNECTED", "SOCKET_DISCONNECTED",
    "CLIENT_CONNECTION_LOST", "CLIENT_DISCONNECTED", "CLIENT_WINDOW_GONE",
}
CHEST_EXHAUSTED_REASONS = {
    "CHESTS_CONFIRMED_EXHAUSTED", "CONFIRMED_CHESTS_EXHAUSTED", "NO_CHEST_REMAINING",
}
STORAGE_FULL_REASONS = {
    "STORAGE_FULL_CONFIRMED", "PERSONAL_BAG_FULL", "PERSONAL_BAG_CONFIRMED_FULL",
}
CONFIG_ERROR_REASONS = {
    "INVALID_CONFIG", "CHEST_FILTER_NOT_CONFIGURED", "NO_VALID_CLIENT", "LICENSE_STOP", "USER_LOGOUT",
}
CLIENT_ERROR_REASONS = {
    "HWND_LOST", "CLIENT_MINIMIZED", "CLIENT_CAPTURE_LOST", "INPUT_BRIDGE_ERROR",
}


def classify_pause_reason(reason: str) -> str:
    r = str(reason or "UNKNOWN").upper()
    if r in TEMPORARY_LAG_REASONS:
        return "TEMPORARY_LAG"
    if r in TEMPORARY_ACTION_LAG_REASONS:
        return "TEMPORARY_ACTION_LAG"
    if r in FILTER_RECOVERY_REASONS:
        return "RECOVERABLE_FILTER_SENSOR_STATE"
    if r in USER_STOP_REASONS:
        return "USER_STOP"
    if r in CONNECTION_LOSS_REASONS:
        return "CONNECTION_LOST"
    if r in CHEST_EXHAUSTED_REASONS:
        return "CHESTS_EXHAUSTED"
    if r in STORAGE_FULL_REASONS:
        return "STORAGE_FULL"
    if r in CONFIG_ERROR_REASONS:
        return "CONFIG_ERROR"
    if r in CLIENT_ERROR_REASONS:
        return "CLIENT_ERROR"
    # Destructive-result uncertainty is never "lag" merely because it timed out.
    if (
        "NOT_CONFIRMED" in r
        or "TRULY_UNCERTAIN" in r
        or "TRULY_UNKNOWN" in r
        or "ITEM_ON_CURSOR" in r
        or "ACTION_STATE_UNCERTAIN" in r
        or r.startswith("DROP_PENDING_")
        or r.startswith("STORE_PENDING_")
    ):
        return "ACTION_STATE_UNCERTAIN"
    return "UNKNOWN"


AUTO_RESUME_DELAY_SECONDS = 15.0


class AutoResumeAfterLagController:
    """Race-safe one-shot canonical-delay auto-resume state machine.

    This controller owns only resume eligibility/token/deadline state. It never starts
    the Chest loop itself. The production Start pipeline remains the sole Start path.
    Pending countdown state intentionally lives only in memory; only the persisted
    config mirror is saved by the caller. `auto_resume_enabled` is the canonical runtime property.
    """

    def __init__(self, enabled: bool = False, delay_sec: float = AUTO_RESUME_DELAY_SECONDS, monotonic_fn=None):
        self._lock = threading.RLock()
        self._monotonic = monotonic_fn or time.monotonic
        self.delay_sec = float(delay_sec)
        self.auto_resume_enabled = bool(enabled)
        self.resume_generation = 0
        self._pause_seq = 0
        self._pending = None
        self._active_claim = None
        self._last_event = None

    def _now(self) -> float:
        return float(self._monotonic())

    def _snapshot_locked(self):
        now = self._now()
        p = dict(self._pending) if isinstance(self._pending, dict) else None
        if p:
            p["remaining_sec"] = max(0.0, float(p["resume_due_monotonic"]) - now)
        c = dict(self._active_claim) if isinstance(self._active_claim, dict) else None
        return {
            "auto_resume_enabled": bool(self.auto_resume_enabled),
            "resume_generation": int(self.resume_generation),
            "pending": p,
            "active_claim": c,
            "last_event": self._last_event,
        }

    def status(self):
        with self._lock:
            return self._snapshot_locked()

    def invalidate(self, event: str):
        with self._lock:
            self.resume_generation += 1
            self._pending = None
            self._active_claim = None
            self._last_event = str(event or "INVALIDATED")
            return self._snapshot_locked()

    def set_enabled(self, enabled: bool):
        with self._lock:
            enabled = bool(enabled)
            if self.auto_resume_enabled == enabled:
                return self._snapshot_locked()
            self.auto_resume_enabled = enabled
            if not enabled:
                self.resume_generation += 1
                self._pending = None
                self._active_claim = None
                self._last_event = "CHECKBOX_DISABLED"
            else:
                self._last_event = "CHECKBOX_ENABLED"
            return self._snapshot_locked()

    def schedule_temporary_lag(self, *, pause_reason: str, session_token: str, safety: dict):
        """Schedule at most one resume token for this lag event.

        `safety` is produced by the backend from current live evidence. The controller
        fails closed if any required fact is absent/false.
        """
        with self._lock:
            category = classify_pause_reason(pause_reason)
            checks = dict(safety or {})
            if not self.auto_resume_enabled:
                return {"scheduled": False, "pause_category": category, "reason": "FEATURE_DISABLED", **self._snapshot_locked()}
            if category not in AUTO_RESUME_ELIGIBLE_CATEGORIES:
                return {"scheduled": False, "pause_category": category, "reason": "PAUSE_NOT_AUTO_RESUME_ELIGIBLE", **self._snapshot_locked()}
            # V12.7 dual-root fix: scheduling and firing have different evidence gates.
            # A TEMPORARY_SENSOR_LAG / recoverable filter-sensor event may exist exactly
            # because the current capture is unhealthy. Requiring capture_healthy here
            # made an eligible event impossible to schedule. Hard safety facts remain
            # mandatory now; transient capture health is re-proven at T+15 preflight.
            required_true = [
                "hwnd_valid", "game_connected", "internet_connected",
                "input_target_valid", "no_chest_exhaustion", "storage_not_full",
                "no_destructive_action_unresolved", "no_item_on_cursor", "user_stop_clear",
            ]
            if category == "TEMPORARY_ACTION_LAG":
                # Destructive-action recovery is stricter even at schedule time.
                required_true += ["capture_healthy", "action_lag_transaction_safe", "source_inventory_stable"]
            failed = [k for k in required_true if checks.get(k) is not True]
            if failed:
                deny_reason = "ACTION_LAG_NOT_PROVEN_SAFE" if category == "TEMPORARY_ACTION_LAG" else "LAG_NOT_PROVEN"
                return {"scheduled": False, "pause_category": category, "reason": deny_reason, "failed_checks": failed, **self._snapshot_locked()}
            # Same active lag pause cannot create timer A/B/C.
            if self._pending is not None or self._active_claim is not None:
                return {"scheduled": False, "pause_category": category, "reason": "AUTO_RESUME_ALREADY_PENDING", **self._snapshot_locked()}
            self._pause_seq += 1
            pause_id = int(self._pause_seq)
            now = self._now()
            wall_now = time.time()
            self._pending = {
                "pause_id": pause_id,
                "pause_reason": str(pause_reason),
                "pause_category": category,
                "auto_resume_eligible": True,
                "scheduled_generation": int(self.resume_generation),
                "session_token": str(session_token or ""),
                "scheduled_monotonic": now,
                "resume_due_monotonic": now + self.delay_sec,
                "scheduled_at_epoch": wall_now,
                "due_at_epoch": wall_now + self.delay_sec,
                "attempt_used": False,
                "claimed": False,
            }
            self._last_event = "AUTO_RESUME_SCHEDULED"
            return {"scheduled": True, **self._snapshot_locked()}

    def _check_preflight_locked(self, *, expected_generation: int, pause_id: int, session_token: str, safety: dict, require_due: bool):
        p = self._pending
        if not self.auto_resume_enabled:
            return False, "CHECKBOX_DISABLED"
        if not isinstance(p, dict):
            return False, "NO_PENDING_AUTO_RESUME"
        if int(expected_generation) != int(self.resume_generation):
            return False, "RESUME_GENERATION_MISMATCH"
        if int(p.get("scheduled_generation", -1)) != int(self.resume_generation):
            return False, "SCHEDULED_GENERATION_STALE"
        if int(pause_id) != int(p.get("pause_id", -1)):
            return False, "PAUSE_ID_MISMATCH"
        if str(session_token or "") != str(p.get("session_token") or ""):
            return False, "SESSION_CHANGED"
        if p.get("pause_category") not in AUTO_RESUME_ELIGIBLE_CATEGORIES:
            return False, "PAUSE_NOT_AUTO_RESUME_ELIGIBLE"
        if p.get("attempt_used"):
            return False, "AUTO_RESUME_ATTEMPT_ALREADY_USED"
        if require_due and self._now() < float(p.get("resume_due_monotonic") or 0.0):
            return False, "AUTO_RESUME_DEADLINE_NOT_REACHED"
        checks = dict(safety or {})
        ordered = [
            ("feature_enabled", bool(self.auto_resume_enabled)),
            ("user_stop_clear", checks.get("user_stop_clear") is True),
            ("hwnd_valid", checks.get("hwnd_valid") is True),
            ("game_connected", checks.get("game_connected") is True),
            ("internet_connected", checks.get("internet_connected") is True),
            ("capture_healthy", checks.get("capture_healthy") is True),
            ("input_target_valid", checks.get("input_target_valid") is True),
            ("no_chest_exhaustion", checks.get("no_chest_exhaustion") is True),
            ("storage_not_full", checks.get("storage_not_full") is True),
            ("no_destructive_action_unresolved", checks.get("no_destructive_action_unresolved") is True),
            ("no_item_on_cursor", checks.get("no_item_on_cursor") is True),
            ("no_duplicate_scheduler_owner", checks.get("no_duplicate_scheduler_owner") is True),
            ("runtime_not_running", checks.get("runtime_not_running") is True),
        ]
        if p.get("pause_category") == "TEMPORARY_ACTION_LAG":
            ordered.extend([
                ("action_lag_transaction_safe", checks.get("action_lag_transaction_safe") is True),
                ("source_inventory_stable", checks.get("source_inventory_stable") is True),
            ])
        for name, ok in ordered:
            if not ok:
                return False, name.upper()
        return True, "APPROVED"

    def preflight(self, *, expected_generation: int, pause_id: int, session_token: str, safety: dict, consume_attempt_on_denied: bool = True):
        with self._lock:
            ok, reason = self._check_preflight_locked(
                expected_generation=expected_generation, pause_id=pause_id,
                session_token=session_token, safety=safety, require_due=True,
            )
            if ok:
                self._last_event = "AUTO_RESUME_REVALIDATION_PASS"
                return {"approved": True, "reason": "APPROVED", **self._snapshot_locked()}
            p = self._pending
            # Once the canonical 15-second attempt is actually due, denial is terminal for this lag event.
            due = bool(isinstance(p, dict) and self._now() >= float(p.get("resume_due_monotonic") or 0.0))
            if consume_attempt_on_denied and due and isinstance(p, dict):
                p["attempt_used"] = True
                self._last_event = "AUTO_RESUME_REVALIDATION_DENIED"
                self._pending = None
            return {"approved": False, "reason": reason, **self._snapshot_locked()}

    def claim_start(self, *, expected_generation: int, pause_id: int, session_token: str, safety: dict, start_request_id: str):
        with self._lock:
            ok, reason = self._check_preflight_locked(
                expected_generation=expected_generation, pause_id=pause_id,
                session_token=session_token, safety=safety, require_due=True,
            )
            if not ok:
                return {"approved": False, "reason": reason, **self._snapshot_locked()}
            if self._active_claim is not None:
                return {"approved": False, "reason": "AUTO_RESUME_START_ALREADY_CLAIMED", **self._snapshot_locked()}
            p = self._pending
            p["claimed"] = True
            p["attempt_used"] = True
            claim_token = uuid.uuid4().hex
            self._active_claim = {
                "claim_token": claim_token,
                "pause_id": int(pause_id),
                "generation": int(self.resume_generation),
                "session_token": str(session_token),
                "start_request_id": str(start_request_id),
            }
            self._last_event = "AUTO_RESUME_START_CLAIMED"
            return {"approved": True, "reason": "APPROVED", "claim_token": claim_token, **self._snapshot_locked()}

    def validate_claim(self, *, claim_token: str, expected_generation: int, pause_id: int, session_token: str, safety: dict):
        with self._lock:
            c = self._active_claim
            if not isinstance(c, dict):
                return {"approved": False, "reason": "NO_ACTIVE_AUTO_RESUME_CLAIM", **self._snapshot_locked()}
            if str(claim_token or "") != str(c.get("claim_token") or ""):
                return {"approved": False, "reason": "AUTO_RESUME_CLAIM_TOKEN_MISMATCH", **self._snapshot_locked()}
            if int(expected_generation) != int(self.resume_generation) or int(c.get("generation", -1)) != int(self.resume_generation):
                return {"approved": False, "reason": "RESUME_GENERATION_MISMATCH", **self._snapshot_locked()}
            if int(pause_id) != int(c.get("pause_id", -1)):
                return {"approved": False, "reason": "PAUSE_ID_MISMATCH", **self._snapshot_locked()}
            if str(session_token or "") != str(c.get("session_token") or ""):
                return {"approved": False, "reason": "SESSION_CHANGED", **self._snapshot_locked()}
            checks = dict(safety or {})
            # Race check again immediately before canonical Start preparation.
            required = [
                "user_stop_clear", "hwnd_valid", "game_connected", "internet_connected",
                "capture_healthy", "input_target_valid", "no_chest_exhaustion",
                "storage_not_full", "no_destructive_action_unresolved", "no_item_on_cursor",
                "no_duplicate_scheduler_owner", "runtime_not_running",
            ]
            # A claimed TEMPORARY_ACTION_LAG restart must still prove the same
            # non-committed transaction is safe immediately before Start.
            pending_category = ((self._pending or {}).get("pause_category") if isinstance(self._pending, dict) else None)
            if pending_category == "TEMPORARY_ACTION_LAG":
                required += ["action_lag_transaction_safe", "source_inventory_stable"]
            bad = [k for k in required if checks.get(k) is not True]
            if not self.auto_resume_enabled:
                bad.insert(0, "feature_enabled")
            if bad:
                return {"approved": False, "reason": bad[0].upper(), "failed_checks": bad, **self._snapshot_locked()}
            self._last_event = "AUTO_RESUME_CLAIM_VALID"
            return {"approved": True, "reason": "APPROVED", **self._snapshot_locked()}

    def consume_claim(self, *, claim_token: str, expected_generation: int):
        with self._lock:
            c = self._active_claim
            if not isinstance(c, dict):
                return {"approved": False, "reason": "NO_ACTIVE_AUTO_RESUME_CLAIM", **self._snapshot_locked()}
            if str(claim_token or "") != str(c.get("claim_token") or ""):
                return {"approved": False, "reason": "AUTO_RESUME_CLAIM_TOKEN_MISMATCH", **self._snapshot_locked()}
            if int(expected_generation) != int(self.resume_generation) or int(c.get("generation", -1)) != int(self.resume_generation):
                return {"approved": False, "reason": "RESUME_GENERATION_MISMATCH", **self._snapshot_locked()}
            if not self.auto_resume_enabled:
                return {"approved": False, "reason": "CHECKBOX_DISABLED", **self._snapshot_locked()}
            consumed_pending = dict(self._pending) if isinstance(self._pending, dict) else None
            self._pending = None
            self._active_claim = None
            self._last_event = "AUTO_RESUME_START_DISPATCHED"
            return {"approved": True, "reason": "APPROVED", "consumed_pending": consumed_pending, **self._snapshot_locked()}
