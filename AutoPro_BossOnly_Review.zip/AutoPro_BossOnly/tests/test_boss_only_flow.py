import unittest
from types import SimpleNamespace as NS
from unittest.mock import Mock
from boss_only_flow import BossOnlyFlow

class Harness(BossOnlyFlow):
    def __init__(self):
        self.config={'mode':'KEEP','ingame_auto_setup_confirmed':True}
        self.core=NS(window_exists=lambda h:True)
        self.api=NS(filter_runtime_guard=lambda *a,**k:{'ok':True})
        self.calls=[];self.cancel=False;self.counters={'cycles':0};self.running=True
        self._other_automation_busy=lambda:False
        self._cancelled=lambda:self.cancel
        self._new_cycle=lambda:NS(completed=False)
        self._ensure_player_bag_open_live=lambda *a:{'ok':True,'snapshot':{'cells':[{'row':0,'col':0,'occupied':False}]},'grid':{}}
        self._capacity_status=lambda s:{'status':'NOT_FULL'}
        self.bag_registry=NS(commit_baseline=lambda s:self.calls.append('baseline'))
        self._dispatch_key1_once=lambda *a:self.action('key1')
        self.loot=[{'cells':[[0,0]]}]
        self._wait_boss_and_autoloot_live_bag=lambda h:{'ok':True,'candidates':self.loot}
        self._autoboss_demerge_suspicious_candidates=lambda h,c,g:c
        self._build_loot_queue=lambda c,s,g:c
        self._process_loot=lambda *a:self.action('filter')
        self._postprocess_checkpoint=lambda h:self.action('checkpoint')
        self._set_state=lambda s:self.calls.append(s)
        self._focus_client=lambda h:{'ok':True}
        self._error=lambda *a:self.calls.append(('error',a[0]))
        self._set_running_flag=lambda v:None
        self.log_writer=NS(flush=lambda:None)
    def action(self,name):self.calls.append(name);return {'ok':True}

class FlowTests(unittest.TestCase):
    def test_single_cycle_order_without_routes_or_ctrl_f(self):
        h=Harness();h._run(12,True)
        self.assertEqual(h.calls,['baseline','key1','filter','checkpoint','BOSS_CYCLE_COMPLETE','SESSION_COMPLETE'])
        self.assertFalse(h.running)
    def test_empty_loot_stops_without_another_key(self):
        h=Harness();h.loot=[];h._run(12,False)
        self.assertEqual(h.calls.count('key1'),1)
        self.assertNotIn('filter',h.calls)
        self.assertIn(('error','NO_NEW_LOOT_CONFIRMED'),h.calls)
    def test_uncertain_filter_stops_continuous_loop(self):
        h=Harness();h._process_loot=lambda *a:{'ok':False,'reason':'FINAL6_UNRESOLVED'};h._run(12,False)
        self.assertEqual(h.calls.count('key1'),1)
        self.assertNotIn('checkpoint',h.calls)
    def test_old_cells_never_reach_filter(self):
        h=Harness();h.loot=[{'cells':[[1,1]]}];r=h._run_one_cycle(12)
        self.assertEqual(r['reason'],'NEW_ITEM_OVERLAPS_OLD_OR_UNCERTAIN_CELLS')
        self.assertNotIn('filter',h.calls)
    def test_cancel_before_key(self):
        h=Harness();h.cancel=True;r=h._run_one_cycle(12)
        self.assertEqual(r['reason'],'USER_STOP');self.assertNotIn('key1',h.calls)
    def test_no_navigation_required_but_confirmation_required(self):
        h=Harness();self.assertTrue(h._validate_start(12)['ok'])
        h.config['ingame_auto_setup_confirmed']=False
        self.assertFalse(h._validate_start(12)['ok'])
    def test_full_bag_prevents_key(self):
        h=Harness();h._capacity_status=lambda s:{'status':'FULL'}
        self.assertFalse(h._run_one_cycle(12)['ok']);self.assertNotIn('key1',h.calls)
