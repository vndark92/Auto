"""V1.7.16 offline integration/regression tests (no game or UI needed)."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from AutoProByEric_ClientOwnership_v1716 import ClientOwnership
from AutoProByEric_RunSafety_v1716 import background_start_gate
from AutoProByEric_MultiAccountLog_v1715 import MultiAccountLog


class InstanceCopyTests(unittest.TestCase):
    def test_copy_isolated_folder_without_recursive_instances(self):
        from tools.create_instance import create_instance
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'app'
            source.mkdir()
            (source / 'AutoProByEric_Stage17_LockedUI_v1_8.py').write_text('print("ok")')
            (source / 'input_tool.json').write_text('{"key":"F5"}')
            (source / 'autopro_runtime_config.json').write_text(json.dumps({
                'locked_client': 123, 'runtime': {'module_running': {'chest': True}},
                'input_mode': 'Foreground'}))
            (source / 'instances').mkdir()
            (source / 'instances' / 'oldacc').mkdir()
            (source / 'logs').mkdir()
            (source / 'logs' / 'secret.log').write_text('PRIVATE LOG')
            dest = create_instance(source, 'Acc02')
            self.assertTrue((dest / 'input_tool.json').exists())
            copied = json.loads((dest / 'autopro_runtime_config.json').read_text())
            self.assertIsNone(copied['locked_client'])
            self.assertEqual(copied['runtime']['module_running'], {})
            self.assertEqual(copied['input_mode'], 'Foreground')
            self.assertFalse((dest / 'instances').exists())
            self.assertFalse((dest / 'logs').exists())
            self.assertTrue((dest / 'INSTANCE_INFO.txt').exists())
            with self.assertRaises(FileExistsError): create_instance(source, 'Acc02')

    def test_invalid_instance_name_rejected(self):
        from tools.create_instance import create_instance
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp)
            (source / 'AutoProByEric_Stage17_LockedUI_v1_8.py').touch()
            for name in ('../outside','abc/def','bad name','x'*33,''):
                with self.subTest(name=name), self.assertRaises(ValueError):
                    create_instance(source, name)


class WindowOwnershipTests(unittest.TestCase):
    def test_same_window_rejected_second_instance(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = ClientOwnership(tmp, shared=False), ClientOwnership(tmp, shared=False)
            try:
                self.assertTrue(a.claim_client(101, 201)['ok'])
                r = b.claim_client(101, 201)
                self.assertFalse(r['ok'], r)
                self.assertEqual(r['reason'], 'OWNED_BY_ANOTHER_AUTOPRO_INSTANCE')
                # Another window may be reserved without sharing game HWND.
                self.assertTrue(b.claim_client(102, 202)['ok'])
                self.assertTrue(a.owns_client(101, 201))
            finally:
                a.close(); b.close()

    def test_lease_released_on_close(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = ClientOwnership(tmp, shared=False), ClientOwnership(tmp, shared=False)
            try:
                self.assertTrue(a.claim_client(12, 23)['ok'])
                self.assertFalse(b.claim_client(12, 23)['ok'])
                a.close()
                self.assertTrue(b.claim_client(12, 23)['ok'])
            finally:
                a.close(); b.close()

    def test_global_physical_exclusion(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = ClientOwnership(tmp, shared=False), ClientOwnership(tmp, shared=False)
            try:
                self.assertTrue(a.claim_physical_input()['ok'])
                self.assertEqual(b.claim_physical_input()['reason'], 'OWNED_BY_ANOTHER_AUTOPRO_INSTANCE')
                a.close()
                self.assertTrue(b.claim_physical_input()['ok'])
            finally:
                a.close(); b.close()

    def test_other_process_cannot_claim_until_release(self):
        with tempfile.TemporaryDirectory() as tmp:
            owner = ClientOwnership(tmp, shared=False)
            script = (
                'import sys,json; from AutoProByEric_ClientOwnership_v1716 import ClientOwnership;'
                ' c=ClientOwnership(sys.argv[1],shared=False);'
                ' r=c.claim_client(55,66); print(json.dumps(r)); c.close()'
            )
            def attempt():
                output = subprocess.check_output([sys.executable, '-c', script, tmp],
                                                 cwd=ROOT, text=True, timeout=8)
                return json.loads(output.strip())
            try:
                self.assertTrue(owner.claim_client(55,66)['ok'])
                self.assertFalse(attempt()['ok'])
                owner.close()
                self.assertTrue(attempt()['ok'])
            finally:
                owner.close()

    def test_invalid_hwnd_never_creates_lease(self):
        with tempfile.TemporaryDirectory() as tmp:
            mgr = ClientOwnership(tmp, shared=False)
            try:
                self.assertEqual(mgr.claim_client(0, 12)['reason'], 'INVALID_CLIENT_IDENTITY')
                self.assertFalse(list(mgr.root.iterdir()))
            finally: mgr.close()


class BackgroundGateTests(unittest.TestCase):
    def test_destructive_modes_refuse_unverified_background(self):
        for mode in ('CHEST', 'ROLL', 'BOSS'):
            with self.subTest(mode=mode):
                result = background_start_gate(mode, 'Background')
                self.assertFalse(result['ok'])
                self.assertTrue(result['safe_pause'])
        self.assertTrue(background_start_gate('CHEST', 'Foreground')['ok'])
        self.assertTrue(background_start_gate('ROLL', 'Auto')['ok'])
        self.assertTrue(background_start_gate('CAST', 'Background')['ok'])


class CastStartGateTests(unittest.TestCase):
    def test_hotkey_and_ui_both_go_through_guard(self):
        from unittest.mock import patch
        import AutoProByEric_InputTool_v1 as mod
        calls = []
        def guard(hwnd):
            calls.append(hwnd)
            return {'ok': False, 'reason': 'OWNED_BY_ANOTHER_AUTOPRO_INSTANCE'}
        with tempfile.TemporaryDirectory() as folder, \
                patch.object(mod, 'CONFIG_PATH', Path(folder)/'input_tool.json'), \
                patch.object(mod.InputToolController, '_start_hotkey_thread', lambda self: None):
            ctl = mod.InputToolController(lambda h,k: {'ok': True}, lambda: 123, lambda: True, start_guard=guard)
            try:
                response = ctl.start(0)  # Same path used by the F10 global hotkey.
                self.assertFalse(response['ok'])
                self.assertEqual(response['reason'], 'OWNED_BY_ANOTHER_AUTOPRO_INSTANCE')
                self.assertEqual(calls, [123])
                self.assertFalse(ctl.status()['running'])
            finally:
                ctl.shutdown()

class AccountLogTests(unittest.TestCase):
    def test_alias_scoped_to_window_and_safe_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = MultiAccountLog(tmp, session_pid=1, session_nonce='a')
            log.append(10, 20, 'Game window 1', 'INFO', 'one')
            log.append(11, 21, 'Game window 2', 'INFO', 'two')
            self.assertEqual(log.set_alias('20:10', 'Acc chính')['alias'], 'Acc chính')
            accounts = {x['id']:x for x in log.recent()['accounts']}
            self.assertEqual(accounts['20:10']['alias'], 'Acc chính')
            self.assertEqual(accounts['21:11']['alias'], '')
            with self.assertRaises(ValueError):
                log.set_alias('../../example', 'bad')

    def test_quiet_account_remains_in_account_selector(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = MultiAccountLog(tmp, session_pid=1, session_nonce='a')
            log.append(1, 10, 'Quiet client', 'INFO', 'old event')
            for i in range(80): log.append(2, 20, 'Busy client', 'ACTION', str(i))
            result = log.recent(limit=12)
            self.assertEqual(len(result['events']), 12)
            self.assertEqual({r['id'] for r in result['accounts']}, {'10:1','20:2'})

    def test_presence_independent_of_log_and_no_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            a = MultiAccountLog(tmp, session_pid=12, session_nonce='one')
            b = MultiAccountLog(tmp, session_pid=13, session_nonce='two')
            a.publish_presence(21, 31, 'Client main', ['CHEST'], False, True)
            b.publish_presence(22, 32, 'Client secondary', [], True, True)
            snap = a.recent(limit=10)
            self.assertEqual(len(snap['events']), 0)
            self.assertEqual({s['account_id'] for s in snap['presence']}, {'31:21', '32:22'})
            self.assertEqual({x['id'] for x in snap['accounts']}, {'31:21', '32:22'})
            self.assertEqual({s['account_id']:s['active_modes'] for s in snap['presence']}['31:21'], ['CHEST'])

    def test_stale_presence_expires(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = MultiAccountLog(tmp, session_pid=1, session_nonce='stale')
            log.publish_presence(2, 3, 'game')
            path = log.root / 'presence' / 'instance_1_stale.json'
            info = json.loads(path.read_text(encoding='utf8'))
            info['last_seen_epoch'] = 1.0
            path.write_text(json.dumps(info), encoding='utf8')
            self.assertFalse(log.presence_snapshot(ttl_seconds=90))

    def test_bounded_rotation_keeps_last_three_archives(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = MultiAccountLog(tmp, session_pid=1, session_nonce='a', max_bytes=4096)
            for i in range(160): log.append(15, 25, 'Busy', 'INFO', 'x' * 250)
            path=log._path(15)
            self.assertTrue(path.exists())
            for i in (1,2,3): self.assertTrue(Path(str(path)+'.'+str(i)).exists())
            self.assertLessEqual(len(list(log.root.glob('events_*'))), 4)
            recent=log.recent(limit=25)
            self.assertTrue(recent['events'])
            self.assertEqual({x['account_id'] for x in recent['events']},{'25:15'})


if __name__ == '__main__':
    unittest.main()
