"""Replay the bundled (partially duplicated!) holdout, not an in-game benchmark."""
from collections import Counter
from pathlib import Path
from PIL import Image
import json, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from AutoProByEric_ClosedWorldOptionVision_v1 import ClosedWorldOptionVisionEngine
reg=json.loads((ROOT/'Data/golden_option_visual_registry.json').read_text(encoding='utf-8'))
rows=[(entry['option_id'],proto) for entry in reg['entries'] for proto in entry.get('visual_prototypes',[]) if proto.get('split')=='holdout']
# This file is an artifact of the original audit, not a runtime dependency.
audit=ROOT/'tests'/'baseline_holdout_results.json'
previous=(json.loads(audit.read_text())['results'] if audit.exists() else [])
print('Holdout rows:',len(rows),'Existing audit rows:',len(previous))
if len(previous)!=len(rows) or any(x[0]!=prev['expected_id'] for x,prev in zip(rows,previous)):
 print('Could not align audit OCR evidence to the registry; fallback to empty OCR.')
 previous=[]
engine=ClosedWorldOptionVisionEngine(ROOT)
results=[]
for i,(expected, proto) in enumerate(rows):
 ocr=previous[i].get('ocr','') if previous else ''
 out=engine.classify_row(Image.open(ROOT/proto['source_row_copy']),ocr_text=ocr)
 pred=out['canonical_option_id']
 results.append({'expected':expected,'predicted':pred,'state':out['identity_state'],'correct':pred==expected and out['identity_authoritative'],
                 'false_confirmed':bool(out['identity_authoritative'] and pred!=expected)})
counts=Counter(r['state'] for r in results)
print('States:',dict(counts))
print('Confirmed correct:',sum(r['correct'] for r in results),'false-confirmed:',sum(r['false_confirmed'] for r in results))
print('False-confirmed examples:',[r for r in results if r['false_confirmed']][:12])
(ROOT/'tests'/'benchmark_holdout_result.json').write_text(json.dumps({'samples':len(results),'counts':dict(counts),'correct_confirmed':sum(r['correct'] for r in results),'false_confirmed':sum(r['false_confirmed'] for r in results),'results':results},ensure_ascii=False,indent=2))
