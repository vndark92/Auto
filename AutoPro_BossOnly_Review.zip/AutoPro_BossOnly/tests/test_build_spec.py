import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from tools import build_windows_onefile as builder

class SpecTests(unittest.TestCase):
    def test_large_unicode_payload_uses_spec_and_retains_collects(self):
        with tempfile.TemporaryDirectory(prefix='Auto Việt ') as tmp:
            root=Path(tmp)
            paths=[root/'Data'/f'ảnh {i}.png' for i in range(600)]
            with patch.object(builder,'ROOT',root):
                spec=builder.write_spec(paths,root/'onefile_payload_manifest.json')
            calls=[]
            def collect_all(name, filter_submodules):
                self.assertFalse(filter_submodules("paddle.jit.sot"))
                self.assertFalse(filter_submodules("paddle.jit.sot.symbolic"))
                self.assertTrue(filter_submodules("paddle.inference"))
                self.assertTrue(filter_submodules("paddle.jit.api"))
                calls.append(name)
                return [],[],[]
            import types,sys
            hooks=types.ModuleType('PyInstaller.utils.hooks');hooks.collect_all=collect_all
            analysis=[]
            def analyze(*args,**kwargs):
                analysis.append((args,kwargs))
                return types.SimpleNamespace(pure=[],scripts=[],binaries=[],datas=kwargs['datas'])
            namespace={'Analysis':analyze,'PYZ':lambda x:x,'EXE':lambda *a,**k:None}
            with patch.dict(sys.modules,{'PyInstaller.utils.hooks':hooks}):
                exec(compile(spec.read_text(),str(spec),'exec'),namespace)
            self.assertEqual(len(analysis[0][1]['datas']),601)
            self.assertIn((str(paths[0]),'Data'),analysis[0][1]['datas'])
            self.assertEqual(calls,['webview','paddleocr','paddle','cv2','pythonnet','win32com'])
            self.assertIn('win32gui',analysis[0][1]['hiddenimports'])
