from __future__ import annotations
import importlib.util
import json
import hashlib
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

SCRIPT = Path(__file__).resolve().parent.parent / 'tools' / 'onefile_launcher.py'
spec = importlib.util.spec_from_file_location('onefile_launcher', SCRIPT)
launch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launch)

class OnefileTest(unittest.TestCase):
    def test_per_exe_profile_is_stable_and_isolated(self):
        with TemporaryDirectory() as d:
            root=Path(d)
            x=launch.app_dir(root/'acc1.exe',root)
            y=launch.app_dir(root/'acc2.exe',root)
            self.assertNotEqual(x,y)
            self.assertEqual(x,launch.app_dir(root/'acc1.exe',root))

    def prepare(self, root, files):
        src=root/'bundle'; src.mkdir()
        records=[]
        for k,(content,mutable) in files.items():
            p=src/k; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(content)
            records.append({'path':k, 'sha256':hashlib.sha256(content).hexdigest(), 'mutable':mutable})
        (src/launch.MANIFEST).write_text(json.dumps({'version':launch.VERSION,'files':records}),encoding='utf-8')
        return src

    def test_initial_unpack_and_no_config_overwrite(self):
        with TemporaryDirectory() as d:
            root=Path(d)
            bundle=self.prepare(root,{'main.py':(b'new',False),'input_tool.json':(b'{}',True)})
            profile=root/'profile'
            launch.stage_payload(bundle,profile)
            (profile/'input_tool.json').write_text('{"changed":true}',encoding='utf-8')
            (profile/'main.py').write_bytes(b'wrong')
            launch.stage_payload(bundle,profile)
            self.assertEqual((profile/'input_tool.json').read_text(),'{"changed":true}')
            self.assertEqual((profile/'main.py').read_bytes(),b'new')

    def test_integrity_check_rejects_corrupt_source(self):
        with TemporaryDirectory() as d:
            root=Path(d)
            b=self.prepare(root,{'main.py':(b'ok',False)})
            (b/'main.py').write_bytes(b'changed')
            with self.assertRaisesRegex(RuntimeError,'checksum mismatch'):
                launch.stage_payload(b,root/'profile')

    def test_path_traversal_rejected(self):
        with TemporaryDirectory() as d:
            root=Path(d); b=root/'bundle'; b.mkdir()
            (b/launch.MANIFEST).write_text(json.dumps({'version':launch.VERSION,'files':[{'path':'../escape.py','sha256':'a'}]}))
            with self.assertRaisesRegex(RuntimeError,'Unsafe embedded'):
                launch.stage_payload(b,root/'profile')

if __name__=='__main__': unittest.main()
