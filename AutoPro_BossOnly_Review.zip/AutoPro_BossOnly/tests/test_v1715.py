"""Offline regression tests. Run: python -m unittest discover -s tests -v"""
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from AutoProByEric_ConfigStore_v1715 import save_json, load_json
from AutoProByEric_MultiAccountLog_v1715 import MultiAccountLog
from AutoProByEric_ClosedWorldOptionVision_v1 import _ocr_secondary_canonical_hint, ClosedWorldOptionVisionEngine


class ConfigTests(unittest.TestCase):
    def test_backup_restores_corrupt_json(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'settings.json'
            save_json(path,{'mode':'A'});save_json(path,{'mode':'B'})
            path.write_text('{invalid',encoding='utf8')
            notices=[]
            self.assertEqual(load_json(path,on_recovery=lambda *a: notices.append(a)),{'mode':'A'})
            self.assertTrue(notices)
            self.assertEqual(load_json(path),{'mode':'A'})

    def test_no_corrupt_backup_promotion(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'settings.json'
            save_json(path,{'value':1});save_json(path,{'value':2})
            path.write_text('{invalid',encoding='utf8')
            save_json(path,{'value':3})
            self.assertEqual(load_json(path.with_name(path.name+'.bak')),{'value':1})


class MultiAccountTests(unittest.TestCase):
    def test_multi_session_separation_and_filter(self):
        with tempfile.TemporaryDirectory() as folder:
            a=MultiAccountLog(folder,session_pid=200,session_nonce='A')
            b=MultiAccountLog(folder,session_pid=201,session_nonce='B')
            a.append(321,1000,'Acc 1','INFO','Started')
            a.append(322,2000,'Acc 2','ACTION','ROLL_START',{'ok':True})
            b.append(321,1000,'Acc 1','INFO','Other instance')
            all_=a.recent(limit=20)
            self.assertEqual(len(all_['events']),3)
            self.assertEqual({e['account_id'] for e in all_['events']},{'1000:321','2000:322'})
            filtered=a.recent(selected_account='2000:322',limit=20)
            self.assertEqual([e['message'] for e in filtered['events']],['ROLL_START'])

    def test_log_rotation(self):
        with tempfile.TemporaryDirectory() as folder:
            obj=MultiAccountLog(folder,session_pid=201,session_nonce='small',max_bytes=4096)
            for i in range(60): obj.append(1,2000,'Acc','INFO',str(i) * 50)
            self.assertTrue(list((Path(folder)/'accounts').glob('*.jsonl.1')))


class OCRTests(unittest.TestCase):
    def test_strict_resource_canonical_hint(self):
        examples={'Sinh lực tối đa +15%':'sinh_luc_toi_a',
                  'Nội lực tối đa +123':'noi_luc_toi_a',
                  'Thể lực tối đa +123':'the_luc_toi_a',
                  '| Néi luc téi da: +457 diém =.':None,
                  'Lực tối đa +457':None,
                  'Sinh nội lực tối đa +222':None}
        for text, expected in examples.items():
            with self.subTest(text=text):
                self.assertEqual(_ocr_secondary_canonical_hint(text), expected)

    def test_original_wrong_holdout_no_false_confirmation(self):
        from PIL import Image
        reg=json.loads((ROOT/'Data/golden_option_visual_registry.json').read_text(encoding='utf-8'))
        entry=next(x for x in reg['entries'] if x['option_id']=='noi_luc_toi_a')
        row=next(x for x in entry['visual_prototypes'] if x['mask_path'].endswith('noi_luc_toi_a_08.png'))
        engine=ClosedWorldOptionVisionEngine(ROOT)
        result=engine.classify_row(Image.open(ROOT/row['source_row_copy']),ocr_text='| Néi luc téi da: +457 diém =.')
        self.assertFalse(result['identity_authoritative'],result)
        self.assertNotEqual(result['canonical_option_id'],'sinh_luc_toi_a',result)


if __name__ == '__main__': unittest.main()

class LogLifecycleTests(unittest.TestCase):
    def test_unlink_symlink_without_following(self):
        import os
        from AutoProByEric_LogLifecycleManager_v1 import LogLifecycleManager
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder)
            logs=base/'logs';logs.mkdir()
            outside=base/'outside.txt';outside.write_text('must survive')
            link=logs/'outside-link'
            try:
                os.symlink(outside,link)
            except (OSError, NotImplementedError):
                self.skipTest('symlink not available')
            result=LogLifecycleManager(logs).clear_all_logs()
            self.assertTrue(result['ok'],result)
            self.assertFalse(link.is_symlink())
            self.assertEqual(outside.read_text(),'must survive')

class InputToolTests(unittest.TestCase):
    def test_skipped_inventory_key_does_not_count_as_sent(self):
        from unittest.mock import patch
        import AutoProByEric_InputTool_v1 as mod
        calls=[]
        def sender(hwnd,key):
            calls.append(key)
            return {'ok':True,'skipped':True} if key=='F4' else {'ok':True}
        with tempfile.TemporaryDirectory() as folder, patch.object(mod,'CONFIG_PATH',Path(folder)/'input_tool.json'),patch.object(mod.InputToolController,'_start_hotkey_thread',lambda self:None):
            ctl=mod.InputToolController(sender,lambda:123,lambda:True)
            try:
                self.assertTrue(ctl.save_config({'selected_keys':['F4','F5'],'continuous':False,'delay_ms':50})['ok'])
                ctl.start(123)
                ctl._thread.join(timeout=2)
                status=ctl.status()
                self.assertEqual(calls,['F4','F5'])
                self.assertEqual(status['sent_count'],1)
                self.assertEqual(status['skipped_count'],1)
                self.assertFalse(status['running'])
            finally:
                ctl.shutdown()

class InputPolicyTests(unittest.TestCase):
    def test_reserved_only_during_conflicting_auto(self):
        from AutoProByEric_InputPolicy_v1715 import reserve_inventory_hotkey
        self.assertTrue(reserve_inventory_hotkey('F4','F4',['CHEST']))
        self.assertTrue(reserve_inventory_hotkey('F4','F4',['ROLL']))
        self.assertTrue(reserve_inventory_hotkey('F4','F4',['BOSS']))
        self.assertFalse(reserve_inventory_hotkey('F5','F4',['CHEST']))
        self.assertFalse(reserve_inventory_hotkey('F4','F4',[]))
        self.assertFalse(reserve_inventory_hotkey('F4','Q',['CHEST']))
