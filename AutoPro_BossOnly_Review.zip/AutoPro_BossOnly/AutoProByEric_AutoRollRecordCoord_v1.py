from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict, field
from enum import Enum
import copy
import ctypes
import hashlib
import json
import math
import queue
import statistics
import threading
import time
import traceback
import uuid
import weakref

import numpy as np
import cv2

BUILD_ID = 'AutoProByEric_V12.11_AutoRoll_V1.7.14E_PostPopupOriginalBagItemReadRootfix'
CONFIG_SCHEMA_VERSION = 8
MAX_ITEMS = 5
ROLL_WAIT_SECONDS = 4.0
ROLL_WAIT_NS = 4_000_000_000
POINT_KEYS = tuple([f'item{i}' for i in range(1, MAX_ITEMS + 1)] + [
    'material', 'item_slot', 'material_slot', 'roll_button', 'popup'
])
REQUIRED_FULL = ('material', 'item_slot', 'material_slot', 'roll_button', 'popup')
_GLOBAL_POINTER_LEASE = threading.RLock()
_OWNER_REGISTRY_LOCK = threading.RLock()
_OWNER_REGISTRY: Dict[str, weakref.ReferenceType] = {}


class RuntimeOwnerRegistry:
    @staticmethod
    def register(name: str, obj):
        with _OWNER_REGISTRY_LOCK:
            ref = _OWNER_REGISTRY.get(str(name))
            live = ref() if ref else None
            if live is not None and live is not obj:
                raise RuntimeError('DUPLICATE_AUTOROLL_OWNER_FATAL:' + str(name))
            _OWNER_REGISTRY[str(name)] = weakref.ref(obj)

    @staticmethod
    def release(name: str, obj):
        with _OWNER_REGISTRY_LOCK:
            ref = _OWNER_REGISTRY.get(str(name))
            if ref and ref() is obj:
                _OWNER_REGISTRY.pop(str(name), None)



def _sha256_file(path: Path) -> Optional[str]:
    try:
        h = hashlib.sha256()
        with Path(path).open('rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None


def _gray_patch_signature(image, point, radius=13, size=16):
    if image is None or not point:
        return []
    arr = np.asarray(image.convert('RGB'))
    h, w = arr.shape[:2]
    x, y = int(point[0]), int(point[1])
    r = max(6, int(radius))
    x0, x1 = max(0, x-r), min(w, x+r+1)
    y0, y1 = max(0, y-r), min(h, y+r+1)
    crop = arr[y0:y1, x0:x1]
    if crop.size == 0:
        return []
    gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
    small = cv2.resize(gray, (size, size), interpolation=cv2.INTER_AREA)
    return small.astype(np.uint8).reshape(-1).tolist()


def _sig_mae(a, b):
    if not a or not b or len(a) != len(b):
        return 255.0
    aa = np.asarray(a, dtype=np.float32)
    bb = np.asarray(b, dtype=np.float32)
    return float(np.mean(np.abs(aa - bb)))


def _slot_features(image, point, radius=16):
    """Semantic-ish visual class features; MAE is diagnostic only, not sole truth."""
    if image is None or not point:
        return None
    arr = np.asarray(image.convert('RGB'))
    h, w = arr.shape[:2]
    x, y = int(point[0]), int(point[1])
    r = max(8, int(radius))
    x0, x1 = max(0, x-r), min(w, x+r+1)
    y0, y1 = max(0, y-r), min(h, y+r+1)
    crop = arr[y0:y1, x0:x1]
    if crop.size == 0:
        return None
    gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 50, 120)
    center = gray[max(0, gray.shape[0]//4):max(1, 3*gray.shape[0]//4),
                  max(0, gray.shape[1]//4):max(1, 3*gray.shape[1]//4)]
    hist = cv2.calcHist([gray], [0], None, [32], [0, 256]).reshape(-1)
    hist = hist / max(1.0, float(hist.sum()))
    nz = hist[hist > 0]
    entropy = float(-(nz * np.log2(nz)).sum()) if nz.size else 0.0
    return {
        'mean': float(gray.mean()),
        'std': float(gray.std()),
        'center_std': float(center.std()) if center.size else 0.0,
        'edge_density': float((edges > 0).mean()),
        'dark_ratio': float((gray < 70).mean()),
        'bright_ratio': float((gray > 180).mean()),
        'entropy': entropy,
        'signature': _gray_patch_signature(image, point, radius=radius, size=16),
    }


def _slot_transition_evidence(before, after, stable_frames=1):
    if not before or not after:
        return {'committed': False, 'state': 'UNRESOLVED', 'signals': {}}
    signals = {
        'texture_delta': abs(float(after['std']) - float(before['std'])),
        'center_texture_delta': abs(float(after['center_std']) - float(before['center_std'])),
        'edge_delta': abs(float(after['edge_density']) - float(before['edge_density'])),
        'dark_delta': abs(float(after['dark_ratio']) - float(before['dark_ratio'])),
        'bright_delta': abs(float(after['bright_ratio']) - float(before['bright_ratio'])),
        'entropy_delta': abs(float(after['entropy']) - float(before['entropy'])),
        'signature_mae': _sig_mae(before.get('signature'), after.get('signature')),
    }
    votes = 0
    votes += signals['texture_delta'] >= 1.2
    votes += signals['center_texture_delta'] >= 1.2
    votes += signals['edge_delta'] >= 0.012
    votes += signals['dark_delta'] >= 0.025
    votes += signals['bright_delta'] >= 0.025
    votes += signals['entropy_delta'] >= 0.08
    # signature is secondary evidence; it cannot prove commit alone.
    signature_support = signals['signature_mae'] >= 4.0
    committed = bool(votes >= 2 or (votes >= 1 and signature_support and stable_frames >= 2))
    return {
        'committed': committed,
        'state': 'OCCUPANCY_TRANSITION_CONFIRMED' if committed else 'NO_SEMANTIC_OCCUPANCY_TRANSITION',
        'semantic_votes': int(votes),
        'signature_support': bool(signature_support),
        'signals': {k: round(float(v), 5) for k, v in signals.items()},
    }


class FilterVerdict(str, Enum):
    ACCEPT = 'ACCEPT'
    REJECT = 'REJECT'
    UNRESOLVED = 'UNRESOLVED'


class InventoryOutcome(str, Enum):
    ALREADY_VISIBLE = 'INVENTORY_ALREADY_VISIBLE'
    OPENED = 'INVENTORY_OPENED_SUCCESSFULLY'
    REACQUIRED = 'INVENTORY_REACQUIRED'
    TEMP_OCCLUDED = 'INVENTORY_TEMPORARILY_OCCLUDED'
    GRID_NOT_FOUND = 'INVENTORY_GRID_NOT_FOUND'
    HOTKEY_FAILED = 'INVENTORY_HOTKEY_FAILED'
    CLIENT_NOT_READY = 'CLIENT_NOT_READY'


@dataclass
class ErrorEnvelope:
    error_code: str
    source_component: str
    source_state: str
    session_id: Optional[str]
    queue_id: Optional[str] = None
    attempt_id: Optional[str] = None
    recoverable: bool = False
    exception_type: Optional[str] = None
    exception_message: Optional[str] = None
    traceback_hash: Optional[str] = None
    evidence_id: Optional[str] = None
    last_event_seq: int = 0
    detail: Dict[str, Any] = field(default_factory=dict)


@dataclass
class InventoryAcquireResult:
    ok: bool
    outcome: InventoryOutcome
    image: Any = None
    grid: Dict[str, Any] = field(default_factory=dict)
    detail: Dict[str, Any] = field(default_factory=dict)


@dataclass
class InteractionTarget:
    target_type: str
    center: List[int]
    safe_rect: List[int]
    coordinate_space: str = 'CLIENT'
    recorded_client_size: List[int] = field(default_factory=list)
    inset_margin: int = 2

    @classmethod
    def client(cls, target_type: str, point: List[int], safe_radius: int = 8,
               recorded_client_size: Optional[List[int]] = None):
        x, y = int(point[0]), int(point[1])
        r = max(4, int(safe_radius))
        return cls(target_type, [x, y], [x-r, y-r, x+r, y+r], 'CLIENT',
                   list(recorded_client_size or []), 2)

    @classmethod
    def screen(cls, target_type: str, point: List[int], safe_radius: int = 8):
        x, y = int(point[0]), int(point[1])
        r = max(4, int(safe_radius))
        return cls(target_type, [x, y], [x-r, y-r, x+r, y+r], 'SCREEN', [], 2)


@dataclass
class FilterEvaluationResult:
    evidence_id: str
    queue_id: str
    generation: int
    profile_results: List[Dict[str, Any]]
    verdict: FilterVerdict
    scoped_result: Dict[str, Any] = field(default_factory=dict)
    reason: Optional[str] = None


@dataclass
class CurrentRollItemIdentity:
    session_id: str
    queue_id: str
    logical_item_id: str
    source_kind: str
    original_grid_anchor: List[int]
    current_grid_anchor: List[int]
    selection_cell_offset: List[int]
    footprint: List[int]
    item_category: str
    visual_signature: List[int]
    original_client_point: List[int]
    current_client_point: List[int]
    cell_offset_px: List[int]
    observation_generation: int = 0
    roll_attempt: int = 0
    completed: bool = False
    status: str = 'PENDING'
    identity_confidence: str = 'CONFIGURED_POINT_LOCK'
    current_owner: str = 'PLAYER_BAG'  # PLAYER_BAG | ROLL_ITEM_SLOT

    @property
    def item_id(self) -> str:
        return self.logical_item_id


@dataclass
class RollAttemptContext:
    session_id: str
    queue_id: str
    logical_item_id: str
    attempt_id: str
    attempt_generation: int
    event_seq_start: int
    status: str = 'BEGIN_ATTEMPT'
    material_identity: Optional[str] = None
    roll_trigger_event_seq: Optional[int] = None
    result_evidence_id: Optional[str] = None
    filter_verdict: Optional[str] = None
    popup_dismissed: bool = False


@dataclass
class CanonicalEvent:
    event_seq: int
    session_id: str
    session_generation: int
    queue_id: Optional[str]
    attempt_id: Optional[str]
    attempt_generation: int
    event_type: str
    state: str
    monotonic_ns: int
    payload: Dict[str, Any]


class SessionCancellationToken:
    def __init__(self):
        self._lock = threading.Lock()
        self.generation = 0
        self.cancelled = False
        self.reason = None

    def reset(self):
        with self._lock:
            self.generation += 1
            self.cancelled = False
            self.reason = None
            return self.generation

    def cancel(self, reason='USER_STOP'):
        with self._lock:
            self.generation += 1
            self.cancelled = True
            self.reason = str(reason or 'USER_STOP')
            return self.generation

    def snapshot(self):
        with self._lock:
            return int(self.generation), bool(self.cancelled), self.reason

    def is_valid(self, generation: int) -> bool:
        with self._lock:
            return (not self.cancelled) and int(generation) == int(self.generation)


class AsyncJsonlLogWriter:
    """Non-blocking buffered JSONL writer for AutoRoll hot-path telemetry/domain logs."""
    def __init__(self, path: Path, max_queue: int = 8192):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.q = queue.Queue(maxsize=max(256, int(max_queue)))
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True, name='AutoRollAsyncLogWriter')
        self._thread.start()

    def submit(self, payload: Dict[str, Any]):
        line = json.dumps(payload, ensure_ascii=False, default=str) + '\n'
        try:
            self.q.put_nowait(line)
        except queue.Full:
            # Preserve critical audit data instead of dropping it under extreme pressure.
            try:
                with self.path.open('a', encoding='utf-8') as f:
                    f.write(line)
            except Exception:
                pass

    def _run(self):
        try:
            with self.path.open('a', encoding='utf-8', buffering=64 * 1024) as f:
                pending = 0
                last_flush = time.monotonic()
                while not self._stop.is_set() or not self.q.empty():
                    try:
                        line = self.q.get(timeout=0.10)
                    except queue.Empty:
                        line = None
                    if line is not None:
                        f.write(line); pending += 1; self.q.task_done()
                    now = time.monotonic()
                    if pending and (pending >= 64 or now - last_flush >= 0.25 or (self._stop.is_set() and self.q.empty())):
                        f.flush(); pending = 0; last_flush = now
                if pending:
                    f.flush()
        except Exception:
            pass

    def flush(self):
        try:
            self.q.join()
        except Exception:
            pass

    def close(self):
        self._stop.set()
        try:
            self.q.join()
        except Exception:
            pass
        if self._thread.is_alive():
            self._thread.join(timeout=1.0)


class AutoRollEventLedger:
    """The only canonical domain-event owner. Timestamps are metadata only."""
    def __init__(self, writer: Callable[[Dict[str, Any]], None]):
        self._writer = writer
        self._lock = threading.Lock()
        self._seq = 0
        self._events: List[CanonicalEvent] = []
        self._once_keys = set()

    @property
    def last_seq(self):
        with self._lock:
            return int(self._seq)

    def reset(self):
        with self._lock:
            self._seq = 0
            self._events = []
            self._once_keys = set()

    def emit(self, *, session_id: str, session_generation: int, queue_id: Optional[str],
             attempt_id: Optional[str], attempt_generation: int, event_type: str,
             state: str, payload: Optional[Dict[str, Any]] = None,
             once_key: Optional[str] = None) -> CanonicalEvent:
        with self._lock:
            if once_key and once_key in self._once_keys:
                raise RuntimeError('DUPLICATE_DOMAIN_EVENT:' + str(once_key))
            if once_key:
                self._once_keys.add(once_key)
            self._seq += 1
            ev = CanonicalEvent(
                event_seq=self._seq,
                session_id=str(session_id or ''),
                session_generation=int(session_generation or 0),
                queue_id=queue_id,
                attempt_id=attempt_id,
                attempt_generation=int(attempt_generation or 0),
                event_type=str(event_type),
                state=str(state),
                monotonic_ns=time.monotonic_ns(),
                payload=dict(payload or {}),
            )
            self._events.append(ev)
        self._writer({'record_type': 'DOMAIN_EVENT', **asdict(ev)})
        return ev

    def events_for_attempt(self, attempt_id: str) -> List[CanonicalEvent]:
        with self._lock:
            return [e for e in self._events if e.attempt_id == attempt_id]

    def all_events(self) -> List[CanonicalEvent]:
        with self._lock:
            return list(self._events)


class RollAttemptInvariantValidator:
    """Validates explicit FSM/event_seq, never clock ordering.

    V1.6.3 contract:
    - Roll/material/filter/commit events are exactly-once per attempt.
    - CURRENT_ITEM_REACQUIRE_* is a repeatable recovery transaction.
      A weak Final6 read may legitimately reacquire the SAME item several times
      inside one Roll attempt before a fresh Final6 becomes authoritative.
    """
    EXACTLY_ONCE_PREFIX = (
        'ATTEMPT_BEGIN', 'ITEM_PLACED', 'MATERIAL_PLACED', 'ROLL_TRIGGERED',
        'ROLL_WAIT_START', 'ROLL_WAIT_COMPLETE', 'POPUP_DISMISS_SENT',
        'FINAL6_RESOLVED',
    )
    REPEATABLE_REACQUIRE = (
        'CURRENT_ITEM_REACQUIRE_START', 'CURRENT_ITEM_REACQUIRED',
    )

    def validate(self, events: List[CanonicalEvent], verdict: FilterVerdict):
        names = [e.event_type for e in events]
        verdict_event = 'FILTER_ACCEPT' if verdict == FilterVerdict.ACCEPT else 'FILTER_REJECT'
        exact = list(self.EXACTLY_ONCE_PREFIX) + [verdict_event, 'ATTEMPT_COMMITTED']

        missing = [x for x in exact if x not in names]
        for x in self.REPEATABLE_REACQUIRE:
            if x not in names:
                missing.append(x)

        duplicates = [x for x in exact if names.count(x) != 1]

        starts = [e for e in events if e.event_type == 'CURRENT_ITEM_REACQUIRE_START']
        dones = [e for e in events if e.event_type == 'CURRENT_ITEM_REACQUIRED']
        reacquire_errors = []

        # Every successful reacquire must have a preceding START. Failed
        # perception reacquires are allowed to have START without DONE.
        si = 0
        for done in dones:
            while si < len(starts) and int(starts[si].event_seq) < int(done.event_seq):
                si += 1
                break
            else:
                reacquire_errors.append({
                    'reason':'REACQUIRED_WITHOUT_PRECEDING_START',
                    'done_seq':done.event_seq,
                })

        by_type = {}
        for e in events:
            by_type.setdefault(e.event_type, []).append(int(e.event_seq))

        seqs = []
        ordered_types = [
            'ATTEMPT_BEGIN','ITEM_PLACED','MATERIAL_PLACED','ROLL_TRIGGERED',
            'ROLL_WAIT_START','ROLL_WAIT_COMPLETE','POPUP_DISMISS_SENT'
        ]
        for x in ordered_types:
            if by_type.get(x):
                seqs.append((x, by_type[x][0]))

        if starts:
            seqs.append(('CURRENT_ITEM_REACQUIRE_START_FIRST', int(starts[0].event_seq)))
        if dones:
            seqs.append(('CURRENT_ITEM_REACQUIRED_LAST', int(dones[-1].event_seq)))

        for x in ['FINAL6_RESOLVED', verdict_event, 'ATTEMPT_COMMITTED']:
            if by_type.get(x):
                seqs.append((x, by_type[x][0]))

        reversed_pairs = []
        for (a, sa), (b, sb) in zip(seqs, seqs[1:]):
            if not int(sa) < int(sb):
                reversed_pairs.append({'a':a,'a_seq':sa,'b':b,'b_seq':sb})

        return {
            'ok': not missing and not duplicates and not reversed_pairs and not reacquire_errors,
            'order_truth':'EVENT_SEQ',
            'missing':missing,
            'duplicates_or_missing_once':duplicates,
            'reacquire_start_count':len(starts),
            'reacquire_success_count':len(dones),
            'reacquire_errors':reacquire_errors,
            'reversed_pairs':reversed_pairs,
            'event_seq':seqs,
        }


class RollItemQueue:
    """The only RollItemQueue/current-item owner."""
    def __init__(self):
        self.items: List[CurrentRollItemIdentity] = []
        self.index = -1
        self._lock = threading.RLock()

    def reset(self):
        with self._lock:
            self.items = []
            self.index = -1

    def load(self, items: List[CurrentRollItemIdentity]):
        with self._lock:
            self.items = list(items)
            self.index = -1

    def activate(self, index: int):
        with self._lock:
            if not (0 <= int(index) < len(self.items)):
                return None
            self.index = int(index)
            item = self.items[self.index]
            item.status = 'ACTIVE'
            return item

    def current(self):
        with self._lock:
            if 0 <= self.index < len(self.items):
                return self.items[self.index]
            return None

    def mark_done(self, queue_id: str):
        with self._lock:
            cur = self.current()
            if cur is None or cur.queue_id != queue_id:
                raise RuntimeError('QUEUE_CURRENT_IDENTITY_MISMATCH')
            if cur.completed or cur.status == 'DONE':
                raise RuntimeError('EXACTLY_ONCE_COMPLETION_VIOLATION')
            cur.completed = True
            cur.status = 'DONE'
            return cur


class AutoRollInputPacing:
    PROFILE_NAME = 'GENTLE_SAFE_20PCT_SLOWER'
    ACTION_TIME_SCALE = 1.20
    ACTION_TIME_KEYS = {
        'move_duration_ms',
        'pre_click_settle_ms',
        'post_click_settle_ms',
        'focus_settle_ms',
        'focus_activation_settle_ms',
        'pick_confirm_timeout_ms',
        'slot_confirm_timeout_ms',
        'retry_delay_ms',
        'verify_poll_ms',
        'tooltip_hover_settle_ms',
        'reader_reread_delay_ms',
        'mouse_down_dwell_ms',
        'focus_click_settle_ms',
    }
    DEFAULTS = {
        # Stored/configured values remain the V1.6.7/V1.7.1 baseline.
        # ms() applies ACTION_TIME_SCALE at runtime so existing user configs
        # are also slowed by exactly 20% without destructive config migration.
        'move_duration_ms': 10,
        'pre_click_settle_ms': 25,
        'post_click_settle_ms': 30,
        'focus_settle_ms': 55,
        'focus_activation_settle_ms': 35,
        'pick_confirm_timeout_ms': 1100,
        'slot_confirm_timeout_ms': 1100,
        'retry_delay_ms': 70,
        'verify_poll_ms': 35,
        'stable_frames': 2,
        'tooltip_hover_settle_ms': 60,
        'reader_reread_delay_ms': 60,
        'mouse_down_dwell_ms': 65,
        'focus_click_settle_ms': 35,
        'identity_signature_max_mae': 34,
        'identity_margin_mae': 4,
        'reacquire_attempts': 3,
        'perception_retries': 2,
        'input_drift_corrections': 2,
        'default_safe_radius_px': 8,
        'slot_evidence_radius_px': 16,
    }

    def __init__(self, data: Optional[Dict[str, Any]] = None):
        merged = dict(self.DEFAULTS)
        if isinstance(data, dict):
            for k in merged:
                try:
                    merged[k] = int(data.get(k, merged[k]))
                except Exception:
                    pass
        self.data = merged

    def ms(self, key: str) -> int:
        base = max(0, int(self.data.get(key, self.DEFAULTS.get(key, 0))))
        if key in self.ACTION_TIME_KEYS:
            # V1.7.2: exact 20% slower AutoRoll action cadence.
            # ceil avoids truncating short waits back toward the old speed.
            return max(0, int(math.ceil(float(base) * self.ACTION_TIME_SCALE)))
        return base

    def stable_frames(self):
        return max(2, min(4, int(self.data.get('stable_frames', 2))))

    def public(self):
        return {'profile': self.PROFILE_NAME, **dict(self.data)}


def _default_config():
    return {
        'schema_version': CONFIG_SCHEMA_VERSION,
        'build_id': BUILD_ID,
        'points': {},
        'filter_profile_ids': [1, 2, 3, 4],
        'record_delay_ms': 1200,
        'pick_verify_threshold': 6.0,
        'operation_speed_profile': 'gentle_safe_20pct_slower',
        'roll_wait_seconds': ROLL_WAIT_SECONDS,
        'queue_mode': 'AUTO_OR_RECORDED_SCAN',
        'auto_discover_if_no_recorded_items': True,
        'input_pacing': dict(AutoRollInputPacing.DEFAULTS),
        'filter_reroll_policy': 'UNLIMITED_UNTIL_ACCEPT_OR_STOP_CONDITION',
        'created_at': time.time(),
    }


AutoRollTimingProfile = AutoRollInputPacing


class AutoRollRecordConfig:
    """Single canonical config model; one-time migration removes legacy control knobs."""
    def __init__(self, path: Path):
        self.path = Path(path)
        self.data = _default_config()
        self.load()

    def load(self):
        cfg = _default_config()
        try:
            if self.path.exists():
                raw = json.loads(self.path.read_text(encoding='utf-8'))
                if isinstance(raw, dict):
                    cfg.update(raw)
        except Exception:
            pass
        points = {}
        for k, v in dict(cfg.get('points') or {}).items():
            if k not in POINT_KEYS or not isinstance(v, dict):
                continue
            p = v.get('client_point') or []
            if len(p) != 2:
                continue
            fp = v.get('footprint') or [1, 1]
            try:
                fp = [max(1, int(fp[0])), max(1, int(fp[1]))]
            except Exception:
                fp = [1, 1]
            safe_radius = int(v.get('safe_radius_px') or AutoRollInputPacing.DEFAULTS['default_safe_radius_px'])
            points[k] = {
                'client_point': [int(p[0]), int(p[1])],
                'signature': list(v.get('signature') or []),
                'client_size': list(v.get('client_size') or v.get('recorded_client_size') or []),
                'recorded_client_size': list(v.get('client_size') or v.get('recorded_client_size') or []),
                'captured_at': float(v.get('captured_at') or 0.0),
                'footprint': fp,
                'target_type': str(v.get('target_type') or k).upper(),
                'safe_radius_px': max(4, min(24, safe_radius)),
            }
        cfg['points'] = points
        # Remove obsolete owner knobs, timestamp validator tuning, point tolerance and popup verification fields.
        obsolete = (
            'result_timeout_ms','result_poll_ms','popup_signature_max_mae','result_stable_threshold',
            'popup_close_timeout_ms','post_popup_settle_ms','pre_roll_popup_max_dismiss_attempts',
            'pre_roll_popup_confirmation_frames','pre_roll_popup_policy','max_attempts','max_rolls',
            'reroll_budget','attempt_order','attempt_timestamp','cursor_tolerance','target_tolerance_px',
            'slot_verify_threshold','result_change_threshold','legacy_speed_profile','legacy_move_delay_ms'
        )
        for key in obsolete:
            cfg.pop(key, None)
        ids = []
        for x in (cfg.get('filter_profile_ids') or [1,2,3,4]):
            try:
                v = int(x)
            except Exception:
                continue
            if v in (1,2,3,4) and v not in ids:
                ids.append(v)
        cfg['filter_profile_ids'] = ids or [1,2,3,4]
        cfg['input_pacing'] = dict(AutoRollInputPacing.DEFAULTS)
        cfg['operation_speed_profile'] = 'gentle_safe'
        cfg['roll_wait_seconds'] = ROLL_WAIT_SECONDS
        cfg['queue_mode'] = 'AUTO_OR_RECORDED_SCAN'
        cfg['filter_reroll_policy'] = 'UNLIMITED_UNTIL_ACCEPT_OR_STOP_CONDITION'
        cfg['schema_version'] = CONFIG_SCHEMA_VERSION
        cfg['build_id'] = BUILD_ID
        self.data = cfg
        return cfg

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + '.tmp')
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(self.path)
        return self.data


class AutoRollFilterAdapter:
    """Neutral adapter with precompiled selected-profile IDs for the per-attempt hot path."""
    def __init__(self, core):
        self.core = core
        self._compiled_profile_ids = frozenset((1,2,3,4))

    def compile_profiles(self, selected_profile_ids):
        ids=[]
        for raw in (selected_profile_ids or [1,2,3,4]):
            try: v=int(raw)
            except Exception: continue
            if v in (1,2,3,4) and v not in ids: ids.append(v)
        self._compiled_profile_ids=frozenset(ids or [1,2,3,4])
        return tuple(sorted(self._compiled_profile_ids))

    def evaluate(self, read: Dict[str, Any], selected_profile_ids: Optional[List[int]], queue_id: str,
                 generation: int, evidence_id: str) -> FilterEvaluationResult:
        filt = read.get('filter') or {}
        selected = self._compiled_profile_ids if selected_profile_ids is None else frozenset(int(x) for x in selected_profile_ids)
        prs = [p for p in (filt.get('profile_results') or []) if int(p.get('profile_id') or 0) in selected]
        if not read.get('ok') or not prs:
            return FilterEvaluationResult(evidence_id, queue_id, generation, prs, FilterVerdict.UNRESOLVED,
                                          {}, 'FINAL6_UNRESOLVED_OR_PROFILE_RESULT_MISSING')
        scoped = self.core.compose_profile_result(prs, frames=filt.get('frames') or [], active_count=len(prs))
        decision = str(scoped.get('decision') or '').upper()
        authority = str(scoped.get('reject_authority') or '').upper()
        if decision == 'PASS':
            verdict = FilterVerdict.ACCEPT
        elif decision == 'FAIL' and authority == 'AUTHORITATIVE_REJECT':
            verdict = FilterVerdict.REJECT
        else:
            verdict = FilterVerdict.UNRESOLVED
        return FilterEvaluationResult(evidence_id, queue_id, generation, prs, verdict, scoped,
                                      None if verdict != FilterVerdict.UNRESOLVED else 'FILTER_UNRESOLVED')


class AutoRollInputDispatcher:
    """One pointer dispatcher. MOVE+VERIFY+CORRECT+DOWN/UP is one atomic lease."""
    def __init__(self, core, pacing: AutoRollInputPacing, telemetry: Callable[..., None],
                 cancellation_valid: Callable[[], bool], automation_busy: Callable[[], Optional[str]]):
        self.core = core
        self.pacing = pacing
        self.telemetry = telemetry
        self.cancellation_valid = cancellation_valid
        self.automation_busy = automation_busy
        self._seen_action_ids = set()

    def reset(self):
        self._seen_action_ids.clear()

    @staticmethod
    def _inside(point, rect):
        if not point or not rect or len(point) != 2 or len(rect) != 4:
            return False
        x, y = int(point[0]), int(point[1])
        x0, y0, x1, y1 = [int(v) for v in rect]
        return x0 <= x <= x1 and y0 <= y <= y1

    def _current_client_size(self, hwnd):
        try:
            img = self.core.capture_client(int(hwnd))
            if img is not None:
                return [int(img.width), int(img.height)]
        except Exception:
            pass
        return []

    def _resolve_target(self, hwnd: int, target: InteractionTarget):
        if target.coordinate_space == 'SCREEN':
            return {'center_screen': list(target.center), 'safe_screen_rect': list(target.safe_rect),
                    'center_client': None, 'safe_client_rect': None, 'scale': [1.0,1.0]}
        current_size = self._current_client_size(hwnd)
        scale_x = scale_y = 1.0
        if len(target.recorded_client_size) == 2 and len(current_size) == 2:
            rw, rh = [max(1, int(v)) for v in target.recorded_client_size]
            cw, ch = [max(1, int(v)) for v in current_size]
            scale_x, scale_y = float(cw)/float(rw), float(ch)/float(rh)
        cx = int(round(int(target.center[0]) * scale_x)); cy = int(round(int(target.center[1]) * scale_y))
        r = target.safe_rect
        sr_client = [int(round(r[0]*scale_x)), int(round(r[1]*scale_y)),
                     int(round(r[2]*scale_x)), int(round(r[3]*scale_y))]
        center_screen = self.core._client_to_screen(int(hwnd), cx, cy)
        p0 = self.core._client_to_screen(int(hwnd), sr_client[0], sr_client[1])
        p1 = self.core._client_to_screen(int(hwnd), sr_client[2], sr_client[3])
        if center_screen is None or p0 is None or p1 is None:
            return None
        safe_screen = [min(int(p0[0]),int(p1[0])), min(int(p0[1]),int(p1[1])),
                       max(int(p0[0]),int(p1[0])), max(int(p0[1]),int(p1[1]))]
        return {'center_screen':[int(center_screen[0]),int(center_screen[1])],
                'safe_screen_rect':safe_screen,'center_client':[cx,cy],
                'safe_client_rect':sr_client,'scale':[scale_x,scale_y], 'current_client_size':current_size}

    def _smooth_move(self, point):
        old = self.core._cursor_screen()
        if old is None:
            return False, None
        sx, sy = int(old[0]), int(old[1]); tx, ty = int(point[0]), int(point[1])
        duration_ms = self.pacing.ms('move_duration_ms')
        steps = max(5, min(24, int(round(duration_ms / 22.0)))) if duration_ms else 1
        started = time.monotonic()
        for i in range(1, steps + 1):
            if not self.cancellation_valid():
                return False, self.core._cursor_screen()
            t = i / float(steps); u = t*t*(3.0 - 2.0*t)
            x = int(round(sx + (tx-sx)*u)); y = int(round(sy + (ty-sy)*u))
            if not self.core._set_cursor_screen(x,y):
                return False, self.core._cursor_screen()
            if duration_ms:
                due = started + (duration_ms/1000.0)*t
                remain = due - time.monotonic()
                if remain > 0: time.sleep(remain)
        return True, self.core._cursor_screen()

    def _send_left(self):
        def send(flag):
            arr = (self.core.INPUT * 1)(); arr[0].type = self.core.INPUT_MOUSE
            arr[0].mi = self.core.MOUSEINPUT(0,0,0,int(flag),0,0)
            return int(self.core.user32_bridge.SendInput(1, ctypes.byref(arr), ctypes.sizeof(self.core.INPUT))) == 1
        down_ns = time.monotonic_ns(); down_ok = send(self.core.MOUSEEVENTF_LEFTDOWN)
        time.sleep(self.pacing.ms('mouse_down_dwell_ms') / 1000.0)
        up_ok = send(self.core.MOUSEEVENTF_LEFTUP); up_ns = time.monotonic_ns()
        return down_ok and up_ok, down_ns, up_ns

    def click(self, hwnd: int, target: InteractionTarget, action_id: str, purpose: str,
              require_foreground=True):
        if action_id in self._seen_action_ids:
            return {'ok':False,'reason':'DUPLICATE_INPUT_ACTION','action_id':action_id}
        with _GLOBAL_POINTER_LEASE:
            if not self.cancellation_valid():
                return {'ok':False,'reason':'USER_STOP'}
            busy = self.automation_busy()
            if busy:
                return {'ok':False,'reason':'POINTER_LEASE_CONTENTION_'+str(busy)}
            resolved = self._resolve_target(hwnd, target)
            if not resolved:
                return {'ok':False,'reason':'TARGET_RESOLUTION_FAILED','target':asdict(target)}
            foreground_before = int(self.core.user32_bridge.GetForegroundWindow() or 0)
            activation = None
            if require_foreground and foreground_before != int(hwnd):
                activation = self.core._activate_window(int(hwnd)); time.sleep(self.pacing.ms('focus_activation_settle_ms') / 1000.0)
            foreground = int(self.core.user32_bridge.GetForegroundWindow() or 0)
            if require_foreground and foreground != int(hwnd):
                return {'ok':False,'reason':'AUTOROLL_FOREGROUND_LOST','foreground_hwnd':foreground,'expected_hwnd':int(hwnd)}
            cursor_before = self.core._cursor_screen()
            self.telemetry('INPUT_LEASE_BEGIN', purpose=purpose, action_id=action_id, target=asdict(target), resolved=resolved)
            moved, cursor_after = self._smooth_move(resolved['center_screen'])
            if not moved:
                return {'ok':False,'reason':'INPUT_MOVE_FAILED','action_id':action_id}
            time.sleep(self.pacing.ms('pre_click_settle_ms') / 1000.0)
            drift_corrections = 0
            current = self.core._cursor_screen()
            max_corrections = max(0, min(3, self.pacing.ms('input_drift_corrections')))
            while not self._inside(current, resolved['safe_screen_rect']) and drift_corrections < max_corrections:
                drift_corrections += 1
                self.telemetry('INPUT_TARGET_DRIFT', purpose=purpose, action_id=action_id,
                               cursor=list(current) if current else None, safe_rect=resolved['safe_screen_rect'], correction=drift_corrections)
                moved, current = self._smooth_move(resolved['center_screen'])
                if not moved:
                    break
                time.sleep(min(.06, self.pacing.ms('pre_click_settle_ms') / 2000.0))
                current = self.core._cursor_screen()
            if not self._inside(current, resolved['safe_screen_rect']):
                return {'ok':False,'reason':'TEMPORARY_INPUT_CONTENTION','action_id':action_id,
                        'cursor':list(current) if current else None,'safe_rect':resolved['safe_screen_rect'],
                        'drift_corrections':drift_corrections}
            if not self.cancellation_valid():
                return {'ok':False,'reason':'USER_STOP'}
            ok, down_ns, up_ns = self._send_left()
            if not ok:
                return {'ok':False,'reason':'AUTOROLL_SENDINPUT_DOWN_UP_FAILED','action_id':action_id}
            self._seen_action_ids.add(action_id)
            time.sleep(self.pacing.ms('post_click_settle_ms') / 1000.0)
            result = {
                'ok':True,'action_id':action_id,'purpose':purpose,'input_dispatched':True,
                'cursor_before':list(cursor_before) if cursor_before else None,
                'cursor_after_move':list(current) if current else None,
                'safe_screen_rect':resolved['safe_screen_rect'],'center_screen':resolved['center_screen'],
                'center_client':resolved.get('center_client'),'safe_client_rect':resolved.get('safe_client_rect'),
                'drift_corrections':drift_corrections,'mouse_down_ns':down_ns,'mouse_up_ns':up_ns,
                'down_duration_ms':round((up_ns-down_ns)/1_000_000.0,3),'foreground_hwnd':foreground,
                'activation':activation,'coordinate_scale':resolved.get('scale'),
                'move_duration_ms':self.pacing.ms('move_duration_ms'),'pre_click_settle_ms':self.pacing.ms('pre_click_settle_ms'),
                'post_click_settle_ms':self.pacing.ms('post_click_settle_ms'),
            }
            self.telemetry('INPUT_DISPATCHED', **result)
            return result


class PickPlaceTransaction:
    """Shared transaction architecture for equipment and material pick/place."""
    def __init__(self, session: 'AutoRollSessionController'):
        self.session = session

    def execute(self, hwnd: int, source_target: InteractionTarget, destination_target: InteractionTarget,
                label: str, action_prefix: str, action_retry_limit=2):
        s = self.session
        source_point = list(source_target.center)
        dest_point = list(destination_target.center)
        max_action_attempts = max(1, min(2, int(action_retry_limit or 1)))
        attempts = []
        for attempt in range(1, max_action_attempts+1):
            if s._cancelled():
                return {'ok':False,'reason':'USER_STOP'}

            # V1.6.6: equipment moves are fail-closed. A weapon must never leave
            # its current UI owner unless the destination UI owner is proven.
            if label == 'ITEM':
                pre_guard=s._roll_ui_scene_guard(int(hwnd),require_empty_item_slot=True)
                if not pre_guard.get('ok'):
                    return {'ok':False,'reason':'ITEM_DESTINATION_NOT_PROVEN_NO_PICK',
                            'no_click':True,'guard':pre_guard}
            elif label == 'ITEM_RETURN':
                # Bag destination was calculated from live grid by the caller.
                bag_probe=s._inventory_presence_probe(int(hwnd),frames=2,settle_ms=40)
                if not bag_probe.get('ok'):
                    return {'ok':False,'reason':'ITEM_RETURN_BAG_NOT_PROVEN_NO_PICK',
                            'no_click':True,'guard':bag_probe}
                grid=(bag_probe.get('ready') or {}).get('grid') or {}
                if s._point_to_cell(dest_point,grid) is None:
                    return {'ok':False,'reason':'ITEM_RETURN_DEST_OUTSIDE_LIVE_BAG_NO_PICK',
                            'no_click':True}

            source_phase_ns=time.monotonic_ns()
            source_before = s.core.capture_client(int(hwnd))
            if source_before is None:
                return {'ok':False,'reason':'CAPTURE_FAILED_BEFORE_'+label+'_SOURCE'}
            source_sig = _gray_patch_signature(source_before, source_point)
            src_id = f'{action_prefix}:SOURCE:TRY{attempt}'
            src_click = s.input_dispatcher.click(hwnd, source_target, src_id, label+'_SOURCE')
            if not src_click.get('ok'):
                if src_click.get('reason') == 'TEMPORARY_INPUT_CONTENTION' and attempt < max_action_attempts:
                    continue
                return {'ok':False,'reason':label+'_SOURCE_CLICK_FAILED','detail':src_click}
            pick = s._wait_source_pick_evidence(hwnd, source_point, source_before, source_sig, label)
            s._metric(label.lower()+'_pick_ms',(time.monotonic_ns()-source_phase_ns)/1_000_000.0)
            attempts.append({'attempt':attempt,'pick':pick})
            if not pick.get('ok'):
                if pick.get('safe_action_retry') and attempt < max_action_attempts:
                    time.sleep(s.pacing.ms('retry_delay_ms')/1000.0)
                    continue
                return {'ok':False,'reason':label+'_PICK_NOT_COMMITTED','detail':pick,'attempts':attempts}
            # Re-prove destination AFTER the source pick and BEFORE any destination click.
            # This closes the exact destructive window where a stale recorded pixel could
            # point at the game world while the weapon is attached to cursor.
            if label == 'ITEM':
                post_guard=s._roll_ui_scene_guard(int(hwnd),require_empty_item_slot=True)
                if not post_guard.get('ok'):
                    rollback=s._rollback_picked_item_to_source(int(hwnd),source_target,action_prefix)
                    return {'ok':False,'reason':'ROLL_UI_LOST_AFTER_ITEM_PICK_NO_WORLD_CLICK',
                            'guard':post_guard,'rollback':rollback,'world_click_blocked':True}
            elif label == 'ITEM_RETURN':
                bag_probe=s._inventory_presence_probe(int(hwnd),frames=2,settle_ms=40)
                grid=(bag_probe.get('ready') or {}).get('grid') or {} if bag_probe.get('ok') else {}
                if (not bag_probe.get('ok')) or s._point_to_cell(dest_point,grid) is None:
                    # Roll slot is the known source owner. If its scene can still be
                    # proven, click it to put the weapon back; otherwise perform no click.
                    source_guard=s._roll_ui_scene_guard(int(hwnd),require_empty_item_slot=False)
                    rollback=None
                    if source_guard.get('ok'):
                        rollback=s.input_dispatcher.click(
                            int(hwnd),source_target,f'{action_prefix}:ROLLBACK_ROLL_SLOT',
                            'ITEM_RETURN_ROLLBACK_TO_ROLL_SLOT'
                        )
                    return {'ok':False,'reason':'PLAYER_BAG_LOST_AFTER_ITEM_PICK_NO_WORLD_CLICK',
                            'bag_guard':bag_probe,'source_guard':source_guard,
                            'rollback':rollback,'world_click_blocked':True}

            destination_phase_ns=time.monotonic_ns()
            slot_before_img = s.core.capture_client(int(hwnd))
            slot_before = _slot_features(slot_before_img, dest_point, s.pacing.ms('slot_evidence_radius_px'))
            dst_id = f'{action_prefix}:DEST'
            dst_click = s.input_dispatcher.click(hwnd, destination_target, dst_id, label+'_DESTINATION')
            if not dst_click.get('ok'):
                return {'ok':False,'reason':label+'_DESTINATION_CLICK_FAILED','detail':dst_click}
            placed = s._wait_slot_semantic_commit(hwnd, dest_point, slot_before, label, pick)
            s._metric(label.lower()+'_place_ms',(time.monotonic_ns()-destination_phase_ns)/1_000_000.0)
            if not placed.get('ok'):
                return {'ok':False,'reason':label+'_PLACEMENT_NOT_COMMITTED','detail':placed,'attempts':attempts}
            return {'ok':True,'attempts':attempts,'pick_evidence':pick,'place_evidence':placed,
                    'source_input':src_click,'destination_input':dst_click}
        return {'ok':False,'reason':label+'_TRANSACTION_FAILED'}


class AutoRollSessionController:
    """Single authoritative AutoRoll owner. No old/new runtime runs in parallel."""
    def __init__(self, api, core, root: Path):
        self.api = api
        self.core = core
        self.root = Path(root)
        self.store = AutoRollRecordConfig(self.root / 'AutoProByEric_AutoRollRecordCoord_v1.json')
        self.pacing = AutoRollTimingProfile(self.store.data.get('input_pacing'))
        self.lock = threading.RLock()
        self.worker = None
        self.state = 'IDLE'
        self.session_id: Optional[str] = None
        self.session_generation = 0
        self.attempt_generation = 0
        self.active_attempt: Optional[RollAttemptContext] = None
        self.queue = RollItemQueue()
        self.total_rolls = 0
        self.matched = 0
        self.last_error: Optional[Dict[str, Any]] = None
        self.last_event: Optional[Dict[str, Any]] = None
        self.log_path = self.root / 'logs' / 'autoroll_v1_7_3_final6_overlap_fusedrow_rootfix.jsonl'
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._log_writer = AsyncJsonlLogWriter(self.log_path)
        self._phase_metrics: Dict[str, List[float]] = {}
        self._last_filter_reject_ns: Optional[int] = None
        self._material_source_cache: Dict[str, Any] = {'target':None,'config_point':None,'valid':False,'generation':0}
        # AutoRoll-only post-Popup cursor park. The successful Popup click is the
        # sole park coordinate while Final6/OCR/Filter processes the returned Bag item.
        self._popup_park_screen: Optional[List[int]] = None
        self._popup_park_client: Optional[List[int]] = None
        self.cancellation = SessionCancellationToken()
        self._cancel_generation = self.cancellation.reset()
        self.ledger = AutoRollEventLedger(self._write_record)
        self.validator = RollAttemptInvariantValidator()
        self.filter_adapter = AutoRollFilterAdapter(core)
        self.input_dispatcher = AutoRollInputDispatcher(core, self.pacing, self._telemetry,
                                                        self._input_token_valid, self._pointer_contention)
        self.pick_place = PickPlaceTransaction(self)
        self._inventory_grid = None
        self._inventory_snapshot = None
        self._owner_registry = {
            'AutoRollSessionController': id(self),
            'AutoRollEventLedger': id(self.ledger),
            'InputDispatcher': id(self.input_dispatcher),
            'FilterAdapter': id(self.filter_adapter),
            'RollItemQueue': id(self.queue),
        }
        if len(set(self._owner_registry.values())) != len(self._owner_registry):
            raise RuntimeError('DUPLICATE_AUTOROLL_OWNER_FATAL')
        for owner_name, owner_obj in (
            ('AutoRollSessionController', self), ('AutoRollEventLedger', self.ledger),
            ('InputDispatcher', self.input_dispatcher), ('FilterAdapter', self.filter_adapter),
        ):
            RuntimeOwnerRegistry.register(owner_name, owner_obj)
        self.component_manifest = self._component_manifest()
        self._write_record({'record_type':'COMPONENT_MANIFEST','manifest':self.component_manifest})


    def close(self):
        try:
            self._log_writer.close()
        except Exception:
            pass
        for owner_name, owner_obj in (
            ('AutoRollSessionController', self), ('AutoRollEventLedger', self.ledger),
            ('InputDispatcher', self.input_dispatcher), ('FilterAdapter', self.filter_adapter),
        ):
            RuntimeOwnerRegistry.release(owner_name, owner_obj)

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Canonical logging / state / errors
    # ------------------------------------------------------------------
    def _write_record(self, rec: Dict[str, Any]):
        payload = {'wall_ts': time.time(), 'build_id': BUILD_ID, **dict(rec)}
        self.last_event = payload
        self._log_writer.submit(payload)

    def _metric(self, name: str, elapsed_ms: float):
        try:
            v=max(0.0,float(elapsed_ms)); bucket=self._phase_metrics.setdefault(str(name),[])
            bucket.append(v)
            if len(bucket)>512: del bucket[:-256]
        except Exception:
            pass

    def _metric_summary(self):
        out={}
        for name, vals in self._phase_metrics.items():
            if not vals: continue
            ordered=sorted(float(x) for x in vals); n=len(ordered)
            p95=ordered[min(n-1,max(0,int(math.ceil(n*0.95))-1))]
            out[name]={'count':n,'median_ms':round(float(statistics.median(ordered)),3),'p95_ms':round(float(p95),3),'worst_ms':round(float(ordered[-1]),3)}
        return out

    def _telemetry(self, event: str, **payload):
        self._write_record({'record_type':'INPUT_TELEMETRY','event':event,'state':self.state,
                            'session_id':self.session_id,'attempt_id':self.active_attempt.attempt_id if self.active_attempt else None,
                            **payload})

    def _domain(self, event_type: str, *, once_key: Optional[str] = None, **payload):
        cur = self.queue.current()
        attempt = self.active_attempt
        return self.ledger.emit(
            session_id=str(self.session_id or ''), session_generation=self.session_generation,
            queue_id=cur.queue_id if cur else None, attempt_id=attempt.attempt_id if attempt else None,
            attempt_generation=attempt.attempt_generation if attempt else self.attempt_generation,
            event_type=event_type, state=self.state, payload=payload, once_key=once_key)

    def _set_state(self, new_state: str, **payload):
        if str(new_state) == 'ERROR':
            raise RuntimeError('BARE_ERROR_STATE_FORBIDDEN')
        previous = self.state
        self.state = str(new_state)
        self._write_record({'record_type':'STATE_TRANSITION','event':'AUTOROLL_STATE','session_id':self.session_id,
                            'previous':previous,'current':self.state,'last_event_seq':self.ledger.last_seq,**payload})

    def _error_envelope(self, code: str, component: str, detail=None, recoverable=False,
                        exc: Optional[BaseException] = None, evidence_id=None):
        trace = None
        if exc is not None:
            trace = traceback.format_exc(limit=12)
        return ErrorEnvelope(
            error_code=str(code), source_component=str(component), source_state=self.state,
            session_id=self.session_id, queue_id=self.queue.current().queue_id if self.queue.current() else None,
            attempt_id=self.active_attempt.attempt_id if self.active_attempt else None,
            recoverable=bool(recoverable), exception_type=type(exc).__name__ if exc else None,
            exception_message=str(exc) if exc else None,
            traceback_hash=hashlib.sha256((trace or '').encode()).hexdigest()[:16] if trace else None,
            evidence_id=evidence_id, last_event_seq=self.ledger.last_seq, detail=dict(detail or {}))

    def _enter_error(self, env: ErrorEnvelope):
        if not isinstance(env, ErrorEnvelope):
            raise RuntimeError('ERROR_ENVELOPE_REQUIRED')
        previous = self.state
        self.state = 'ERROR'
        self.last_error = asdict(env)
        self._write_record({'record_type':'STATE_TRANSITION','event':'AUTOROLL_ERROR','previous':previous,
                            'current':'ERROR','error_envelope':asdict(env)})

    def _component_manifest(self):
        p = self.root
        return {
            'app_build_id': BUILD_ID,
            'autoroll_component': {'component_id':'AutoRollSessionController','version':'1.7.4-profile-aware-two-stage-registry',
                                   'sha256':_sha256_file(Path(__file__))},
            'reader_component': {'component_id':'AutoProByEric_Stage16_Reader_v1_6','version':'shared-v12.11',
                                 'sha256':_sha256_file(p/'AutoProByEric_Stage16_Reader_v1_6.py')},
            'filter_component': {'component_id':'AutoProByEric_ItemFilterEngine_v1','version':'shared-v12.11',
                                 'sha256':_sha256_file(p/'AutoProByEric_ItemFilterEngine_v1.py')},
            'input_dispatcher_component': {'component_id':'AutoRollInputDispatcher','version':'1.6.1-fast-atomic-input-lease',
                                           'sha256':_sha256_file(Path(__file__))},
            'owner_registry': dict(self._owner_registry),
        }

    # ------------------------------------------------------------------
    # Public API / config
    # ------------------------------------------------------------------
    @property
    def current_item(self):
        return self.queue.current()

    @property
    def current_item_index(self):
        return self.queue.index

    def is_running(self):
        return bool(self.worker and self.worker.is_alive())

    def status(self):
        pts = self.store.data.get('points') or {}
        items = []
        if self.queue.items:
            for i, ident in enumerate(self.queue.items[:MAX_ITEMS], 1):
                items.append({'index':i,'ready':True,'client_point':list(ident.current_client_point),
                              'state':ident.status,'queue_id':ident.queue_id,'roll_attempt':ident.roll_attempt,
                              'completed':ident.completed,'identity_confidence':ident.identity_confidence})
        else:
            for i in range(1,MAX_ITEMS+1):
                p = pts.get(f'item{i}')
                items.append({'index':i,'ready':bool(p),'client_point':list(p.get('client_point') or []) if p else None,
                              'state':'READY' if p else 'EMPTY'})
        cur = self.current_item
        return {
            'ok':True,'build_id':BUILD_ID,'running':self.is_running(),'state':self.state,
            'input_speed_profile':self.pacing.PROFILE_NAME,'input_pacing':self.pacing.public(),
            'session_id':self.session_id,'session_generation':self.session_generation,
            'attempt_generation':self.attempt_generation,'event_seq':self.ledger.last_seq,
            'filter_reroll_policy':'UNLIMITED_SAME_ITEM_UNTIL_ACCEPT_OR_STOP_CONDITION',
            'current_item_attempt':cur.roll_attempt if cur else 0,'current_item_index':self.current_item_index,
            'current_item_number':self.current_item_index+1 if self.current_item_index>=0 else None,
            'current_item_identity':asdict(cur) if cur else None,'total_rolls':self.total_rolls,'matched':self.matched,
            'filter_profile_ids':list(self.store.data.get('filter_profile_ids') or [1,2,3,4]),
            'items':items,'queue_count':len(self.queue.items) if self.queue.items else sum(1 for x in items if x.get('ready')),
            'queue_source':'RUNTIME_SCAN' if self.queue.items else 'CONFIGURED_POINTS',
            'points':{k:{'client_point':list(v.get('client_point') or []),'safe_radius_px':v.get('safe_radius_px')} for k,v in pts.items()},
            'material_ready':bool(pts.get('material')),'item_slot_ready':bool(pts.get('item_slot')),
            'material_slot_ready':bool(pts.get('material_slot')),'roll_button_ready':bool(pts.get('roll_button')),
            'popup_ready':bool(pts.get('popup')),
            'popup_dismiss':{'ready':bool(pts.get('popup')),'client_point':list((pts.get('popup') or {}).get('client_point') or []),
                             'action_type':'CLICK_FIRE_AND_FORGET','verify_close':False},
            'result_inspection':{'item_index':self.current_item_index+1 if self.current_item_index>=0 else None,
                                 'client_point':list(cur.current_client_point) if cur else [],'action_type':'HOVER','click_allowed':False},
            'performance_metrics':self._metric_summary(),'material_source_cache':{'valid':bool(self._material_source_cache.get('valid')),'generation':int(self._material_source_cache.get('generation') or 0)},
            'component_manifest':self.component_manifest,'owner_registry':dict(self._owner_registry),'last_error':self.last_error,
            'last_event':self.last_event,
        }

    def set_filter_profiles(self, profile_ids):
        if self.is_running(): return {'ok':False,'reason':'AUTO_ROLL_RUNNING'}
        ids=[]
        for raw in (profile_ids or []):
            try: v=int(raw)
            except Exception: continue
            if v in (1,2,3,4) and v not in ids: ids.append(v)
        if not ids: return {'ok':False,'reason':'AUTO_ROLL_FILTER_PROFILE_SELECTION_EMPTY'}
        self.store.data['filter_profile_ids']=ids; self.store.save()
        return {'ok':True,'filter_profile_ids':ids}

    def clear_points(self):
        if self.is_running(): return {'ok':False,'reason':'AUTO_ROLL_RUNNING'}
        self.store.data['points']={}; self.store.save(); self.queue.reset(); self.total_rolls=0; self.matched=0; self.last_error=None
        self._set_state('IDLE'); return {'ok':True}

    def record_point(self, hwnd: int, kind: str, delay_ms: Optional[int]=None):
        if self.is_running(): return {'ok':False,'reason':'AUTO_ROLL_RUNNING'}
        hwnd=int(hwnd or 0); kind=str(kind or '').strip().lower()
        if kind not in POINT_KEYS: return {'ok':False,'reason':'AUTOROLL_RECORD_KIND_INVALID','kind':kind}
        if not hwnd or not self.core.window_exists(hwnd): return {'ok':False,'reason':'NO_VALID_CLIENT'}
        delay=max(0,min(4000,int(self.store.data.get('record_delay_ms',1200) if delay_ms is None else delay_ms)))
        self._set_state('RECORDING_POINT',kind=kind); time.sleep(delay/1000.0)
        p=self.core.get_cursor_client(hwnd); image=self.core.capture_client(hwnd)
        if p is None or image is None:
            self._set_state('IDLE'); return {'ok':False,'reason':'AUTOROLL_POINT_CAPTURE_FAILED'}
        x,y=int(p[0]),int(p[1])
        if not (0<=x<int(image.width) and 0<=y<int(image.height)):
            self._set_state('IDLE'); return {'ok':False,'reason':'CURSOR_NOT_INSIDE_SELECTED_JX1_CLIENT','client_point':[x,y]}
        radius=self.pacing.ms('default_safe_radius_px')
        self.store.data.setdefault('points',{})[kind]={
            'client_point':[x,y],'signature':_gray_patch_signature(image,[x,y]),
            'client_size':[int(image.width),int(image.height)],'recorded_client_size':[int(image.width),int(image.height)],
            'captured_at':time.time(),'footprint':[1,1],'target_type':kind.upper(),'safe_radius_px':radius,
        }
        self.store.save(); self._set_state('IDLE')
        return {'ok':True,'kind':kind,'client_point':[x,y],'coordinate_space':'CLIENT','safe_radius_px':radius}

    def _point_rec(self, kind):
        return ((self.store.data.get('points') or {}).get(kind) or {})

    def _point(self, kind):
        p=self._point_rec(kind).get('client_point') or []
        return [int(p[0]),int(p[1])] if len(p)==2 else None

    def _target(self, kind, point=None, target_type=None):
        rec=self._point_rec(kind)
        p=list(point or rec.get('client_point') or [])
        if len(p)!=2: return None
        radius=int(rec.get('safe_radius_px') or self.pacing.ms('default_safe_radius_px'))
        size=list(rec.get('recorded_client_size') or rec.get('client_size') or [])
        return InteractionTarget.client(target_type or str(rec.get('target_type') or kind).upper(),p,radius,size)

    def _validate_start(self, hwnd, test_one=False):
        if not hwnd or not self.core.window_exists(hwnd): return {'ok':False,'reason':'GAME_CLIENT_NOT_FOUND'}
        pts=self.store.data.get('points') or {}; missing=[]
        if test_one:
            if not pts.get('item1'): missing.append('item1')
            if not pts.get('item_slot'): missing.append('item_slot')
        else:
            for k in REQUIRED_FULL:
                if not pts.get(k): missing.append(k)
            if not any(pts.get(f'item{i}') for i in range(1,MAX_ITEMS+1)) and not self.store.data.get('auto_discover_if_no_recorded_items',True):
                missing.append('at_least_one_item')
        if missing: return {'ok':False,'reason':'ROLL_POPUP_COORD_NOT_CONFIGURED' if missing==['popup'] else 'AUTOROLL_SETUP_INCOMPLETE','missing':missing}
        return {'ok':True}

    def _other_automation_busy(self):
        try:
            guard=self.api.automation_mode_guard('ROLL')
            if not guard.get('ok'):
                return str(guard.get('blocking_mode') or 'UNKNOWN')
            return None
        except Exception:
            # Compatibility fallback if this coordinator is reused with an older API.
            st=str(getattr(self.api,'_runtime_lifecycle_state','STOPPED') or 'STOPPED').upper()
            if st in ('STARTING','RUNNING','RECOVERY_WAIT','RECOVERY_RUNNING','STOPPING'): return 'CHEST'
            try:
                states=self.api._cfg.get('runtime',{}).get('module_running',{})
                if bool(states.get('chest',False)): return 'CHEST'
                boss_ctl=getattr(self.api,'_auto_boss',None)
                if boss_ctl is not None and boss_ctl.is_running(): return 'BOSS'
                if bool(states.get('boss',False)): return 'BOSS'
            except Exception: pass
            return None

    def _pointer_contention(self):
        return self._other_automation_busy()

    def _set_roll_running_flag(self, running):
        try:
            self.api._cfg.setdefault('runtime',{}).setdefault('module_running',{})['roll']=bool(running)
            save=getattr(self.core,'_save_app_config',None)
            if callable(save): save(self.api._cfg)
        except Exception: pass

    def start(self, hwnd: int, test_one=False):
        hwnd=int(hwnd or 0); test_one=bool(test_one)
        with self.lock:
            if self.is_running(): return {'ok':False,'reason':'AUTO_ROLL_ALREADY_RUNNING'}
            busy=self._other_automation_busy()
            if busy: return {'ok':False,'reason':'ACTIVE_AUTOMATION_MODE_'+busy}
            valid=self._validate_start(hwnd,test_one)
            if not valid.get('ok'): return valid
            selected_profiles=self.store.data.get('filter_profile_ids') or [1,2,3,4]
            try:
                filter_guard=self.api.filter_runtime_guard('AUTO_ROLL',selected_profile_ids=selected_profiles,require_enabled_rules=True)
            except Exception as e:
                filter_guard={'ok':False,'reason':'AUTO_ROLL_FILTER_PREFLIGHT_EXCEPTION','error':str(e)}
            if not filter_guard.get('ok'):
                return {'ok':False,'reason':filter_guard.get('reason','AUTO_ROLL_FILTER_STARTUP_FAILED'),
                        'startup_contract':filter_guard,'no_input_sent':True}
            self.session_id='ARS-'+uuid.uuid4().hex[:12].upper(); self.session_generation += 1; self.attempt_generation=0
            self._cancel_generation=self.cancellation.reset(); self.ledger.reset(); self.queue.reset(); self.total_rolls=0; self.matched=0
            self.active_attempt=None; self.last_error=None; self.input_dispatcher.reset(); self._inventory_grid=None; self._inventory_snapshot=None
            self._phase_metrics={}; self._last_filter_reject_ns=None; self._material_source_cache={'target':None,'config_point':None,'valid':False,'generation':0}
            self.filter_adapter.compile_profiles(selected_profiles)
            self._set_state('SESSION_START',hwnd=hwnd,test_one=test_one); self._set_roll_running_flag(True)
            self._domain('SESSION_START',once_key=f'{self.session_id}:SESSION_START',hwnd=hwnd,test_one=test_one,component_manifest=self.component_manifest)
            target=self._run_test_one if test_one else self._run_full
            self.worker=threading.Thread(target=target,args=(hwnd,),daemon=True,name='AutoRollV167GentlePacing')
            self.worker.start()
            return {'ok':True,'state':self.state,'test_one':test_one,'session_id':self.session_id,'speed_profile':self.pacing.PROFILE_NAME}

    def stop(self, reason='USER_STOP'):
        with self.lock:
            self.cancellation.cancel(str(reason or 'USER_STOP'))
            if not self.is_running():
                self.state='STOPPED'; self._set_roll_running_flag(False); return {'ok':True,'running':False,'state':self.state}
            self._set_state('STOPPING',reason=reason)
            self._domain('USER_STOP_REQUESTED',once_key=f'{self.session_id}:USER_STOP',reason=str(reason or 'USER_STOP'))
            return {'ok':True,'running':True,'state':self.state,'safe_boundary_pending':True}

    def _input_token_valid(self):
        return self.cancellation.is_valid(self._cancel_generation)

    def _cancelled(self):
        return not self._input_token_valid()

    # ------------------------------------------------------------------
    # Inventory typed acquisition / deterministic queue
    # ------------------------------------------------------------------
    def _inventory_presence_probe(self, hwnd: int, frames=3, settle_ms=55):
        """V1.6.2 non-destructive source-inventory presence consensus.

        IMPORTANT:
        - Never sends Q/F4.
        - Never invokes shared layout recovery.
        - Accepts a verified live grid even when its anchor has drifted from the
          historical canonical position. AutoRoll should adapt to the live grid,
          not close/reopen a visible bag just to normalize geometry.
        """
        hwnd=int(hwnd)
        observations=[]
        frames=max(2,min(5,int(frames or 3)))
        for idx in range(frames):
            if self._cancelled():
                return {'ok':False,'reason':'USER_STOP','observations':observations}
            ready=self.api._capture_inventory_ready(hwnd,try_open=False)
            observations.append({
                'probe':idx+1,
                'ok':bool(ready.get('ok')),
                'reason':ready.get('reason'),
                'capture_mode':ready.get('capture_mode'),
            })
            if ready.get('ok'):
                grid=ready.get('grid') or {}
                drifted=False
                try:
                    drifted=bool(self.api._grid_layout_drifted(ready.get('image'),grid))
                except Exception:
                    drifted=False
                if drifted:
                    self._domain('INVENTORY_LAYOUT_DRIFT_ACCEPTED_NO_TOGGLE',
                                 probe=idx+1,capture_mode=ready.get('capture_mode'))
                return {'ok':True,'ready':ready,'observations':observations,'source':'SHARED_NONDESTRUCTIVE'}

            # Extra owner-neutral canonical proof. This is still read-only and
            # specifically guards against a transient generic detector miss.
            try:
                img=self.core.capture_client(hwnd)
                canon=getattr(self.core,'_canonical_source_grid_candidate',lambda _img:{'ok':False})(img)
                if isinstance(canon,dict) and canon.get('ok'):
                    grid=canon.get('grid') or {}
                    return {
                        'ok':True,
                        'ready':{
                            'ok':True,'image':img,'grid':grid,'opened':False,
                            'capture_mode':'AUTOROLL_CANONICAL_PRESENCE_PROBE'
                        },
                        'observations':observations,
                        'source':'CANONICAL_SOURCE_GRID'
                    }
            except Exception:
                pass
            if idx+1<frames:
                time.sleep(max(.02,float(settle_ms)/1000.0))
        return {'ok':False,'reason':'INVENTORY_ABSENCE_CONFIRMED','observations':observations}

    def _acquire_inventory(self, hwnd: int, reacquire=False):
        """V1.6.2 single-owner Q/F4 acquisition.

        Root contract:
        1) Prove visible inventory non-destructively first.
        2) If visible, NEVER toggle it closed.
        3) Only after repeated confirmed absence, send the selected Q/F4 exactly once.
        4) After that key, only poll non-destructively; never close/reopen for layout drift.

        This intentionally does not call _capture_inventory_ready(..., try_open=True),
        because that shared path may perform deterministic CLOSE->REOPEN layout recovery.
        That behavior is valid for other modules but is destructive for AutoRoll start.
        """
        hwnd=int(hwnd)
        pre=self._inventory_presence_probe(hwnd,frames=3,settle_ms=55)
        if pre.get('ok'):
            ready=pre.get('ready') or {}
            self._inventory_grid=ready.get('grid') or self._inventory_grid
            return InventoryAcquireResult(
                True,
                InventoryOutcome.REACQUIRED if reacquire else InventoryOutcome.ALREADY_VISIBLE,
                ready.get('image'), ready.get('grid') or {}, {
                    **dict(ready),
                    'autoroll_inventory_owner':'AUTOROLL_V1_6_2',
                    'hotkey_sent':False,
                    'presence_probe':pre,
                }
            )

        if self._cancelled():
            return InventoryAcquireResult(False,InventoryOutcome.TEMP_OCCLUDED,None,{},
                                          {'reason':'USER_STOP','presence_probe':pre})

        # Confirmed absent. AutoRoll is now the only owner allowed to send the
        # inventory toggle for this acquisition transaction.
        key=str(self.api.get_inventory_hotkey())
        mode=str(getattr(self.api,'_cfg',{}).get('input_mode','Auto'))
        self._domain('INVENTORY_HOTKEY_OPEN_REQUEST',
                     key=key,mode=mode,reacquire=bool(reacquire),
                     absence_confirmed=True,exactly_once=True)

        sent=self.api.send_inventory_hotkey_once(hwnd,key,mode,'AUTOROLL_ACQUIRE_INVENTORY') if hasattr(self.api,'send_inventory_hotkey_once') else self.api.send_client_key_once(hwnd,key,mode)
        if not sent.get('ok'):
            return InventoryAcquireResult(
                False,InventoryOutcome.HOTKEY_FAILED,None,{},
                {'reason':'INVENTORY_HOTKEY_SEND_FAILED','hotkey':key,'input':sent,'presence_probe':pre}
            )

        # Poll presence only. Never call shared try_open=True here because that
        # could issue a second toggle or CLOSE->REOPEN layout normalization.
        deadline=time.monotonic()+1.65
        polls=0
        last=None
        while time.monotonic()<deadline:
            if self._cancelled():
                return InventoryAcquireResult(False,InventoryOutcome.TEMP_OCCLUDED,None,{},
                                              {'reason':'USER_STOP','hotkey':key,'input':sent})
            time.sleep(.075 if polls else .16)
            polls+=1
            probe=self._inventory_presence_probe(hwnd,frames=2,settle_ms=35)
            last=probe
            if probe.get('ok'):
                ready=probe.get('ready') or {}
                self._inventory_grid=ready.get('grid') or self._inventory_grid
                self._domain('INVENTORY_HOTKEY_OPEN_CONFIRMED',
                             key=key,polls=polls,reacquire=bool(reacquire))
                return InventoryAcquireResult(
                    True,
                    InventoryOutcome.REACQUIRED if reacquire else InventoryOutcome.OPENED,
                    ready.get('image'),ready.get('grid') or {},{
                        **dict(ready),
                        'autoroll_inventory_owner':'AUTOROLL_V1_6_2',
                        'hotkey_sent':True,
                        'hotkey':key,
                        'input':sent,
                        'open_polls':polls,
                        'presence_probe':probe,
                    }
                )

        # The key was sent exactly once but the bag did not become provably visible.
        # Do not send it again: a second toggle could close a late-opening bag.
        return InventoryAcquireResult(
            False,InventoryOutcome.GRID_NOT_FOUND,None,{},
            {
                'reason':'INVENTORY_OPEN_NOT_CONFIRMED_AFTER_EXACTLY_ONCE_HOTKEY',
                'hotkey':key,'input':sent,'polls':polls,
                'initial_presence':pre,'last_presence':last,
                'second_toggle_blocked':True,
            }
        )

    def _point_to_cell(self, point, grid):
        if not point or not grid:return None
        xs=[int(x) for x in (grid.get('x_lines') or [])]; ys=[int(y) for y in (grid.get('y_lines') or [])]
        if len(xs)<2 or len(ys)<2:return None
        c=next((i for i in range(len(xs)-1) if xs[i]<=int(point[0])<xs[i+1]),None)
        r=next((i for i in range(len(ys)-1) if ys[i]<=int(point[1])<ys[i+1]),None)
        return [int(r),int(c)] if r is not None and c is not None else None

    def _cell_point(self, grid,row,col,offset_px=None):
        xs=[int(x) for x in (grid.get('x_lines') or [])]; ys=[int(y) for y in (grid.get('y_lines') or [])]
        if not (0<=int(col)<len(xs)-1 and 0<=int(row)<len(ys)-1):return None
        if offset_px and len(offset_px)==2:
            x=xs[col]+int(offset_px[0]); y=ys[row]+int(offset_px[1])
            return [max(xs[col]+2,min(xs[col+1]-3,x)),max(ys[row]+2,min(ys[row+1]-3,y))]
        return [int((xs[col]+xs[col+1])//2),int((ys[row]+ys[row+1])//2)]

    def _occupied_map(self,snap):
        return {(int(c.get('row',-1)),int(c.get('col',-1))):bool(c.get('occupied')) for c in (snap or {}).get('cells',[])}

    def _component_for_cell(self,occupied,row,col):
        start=(int(row),int(col))
        if not occupied.get(start):return []
        seen={start}; stack=[start]
        while stack:
            r,c=stack.pop()
            for n in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
                if occupied.get(n) and n not in seen: seen.add(n); stack.append(n)
        return sorted(seen)

    def _safe_component_footprint(self,component):
        if not component:return ([1,1],None,'NO_COMPONENT')
        rs=[r for r,c in component]; cs=[c for r,c in component]; r0,r1=min(rs),max(rs); c0,c1=min(cs),max(cs)
        fw,fh=c1-c0+1,r1-r0+1; allowed={(1,1),(1,2),(2,1),(2,2),(1,3),(3,1),(1,4),(4,1),(2,3),(3,2)}
        if len(component)==fw*fh and (fw,fh) in allowed:return ([fw,fh],[r0,c0],'ISOLATED_RECTANGULAR_COMPONENT')
        return ([1,1],None,'ADJACENT_OR_AMBIGUOUS_FALLBACK')

    def _build_identity_from_point(self,idx,source_kind,point,ready,snap):
        grid=ready.grid if isinstance(ready,InventoryAcquireResult) else ready.get('grid') or {}
        image=ready.image if isinstance(ready,InventoryAcquireResult) else ready.get('image')
        cell=self._point_to_cell(point,grid)
        if cell is None:return {'ok':False,'reason':'RECORDED_ITEM_POINT_OUTSIDE_PLAYER_INVENTORY_GRID'}
        occupied=self._occupied_map(snap)
        if not occupied.get((cell[0],cell[1])):return {'ok':False,'reason':'RECORDED_ITEM_POINT_EMPTY','cell':cell}
        comp=self._component_for_cell(occupied,*cell); fp,top_left,why=self._safe_component_footprint(comp)
        if top_left is None:top_left=list(cell)
        xs=[int(x) for x in grid.get('x_lines',[])]; ys=[int(y) for y in grid.get('y_lines',[])]
        off=[cell[0]-top_left[0],cell[1]-top_left[1]]; offset_px=[int(point[0])-xs[cell[1]],int(point[1])-ys[cell[0]]]
        qid=f'Q{idx:02d}'; logical=f'{self.session_id}:{qid}'
        ident=CurrentRollItemIdentity(str(self.session_id),qid,logical,source_kind,list(top_left),list(top_left),off,list(fp),
                                      'EQUIPMENT_CONFIGURED',_gray_patch_signature(image,point),list(point),list(point),offset_px,
                                      identity_confidence=why)
        return {'ok':True,'identity':ident,'component':comp}

    def _discover_isolated_candidates(self,ready,snap):
        occupied=self._occupied_map(snap); remaining={rc for rc,v in occupied.items() if v}; comps=[]
        while remaining:
            start=min(remaining); comp=set(self._component_for_cell(occupied,*start)); remaining-=comp; comps.append(sorted(comp))
        material_cell=self._point_to_cell(self._point('material'),ready.grid)
        out=[]
        for comp in comps:
            if material_cell and tuple(material_cell) in set(comp):continue
            fp,top_left,why=self._safe_component_footprint(comp)
            if top_left is not None and why=='ISOLATED_RECTANGULAR_COMPONENT':out.append({'component':comp,'anchor':top_left,'footprint':fp})
        return out[:MAX_ITEMS]

    def _candidate_dict(self,ident,grid):
        ar,ac=[int(x) for x in ident.current_grid_anchor]; fw,fh=[max(1,int(x)) for x in ident.footprint]
        cells=[[r,c] for r in range(ar,ar+fh) for c in range(ac,ac+fw)]
        return {'candidate_id':1,'cells':cells,'geometric_cells':cells,'anchor':[ar,ac],'footprint':[fw,fh],
                'cell_count':len(cells),'confidence':.99,'queue_id':ident.queue_id,'status':'PENDING','decision':'PENDING',
                'group_id':None,'group_label':None,'group_confidence':0.0}

    def _classify_auto_candidate_equipment(self,hwnd,candidate,grid):
        old_q=self.api._new_item_queue; old_results=self.api._queue_read_results; old_grid=self.api._inventory_grid
        try:
            self.api._new_item_queue=[copy.deepcopy(candidate)]; self.api._queue_read_results=[]; self.api._inventory_grid=grid
            reader_ns=time.monotonic_ns(); read=self.api._read_queue_item_internal(int(hwnd),0,batch_session=True,execution_mode='READER_TEST'); self._metric('final6_reader_ms',(time.monotonic_ns()-reader_ns)/1_000_000.0)
            gp=read.get('group_pick') or {}; qi=read.get('queue_item') or {}; known=bool(gp.get('identity_known')) or bool(qi.get('group_identity_known'))
            gid=gp.get('group_id') or qi.get('group_id'); label=gp.get('group_label') or qi.get('group_label')
            return {'eligible':bool(read.get('ok') and known and (gid or label)),'group_id':gid,'group_label':label}
        except Exception as e:return {'eligible':False,'reason':'AUTO_DISCOVERY_TOOLTIP_CLASSIFY_FAILED','error':str(e)}
        finally:
            self.api._new_item_queue=old_q; self.api._queue_read_results=old_results; self.api._inventory_grid=old_grid

    def _build_roll_item_queue(self,hwnd):
        self._set_state('INVENTORY_ACQUIRE')
        ready=self._acquire_inventory(hwnd)
        self._domain('INVENTORY_ACQUIRE_RESULT',outcome=ready.outcome.value,ok=ready.ok)
        if not ready.ok:return {'ok':False,'reason':ready.outcome.value,'detail':ready.detail}
        self._inventory_grid=ready.grid; snap=self.core.snapshot_inventory(ready.image,ready.grid); self._inventory_snapshot=snap
        pts=self.store.data.get('points') or {}; recorded=[(f'item{i}',pts.get(f'item{i}')) for i in range(1,MAX_ITEMS+1) if pts.get(f'item{i}')]
        queue=[]; skipped=[]
        if recorded:
            source='RECORDED_ELIGIBLE_SCAN'
            for source_kind,rec in recorded:
                built=self._build_identity_from_point(len(queue)+1,source_kind,list(rec.get('client_point') or []),ready,snap)
                if built.get('ok'):queue.append(built['identity'])
                else:skipped.append(built)
        else:
            source='AUTO_ISOLATED_EQUIPMENT_SCAN'
            for raw in self._discover_isolated_candidates(ready,snap):
                ar,ac=raw['anchor']; fw,fh=raw['footprint']; p=self._cell_point(ready.grid,ar,ac)
                qid=f'Q{len(queue)+1:02d}'; logical=f'{self.session_id}:{qid}'
                ident=CurrentRollItemIdentity(str(self.session_id),qid,logical,f'auto{len(queue)+1}',[ar,ac],[ar,ac],[0,0],[fw,fh],
                                              'AUTO_DISCOVERY_PENDING',_gray_patch_signature(ready.image,p),list(p),list(p),[0,0],
                                              identity_confidence='AUTO_ISOLATED_COMPONENT')
                classified=self._classify_auto_candidate_equipment(hwnd,self._candidate_dict(ident,ready.grid),ready.grid)
                if classified.get('eligible'):
                    ident.item_category=str(classified.get('group_label') or classified.get('group_id') or 'EQUIPMENT'); queue.append(ident)
                    if len(queue)>=MAX_ITEMS:break
                else:skipped.append({'reason':'AUTO_CANDIDATE_NOT_PROVEN_EQUIPMENT','anchor':[ar,ac],'footprint':[fw,fh]})
        if not queue:return {'ok':False,'reason':'NO_ELIGIBLE_ROLL_ITEMS','queue_source':source,'skipped':skipped}
        self.queue.load(queue); self._set_state('QUEUE_BUILD',queue_count=len(queue),queue_source=source)
        self._domain('QUEUE_BUILT',count=len(queue),queue_source=source,
                     queue=[{'queue_id':q.queue_id,'logical_item_id':q.logical_item_id,'anchor':q.current_grid_anchor,'footprint':q.footprint} for q in queue])
        return {'ok':True,'queue_source':source,'skipped':skipped}

    # ------------------------------------------------------------------
    # Evidence / transactions
    # ------------------------------------------------------------------
    def _wait_source_pick_evidence(self,hwnd,point,before_image,before_sig,label):
        deadline=time.monotonic()+self.pacing.ms('pick_confirm_timeout_ms')/1000.0; stable=0; samples=[]; last=None
        threshold=float(self.store.data.get('pick_verify_threshold',6.0) or 6.0)
        while time.monotonic()<deadline:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
            img=self.core.capture_client(int(hwnd)); last=img
            if img is None: time.sleep(self.pacing.ms('verify_poll_ms')/1000.0); continue
            sig=_gray_patch_signature(img,point); mae=_sig_mae(before_sig,sig); changed=mae>=threshold
            stable=stable+1 if changed else 0; samples.append({'mae':round(mae,3),'changed':changed})
            if stable>=self.pacing.stable_frames():return {'ok':True,'state':'PICK_EVIDENCE_CONFIRMED','mae':mae,'samples':samples,'image':img}
            time.sleep(self.pacing.ms('verify_poll_ms')/1000.0)
        # Retry action only when source still looks unchanged AND cursor probe says clear.
        cur_sig=_gray_patch_signature(last,point) if last is not None else []; source_present=_sig_mae(before_sig,cur_sig)<threshold
        cursor={'state':'CURSOR_UNCERTAIN'}; probe=getattr(self.core,'_probe_cursor_attachment',None)
        if callable(probe) and last is not None:
            try:cursor=probe(before_image,last,point)
            except Exception as e:cursor={'state':'CURSOR_UNCERTAIN','error':str(e)}
        clear=str(cursor.get('state') or '').upper() in ('CURSOR_CLEAR','CURSOR_EMPTY_CONFIRMED')
        return {'ok':False,'reason':'PICK_EVIDENCE_UNRESOLVED','source_present':source_present,'cursor_probe':cursor,
                'safe_action_retry':bool(source_present and clear),'samples':samples}

    def _wait_slot_semantic_commit(self,hwnd,point,before_features,label,pick_evidence):
        deadline=time.monotonic()+self.pacing.ms('slot_confirm_timeout_ms')/1000.0; stable=0; samples=[]
        while time.monotonic()<deadline:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
            img=self.core.capture_client(int(hwnd)); features=_slot_features(img,point,self.pacing.ms('slot_evidence_radius_px'))
            ev=_slot_transition_evidence(before_features,features,stable_frames=stable+1)
            if ev.get('committed'):stable+=1
            else:stable=0
            samples.append({'stable':stable,'evidence':ev})
            if stable>=self.pacing.stable_frames():
                return {'ok':True,'state':'OCCUPIED_BY_'+('MATERIAL' if label=='MATERIAL' else 'ITEM'),
                        'stable_frames':stable,'semantic_evidence':ev,'pick_evidence_state':pick_evidence.get('state')}
            time.sleep(self.pacing.ms('verify_poll_ms')/1000.0)
        return {'ok':False,'reason':'PLACE_EVIDENCE_NOT_COMMITTED','samples':samples[-8:]}

    def _reacquire_current_item(self,hwnd,ident,generation):
        reacquire_ns=time.monotonic_ns()
        self._set_state('REACQUIRE_SAME_ITEM',queue_id=ident.queue_id,generation=generation)
        # V1.6.3: reacquire is a repeatable perception transaction, NOT an
        # exactly-once attempt event. Each retry receives its own transaction id.
        reacquire_txn_id='RQ-'+uuid.uuid4().hex[:12].upper()
        self._domain('CURRENT_ITEM_REACQUIRE_START',
                     once_key=f'{self.active_attempt.attempt_id}:{reacquire_txn_id}:START',
                     reacquire_txn_id=reacquire_txn_id)
        max_tries=max(1,min(4,self.pacing.ms('reacquire_attempts'))); threshold=float(self.pacing.ms('identity_signature_max_mae')); margin=float(self.pacing.ms('identity_margin_mae'))
        # FAST happy path: the same logical item is expected at the already locked point.
        # One targeted capture/signature check avoids a full inventory scan; recovery falls back below.
        fast_image=self.core.capture_client(int(hwnd))
        if fast_image is not None and ident.current_client_point and ident.visual_signature:
            fast_mae=_sig_mae(ident.visual_signature,_gray_patch_signature(fast_image,ident.current_client_point))
            if fast_mae<=threshold and self._inventory_grid:
                ident.observation_generation=int(generation)
                self._domain('CURRENT_ITEM_REACQUIRED',
                             once_key=f'{self.active_attempt.attempt_id}:{reacquire_txn_id}:DONE',
                             reacquire_txn_id=reacquire_txn_id,
                             anchor=ident.current_grid_anchor,client_point=ident.current_client_point,visual_mae=round(float(fast_mae),3),fast_path='KNOWN_POINT_SIGNATURE')
                self._metric('item_reacquire_ms',(time.monotonic_ns()-reacquire_ns)/1_000_000.0)
                return {'ok':True,'identity':ident,'grid':self._inventory_grid,'snapshot':self._inventory_snapshot,'fast_path':'KNOWN_POINT_SIGNATURE'}
        for attempt in range(1,max_tries+1):
            if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
            ready=self._acquire_inventory(hwnd,reacquire=True)
            if not ready.ok:
                self._domain('INVENTORY_ACQUIRE_RESULT',outcome=ready.outcome.value,ok=False,reacquire=True,attempt=attempt)
                time.sleep(self.pacing.ms('reader_reread_delay_ms')/1000.0); continue
            grid=ready.grid; snap=self.core.snapshot_inventory(ready.image,grid); occupied=self._occupied_map(snap)
            ar,ac=[int(x) for x in ident.current_grid_anchor]; orow,ocol=[int(x) for x in ident.selection_cell_offset]; expected=[ar+orow,ac+ocol]
            candidates=[]; p=self._cell_point(grid,*expected,ident.cell_offset_px)
            if p and occupied.get(tuple(expected)):
                expected_mae=_sig_mae(ident.visual_signature,_gray_patch_signature(ready.image,p))
                # Hot path: the known current item is still at its expected anchor; avoid full inventory candidate scan.
                if expected_mae<=threshold:
                    ident.current_client_point=list(p); ident.observation_generation=int(generation)
                    self._inventory_grid=grid; self._inventory_snapshot=snap
                    self._domain('CURRENT_ITEM_REACQUIRED',
                                 once_key=f'{self.active_attempt.attempt_id}:{reacquire_txn_id}:DONE',
                                 reacquire_txn_id=reacquire_txn_id,
                                 anchor=ident.current_grid_anchor,client_point=ident.current_client_point,visual_mae=round(float(expected_mae),3),fast_path=True)
                    self._metric('item_reacquire_ms',(time.monotonic_ns()-reacquire_ns)/1_000_000.0)
                    return {'ok':True,'identity':ident,'grid':grid,'snapshot':snap,'fast_path':True}
                candidates.append({'mae':expected_mae,'cell':expected,'point':p,'same_anchor':True})
            for (r,c),occ in occupied.items():
                if not occ or [r,c]==expected:continue
                cp=self._cell_point(grid,r,c,ident.cell_offset_px)
                if cp:candidates.append({'mae':_sig_mae(ident.visual_signature,_gray_patch_signature(ready.image,cp)),'cell':[r,c],'point':cp,'same_anchor':False})
            candidates.sort(key=lambda x:(float(x['mae']),0 if x['same_anchor'] else 1,x['cell']))
            if candidates:
                best=candidates[0]; second=candidates[1] if len(candidates)>1 else None
                decisive=best['mae']<=threshold and (second is None or float(second['mae'])-float(best['mae'])>=margin or best['same_anchor'])
                if decisive:
                    sel=best['cell']; ident.current_grid_anchor=[sel[0]-orow,sel[1]-ocol]; ident.current_client_point=list(best['point']); ident.observation_generation=int(generation)
                    self._inventory_grid=grid; self._inventory_snapshot=snap
                    self._domain('CURRENT_ITEM_REACQUIRED',
                                 once_key=f'{self.active_attempt.attempt_id}:{reacquire_txn_id}:DONE',
                                 reacquire_txn_id=reacquire_txn_id,
                                 anchor=ident.current_grid_anchor,client_point=ident.current_client_point,visual_mae=round(float(best['mae']),3))
                    self._metric('item_reacquire_ms',(time.monotonic_ns()-reacquire_ns)/1_000_000.0)
                    return {'ok':True,'identity':ident,'grid':grid,'snapshot':snap}
            time.sleep(self.pacing.ms('reader_reread_delay_ms')/1000.0)
        self._metric('item_reacquire_ms',(time.monotonic_ns()-reacquire_ns)/1_000_000.0)
        return {'ok':False,'reason':'CURRENT_ITEM_LOST'}

    def _roll_slot_synthetic_grid(self, point, cell_px=32):
        """Create a temporary 6x10 lattice whose [0,0] cell centers on Roll item slot.

        The shared Final6 reader only needs a grid to generate safe hover points.
        This synthetic grid lets AutoRoll reuse the canonical reader/Filter truth
        without modifying Stage16/Stage17 or pretending the Roll slot is Player Bag.
        """
        if not point or len(point) < 2:
            return {}
        cx, cy = int(point[0]), int(point[1])
        cell = max(24, min(42, int(cell_px)))
        x0 = cx - cell // 2
        y0 = cy - cell // 2
        return {
            'ok': True,
            'x_lines': [x0 + i*cell for i in range(7)],
            'y_lines': [y0 + i*cell for i in range(11)],
            'source': 'AUTOROLL_ROLL_SLOT_SYNTHETIC_GRID',
            'confidence': 1.0,
        }

    def _roll_slot_candidate(self, ident):
        fw, fh = [max(1, int(x)) for x in (ident.footprint or [1,1])]
        # Actual hover cell is [0,0]; preserve true footprint only for group/filter identity.
        return {
            'candidate_id': 1,
            'cells': [[0,0]],
            'geometric_cells': [[0,0]],
            'anchor': [0,0],
            'footprint': [fw,fh],
            'cell_count': 1,
            'confidence': .99,
            'queue_id': ident.queue_id,
            'status': 'PENDING',
            'decision': 'PENDING',
            'group_id': None,
            'group_label': None,
            'group_confidence': 0.0,
        }

    def _read_current_item_at_roll_slot_once(self, hwnd, ident, generation):
        """Read the rolled item directly from ROLL_ITEM_SLOT using canonical Final6.

        This is the critical V1.6.4 owner path. After pick->place->Roll, the item
        may remain in the Roll slot. V1.6.3 incorrectly searched Player Bag only.
        """
        if int(generation) != int(self.attempt_generation):
            return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,'reason':'STALE_EVIDENCE'}
        slot = self._point('item_slot')
        if not slot:
            return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,'reason':'ROLL_ITEM_SLOT_NOT_CONFIGURED'}
        grid = self._roll_slot_synthetic_grid(slot)
        if not grid:
            return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,'reason':'ROLL_ITEM_SLOT_GRID_FAILED'}
        candidate = self._roll_slot_candidate(ident)

        old_q=self.api._new_item_queue
        old_results=self.api._queue_read_results
        old_grid=self.api._inventory_grid
        try:
            self.api._new_item_queue=[copy.deepcopy(candidate)]
            self.api._queue_read_results=[]
            self.api._inventory_grid=grid
            reader_ns=time.monotonic_ns()
            read=self.api._read_queue_item_internal(int(hwnd),0,batch_session=True,execution_mode='READER_TEST')
            self._metric('final6_reader_ms',(time.monotonic_ns()-reader_ns)/1_000_000.0)

            reason=str(read.get('reason') or '')
            tooltip_found = reason != 'TOOLTIP_NOT_FOUND_ON_ITEM'
            evidence_id='EVID-'+uuid.uuid4().hex[:12].upper()
            evidence={
                'evidence_id':evidence_id,
                'current_item_id':ident.logical_item_id,
                'generation':int(generation),
                'timestamp':time.time(),
                'owner':'ROLL_ITEM_SLOT',
            }
            if self.current_item is not ident or ident.logical_item_id!=evidence['current_item_id'] or int(self.attempt_generation)!=generation:
                return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,'reason':'STALE_EVIDENCE','evidence':evidence}

            filter_ns=time.monotonic_ns()
            result=self.filter_adapter.evaluate(read,None,ident.queue_id,generation,evidence_id)
            self._metric('filter_ms',(time.monotonic_ns()-filter_ns)/1_000_000.0)

            if tooltip_found:
                ident.current_owner='ROLL_ITEM_SLOT'
                ident.observation_generation=int(generation)
                self._domain('POST_ROLL_ITEM_OWNER_RESOLVED',
                             owner='ROLL_ITEM_SLOT',
                             queue_id=ident.queue_id,
                             client_point=list(slot),
                             evidence='TOOLTIP_PRESENT_AT_ROLL_ITEM_SLOT')

            if result.verdict != FilterVerdict.UNRESOLVED:
                self.active_attempt.result_evidence_id=evidence_id
                self._domain('FINAL6_RESOLVED',
                             once_key=f'{self.active_attempt.attempt_id}:FINAL6_RESOLVED',
                             evidence_id=evidence_id,queue_id=ident.queue_id,generation=generation,
                             final6_source='ROLL_ITEM_SLOT_TOOLTIP')

            return {
                'ok':bool(read.get('ok')),
                'verdict':result.verdict,
                'read':read,
                'filter_result':asdict(result),
                'evidence':evidence,
                'tooltip_found':bool(tooltip_found),
                'owner':'ROLL_ITEM_SLOT' if tooltip_found else None,
                'reason':reason or (result.reason if hasattr(result,'reason') else None),
            }
        finally:
            self.api._new_item_queue=old_q
            self.api._queue_read_results=old_results
            self.api._inventory_grid=old_grid

    @staticmethod
    def _read_reason(rd):
        if not isinstance(rd,dict):
            return ''
        if rd.get('reason'):
            return str(rd.get('reason'))
        read=rd.get('read')
        if isinstance(read,dict) and read.get('reason'):
            return str(read.get('reason'))
        last=rd.get('last')
        if isinstance(last,dict):
            return AutoRollSessionController._read_reason(last)
        return ''

    def _scaled_recorded_point_for_live_capture(self, kind, image):
        rec=self._point_rec(kind)
        p=list(rec.get('client_point') or [])
        rs=list(rec.get('recorded_client_size') or rec.get('client_size') or [])
        if image is None or len(p)!=2:
            return None
        if len(rs)==2 and int(rs[0])>0 and int(rs[1])>0:
            sx=float(image.width)/float(rs[0]); sy=float(image.height)/float(rs[1])
            return [int(round(float(p[0])*sx)),int(round(float(p[1])*sy))]
        return [int(p[0]),int(p[1])]

    def _roll_ui_scene_guard(self, hwnd, require_empty_item_slot=False):
        """Fail-closed proof that recorded Roll UI is really under destination coordinates.

        V1.6.5 only checked that recorded points were inside the client rectangle.
        That is not sufficient: if Roll UI is closed/moved, clicking the old
        `item_slot` coordinate while an item is attached to the cursor can drop
        the weapon onto the world.

        This guard performs no input. It compares live patches against the
        signatures captured when points were recorded.
        """
        img=self.core.capture_client(int(hwnd))
        if img is None:
            return {'ok':False,'reason':'ROLL_UI_SCENE_CAPTURE_FAILED'}

        anchors=['material_slot','roll_button']
        if require_empty_item_slot:
            anchors.insert(0,'item_slot')

        threshold=max(42.0,float(self.pacing.ms('identity_signature_max_mae'))+12.0)
        checks=[]
        for kind in anchors:
            rec=self._point_rec(kind)
            sig=list(rec.get('signature') or [])
            p=self._scaled_recorded_point_for_live_capture(kind,img)
            if not sig or p is None:
                continue
            live=_gray_patch_signature(img,p)
            mae=_sig_mae(sig,live)
            checks.append({'kind':kind,'mae':round(float(mae),3),'match':bool(mae<=threshold),'point':list(p)})

        if require_empty_item_slot:
            item_check=next((x for x in checks if x['kind']=='item_slot'),None)
            if not item_check or not item_check.get('match'):
                return {'ok':False,'reason':'ROLL_ITEM_SLOT_EMPTY_STATE_NOT_PROVEN',
                        'threshold':threshold,'checks':checks}

        matches=sum(1 for x in checks if x.get('match'))
        required=2 if len(checks)>=2 else 1
        ok=bool(checks and matches>=required)
        return {
            'ok':ok,
            'reason':None if ok else 'ROLL_UI_SCENE_NOT_PROVEN_NO_CLICK',
            'matches':matches,'required':required,'threshold':threshold,'checks':checks
        }

    def _live_bag_cell_truth(self, hwnd, ident, require_empty=False):
        """Resolve the original/current item cell from the LIVE Player Bag grid.

        Never trusts stale recorded client pixels for a destructive item move.
        """
        ready=self._acquire_inventory(int(hwnd),reacquire=True)
        if not ready.ok:
            return {'ok':False,'reason':'PLAYER_BAG_NOT_PROVEN_NO_CLICK','detail':ready.detail}

        grid=ready.grid
        image=ready.image
        snap=self.core.snapshot_inventory(image,grid)
        occupied=self._occupied_map(snap)

        top_left=list(ident.original_grid_anchor or ident.current_grid_anchor or [])
        sel=list(ident.selection_cell_offset or [0,0])
        if len(top_left)!=2 or len(sel)!=2:
            return {'ok':False,'reason':'ITEM_GRID_IDENTITY_MISSING'}

        selection_cell=[int(top_left[0])+int(sel[0]),int(top_left[1])+int(sel[1])]
        point=self._cell_point(grid,selection_cell[0],selection_cell[1],ident.cell_offset_px)
        if point is None:
            return {'ok':False,'reason':'ITEM_BAG_DESTINATION_OUTSIDE_LIVE_GRID',
                    'selection_cell':selection_cell}

        if require_empty:
            fw,fh=[max(1,int(x)) for x in (ident.footprint or [1,1])]
            cells=[]
            for rr in range(int(top_left[0]),int(top_left[0])+fh):
                for cc in range(int(top_left[1]),int(top_left[1])+fw):
                    cells.append((rr,cc))
            blocked=[list(rc) for rc in cells if occupied.get(rc)]
            if blocked:
                return {'ok':False,'reason':'ITEM_BAG_DESTINATION_OCCUPIED_NO_CLICK',
                        'blocked_cells':blocked,'selection_cell':selection_cell}

        return {
            'ok':True,'ready':ready,'grid':grid,'snapshot':snap,
            'point':list(point),'selection_cell':selection_cell,
            'occupied':occupied,
        }

    def _prepare_initial_item_move(self, hwnd, ident):
        """Pre-pick guard for Player Bag -> Roll item slot.

        Both owners must be proven BEFORE the weapon leaves the bag.
        """
        bag=self._live_bag_cell_truth(hwnd,ident,require_empty=False)
        if not bag.get('ok'):
            return bag

        cell=tuple(bag.get('selection_cell') or [])
        if len(cell)!=2 or not bag.get('occupied',{}).get(cell):
            return {'ok':False,'reason':'ITEM_SOURCE_NOT_OCCUPIED_NO_CLICK','cell':list(cell)}

        roll=self._roll_ui_scene_guard(hwnd,require_empty_item_slot=True)
        if not roll.get('ok'):
            return roll

        # Use live grid coordinates rather than stale recorded client pixels.
        ident.current_client_point=list(bag['point'])
        self._inventory_grid=bag['grid']
        self._inventory_snapshot=bag['snapshot']

        return {
            'ok':True,
            'source_target':InteractionTarget.client(
                'ITEM_SOURCE',list(bag['point']),self.pacing.ms('default_safe_radius_px'),
                [int(bag['ready'].image.width),int(bag['ready'].image.height)]
            ),
            'destination_target':self._target('item_slot',target_type='ROLL_ITEM_SLOT'),
            'bag':bag,'roll':roll,
        }

    def _rollback_picked_item_to_source(self, hwnd, source_target, action_prefix):
        """Best-effort safe rollback after pick if Roll destination loses proof.

        It clicks only the already-proven Player Bag source cell. If Bag proof is
        unavailable, it performs NO click; this is safer than a possible world drop.
        """
        probe=self._inventory_presence_probe(int(hwnd),frames=2,settle_ms=45)
        if not probe.get('ok'):
            self._telemetry('ITEM_ROLLBACK_WITHHELD_NO_WORLD_CLICK',
                            reason='PLAYER_BAG_NOT_PROVEN',action_prefix=action_prefix)
            return {'ok':False,'reason':'ROLLBACK_WITHHELD_PLAYER_BAG_NOT_PROVEN','no_click':True}

        grid=(probe.get('ready') or {}).get('grid') or {}
        if self._point_to_cell(source_target.center,grid) is None:
            self._telemetry('ITEM_ROLLBACK_WITHHELD_NO_WORLD_CLICK',
                            reason='SOURCE_OUTSIDE_LIVE_BAG_GRID',action_prefix=action_prefix)
            return {'ok':False,'reason':'ROLLBACK_WITHHELD_SOURCE_OUTSIDE_BAG','no_click':True}

        rb=self.input_dispatcher.click(
            int(hwnd),source_target,f'{action_prefix}:ROLLBACK_SOURCE',
            'ITEM_ROLLBACK_TO_BAG_SOURCE'
        )
        self._telemetry('ITEM_ROLLBACK_TO_SOURCE',ok=bool(rb.get('ok')),
                        action_prefix=action_prefix,detail=rb)
        return {'ok':bool(rb.get('ok')),'detail':rb}

    def _guarded_return_roll_item_to_bag(self, hwnd, ident, event_name):
        """Move item Roll slot -> Player Bag only when BOTH UI owners are proven.

        Destination is recalculated from the current live inventory grid. This
        removes the V1.6.5 stale-pixel path that could place the item onto world.
        """
        if str(getattr(ident,'current_owner','PLAYER_BAG')) != 'ROLL_ITEM_SLOT':
            return {'ok':True,'skipped':True,'owner':'PLAYER_BAG'}

        roll=self._roll_ui_scene_guard(int(hwnd),require_empty_item_slot=False)
        if not roll.get('ok'):
            return {'ok':False,'reason':'ROLL_SLOT_OWNER_NOT_PROVEN_NO_CLICK','roll_guard':roll,'no_click':True}

        bag=self._live_bag_cell_truth(int(hwnd),ident,require_empty=True)
        if not bag.get('ok'):
            return {'ok':False,'reason':bag.get('reason','PLAYER_BAG_DESTINATION_NOT_PROVEN_NO_CLICK'),
                    'bag_guard':bag,'no_click':True}

        src=self._target('item_slot',target_type='ROLL_ITEM_SLOT')
        dst=InteractionTarget.client(
            'ITEM_BAG_DESTINATION',list(bag['point']),self.pacing.ms('default_safe_radius_px'),
            [int(bag['ready'].image.width),int(bag['ready'].image.height)]
        )

        txid=f'{self.session_id}:{ident.queue_id}:{event_name}'
        tx=self.pick_place.execute(int(hwnd),src,dst,'ITEM_RETURN',txid)
        if not tx.get('ok'):
            return {'ok':False,'reason':'GUARDED_ITEM_RETURN_FAILED','detail':tx}

        ident.current_owner='PLAYER_BAG'
        ident.current_client_point=list(bag['point'])
        ident.current_grid_anchor=list(ident.original_grid_anchor)
        self._inventory_grid=bag['grid']
        self._inventory_snapshot=bag['snapshot']

        self._domain(event_name,
                     once_key=f'{self.session_id}:{ident.queue_id}:{event_name}',
                     queue_id=ident.queue_id,bag_point=list(bag['point']),
                     evidence=tx.get('place_evidence'))
        return {'ok':True,'owner':'PLAYER_BAG','detail':tx,'bag_point':list(bag['point'])}

    def _safe_recover_item_before_error(self, hwnd, ident, reason):
        """On perception/read failure, recover the weapon to Bag only if safe.

        If safety proof fails, do not click anywhere. The item remains in the
        verified Roll slot/cursor for manual recovery instead of risking a drop.
        """
        if str(getattr(ident,'current_owner','PLAYER_BAG')) != 'ROLL_ITEM_SLOT':
            return {'ok':True,'skipped':True,'owner':getattr(ident,'current_owner','PLAYER_BAG')}

        rr=self._guarded_return_roll_item_to_bag(
            int(hwnd),ident,'ERROR_RECOVERY_ITEM_RETURNED_TO_BAG'
        )
        if rr.get('ok'):
            self._telemetry('ERROR_RECOVERY_ITEM_SAFE',reason=str(reason),owner='PLAYER_BAG')
            return rr

        self._telemetry('ERROR_RECOVERY_NO_WORLD_CLICK',
                        reason=str(reason),recovery=rr,
                        instruction='MANUAL_RECOVERY_REQUIRED')
        return {'ok':False,'reason':'ITEM_SAFE_HOLD_MANUAL_RECOVERY_REQUIRED',
                'no_world_click':True,'detail':rr}

    def _return_accepted_item_to_bag(self, hwnd, ident):
        """V1.6.6 guarded accepted-item return using LIVE Player Bag geometry."""
        if str(getattr(ident,'current_owner','PLAYER_BAG')) != 'ROLL_ITEM_SLOT':
            return {'ok':True,'skipped':True,'owner':'PLAYER_BAG'}
        self._set_state('RETURN_ACCEPTED_ITEM',queue_id=ident.queue_id)
        return self._guarded_return_roll_item_to_bag(
            int(hwnd),ident,'ACCEPTED_ITEM_RETURNED_TO_BAG'
        )

    def _read_current_item_once(self,hwnd,ident,generation):
        if int(generation)!=int(self.attempt_generation):return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,'reason':'STALE_EVIDENCE'}
        candidate=self._candidate_dict(ident,self._inventory_grid or {}); old_q=self.api._new_item_queue; old_results=self.api._queue_read_results; old_grid=self.api._inventory_grid
        previous_park=getattr(self.api,'_autoroll_popup_park_screen',None)
        try:
            self.api._new_item_queue=[copy.deepcopy(candidate)]; self.api._queue_read_results=[]; self.api._inventory_grid=self._inventory_grid
            # Post-Popup truth: item is back in its original Player Bag cell. Hover
            # happens only on that Bag candidate; while OCR/Paddle/Filter processes,
            # the cursor parks at the exact successful Popup click coordinate.
            park=list(self._popup_park_screen or [])
            if len(park)!=2:
                return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,'reason':'ROLL_POPUP_PARK_COORD_NOT_AVAILABLE'}
            self.api._autoroll_popup_park_screen=[int(park[0]),int(park[1])]
            self.core._set_cursor_screen(int(park[0]),int(park[1]))
            reader_ns=time.monotonic_ns(); read=self.api._read_queue_item_internal(int(hwnd),0,batch_session=True,execution_mode='READER_TEST'); self._metric('final6_reader_ms',(time.monotonic_ns()-reader_ns)/1_000_000.0)
            evidence_id='EVID-'+uuid.uuid4().hex[:12].upper(); evidence={'evidence_id':evidence_id,'current_item_id':ident.logical_item_id,'generation':int(generation),'timestamp':time.time(),'owner':'PLAYER_BAG','source_anchor':list(ident.original_grid_anchor)}
            if self.current_item is not ident or ident.logical_item_id!=evidence['current_item_id'] or int(self.attempt_generation)!=generation:
                return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,'reason':'STALE_EVIDENCE','evidence':evidence}
            filter_ns=time.monotonic_ns(); result=self.filter_adapter.evaluate(read,None,ident.queue_id,generation,evidence_id); self._metric('filter_ms',(time.monotonic_ns()-filter_ns)/1_000_000.0)
            if result.verdict != FilterVerdict.UNRESOLVED:
                self.active_attempt.result_evidence_id=evidence_id
                self._domain('FINAL6_RESOLVED',once_key=f'{self.active_attempt.attempt_id}:FINAL6_RESOLVED',
                             evidence_id=evidence_id,queue_id=ident.queue_id,generation=generation,final6_source='ORIGINAL_PLAYER_BAG_ITEM_TOOLTIP')
            return {'ok':bool(read.get('ok')),'verdict':result.verdict,'read':read,'filter_result':asdict(result),'evidence':evidence,'owner':'PLAYER_BAG'}
        finally:
            try:
                park=list(self._popup_park_screen or [])
                if len(park)==2:self.core._set_cursor_screen(int(park[0]),int(park[1]))
                if previous_park is None:
                    try: delattr(self.api,'_autoroll_popup_park_screen')
                    except Exception: pass
                else:self.api._autoroll_popup_park_screen=previous_park
            finally:
                self.api._new_item_queue=old_q; self.api._queue_read_results=old_results; self.api._inventory_grid=old_grid

    def _read_current_item_with_recovery(self,hwnd,ident,generation):
        """Re-read the SAME rolled item only at its original Player Bag location.

        Game contract for this build: once Popup is clicked, the rolled item has
        returned to its old Bag cell. ROLL_ITEM_SLOT is therefore not an owner/read
        candidate after Popup. Read instability remains non-destructive and retries
        the same Bag item until ACCEPT/REJECT, USER_STOP, or repeated physical loss.
        """
        retries=max(1,min(3,self.pacing.ms('perception_retries')))
        last=None; batch=0; owner_loss_attempts=0
        while True:
            batch+=1; saw_tooltip_this_batch=False
            for perception_attempt in range(1,retries+1):
                if self._cancelled():
                    return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,'reason':'USER_STOP'}

                # Authoritative post-Popup location = the item's original Bag cell.
                ident.current_owner='PLAYER_BAG'
                ident.current_grid_anchor=list(ident.original_grid_anchor)
                ident.current_client_point=list(ident.original_client_point)

                reacq=self._reacquire_current_item(hwnd,ident,generation)
                if not reacq.get('ok'):
                    owner_loss_attempts+=1; last=reacq
                    self._telemetry('POST_POPUP_ORIGINAL_BAG_ITEM_REACQUIRE_RETRY',queue_id=ident.queue_id,
                                    generation=generation,attempt=perception_attempt,batch=batch,
                                    owner='PLAYER_BAG',source_anchor=list(ident.original_grid_anchor),
                                    reason=str(reacq.get('reason') or 'CURRENT_ITEM_LOST'))
                    time.sleep(self.pacing.ms('reader_reread_delay_ms')/1000.0)
                    continue

                # Reacquire may update live pixel geometry, but ownership/anchor is
                # still the same original logical Bag item; Roll-slot probing is forbidden.
                ident.current_owner='PLAYER_BAG'
                rd=self._read_current_item_once(hwnd,ident,generation)
                last=rd
                read_obj=rd.get('read') if isinstance(rd,dict) else None
                if isinstance(read_obj,dict) and str(read_obj.get('reason') or '')!='TOOLTIP_NOT_FOUND_ON_ITEM':
                    saw_tooltip_this_batch=True; owner_loss_attempts=0
                if rd.get('verdict') in (FilterVerdict.ACCEPT,FilterVerdict.REJECT):
                    ident.current_owner='PLAYER_BAG'
                    return rd
                self._telemetry('PERCEPTION_RETRY',queue_id=ident.queue_id,generation=generation,
                                attempt=perception_attempt,batch=batch,
                                reason=self._read_reason(rd) or 'FINAL6_UNRESOLVED',owner='PLAYER_BAG',
                                source_anchor=list(ident.original_grid_anchor),roll_slot_probe=False)
                time.sleep(self.pacing.ms('reader_reread_delay_ms')/1000.0)

            if saw_tooltip_this_batch:
                self._set_state('FILTER_RECHECK_SAME_ITEM',queue_id=ident.queue_id,
                                batch=batch,attempt=ident.roll_attempt)
                self._telemetry('FILTER_RECHECK_SAME_ITEM_CONTINUE',queue_id=ident.queue_id,
                                generation=generation,batch=batch,destructive_input_count=0,
                                owner='PLAYER_BAG',source_anchor=list(ident.original_grid_anchor),
                                roll_slot_probe=False,last_reason=self._read_reason(last) or 'FINAL6_UNRESOLVED')
                time.sleep(max(0.35,self.pacing.ms('reader_reread_delay_ms')/1000.0))
                continue

            owner_loss_limit=max(6,retries*3)
            if owner_loss_attempts >= owner_loss_limit:
                return {'ok':False,'verdict':FilterVerdict.UNRESOLVED,
                        'reason':'CURRENT_ITEM_LOST','last':last,'owner_loss_attempts':owner_loss_attempts,
                        'expected_owner':'PLAYER_BAG','expected_anchor':list(ident.original_grid_anchor)}
            self._set_state('FILTER_RECHECK_SAME_ITEM',queue_id=ident.queue_id,
                            batch=batch,attempt=ident.roll_attempt,reason='TRANSIENT_READ_UNSTABLE')
            self._telemetry('FILTER_RECHECK_SAME_ITEM_CONTINUE',queue_id=ident.queue_id,
                            generation=generation,batch=batch,destructive_input_count=0,
                            owner_loss_attempts=owner_loss_attempts,owner='PLAYER_BAG',
                            source_anchor=list(ident.original_grid_anchor),roll_slot_probe=False,
                            last_reason=self._read_reason(last) or 'FINAL6_UNRESOLVED')
            time.sleep(max(0.35,self.pacing.ms('reader_reread_delay_ms')/1000.0))
            continue

    # ------------------------------------------------------------------
    # Roll attempt / exact wait / popup / invariant
    # ------------------------------------------------------------------
    def _wait_until_deadline_ns(self,deadline_ns,clock_ns=time.monotonic_ns,sleeper=time.sleep):
        while True:
            if self._cancelled():return {'ok':False,'reason':'USER_STOP_DURING_ROLL_WAIT_4S'}
            now=int(clock_ns())
            if now>=int(deadline_ns):return {'ok':True,'now_ns':now,'deadline_ns':int(deadline_ns)}
            remain=int(deadline_ns)-now; sleeper(min(.05,max(.0005,remain/1_000_000_000.0)))

    def _trigger_roll_and_wait(self,hwnd,attempt):
        target=self._target('roll_button',target_type='ROLL_BUTTON')
        pre=self.core.capture_client(int(hwnd))
        if pre is None:return {'ok':False,'reason':'CAPTURE_FAILED_PRE_ROLL'}
        action=f'{attempt.attempt_id}:ROLL'
        r=self.input_dispatcher.click(hwnd,target,action,'ROLL_BUTTON')
        if not r.get('ok'):return {'ok':False,'reason':'ROLL_ACTION_NOT_STARTED','detail':r}
        roll_ev=self._domain('ROLL_TRIGGERED',once_key=f'{attempt.attempt_id}:ROLL_TRIGGERED',action_id=action)
        if self._last_filter_reject_ns is not None:
            self._metric('reject_to_next_roll_ms',(time.monotonic_ns()-self._last_filter_reject_ns)/1_000_000.0)
            self._last_filter_reject_ns=None
        attempt.roll_trigger_event_seq=roll_ev.event_seq
        # The 4.0s domain window is measured from the physical mouse-UP that
        # committed the Roll input, not from a later callback/post-click settle.
        start_ns=int(r.get('mouse_up_ns') or time.monotonic_ns()); deadline=start_ns+ROLL_WAIT_NS
        self._set_state('WAIT_RESULT_4S',attempt_id=attempt.attempt_id)
        self._domain('ROLL_WAIT_START',once_key=f'{attempt.attempt_id}:ROLL_WAIT_START',requested_ms=4000,roll_commit_ns=start_ns,deadline_ns=deadline)
        waited=self._wait_until_deadline_ns(deadline)
        if not waited.get('ok'):return waited
        actual_ns=time.monotonic_ns(); elapsed_ms=(actual_ns-start_ns)/1_000_000.0
        if elapsed_ms < 4000.0:
            return {'ok':False,'reason':'ROLL_WAIT_CONTRACT_VIOLATION','elapsed_ms':elapsed_ms}
        self._domain('ROLL_WAIT_COMPLETE',once_key=f'{attempt.attempt_id}:ROLL_WAIT_COMPLETE',requested_ms=4000,actual_ms=round(elapsed_ms,3))
        return {'ok':True,'actual_ms':elapsed_ms,'pre_image':pre}

    def _popup_fire_and_forget(self,hwnd,attempt):
        if attempt.popup_dismissed:return {'ok':False,'reason':'POPUP_DISMISS_DUPLICATE_BLOCKED'}
        target=self._target('popup',target_type='POPUP_DISMISS')
        if target is None:return {'ok':False,'reason':'ROLL_POPUP_COORD_NOT_CONFIGURED'}
        action=f'{attempt.attempt_id}:POPUP_DISMISS'
        r=self.input_dispatcher.click(hwnd,target,action,'POPUP_DISMISS')
        if not r.get('ok'):return {'ok':False,'reason':'POPUP_DISMISS_INPUT_FAILED','detail':r}
        click_screen=list(r.get('center_screen') or [])
        click_client=list(r.get('center_client') or target.center or [])
        if len(click_screen)!=2:
            return {'ok':False,'reason':'ROLL_POPUP_PARK_COORD_NOT_AVAILABLE','detail':r}
        self._popup_park_screen=[int(click_screen[0]),int(click_screen[1])]
        self._popup_park_client=[int(click_client[0]),int(click_client[1])] if len(click_client)==2 else None
        self.core._set_cursor_screen(int(click_screen[0]),int(click_screen[1]))
        attempt.popup_dismissed=True
        self._domain('POPUP_DISMISS_SENT',once_key=f'{attempt.attempt_id}:POPUP_DISMISS_SENT',client_point=target.center,verify_close=False,fire_and_forget=True)
        self._telemetry('AUTOROLL_CURSOR_PARK_POPUP_COORD',attempt_id=attempt.attempt_id,
                        client_point=list(self._popup_park_client or []),screen_point=list(self._popup_park_screen),
                        post_popup_item_owner='PLAYER_BAG')
        return {'ok':True,'fire_and_forget':True,'verify_close':False,
                'park_screen':list(self._popup_park_screen),'park_client':list(self._popup_park_client or []),
                'post_popup_item_owner':'PLAYER_BAG'}

    def _new_attempt(self,ident):
        self.attempt_generation += 1; ident.roll_attempt += 1; ident.observation_generation=self.attempt_generation; ident.status='ACTIVE'
        attempt=RollAttemptContext(str(self.session_id),ident.queue_id,ident.logical_item_id,'A-'+uuid.uuid4().hex[:12].upper(),
                                   self.attempt_generation,self.ledger.last_seq+1)
        self.active_attempt=attempt; self._set_state('BEGIN_ATTEMPT',queue_id=ident.queue_id,attempt=ident.roll_attempt)
        self._domain('ATTEMPT_BEGIN',once_key=f'{attempt.attempt_id}:ATTEMPT_BEGIN',attempt_number=ident.roll_attempt,logical_item_id=ident.logical_item_id)
        return attempt

    def _get_material_target_fast(self, hwnd):
        point=self._point('material')
        if not point:
            return None
        cached=self._material_source_cache
        if cached.get('valid') and cached.get('config_point')==list(point) and cached.get('target') is not None:
            return cached.get('target')
        target=self._target('material',target_type='MATERIAL_SOURCE')
        cached.update({'target':target,'config_point':list(point),'valid':bool(target),'generation':int(cached.get('generation') or 0)+1})
        return target

    def _invalidate_material_cache(self, reason='UNKNOWN'):
        self._material_source_cache.update({'valid':False,'target':None,'generation':int(self._material_source_cache.get('generation') or 0)+1,'invalid_reason':str(reason)})

    def _execute_one_roll_attempt(self,hwnd,ident):
        attempt=self._new_attempt(ident); generation=attempt.attempt_generation
        if self.queue.current() is not ident or ident.logical_item_id!=attempt.logical_item_id:
            return {'ok':False,'reason':'CURRENT_ITEM_IDENTITY_CORRUPTED'}
        attempt_started_ns=time.monotonic_ns()
        self._set_state('PLACE_ITEM')
        # The previous Roll has already returned the item to its original Player Bag
        # cell after Popup. Every new attempt therefore starts from Player Bag again;
        # never reuse or click an assumed item in ROLL_ITEM_SLOT.
        ident.current_owner='PLAYER_BAG'
        ident.current_grid_anchor=list(ident.original_grid_anchor)
        prepared=self._prepare_initial_item_move(hwnd,ident)
        if not prepared.get('ok'):
            return {'ok':False,'reason':prepared.get('reason','ITEM_MOVE_PRECHECK_FAILED'),
                    'detail':prepared,'world_click_blocked':True}
        src_target=prepared.get('source_target')
        dst_target=prepared.get('destination_target')
        if src_target is None or dst_target is None:
            return {'ok':False,'reason':'ITEM_MOVE_TARGET_NOT_PROVEN','world_click_blocked':True}
        phase_ns=time.monotonic_ns()
        item_tx=self.pick_place.execute(hwnd,src_target,dst_target,'ITEM',f'{attempt.attempt_id}:ITEM')
        self._metric('item_pick_place_ms',(time.monotonic_ns()-phase_ns)/1_000_000.0)
        if not item_tx.get('ok'):
            return {'ok':False,'reason':'ITEM_PLACEMENT_FAILED','detail':item_tx}
        self._domain('ITEM_PLACED',once_key=f'{attempt.attempt_id}:ITEM_PLACED',
                     evidence=item_tx.get('place_evidence'))
        self._set_state('PLACE_MATERIAL')
        material_find_ns=time.monotonic_ns(); mat_src=self._get_material_target_fast(hwnd); self._metric('material_find_ms',(time.monotonic_ns()-material_find_ns)/1_000_000.0); mat_dst=self._target('material_slot',target_type='ROLL_MATERIAL_SLOT')
        phase_ns=time.monotonic_ns(); mat_tx=self.pick_place.execute(hwnd,mat_src,mat_dst,'MATERIAL',f'{attempt.attempt_id}:MATERIAL'); self._metric('material_pick_place_ms',(time.monotonic_ns()-phase_ns)/1_000_000.0)
        if not mat_tx.get('ok'):
            self._invalidate_material_cache(mat_tx.get('reason') or 'MATERIAL_TRANSACTION_FAILED')
            reason='MATERIAL_EXHAUSTED' if 'PICK_NOT_COMMITTED' in str(mat_tx.get('reason')) else 'MATERIAL_PLACEMENT_FAILED'
            return {'ok':False,'reason':reason,'detail':mat_tx}
        attempt.material_identity='CACHED_RECORDED_MATERIAL_SOURCE' if self._material_source_cache.get('valid') else 'RECORDED_MATERIAL_SOURCE'
        self._domain('MATERIAL_PLACED',once_key=f'{attempt.attempt_id}:MATERIAL_PLACED',evidence=mat_tx.get('place_evidence'))
        self._set_state('TRIGGER_ROLL')
        phase_ns=time.monotonic_ns(); roll=self._trigger_roll_and_wait(hwnd,attempt); self._metric('roll_wait_ms',(time.monotonic_ns()-phase_ns)/1_000_000.0)
        if not roll.get('ok'):return roll
        self.total_rolls += 1
        phase_ns=time.monotonic_ns(); popup=self._popup_fire_and_forget(hwnd,attempt); self._metric('popup_dispatch_ms',(time.monotonic_ns()-phase_ns)/1_000_000.0)
        if not popup.get('ok'):return popup
        if self._cancelled():return {'ok':False,'reason':'USER_STOP'}
        # Game truth after Popup: rolled item has returned to its original Player Bag cell.
        ident.current_owner='PLAYER_BAG'
        ident.current_grid_anchor=list(ident.original_grid_anchor)
        ident.current_client_point=list(ident.original_client_point)
        self._domain('POST_POPUP_ITEM_OWNER_RESET',once_key=f'{attempt.attempt_id}:POST_POPUP_ITEM_OWNER_RESET',
                     owner='PLAYER_BAG',source_anchor=list(ident.original_grid_anchor),
                     source_client_point=list(ident.original_client_point),roll_slot_probe=False)
        phase_ns=time.monotonic_ns(); rd=self._read_current_item_with_recovery(hwnd,ident,generation); self._metric('item_reacquire_final6_filter_ms',(time.monotonic_ns()-phase_ns)/1_000_000.0)
        verdict=rd.get('verdict',FilterVerdict.UNRESOLVED)
        if verdict == FilterVerdict.UNRESOLVED:return {'ok':False,'reason':rd.get('reason') or 'FINAL6_UNRESOLVED','read':rd}
        self._set_state('FILTER')
        self.active_attempt.filter_verdict=verdict.value
        self._domain('FILTER_ACCEPT' if verdict==FilterVerdict.ACCEPT else 'FILTER_REJECT',
                     once_key=f'{attempt.attempt_id}:FILTER_VERDICT',evidence_id=attempt.result_evidence_id)
        self._domain('ATTEMPT_COMMITTED',once_key=f'{attempt.attempt_id}:ATTEMPT_COMMITTED',verdict=verdict.value)
        invariant=self.validator.validate(self.ledger.events_for_attempt(attempt.attempt_id),verdict)
        if not invariant.get('ok'):
            return {'ok':False,'reason':'ROLL_ATTEMPT_INVARIANT_VIOLATION','invariant':invariant}
        self._metric('attempt_total_ms',(time.monotonic_ns()-attempt_started_ns)/1_000_000.0)
        return {'ok':True,'verdict':verdict,'read':rd,'attempt_id':attempt.attempt_id,'generation':generation}

    # ------------------------------------------------------------------
    # Focus / runner
    # ------------------------------------------------------------------
    def _focus_client(self,hwnd):
        wr=self.core._window_rect(int(hwnd)); co=self.core._client_origin_screen(int(hwnd))
        if not wr or not co:return {'ok':False,'reason':'WINDOW_GEOMETRY_FAILED'}
        left,top,right,bottom=[int(x) for x in wr]; client_x,client_y=[int(x) for x in co]; caption_h=client_y-top
        if caption_h<8:return {'ok':False,'reason':'FOCUS_CLICK_UNAVAILABLE'}
        x=left+max(70,min(220,(right-left)//3)); x=min(x,right-150); y=top+max(4,min(caption_h-3,caption_h//2))
        target=InteractionTarget.screen('CLIENT_FOCUS',[x,y],8)
        r=self.input_dispatcher.click(int(hwnd),target,f'{self.session_id}:FOCUS','CLIENT_FOCUS',require_foreground=False)
        if not r.get('ok'):return r
        foreground=int(self.core.user32_bridge.GetForegroundWindow() or 0)
        if foreground!=int(hwnd):return {'ok':False,'reason':'FOCUS_HANDSHAKE_FAILED','foreground_hwnd':foreground}
        time.sleep(self.pacing.ms('focus_settle_ms')/1000.0); return {'ok':True,'foreground_hwnd':foreground}

    def _run_test_one(self,hwnd):
        try:
            self._set_state('CLIENT_ACQUIRE'); focus=self._focus_client(hwnd)
            if not focus.get('ok'):
                self._enter_error(self._error_envelope(focus.get('reason','CLIENT_NOT_READY'),'InputDispatcher',focus)); return
            ready=self._acquire_inventory(hwnd)
            if not ready.ok:
                self._enter_error(self._error_envelope(ready.outcome.value,'InventoryAcquire',ready.detail)); return
            snap=self.core.snapshot_inventory(ready.image,ready.grid); p=self._point('item1'); built=self._build_identity_from_point(1,'item1',p,ready,snap)
            if not built.get('ok'):
                self._enter_error(self._error_envelope(built.get('reason','CURRENT_ITEM_LOST'),'RollItemQueue',built)); return
            ident=built['identity']; self.queue.load([ident]); self.queue.activate(0); attempt=self._new_attempt(ident)
            item_tx=self.pick_place.execute(hwnd,self._target('item1',point=ident.current_client_point,target_type='ITEM_SOURCE'),self._target('item_slot',target_type='ROLL_ITEM_SLOT'),'ITEM',f'{attempt.attempt_id}:ITEM')
            if not item_tx.get('ok'):
                self._enter_error(self._error_envelope('ITEM_PLACEMENT_FAILED','PickPlaceTransaction',item_tx)); return
            self._domain('ITEM_PLACED',once_key=f'{attempt.attempt_id}:ITEM_PLACED',evidence=item_tx.get('place_evidence'))
            self._set_state('TEST_ITEM_SLOT_CONFIRMED')
        except Exception as e:
            self._enter_error(self._error_envelope('FATAL_RUNTIME_ERROR','AutoRollSessionController',{},False,e))
        finally:
            self.active_attempt=None; self._set_roll_running_flag(False)

    def _run_full(self,hwnd):
        try:
            self._set_state('CLIENT_ACQUIRE'); focus=self._focus_client(hwnd)
            if not focus.get('ok'):
                self._enter_error(self._error_envelope(focus.get('reason','CLIENT_NOT_READY'),'InputDispatcher',focus)); return
            self._set_state('ROLL_UI_VERIFY'); cap=self.core.capture_client(int(hwnd))
            if cap is None:
                self._enter_error(self._error_envelope('ROLL_UI_NOT_FOUND','RollUIVerify')); return
            for key in REQUIRED_FULL:
                p=self._point(key)
                if not p or not (0<=p[0]<int(cap.width) and 0<=p[1]<int(cap.height)):
                    self._enter_error(self._error_envelope('ROLL_UI_NOT_FOUND','RollUIVerify',{'invalid_point':key})); return
            scene=self._roll_ui_scene_guard(int(hwnd),require_empty_item_slot=True)
            if not scene.get('ok'):
                self._enter_error(self._error_envelope(
                    'ROLL_UI_SCENE_NOT_PROVEN_NO_ITEM_PICK','RollUIVerify',
                    {'guard':scene,'world_click_blocked':True}
                )); return
            qb=self._build_roll_item_queue(hwnd)
            if not qb.get('ok'):
                self._enter_error(self._error_envelope(qb.get('reason','INVENTORY_GRID_NOT_FOUND'),'RollItemQueue',qb)); return
            for idx in range(len(self.queue.items)):
                if self._cancelled():self._set_state('STOPPED'); return
                ident=self.queue.activate(idx)
                if ident is None or ident.completed:continue
                self._set_state('ITEM_ACTIVATE',queue_id=ident.queue_id,logical_item_id=ident.logical_item_id,index=idx)
                self._domain('ITEM_ACTIVE',once_key=f'{self.session_id}:{ident.queue_id}:ITEM_ACTIVE',logical_item_id=ident.logical_item_id,index=idx)
                while not ident.completed:
                    if self._cancelled():self._set_state('STOPPED'); return
                    if self.queue.current() is not ident:
                        self._enter_error(self._error_envelope('CURRENT_ITEM_IDENTITY_CORRUPTED','RollItemQueue')); return
                    result=self._execute_one_roll_attempt(hwnd,ident)
                    if not result.get('ok'):
                        reason=str(result.get('reason') or 'FATAL_RUNTIME_ERROR')
                        if reason.startswith('USER_STOP'):
                            self._set_state('STOPPED'); return
                        if reason=='MATERIAL_EXHAUSTED':
                            self._set_state('MATERIAL_EXHAUSTED',queue_id=ident.queue_id); self._domain('MATERIAL_EXHAUSTED',queue_id=ident.queue_id); return

                        recovery=None
                        if str(getattr(ident,'current_owner','PLAYER_BAG')) == 'ROLL_ITEM_SLOT':
                            recovery=self._safe_recover_item_before_error(hwnd,ident,reason)
                            result=dict(result)
                            result['item_safety_recovery']=recovery
                            if not recovery.get('ok') and recovery.get('no_world_click'):
                                reason='ITEM_SAFE_HOLD_MANUAL_RECOVERY_REQUIRED'

                        self._enter_error(self._error_envelope(reason,'AutoRollSessionController',result)); return
                    verdict=result.get('verdict')
                    if verdict==FilterVerdict.ACCEPT:
                        returned=self._return_accepted_item_to_bag(hwnd,ident)
                        if not returned.get('ok'):
                            self._enter_error(self._error_envelope(returned.get('reason','ACCEPTED_ITEM_RETURN_FAILED'),
                                                                  'AutoRollSessionController',returned))
                            return
                        self.queue.mark_done(ident.queue_id); self.matched+=1
                        self._set_state('ITEM_DONE',queue_id=ident.queue_id,attempts=ident.roll_attempt)
                        self._domain('ITEM_DONE',once_key=f'{self.session_id}:{ident.queue_id}:ITEM_DONE',attempts=ident.roll_attempt)
                        break
                    if verdict==FilterVerdict.REJECT:
                        reject_transition_ns=time.monotonic_ns(); self._last_filter_reject_ns=reject_transition_ns
                        # NORMAL gameplay transition: same item, new attempt, new material, no limit.
                        if self.queue.current() is not ident:
                            self._enter_error(self._error_envelope('CURRENT_ITEM_IDENTITY_CORRUPTED','RollItemQueue')); return
                        self._set_state('SAME_ITEM_REROLL',queue_id=ident.queue_id,next_attempt=ident.roll_attempt+1)
                        self._domain('SAME_ITEM_REROLL_REQUESTED',once_key=f'{self.active_attempt.attempt_id}:SAME_ITEM_REROLL_REQUESTED',
                                     completed_attempt=ident.roll_attempt,next_attempt=ident.roll_attempt+1,max_filter_rerolls='UNLIMITED',hot_path=True)
                        self._metric('reject_to_next_attempt_dispatch_ms',(time.monotonic_ns()-reject_transition_ns)/1_000_000.0)
                        continue
                if idx+1<len(self.queue.items):self._set_state('NEXT_ITEM',from_queue_id=ident.queue_id,to_queue_id=self.queue.items[idx+1].queue_id)
            self._set_state('SESSION_COMPLETE',matched=self.matched,total_rolls=self.total_rolls)
            self._domain('AUTOROLL_COMPLETE',once_key=f'{self.session_id}:AUTOROLL_COMPLETE',matched=self.matched,total_rolls=self.total_rolls,performance_metrics=self._metric_summary())
            self._log_writer.flush()
        except Exception as e:
            self._enter_error(self._error_envelope('FATAL_RUNTIME_ERROR','AutoRollSessionController',{},False,e))
        finally:
            self.active_attempt=None; self._set_roll_running_flag(False)


# Compatibility import name only; there is no second runtime owner.
AutoRollRecordCoordCoordinator = AutoRollSessionController
