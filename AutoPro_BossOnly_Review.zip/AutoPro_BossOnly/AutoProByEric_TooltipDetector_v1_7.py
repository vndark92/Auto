from __future__ import annotations
from typing import Tuple, Dict, Any
import cv2
import numpy as np
from PIL import Image

def _candidate_rects(w:int,h:int,cx:int,cy:int):
    """
    JX1 tooltip can extend far to the left and vertically beyond the hovered item.
    Search multiple sizes and a few wide/full-height regions.
    """
    sizes=[
        (280,240),(320,280),(360,320),(400,350),
        (440,390),(480,430),(520,470)
    ]
    rects=[]

    for cw,ch in sizes:
        anchors=[
            (cx-cw-10,cy-ch//2),
            (cx-cw-10,cy-ch+30),
            (cx-cw//2,cy-ch-10),
            (cx+10,cy-ch//2),
        ]
        for x0,y0 in anchors:
            cw2=min(cw,w)
            ch2=min(ch,h)
            x0=max(0,min(w-cw2,x0))
            y0=max(0,min(h-ch2,y0))
            x1=min(w,x0+cw2)
            y1=min(h,y0+ch2)
            if x1-x0>=180 and y1-y0>=160:
                rects.append((x0,y0,x1,y1))

    # Inventory is usually on the right; tooltip often expands left from cursor.
    rects += [
        (max(0,cx-560),0,min(w,cx+25),h),
        (max(0,cx-500),0,w,h),
        (max(0,w-560),0,w,h),
    ]

    seen=set();out=[]
    for r in rects:
        if r not in seen and r[2]>r[0] and r[3]>r[1]:
            seen.add(r);out.append(r)
    return out

def _text_mask(arr_rgb):
    bgr=cv2.cvtColor(arr_rgb,cv2.COLOR_RGB2BGR)
    b,g,r=cv2.split(bgr)
    bi,gi,ri=b.astype(int),g.astype(int),r.astype(int)
    mx=np.maximum.reduce([b,g,r]).astype(int)
    mn=np.minimum.reduce([b,g,r]).astype(int)

    colored=(mx>78)&((mx-mn)>16)
    neutral=(mx>98)&((mx-mn)<=26)
    blue=(bi>125)&((bi-gi)>18)&((bi-ri)>18)
    cyan=(bi>115)&(gi>95)&(ri<145)&((bi-ri)>20)
    return (colored|neutral|blue|cyan).astype(np.uint8)

def _line_candidates(crop:Image.Image):
    arr=np.array(crop.convert("RGB"))
    mask=_text_mask(arr)
    hh,ww=mask.shape

    ybase=int(hh*.18)
    x0,x1=int(ww*.03),int(ww*.97)
    roi=mask[ybase:,x0:x1]
    signal=(roi>0).sum(axis=1)

    active=signal>7
    bands=[];start=None;last=None
    for i,v in enumerate(active):
        if v:
            if start is None:start=i
            last=i
        elif start is not None and i-last>2:
            bands.append((start,last));start=None
    if start is not None:
        bands.append((start,last))

    rows=[]
    for a,bn in bands:
        height=bn-a+1
        if not (5<=height<=17):
            continue
        row=roi[a:bn+1]
        ys,xs=np.where(row>0)
        if len(xs)<15:
            continue
        span=int(xs.max()-xs.min()+1)
        peak=int(signal[a:bn+1].max()) if bn>=a else 0
        if span<45 or peak<9:
            continue
        rows.append((a+ybase,bn+ybase,span,peak))
    return rows

def _text_energy(crop:Image.Image):
    arr=np.array(crop.convert("RGB"))
    return float(_text_mask(arr).mean())

def _expand_rect(rect,w,h,padx=88,pady=62):
    x0,y0,x1,y1=rect
    return (
        max(0,x0-padx),
        max(0,y0-pady),
        min(w,x1+padx),
        min(h,y1+pady),
    )

def _find_runs_bool(mask_1d, min_len=1):
    runs=[]
    start=None
    for i,v in enumerate(mask_1d):
        if bool(v) and start is None:
            start=i
        if start is not None and ((not bool(v)) or i==len(mask_1d)-1):
            end=i-1 if not bool(v) else i
            if end-start+1>=min_len:
                runs.append((start,end))
            start=None
    return runs


def _panel_text_guard_px(panel_candidate: Image.Image, canvas_h: int) -> int:
    """Return a bounded glyph guard around the translucent panel edge.

    The green-background projection is a locator, not the owner of the last text
    pixel.  JX1 option glyphs can extend below the detected green run, so a crop
    ending exactly at that run can destroy row 6 before Final6 ever sees it.
    Derive the guard from observed text cadence when possible; otherwise use a
    small scale-aware fallback.  This never fabricates rows and never weakens
    Final6 cadence/segmentation gates.
    """
    try:
        rows=_line_candidates(panel_candidate)
        centers=[(float(a)+float(b))/2.0 for a,b,*_ in rows]
        if len(centers)>=2:
            diffs=[b-a for a,b in zip(centers,centers[1:]) if 8.0 <= (b-a) <= 48.0]
            if diffs:
                pitch=float(np.median(np.asarray(diffs,dtype=float)))
                return int(np.clip(round(pitch*1.20),14,32))
    except Exception:
        pass
    return int(np.clip(round(float(canvas_h)*0.052),14,28))


def _tighten_live_tooltip_panel(crop:Image.Image, cursor_local_x=None):
    """
    Isolate JX1 tooltip without confusing the inventory's dark-green grid
    with the tooltip itself.

    v4.8 failure:
      expanded client crop was wide enough, but the old color-density logic
      selected the right-side inventory block. The saved tooltip became only
      149 px wide (client x 651..800), cutting the option text on the left.

    v4.9 rule:
      - Tooltip left edge must be near and to the LEFT of the hovered item.
      - Search only roughly cursor-260 .. cursor for the first strong green
        panel run.
      - Keep the full right side after that edge.
    """
    arr=np.asarray(crop.convert("RGB"))
    if arr.ndim!=3:
        return None
    h,w=arr.shape[:2]
    if w<260 or h<220:
        return None

    R=arr[:,:,0].astype(np.int16)
    G=arr[:,:,1].astype(np.int16)
    B=arr[:,:,2].astype(np.int16)
    mean=(R+G+B)/3.0
    bg=((G-R)>5) & (mean<85)

    ya=max(0,int(h*.30))
    yb=min(h,int(h*.93))
    if yb-ya<80:
        return None

    col=bg[ya:yb,:].mean(axis=0)
    k=np.ones(7,dtype=float)/7.0
    col_s=np.convolve(col,k,mode="same")

    all_runs=_find_runs_bool(
        col_s>0.45,
        min_len=max(10,int(w*.018))
    )
    if not all_runs:
        return None

    if cursor_local_x is None:
        cursor_local_x=int(w*.78)
    cursor_local_x=max(0,min(w-1,int(cursor_local_x)))

    search_left=max(0,cursor_local_x-max(260,int(w*.44)))
    search_right=min(w-1,cursor_local_x+18)

    near_runs=[
        r for r in all_runs
        if r[0] <= search_right and r[1] >= search_left
    ]

    # Prefer the FIRST strong panel edge near the cursor, not the longest
    # inventory-background run on the far right.
    strong_runs=[]
    for r in near_runs:
        a,b=r
        strength=float(np.mean(col_s[a:b+1]))
        strong_runs.append((a,b,strength))

    if strong_runs:
        strong_runs.sort(key=lambda x:(x[0], -x[2], -(x[1]-x[0])))
        x0=int(strong_runs[0][0])
        x_strength=float(strong_runs[0][2])
    else:
        # Safe fallback anchored from cursor rather than inventory geometry.
        x0=max(0,cursor_local_x-max(215,int(w*.36)))
        x_strength=float(col_s[x0]) if x0 < len(col_s) else 0.0

    # Find vertical panel run only around tooltip/cursor neighborhood so the
    # inventory grid to the far right does not dominate the row score.
    xr0=max(0,x0)
    xr1=min(w,max(xr0+70,cursor_local_x+55))
    row=bg[:,xr0:xr1].mean(axis=1)
    rk=np.ones(9,dtype=float)/9.0
    row_s=np.convolve(row,rk,mode="same")
    row_runs=_find_runs_bool(
        row_s>0.28,
        min_len=max(90,int(h*.24))
    )
    if not row_runs:
        return None

    yrun=max(row_runs,key=lambda r:r[1]-r[0]+1)
    y0,y1=int(yrun[0]),int(yrun[1])

    if x0>=w-100 or y1-y0<100:
        return None

    # Full width is intentional. LAST-6 OCR needs complete option values/units.
    # V1.7.8: the green run is only a panel locator. Preserve a bounded glyph
    # guard so the sixth option line cannot be clipped before strict Final6.
    x1=w
    provisional_y1=min(h,y1+1)
    provisional=crop.crop((x0,y0,x1,provisional_y1))
    text_guard=_panel_text_guard_px(provisional,h)
    y0=max(0,y0-min(5,max(2,text_guard//6)))
    y1=min(h,provisional_y1+text_guard)

    tight=crop.crop((x0,y0,x1,y1))
    rows=_line_candidates(tight)
    if len(rows)<6:
        return None

    return {
        "rect_local":(int(x0),int(y0),int(x1),int(y1)),
        "crop":tight,
        "candidate_lines":len(rows),
        "green_col_peak":round(float(x_strength),3),
        "panel_height":int(y1-y0),
        "panel_width":int(x1-x0),
        "cursor_local_x":int(cursor_local_x),
        "search_left":int(search_left),
        "search_right":int(search_right),
        "isolation_strategy":"CURSOR_ANCHORED_LEFT_EDGE_V4_10_TEXT_GUARD",
        "text_guard_px":int(text_guard),
    }



def _recover_tooltip_panel_projection(crop:Image.Image, cursor_local_x=None):
    """Recover the actual dark-green tooltip panel from a large fallback crop.

    This specifically prevents the v6.2 Q4 failure where a 677x497 client-area
    crop was fed to LAST-6.  The tooltip is a tall green translucent panel with a
    strong left edge and a long vertical run near the hovered inventory item.
    """
    arr=np.asarray(crop.convert("RGB"))
    if arr.ndim!=3: return None
    h,w=arr.shape[:2]
    if w<260 or h<220: return None
    R=arr[:,:,0].astype(np.int16); G=arr[:,:,1].astype(np.int16); B=arr[:,:,2].astype(np.int16)
    mean=(R+G+B)/3.0
    green=((G-R)>5) & (mean<95)
    if cursor_local_x is None: cursor_local_x=int(w*.82)
    cx=max(0,min(w-1,int(cursor_local_x)))

    # Search for a strong tooltip left edge to the left of cursor.
    col=green.mean(axis=0)
    col_s=np.convolve(col,np.ones(7)/7.0,mode="same")
    lo=max(0,cx-max(390,int(w*.62))); hi=max(lo+1,min(w,cx-18))
    active=col_s[lo:hi]>0.32
    runs=_find_runs_bool(active,min_len=5)
    if not runs: return None
    scored=[]
    for a,b in runs:
        aa,bb=lo+a,lo+b
        strength=float(np.mean(col_s[aa:bb+1]))
        scored.append((aa,bb,strength))
    # Earliest strong run near cursor is normally the tooltip left edge.
    scored.sort(key=lambda x:(x[0],-x[2]))
    x0=int(scored[0][0])
    x1=min(w,max(cx+55,x0+260))

    row=green[:,x0:x1].mean(axis=1)
    row_s=np.convolve(row,np.ones(9)/9.0,mode="same")
    rr=_find_runs_bool(row_s>0.24,min_len=max(120,int(h*.24)))
    if not rr: return None
    y0,y1=max(rr,key=lambda r:r[1]-r[0]+1)
    raw_y0=max(0,int(y0)-2); raw_y1=min(h,int(y1)+4)
    provisional=crop.crop((x0,raw_y0,x1,raw_y1))
    text_guard=_panel_text_guard_px(provisional,h)
    y0=max(0,raw_y0-min(5,max(2,text_guard//6)))
    y1=min(h,raw_y1+text_guard)
    if y1-y0<150: return None

    panel=crop.crop((x0,y0,x1,y1))
    rows=_line_candidates(panel)
    if len(rows)<4: return None
    return {
        "rect_local":(x0,y0,x1,y1),"crop":panel,"candidate_lines":len(rows),
        "panel_width":x1-x0,"panel_height":y1-y0,
        "cursor_local_x":cx,"isolation_strategy":"GREEN_PROJECTION_RECOVERY_V6_4_TEXT_GUARD",
        "green_col_peak":round(float(np.max(col_s[lo:hi])),3),
        "text_guard_px":int(text_guard),
    }

def detect_tooltip_near_cursor(client_img:Image.Image,cursor_xy:Tuple[int,int])->Dict[str,Any]:
    w,h=client_img.size
    cx,cy=cursor_xy

    best=None
    all_scores=[]

    for rect in _candidate_rects(w,h,cx,cy):
        crop=client_img.crop(rect)
        rows=_line_candidates(crop)
        count=len(rows)
        energy=_text_energy(crop)

        # Prefer 5-10 line text blocks. Live logs showed 5 when one row was missed.
        structural=min(count,10)*13.0
        if 5<=count<=10:
            structural+=18
        if count>14:
            structural-=22

        score=structural+energy*85.0
        item={
            "rect":rect,
            "candidate_lines":count,
            "score":round(score,3),
        }
        all_scores.append(item)

        if best is None or score>best["score"]:
            best={
                "rect":rect,
                "candidate_lines":count,
                "score":score,
                "crop":crop,
            }

    if best is None:
        return {"status":"NOT_FOUND","candidates":all_scores}

    # Stage 1 detector is intentionally permissive.
    # The reader still requires exactly 6 final rows before READY.
    if best["candidate_lines"]<4:
        return {"status":"NOT_FOUND","candidates":all_scores}

    expanded=_expand_rect(best["rect"],w,h)
    ex0,ey0,ex1,ey1=expanded

    # v4.8: DO NOT clamp the tooltip at cursor+36.
    # Real JX1 tooltip text/value extends to the right of the hover point.
    # The old clamp produced a 208px crop and cut option values/units.
    # Panel isolation below will remove unrelated content instead.

    if best["rect"][2] >= w-2:
        ex0=max(0,min(ex0,cx-max(430,int(w*.62))))
        ex1=w

    # LAST-6 root fix. The live Q01 crop stopped at y=316 and clipped the
    # final gray option row. Expand far enough below the first detector hit.
    if ey0 <= 2 or best["rect"][1] <= int(h*.14):
        ey0=0
        ey1=min(h,max(
            ey1,
            cy+max(320,int(h*.56)),
            best["rect"][3]+max(125,int(h*.20))
        ))
    else:
        ey1=min(h,max(ey1,best["rect"][3]+max(105,int(h*.17))))

    expanded=(ex0,ey0,ex1,ey1)
    crop=client_img.crop(expanded)

    # Root fix v4.7: isolate the actual tooltip panel inside this large crop.
    # Never feed map/chat rows into LAST-6 extraction.
    panel=_tighten_live_tooltip_panel(crop, cursor_local_x=(cx-ex0))
    if panel is not None:
        tx0,ty0,tx1,ty1=panel["rect_local"]
        final_rect=(ex0+tx0,ey0+ty0,ex0+tx1,ey0+ty1)
        final_crop=panel["crop"]
        final_lines=panel["candidate_lines"]
        return {
            "status":"FOUND",
            "rect":final_rect,
            "expanded_rect":expanded,
            "raw_rect":best["rect"],
            "candidate_lines":final_lines,
            "score":round(best["score"],3),
            "crop":final_crop,
            "candidates":all_scores,
            "soft_candidate":final_lines<6,
            "panel_tightened":True,
            "panel_rect_local":panel["rect_local"],
            "panel_width":panel["panel_width"],
            "panel_height":panel["panel_height"],
            "cursor_local_x":panel.get("cursor_local_x"),
            "panel_isolation_strategy":panel.get("isolation_strategy"),
            "crop_strategy":"cursor-anchored-tooltip-v4.9",
        }

    # v6.3 recovery: never feed a near-full client-area crop into LAST-6.
    recovered=_recover_tooltip_panel_projection(crop,cursor_local_x=(cx-ex0))
    if recovered is not None:
        tx0,ty0,tx1,ty1=recovered["rect_local"]
        final_rect=(ex0+tx0,ey0+ty0,ex0+tx1,ey0+ty1)
        return {
            "status":"FOUND","rect":final_rect,"expanded_rect":expanded,
            "raw_rect":best["rect"],"candidate_lines":recovered["candidate_lines"],
            "score":round(best["score"],3),"crop":recovered["crop"],
            "candidates":all_scores,"soft_candidate":False,"panel_tightened":True,
            "panel_rect_local":recovered["rect_local"],
            "panel_width":recovered["panel_width"],"panel_height":recovered["panel_height"],
            "cursor_local_x":recovered["cursor_local_x"],
            "panel_isolation_strategy":recovered["isolation_strategy"],
            "crop_strategy":"green-projection-recovery-v6.3",
        }

    # Hard reject unsafe fallback. Backend will try another occupied-cell hover
    # point rather than creating a false READY from map/inventory/chat text.
    return {
        "status":"CROP_REJECTED","rect":expanded,"raw_rect":best["rect"],
        "candidate_lines":best["candidate_lines"],"score":round(best["score"],3),
        "candidates":all_scores,"panel_tightened":False,
        "crop_strategy":"rejected-expanded-fallback-v6.3",
        "reason":"TOOLTIP_PANEL_NOT_ISOLATED",
    }
