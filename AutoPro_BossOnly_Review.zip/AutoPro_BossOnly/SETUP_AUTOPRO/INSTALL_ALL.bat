@echo off
setlocal
cd /d "%~dp0"
echo AUTO PRO BY ERIC - ONE FOLDER ENVIRONMENT INSTALLER
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-AutoPro.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo SETUP FAILED - error code %RC%.
  echo See the messages above.
) else (
  echo SETUP COMPLETE.
)
pause
exit /b %RC%
