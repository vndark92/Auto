﻿$ErrorActionPreference = "Stop"
$SetupDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $SetupDir
$Installers = Join-Path $SetupDir "installers"
$Wheelhouse = Join-Path $SetupDir "wheelhouse"
$ModelCache = Join-Path $SetupDir "model_cache"
$Req = Join-Path $SetupDir "requirements-py312.txt"
New-Item -ItemType Directory -Force -Path $Installers,$Wheelhouse,$ModelCache | Out-Null

function Download-IfMissing([string]$Url, [string]$OutFile) {
    if (-not (Test-Path $OutFile)) {
        Write-Host "Downloading:" $Url
        Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $OutFile
    } else {
        Write-Host "Already cached:" $OutFile
    }
}

Write-Host "[1/4] Cache Windows installers"
Download-IfMissing "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe" (Join-Path $Installers "python-3.12.10-amd64.exe")
Download-IfMissing "https://aka.ms/vc14/vc_redist.x64.exe" (Join-Path $Installers "vc_redist.x64.exe")
Download-IfMissing "https://sourceforge.net/projects/tesseract-ocr.mirror/files/5.5.0/tesseract-ocr-w64-setup-5.5.0.20241111.exe/download" (Join-Path $Installers "tesseract-ocr-w64-setup-5.5.0.20241111.exe")

Write-Host "[2/4] Build Python wheelhouse"
try {
    & py -3.12 --version
    if ($LASTEXITCODE -ne 0) { throw "Python 3.12 missing" }
} catch {
    throw "Install Python 3.12 first (run INSTALL_ALL.bat), then run PREPARE_OFFLINE_BUNDLE.bat."
}
& py -3.12 -m pip install --upgrade pip wheel
if ($LASTEXITCODE -ne 0) { throw "pip/wheel update failed" }
& py -3.12 -m pip wheel -r "$Req" -w "$Wheelhouse"
if ($LASTEXITCODE -ne 0) { throw "wheelhouse build failed" }

Write-Host "[3/4] Copy Paddle model caches when present"
$homeDir = [Environment]::GetFolderPath("UserProfile")
foreach ($name in @(".paddlex",".paddleocr")) {
    $src = Join-Path $homeDir $name
    $dst = Join-Path $ModelCache $name
    if (Test-Path $src) {
        if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
        Copy-Item $src $dst -Recurse -Force
        Write-Host "Cached:" $src
    } else {
        Write-Warning "$name cache not found. Run CHECK_PADDLEOCR_ENGINE.bat once to warm up models, then run this script again."
    }
}

Write-Host "[4/4] Write hashes"
$hashOut = Join-Path $SetupDir "OFFLINE_BUNDLE_HASHES.txt"
$items = Get-ChildItem -Path $Installers,$Wheelhouse -File -Recurse | Sort-Object FullName
$lines = @()
foreach ($f in $items) {
    $h = Get-FileHash -Algorithm SHA256 -Path $f.FullName
    $rel = $f.FullName.Substring($SetupDir.Length).TrimStart('\')
    $lines += ($h.Hash.ToLower() + "  " + $rel)
}
$lines | Set-Content -Encoding ASCII $hashOut
Write-Host ""
Write-Host "Offline cache prepared."
Write-Host "Keep the whole Auto Pro folder. After a future Windows reinstall, run SETUP_AUTOPRO\INSTALL_ALL.bat."
Write-Host "Hashes:" $hashOut
