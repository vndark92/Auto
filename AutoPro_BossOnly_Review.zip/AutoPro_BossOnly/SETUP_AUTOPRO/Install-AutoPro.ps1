﻿$ErrorActionPreference = "Stop"
$SetupDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $SetupDir
$Installers = Join-Path $SetupDir "installers"
$Wheelhouse = Join-Path $SetupDir "wheelhouse"
$ModelCache = Join-Path $SetupDir "model_cache"
$Req = Join-Path $SetupDir "requirements-py312.txt"

New-Item -ItemType Directory -Force -Path $Installers,$Wheelhouse,$ModelCache | Out-Null

function Step([string]$Text) {
    Write-Host ""
    Write-Host "============================================================"
    Write-Host $Text
    Write-Host "============================================================"
}
function Download-IfMissing([string]$Url, [string]$OutFile) {
    if (Test-Path $OutFile) {
        Write-Host "Using bundled/cache:" $OutFile
        return
    }
    Write-Host "Downloading:" $Url
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $OutFile
}
function Test-Py312 {
    try {
        & py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,12) else 1)" 2>$null
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}
function Find-Tesseract {
    $cmd = Get-Command tesseract -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $candidates = @(
        "$env:ProgramFiles\Tesseract-OCR\tesseract.exe",
        "${env:ProgramFiles(x86)}\Tesseract-OCR\tesseract.exe"
    )
    foreach ($p in $candidates) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    return $null
}

Step "[1/6] Python 3.12"
if (-not (Test-Py312)) {
    $pm = Get-Command pymanager -ErrorAction SilentlyContinue
    if ($pm) {
        Write-Host "Python Install Manager detected. Installing Python 3.12..."
        & pymanager install 3.12
    }
}
if (-not (Test-Py312)) {
    $pyInstaller = Join-Path $Installers "python-3.12.10-amd64.exe"
    Download-IfMissing "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe" $pyInstaller
    Write-Host "Installing Python 3.12.10..."
    Start-Process -Wait -FilePath $pyInstaller -ArgumentList @(
        "/quiet",
        "InstallAllUsers=0",
        "PrependPath=0",
        "Include_launcher=1",
        "Include_pip=1",
        "Include_test=0"
    )
}
if (-not (Test-Py312)) {
    throw "Python 3.12 is still unavailable. Re-open this installer after Python installation finishes."
}
& py -3.12 --version

Step "[2/6] Microsoft Visual C++ Runtime x64"
$vc = Join-Path $Installers "vc_redist.x64.exe"
Download-IfMissing "https://aka.ms/vc14/vc_redist.x64.exe" $vc
Write-Host "Installing/updating VC++ runtime (UAC may appear)..."
$p = Start-Process -Wait -PassThru -Verb RunAs -FilePath $vc -ArgumentList @("/install","/passive","/norestart")
Write-Host "VC++ installer exit code:" $p.ExitCode

Step "[3/6] Tesseract OCR"
$tess = Find-Tesseract
if (-not $tess) {
    $tessInstaller = Join-Path $Installers "tesseract-ocr-w64-setup-5.5.0.20241111.exe"
    Download-IfMissing "https://sourceforge.net/projects/tesseract-ocr.mirror/files/5.5.0/tesseract-ocr-w64-setup-5.5.0.20241111.exe/download" $tessInstaller
    Write-Host "Installing Tesseract OCR (UAC may appear)..."
    $tp = Start-Process -Wait -PassThru -Verb RunAs -FilePath $tessInstaller -ArgumentList @("/S")
    Write-Host "Tesseract installer exit code:" $tp.ExitCode
    Start-Sleep -Seconds 2
    $tess = Find-Tesseract
}
if (-not $tess) {
    throw "Tesseract OCR was not found after installation."
}
Write-Host "Tesseract:" $tess
$tessDir = Split-Path -Parent $tess
if (($env:Path -split ';') -notcontains $tessDir) {
    $env:Path = "$tessDir;$env:Path"
}
$userPath = [Environment]::GetEnvironmentVariable("Path","User")
if (($userPath -split ';') -notcontains $tessDir) {
    $newUserPath = if ([string]::IsNullOrWhiteSpace($userPath)) { $tessDir } else { $userPath.TrimEnd(';') + ";" + $tessDir }
    [Environment]::SetEnvironmentVariable("Path",$newUserPath,"User")
}

Step "[4/6] Python packages for Auto Pro"
& py -3.12 -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed" }

$wheelFiles = @(Get-ChildItem -Path $Wheelhouse -Filter "*.whl" -File -ErrorAction SilentlyContinue)
if ($wheelFiles.Count -gt 0) {
    Write-Host "Using local wheelhouse:" $Wheelhouse
    & py -3.12 -m pip install --no-index --find-links="$Wheelhouse" -r "$Req"
} else {
    Write-Host "Wheelhouse empty; installing from PyPI..."
    & py -3.12 -m pip install -r "$Req"
}
if ($LASTEXITCODE -ne 0) { throw "Python dependency installation failed" }

Step "[5/6] Restore OCR model cache if bundled"
$homeDir = [Environment]::GetFolderPath("UserProfile")
foreach ($name in @(".paddlex",".paddleocr")) {
    $src = Join-Path $ModelCache $name
    $dst = Join-Path $homeDir $name
    if (Test-Path $src) {
        Write-Host "Restoring" $name "cache..."
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Copy-Item -Path (Join-Path $src "*") -Destination $dst -Recurse -Force -ErrorAction SilentlyContinue
    }
}

Step "[6/6] Verify environment"
& py -3.12 (Join-Path $SetupDir "CHECK_ENV.py")
if ($LASTEXITCODE -ne 0) {
    throw "Environment check failed. See ENV_STATUS.json in the Auto Pro folder."
}

Write-Host ""
Write-Host "Warming up PaddleOCR Vietnamese model..."
& py -3.12 (Join-Path $Root "PADDLEOCR_SETUP.py")
if ($LASTEXITCODE -ne 0) {
    Write-Warning "PaddleOCR warmup failed. Auto Pro can still use Tesseract fallback. Check PADDLEOCR_ENGINE_STATUS.json."
} else {
    Write-Host "PaddleOCR warmup: OK"
}

Write-Host ""
Write-Host "AUTO PRO ENVIRONMENT READY."
Write-Host "Run: RUN_AUTOPRO.bat"
