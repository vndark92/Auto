from __future__ import annotations
import json, os, sys, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUNDLED_TESSDATA = ROOT / "runtime" / "tessdata"
if BUNDLED_TESSDATA.exists():
    os.environ["TESSDATA_PREFIX"] = str(BUNDLED_TESSDATA)

status = {
    "python": sys.version,
    "python_executable": sys.executable,
    "root": str(ROOT),
    "modules": {},
    "tesseract": {},
}
ok = True

def check_module(import_name, display=None):
    global ok
    name = display or import_name
    try:
        mod = __import__(import_name)
        ver = getattr(mod, "__version__", None)
        status["modules"][name] = {"ok": True, "version": str(ver) if ver else ""}
    except Exception as e:
        status["modules"][name] = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        ok = False

for mod, label in [
    ("numpy", "numpy"),
    ("PIL", "Pillow"),
    ("cv2", "opencv-python"),
    ("pytesseract", "pytesseract"),
    ("mss", "mss"),
    ("webview", "pywebview"),
    ("paddle", "paddlepaddle"),
    ("paddleocr", "paddleocr"),
]:
    check_module(mod, label)

try:
    import pytesseract
    candidates = []
    w = shutil.which("tesseract")
    if w:
        candidates.append(Path(w))
    candidates += [
        Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Tesseract-OCR" / "tesseract.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / "Tesseract-OCR" / "tesseract.exe",
    ]
    tess = next((p for p in candidates if p.exists()), None)
    if not tess:
        raise FileNotFoundError("tesseract.exe not found")
    pytesseract.pytesseract.tesseract_cmd = str(tess)
    ver = str(pytesseract.get_tesseract_version())
    langs = sorted(set(pytesseract.get_languages(config="")))
    status["tesseract"] = {
        "ok": True,
        "path": str(tess),
        "version": ver,
        "languages": langs,
        "bundled_tessdata": str(BUNDLED_TESSDATA) if BUNDLED_TESSDATA.exists() else "",
    }
    if not {"eng", "vie"}.issubset(set(langs)):
        status["tesseract"]["ok"] = False
        status["tesseract"]["error"] = "Missing eng/vie language data"
        ok = False
except Exception as e:
    status["tesseract"] = {"ok": False, "error": f"{type(e).__name__}: {e}"}
    ok = False

out = ROOT / "ENV_STATUS.json"
out.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")

print("=" * 64)
print("AUTO PRO BY ERIC - ENVIRONMENT CHECK")
print("=" * 64)
print("Python:", sys.version.split()[0], "|", sys.executable)
for name, v in status["modules"].items():
    print(f"{name:16}:", "OK" if v.get("ok") else "FAIL", v.get("version") or v.get("error",""))
t = status["tesseract"]
print("Tesseract       :", "OK" if t.get("ok") else "FAIL", t.get("version") or t.get("error",""))
if t.get("path"):
    print("Tesseract path  :", t["path"])
if t.get("languages"):
    print("Tesseract langs :", ", ".join(t["languages"]))
print("=" * 64)
print("RESULT:", "READY" if ok else "NOT READY")
print("Status file:", out)
raise SystemExit(0 if ok else 1)
