PREPARE_OFFLINE_BUNDLE.bat copies .paddlex/.paddleocr caches here when available.
