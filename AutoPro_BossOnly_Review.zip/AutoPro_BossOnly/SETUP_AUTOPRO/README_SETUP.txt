AUTO PRO BY ERIC - SETUP_AUTOPRO

MỤC TIÊU
- Giữ toàn bộ bộ cài / kiểm tra môi trường trong cùng một folder với Auto Pro.
- Sau khi cài lại Windows, không cần nhớ từng lệnh pip/module nữa.

DÙNG SAU KHI CÀI LẠI WINDOWS
1. Mở folder SETUP_AUTOPRO.
2. Chạy INSTALL_ALL.bat.
3. Chờ Python 3.12, VC++ Runtime, Tesseract và các Python package được kiểm tra/cài.
4. Khi báo READY, quay lại folder Auto Pro và chạy RUN_AUTOPRO.bat.

CHUẨN BỊ BỘ CÀI OFFLINE NGAY BÂY GIỜ
- Khi máy đang có Internet và Python 3.12 đã hoạt động, chạy:
  PREPARE_OFFLINE_BUNDLE.bat
- Script sẽ tải/cache:
  + Python 3.12.10 x64 installer
  + Microsoft VC++ x64 installer
  + Tesseract 5.5.0 x64 installer
  + wheelhouse cho toàn bộ Python dependency
  + cache Paddle/PaddleOCR model nếu đã được warm-up
- Sau khi hoàn tất, giữ NGUYÊN cả folder Auto Pro. Lần cài Windows sau INSTALL_ALL.bat sẽ ưu tiên file cache trong folder.

RUNTIME CHỐT
- Python 3.12
- PaddlePaddle 3.3.1
- PaddleOCR 3.7.0
- pywebview 6.2.1
- pytesseract 0.3.13
- Tesseract 5.5.x
- mss + Pillow + OpenCV + NumPy

LƯU Ý
- RUN_AUTOPRO.bat đã khóa runtime về Python 3.12; không dùng python mặc định (Python 3.15 có thể cùng tồn tại).
- Tesseract language data eng/vie đã có sẵn trong runtime/tessdata của Auto.
- CHECK_ENV.bat tạo ENV_STATUS.json ở root Auto Pro.
- CHECK_PADDLEOCR_ENGINE.bat dùng Python 3.12 và warm-up PaddleOCR.
