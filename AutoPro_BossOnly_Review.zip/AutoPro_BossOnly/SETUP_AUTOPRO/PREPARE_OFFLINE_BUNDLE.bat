@echo off
setlocal
cd /d "%~dp0"
echo AUTO PRO BY ERIC - PREPARE OFFLINE BUNDLE
echo This downloads installers and builds a Python wheel cache for future Windows reinstalls.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Prepare-OfflineBundle.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo OFFLINE CACHE PREP FAILED - error code %RC%.
) else (
  echo OFFLINE CACHE READY.
)
pause
exit /b %RC%
