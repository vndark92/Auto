@echo off
setlocal
cd /d "%~dp0"
py -3.12 "%~dp0CHECK_ENV.py"
set "RC=%ERRORLEVEL%"
echo.
pause
exit /b %RC%
