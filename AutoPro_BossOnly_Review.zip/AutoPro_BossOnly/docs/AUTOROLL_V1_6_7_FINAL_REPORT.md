# Auto Pro By Eric — AutoRoll V1.6.7 Gentle Pacing

V1.6.7 only slows AutoRoll input pacing slightly.

Baseline click transaction (excluding OS/game overhead):
- V1.6.6: ~105 ms
- V1.6.7: ~130 ms
- Increase: ~25 ms per click transaction

Changed pacing:
- cursor move: 0 -> 10 ms
- pre-click settle: 20 -> 25 ms
- mouse-down dwell: 60 -> 65 ms
- post-click settle: 25 -> 30 ms
- focus settle: 50 -> 55 ms
- activation settle: 30 -> 35 ms
- retry delay: 60 -> 70 ms
- verify poll: 30 -> 35 ms
- tooltip hover settle: 50 -> 60 ms
- reader reread delay: 50 -> 60 ms
- focus click settle: 30 -> 35 ms

Preserved exactly:
- 4.0-second Roll wait
- V1.6.6 No-World-Drop Guard
- V1.6.5 Final6 segmentation
- V1.6.4 post-Roll owner
- V1.6.3 reacquire ledger
- V1.6.2 inventory toggle owner
- shared AutoBoss / InventorySensor / Stage16 / Filter / Stage17 / Storage

Compile: PASS
Protected shared hashes: PASS
Live JX1 confirmation required.
