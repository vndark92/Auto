# Auto Pro By Eric V12.11 — AutoRoll V1.7.7E
## Inventory Hotkey Focus + Visible Grid Rootfix

### Root cause isolated
V1.7.5E → V1.7.6E source diff proves Stage17 and AutoRoll input code were byte-identical; the Paddle oneDNN rootfix did not overwrite Q/F4 code. The visible message was also misleading: the old UI displayed `KHÔNG MỞ ĐƯỢC Q/F4` for nearly every `chest_prepare_loop()` failure, regardless of the actual backend reason.

### Rootfix
- Dedicated Q/F4 gateway: activate JX1 → safe physical top-HUD click → exactly one Foreground/SendInput inventory key.
- Verified visible 6×10 grid is accepted in place; anchor drift never forces close/reopen.
- Two independent absence observations are required before Q/F4 can fire.
- Open confirmation uses bounded 1.85 s polling with two geometry-consistent 6×10 frames.
- AutoRoll acquisition uses the same gateway; AutoBoss close uses its already-proven focused helper.
- Chest UI now shows the exact backend reason; Q/F4 failure text is reserved for genuine inventory-input/open failures.
- V1.7.6E Paddle oneDNN rootfix and protected OCR/filter/inventory/storage files remain hash-identical.

### QA
- Python source compile: PASS
- JSON parse: PASS
- UI JavaScript `node --check`: PASS
- Targeted runtime simulation: PASS
  - visible drifted grid → accepted, zero toggle
  - first miss / second visible → zero toggle
  - two absences → exactly one Q/F4 → two stable grids → OPEN confirmed
- Protected V1.7.6E Paddle/runtime hashes: PASS
- Live Windows/JX1 test: REQUIRED before locking canonical.

**Status: QA Candidate.**
