# AutoRoll V1.7.5E — Slot-Specific Teaching Registry + Implicit Percent

Built on the latest **V1.7.4E One-Folder Environment Bundle**. Environment/setup files are preserved.

## Integrated registry
- Vũ khí: Closed-9 unchanged.
- Đồ Chung base: Closed-10.
- Áo: Closed-11 = Base-10 + **Sinh lực tối đa**.
- Bao tay: Closed-11 = Base-10 + **Tăng công kích kỹ năng**.
- Dây chuyền: Closed-3 = **Kỹ năng Võ công vốn có + Kháng tất cả + Mức kháng tính tối đa**.
- Ngọc bội: Closed-2 unchanged.
- GLOBAL remains the broad 20-option union; the three taught slot extensions require the explicit Áo/Bao tay/Dây chuyền scope.

## Numeric contract
For exactly the three taught options above, VALUE ROI reads only the number. `%` is supplied by registry; OCR of `+`, `:` and `%` is not required. If the number is unresolved or multiple numeric tokens conflict, result stays `UNRESOLVED`.

## Teaching truth
The three user crops are bundled under `Data/teaching_truth_v175/` and recorded in `Data/user_teaching_truth_v1_7_5.json`. Exact-crop closed-world replay: **3/3 OPTION_CONFIRMED**, visual score **1.0**, ensemble **0.94**.

## QA
- Python compile: **22/22 PASS**.
- JSON: **25/25 PASS**.
- UI JavaScript syntax: **PASS**.
- Registry: **34/34 unique IDs + unit contracts PASS**.
- Stage16 taught semantic aliases: **3/3 PASS**.
- Historical Final6: **256/256 PASS**, overlap 0.
- Current-log Final6: **36/36 PASS**, overlap 0.
- Combined segmentation: **292/292 PASS**, overlap 0.
- Protected AutoBoss / InventorySensor / ItemFilterEngine / Storage / launcher / Paddle setup / SETUP_AUTOPRO: **20/20 hashes unchanged**.
- AutoRoll transaction/pacing/safety state machine unchanged; only BUILD_ID metadata changed.

Preserved: No World Drop Guard, +20% pacing, exact 4.0s Roll wait, V1.7.3 non-overlap Final6, Paddle Stage17 bridge, and Python 3.12 one-folder environment setup.

**Status:** QA Candidate. Live JX1 behavior is not claimed until tested on the user's client.
