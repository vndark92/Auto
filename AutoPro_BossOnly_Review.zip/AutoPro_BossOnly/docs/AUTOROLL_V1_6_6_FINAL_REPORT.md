# Auto Pro By Eric — AutoRoll V1.6.6 No World Drop Guard

## Reported regression
AutoRoll can again lose/drop the weapon while Final6 is unstable.

## What the supplied archive proves
The archive contains tooltip/proof/queue artifacts, including repeated Q01 weapon reads, but it does not contain the AutoRoll JSONL state ledger. Therefore the exact destructive click cannot be claimed from the archive alone.

## Code-audit root cause
V1.6.5 still had a destructive safety gap:

- startup Roll UI verification only proved that recorded coordinates were inside the client;
- an item could then be picked from Player Bag;
- the next placement click trusted the recorded Roll-slot pixel;
- accepted-item return could use the old recorded Bag pixel.

If Roll UI or Player Bag moved, closed, or changed owner during a long session, a valid click coordinate could now be **world space**. With the weapon attached to cursor, that is an accidental world drop.

## V1.6.6 rootfix

### Before Player Bag -> Roll slot
1. Resolve item from the live Player Bag grid.
2. Prove the source cell is occupied.
3. Prove Roll UI scene signatures.
4. Prove the Roll item slot is in the recorded empty state.
5. Only then permit the source pick.

### After source pick
Roll UI is proved a second time **before the destination click**.

If proof is lost:
- destination click is blocked;
- AutoRoll tries to return the weapon to the already-proven Bag source cell;
- if Bag cannot be proved, AutoRoll performs **no click**.

### Roll slot -> Player Bag
V1.6.6 no longer uses `original_client_point` as an equipment destination.

It:
- acquires the live Bag;
- resolves the original logical cell from the live 6x10 grid;
- requires the complete item footprint to be empty;
- computes the current live destination coordinate;
- re-proves Bag after the source pick;
- only then places the weapon.

### On Final6/read failure
If the item is proven in the Roll slot:
- guarded return to Bag is attempted;
- if safety proof fails, AutoRoll stops as `ITEM_SAFE_HOLD_MANUAL_RECOVERY_REQUIRED`;
- no world click is sent.

## Preserved
- V1.6.2 inventory Q/F4 single-owner rootfix
- V1.6.3 reacquire ledger rootfix
- V1.6.4 post-Roll owner rootfix
- V1.6.5 Final6 row stabilization
- exact 4.0s Roll wait

Shared AutoBoss / InventorySensor / Stage16 / Filter / Stage17 / Storage remain unchanged.

Compile-all: **PASS**
Static No-World-Drop contracts: **PASS**
Protected shared hashes: **PASS**

Live JX1 confirmation is still required.
