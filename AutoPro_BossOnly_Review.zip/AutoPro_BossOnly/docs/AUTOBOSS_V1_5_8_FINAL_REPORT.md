# Auto Pro By Eric — Auto Boss V1.5.8

## Root causes found

### 1. Only one Boss item receives a Final6 target
The V1.5.4 fair scheduler was already correct, but it can only rotate over queue rows that exist. The live bag detector still represents adjacent changed cells as one connected candidate when multiple pickups arrive between two scan frames. In that case the queue contains only `L01`, so there is no `L02` for Final6 to visit.

V1.5.8 adds **Point-B tooltip demerge** for suspicious multi-cell delta candidates. Every changed cell is hovered. Cells that produce the same tooltip remain one multi-cell physical item; cells that produce different tooltip fingerprints are split into separate physical candidates before `L01/L02/...` is built. If the proof is incomplete, the original candidate is preserved rather than guessed.

### 2. A definitive FAIL/REJECT can be classified but not dropped
V1.5.7 `_process_loot()` returned immediately whenever any sibling item remained `FINAL6_UNRESOLVED_ITEMS`. That means an already authoritative `REJECT` in the same queue was never sent to DropController.

V1.5.8 commits authoritative resolved dispositions first:
- REJECT -> verified DROP even if another sibling is unresolved.
- ACCEPT + KEEP -> keep/remember, no movement.
- ACCEPT + STORE -> deferred until the whole queue is resolved, because Store mutates the second container.
- UNRESOLVED -> remains untouched and may still cause Safe Stop. It is never silently converted to REJECT.

## Not changed
Navigation A<->B, shared InventorySensor, Stage16 Final6 Reader, Filter Engine, Option Registry, Stage17 Backend, AutoRoll and Storage core are unchanged.

## Live acceptance
With 3 adjacent Boss drops, Loot Queue should contain separate L01/L02/L03 when tooltip identity proves they are separate items. A definitive FILTER_REJECT must be dropped even if another queue row later remains unresolved.
