# Auto Pro By Eric V12.11 — V1.7.10E
## Adaptive Paddle Final6 Speed Rootfix

Status: **QA CANDIDATE — live Windows/JX1 verification required**.

### Root cause
The new log `logs(20261014-070501).rar` proves the slowness is not InventorySensor, Final6 segmentation, or the per-Auto startup contract. PaddleOCR was invoked in **245/246 reads (99.59%)** and its own elapsed time had **9.275 s median / 9.696 s p95**. It was also OCRing the entire tooltip although Paddle's contract is only NAME/FAMILY evidence for the six option rows.

### Correct architectural fix
1. **Stage A — fast authoritative reader:** existing Final6 segmentation, foreground Tesseract, ClosedWorld Vision, unit gates and numeric authorities run first with Paddle deferred.
2. **Escalation policy:** Paddle is invoked only when necessary. PASS and UNKNOWN always escalate. A suspected absent wanted option escalates whenever Tesseract has a near-target hint. A value-confirmed reject may stay fast only when Tesseract independently sees the failed target.
3. **Stage B — Paddle rescue:** if escalation is required, the canonical scan reruns with Paddle. Paddle remains text-only evidence and cannot provide numeric truth or directly decide PASS/FAIL.
4. **Exact Paddle workload:** Paddle receives only the native **Final6 NAME ROI**, not the title/base-stat portion of the tooltip. Coordinates are translated back to the original tooltip space before V1.7.8 unique-row assignment.

### Why this is not a patch
No OCR threshold, ClosedWorld threshold, numeric threshold, Final6 cadence, OptionRegistry, filter semantics, or per-Auto ownership was weakened. The slow engine is moved into its correct role: **bounded ambiguity rescue**, not unconditional primary work.

### Replay / QA
- Historical false-absence cases from the V1.7.8 forensic set: **11/11 still force Paddle escalation**.
- Final6 ROI geometry replay: **245/245** complete historical frames covered.
- Median Paddle input area after ROI ownership: **23.08% of the old full-tooltip area** = **76.92% less image area** before inference.
- Foreground + Tesseract component benchmark in this environment: **~0.412 s median** over 39 samples. This is not a Windows/JX1 end-to-end speed claim.
- Python source compile: **23/23 PASS**. JSON parse: PASS. Inline JS syntax: PASS. Policy unit tests: PASS.

### Preserved
V1.7.9E Auto Chest / Auto Roll / Auto Boss startup contracts and mutual exclusion remain unchanged. AutoBoss, AutoRoll transaction owner, InventorySensor, ItemFilterEngine, OptionRegistry, Stage16, Paddle runtime engine, ClosedWorld Vision, TooltipDetector and StorageTruth hashes remain unchanged.

### Live acceptance
Run Reader Test on JX1 and inspect `adaptive_paddle`: clear authoritative rejects should normally stay on Stage A; PASS/UNKNOWN/suspicious absence must escalate. Measure actual median/p95 before promoting this build.
