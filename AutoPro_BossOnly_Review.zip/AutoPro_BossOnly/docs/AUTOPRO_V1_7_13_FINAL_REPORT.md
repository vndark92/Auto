# Auto Pro By Eric V12.11 — AutoRoll V1.7.13E
## AutoRoll Stable Read Consensus + UI Status Dock Rootfix

Status: **QA CANDIDATE — LIVE JX1 VERIFICATION REQUIRED**

Parent: `AutoProByEric_V12.11_AutoRoll_V1.7.12E_DropTransientReconcileContinueRootfix_QA_CANDIDATE.zip`

## User-visible fixes

1. The Auto Roll result/status box was removed from the upper **TRẠNG THÁI** panel and docked at the bottom of the **FLOW** panel, in the empty area requested by the user.
2. `UNKNOWN/UNRESOLVED` Final6 evidence no longer becomes a fatal Auto Roll stop while the same physical item/tooltip is still proven. Auto Roll enters `FILTER_RECHECK_SAME_ITEM` and performs read-only fresh rechecks of the same item until ACCEPT, REJECT, or USER STOP.
3. No new Roll, material placement, popup click, or queue advance is permitted during `FILTER_RECHECK_SAME_ITEM`.

## Forensic basis — logs(20261014-151548).rar

- Queue reads: **47**
- Authoritative REJECT: **45**
- UNRESOLVED: **2** (`20261014_221147`, `20261014_221204`)
- Paddle used: **16/47**
- Paddle median elapsed in used frames: **2811.7185 ms**
- All reads used necklace scope `daychuyen`, Profile 4.

Both terminal UNRESOLVED reads showed the same actual option set. The visible tooltip includes:

- `Mức kháng tính tối đa: +6%`
- `Kháng tất cả: +35%`
- no `Kỹ năng Võ công vốn có`

The old runtime nevertheless produced:

- Skill rule: `UNKNOWN / TARGET_EXCLUSION_INCOMPLETE`
- All Resist rule: `UNKNOWN / TARGET_VALUE_UNKNOWN`
- Max Resist Cap rule: **PASS with false value 11**

This was not a Roll transaction error. It was a reader/evidence ownership error followed by an AutoRoll state-machine policy error.

## Root cause 1 — asymmetric target exclusion

The target-specific text selector could rank an `UNKNOWN` Tesseract family above a high-confidence Paddle reading of a *different known family*. On the real `Mức kháng tính tối đa` row, that left one physical row `ROW_UNKNOWN` while evaluating whether `Kỹ năng Võ công vốn có` was absent. Five rows were excluded, one stayed unknown, therefore the mandatory Skill rule could never reach `FAIL_ABSENT_CONFIRMED`.

### Rootfix

Every physical Final6 row now resolves **one target-independent canonical NAME/FAMILY** first via the existing multimodal canonical-row fusion. In addition, when the canonical V12 visual classifier has authoritatively identified a row as option X, that single row identity owns target compatibility: X is `TARGET_COMPATIBLE` and other configured option IDs are `TARGET_EXCLUDED`. A row can no longer be authoritatively `Mức kháng tính tối đa` while simultaneously remaining visually UNKNOWN for whether it is `Kỹ năng Võ công vốn có`.

The existing V1.7.8 anti-false-absence veto is preserved: if strong target-compatible Paddle text explicitly conflicts with the visual identity, the conflicting target remains `ROW_UNKNOWN` rather than being forced negative. Paddle still has **no numeric authority** and cannot manufacture PASS/FAIL by itself.

## Root cause 2 — +6% became 11

The old generic same-row rescue used one blue/gray VALUE crop beginning near 42% of the row. On this tooltip, the real `+6%` value is orange while the label is blue/purple. The mask removed the real orange value and Tesseract interpreted surviving label glyphs as `11`. That incorrect value was marked authoritative.

### Rootfix

Percent values now use native same-row consensus:

- existing explicit-percent tight ROI reader;
- independent overlapping blue/gray percent modal reader;
- explicit `%` is required by these native readers;
- if two authoritative readers disagree, result is UNKNOWN;
- no broad number-only fallback is allowed for this path.

Actual-row replay:

- `Mức kháng tính tối đa +6%` => **6 authoritative**
- `Kháng tất cả +35%` => **35 authoritative**

The generic numeric rescue is now executed **before V12 ObservedOption is frozen**, so configured PERCENT/POINT rules such as `Kháng tất cả` can carry numeric truth into the canonical Filter instead of remaining permanently value-unknown.

## Root cause 3 — UNKNOWN was treated as fatal Auto Roll failure

The old `_read_current_item_with_recovery()` used a fixed read budget. After the budget, `UNRESOLVED` returned to the Roll attempt as `ok=False`, and the session entered ERROR/STOP even when the current Roll item and tooltip were still proven.

### Rootfix

`UNKNOWN` now means **observe again, same item, no destructive action**:

`FILTER_RECHECK_SAME_ITEM`

- same logical item remains owner;
- fresh read batches continue;
- USER STOP always wins;
- ACCEPT/REJECT exits normally;
- repeated real owner/tooltip loss is the only path to `CURRENT_ITEM_LOST`;
- no reroll is allowed merely because OCR is uncertain.

## Latest failing-case replay

Both formerly unresolved captures (`221147`, `221204`) replay as:

- `Kỹ năng Võ công vốn có`: absent across all six physical rows => `FAIL_ABSENT_CONFIRMED`
- `Kháng tất cả`: **35** authoritative
- `Mức kháng tính tối đa`: **6** authoritative
- Profile 4 result: **AUTHORITATIVE REJECT**

This is the correct result: the item does not satisfy the mandatory Skill rule, and Max Resist Cap 6 is below target 7.

## Regression protection

The eleven historical V1.7.8 cases where strong Paddle target text correctly blocked a false absence certificate were replayed against the V1.7.13 evidence gate: **11/11 still protected** (`ROW_UNKNOWN`, never false TARGET_EXCLUDED).

## Scope control

Runtime behavior changes are limited to exactly three files:

- `AutoProByEric_Stage17_Backend_v1_8.py`
- `AutoProByEric_AutoRollRecordCoord_v1.py`
- `ui_locked.html`

Package metadata was updated in `BUILD_VERSION.json`, `LEAN_PACKAGE_MANIFEST.json`, and `README_START.txt`. Across the **514 parent package files** (excluding generated Python cache/runtime logs), **508 are hash-identical** to V1.7.12E; there are **0 missing parent files** and no other runtime changes. V1.7.12E Auto Chest Drop transient-reconciliation rootfix is preserved.

## Offline QA

- Python source compile: **24/24 PASS**
- JSON parse before report generation: **34/34 PASS**
- Inline UI JavaScript syntax: **4/4 PASS**
- Latest two terminal UNRESOLVED captures: **2/2 replay to correct authoritative REJECT**
- Actual percent-row numeric replay: **2/2 PASS** (`6`, `35`)
- V1.7.8 false-absence regression set: **11/11 PASS**
- Canonical-row target-compatibility consistency: **PASS** — authoritative option identity makes the same target compatible and other configured targets excluded, except preserved explicit multimodal conflict veto.
- AutoRoll read-only recovery simulation: **PASS** — three UNKNOWN reads entered `FILTER_RECHECK_SAME_ITEM`; fourth authoritative REJECT returned normally; destructive-input count remained zero during recheck.
- UI static contract: status/result box is inside FLOW and bottom-docked; recheck friendly state is present.

## Live acceptance gate

Do not promote/lock V1.7.13E until Windows/JX1 confirms:

1. the result box is visually in the requested lower FLOW area;
2. an intermittent reader UNKNOWN visibly becomes `CHƯA ỔN ĐỊNH · ĐANG SOI LẠI CÙNG ITEM`, not STOP;
3. the same item is not rerolled during that uncertainty;
4. once evidence becomes authoritative, Auto Roll resumes the correct REJECT same-item-reroll or MATCH next-item path.
