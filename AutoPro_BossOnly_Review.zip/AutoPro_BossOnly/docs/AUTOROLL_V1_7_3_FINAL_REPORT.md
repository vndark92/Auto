# Auto Pro By Eric — AutoRoll V1.7.3 Final6 Overlap / Fused Row Rootfix

## Evidence from `logs(20261007-213139).rar`

The archive contains **36** root tooltip frames for Q01 from 00:21:20 through 00:29:53.

V1.7.2's structural gate reports **36/36** frames as valid, but **3** frames are malformed despite that PASS.

The malformed frames contain the same geometry pattern:

- row5 = `262..270`
- row6 = `265..287`
- overlap = `6px`
- row6 height = `23px`

That means two different Final6 physical rows are sharing pixels; the last band is a fused/duplicated row rather than a valid independent option line.

## Root cause

Two weaknesses combined:

1. `_segmentation_truth_gate_v63()` checked cadence and median height but did not enforce a non-overlap invariant.
2. The fused-row splitter was slightly too strict. The real merged 23px band has a strong projection valley that yields about `13px + 10px`, but V1.7.2 capped each half at `1.55 × median row height`, rejecting the valid split by roughly one pixel.

## V1.7.3 fix

- Final6 rows may **never overlap in Y**.
- `_score_six()` rejects overlap before candidate selection.
- `_segmentation_truth_gate_v63()` independently rejects overlap.
- A single extreme height outlier is rejected as a fused/background-contaminated row.
- Fused-row split upper bound changes only from `1.55×` to `1.75×`.
- Strong projection-valley, glyph-count and horizontal-span proof remain mandatory.

## Current-log replay

- frames: **36**
- V1.7.2 structural PASS: **36/36**
- V1.7.2 frames containing overlap: **3**
- V1.7.3 structural PASS: **36/36**
- V1.7.3 frames containing overlap: **0**

The malformed overlapping geometry is therefore no longer allowed to silently pass as a valid Final6 block.

## Preserved

- PaddleOCR V1.7.1 Runtime Bridge
- AutoRoll V1.7.2 pacing 20% slower
- exact 4-second Roll wait
- No World Drop Guard
- AutoBoss
- InventorySensor
- Filter / OptionRegistry
- Storage core

Live JX1 confirmation is still required.
