# Auto Pro By Eric V12.11 — V1.7.12E Drop Transient Reconcile Continue Rootfix

## Live-log root cause
Input: `logs(20261014-142738).rar`.

- 292 Drop traces were present.
- 291/292 reached `FINALIZER_COMPLETE`.
- Exactly one trace, cycle **295** / `DROP-000295-Q01`, stopped at `PRE_SAFE_PAUSE_RECOVERY`.
- That cycle had **CURSOR_EMPTY_CONFIRMED** but contradictory source frames: `ITEM_STILL_IN_SOURCE` then `ITEM_GONE`.
- Ground/world evidence was explicitly `WORLD_OCCLUSION_TRANSIENT`.
- The backend then classified `PRE_SAFE_PAUSE_RECOVERY` as category `UNKNOWN`, `auto_resume_eligible=false`, `auto_resume_scheduled=false`; the lifecycle ended `STOPPED`. Therefore the UI text looked like recovery, but no scheduler owned it.

## Root cause in control flow
The Drop policy mapped an `UNKNOWN` source/cursor reconciliation directly toward Safe Pause. `_safe_pause_v2()` then rejected that pause merely because one axis (cursor) was known and rewrote the state to `PRE_SAFE_PAUSE_RECOVERY`. That rewrite had no canonical recovery owner or timer. This was a dead-end state, not a real recovery state.

## V1.7.12E rootfix
1. `SOURCE_AMBIGUOUS + CURSOR_EMPTY_CONFIRMED` now enters **bounded observation-only settle reconciliation** on the same logical item and the same `drop_tx_id`.
2. Settle recovery sends **zero source clicks and zero ground clicks**. It uses neutral cursor movement, fresh captures, source fingerprint checks, and a tooltip-presence probe that can prove only `SOURCE_PRESENT`.
3. Settled `COMMITTED` finalizes the existing Drop and continues Auto Chest.
4. Settled `NOT_COMMITTED` returns to the already-existing same-item retry path; it does not open a new chest.
5. Settled `PARTIAL` returns to the existing ground-only recovery path.
6. Only a state that remains `UNKNOWN` after the bounded fresh observations is a true safety stop.
7. Safe-Pause authorization now uses the full source/cursor reconciliation matrix. A single known axis no longer manufactures `PRE_SAFE_PAUSE_RECOVERY`.

## Scope
Only `AutoProByEric_Stage17_Backend_v1_8.py` plus build/report metadata changed. AutoRoll, AutoBoss, InventorySensor, ItemFilterEngine, OptionRegistry, Stage16 Reader, Paddle runtime/speed path, ClosedWorld Vision, TooltipDetector, StorageTruth, AutoResume controller and `ui_locked.html` are hash-identical to V1.7.11E.

## Offline QA
- Python compile: **23/23 PASS**.
- Inline JavaScript syntax: **4/4 PASS**.
- Parent protected files unchanged: **472 files**, unexpected changed/missing: **0**.
- Targeted Drop recovery simulations: **8/8 PASS**.

## Live acceptance
Run Auto Mở Rương again on Windows/JX1. For a transient contradictory Drop frame, the log should show `DROP_TRANSIENT_AMBIGUITY_SETTLE_BEGIN` -> `DROP_TRANSIENT_AMBIGUITY_SETTLE_RESULT`, then either `DROP_CONFIRMED`/`FINALIZER_COMPLETE` or same-item retry. It must not surface `PRE_SAFE_PAUSE_RECOVERY` for the cycle-295 state pattern.

Status: **QA CANDIDATE — live JX1 verification required before lock.**
