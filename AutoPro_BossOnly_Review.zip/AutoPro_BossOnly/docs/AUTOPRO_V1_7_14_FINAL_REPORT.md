# Auto Pro By Eric V12.11 — V1.7.14E
## All-Auto Read-Unstable Continue Contract Rootfix

### User contract
Reader instability (`UNRESOLVED`, temporary tooltip/Final6 uncertainty) must not stop Auto Chest, Auto Roll, or Auto Boss.

### Auto Chest
Unknown filter evidence is non-destructive. The item remains in Player Inventory and is finalized as `UNRESOLVED_DEFERRED_SAFE_KEEP`. If fresh capacity remains safe, the next chest starts immediately. No Drop or Store is authorized from uncertainty and no FILTER_RECHECK_PENDING whole-loop stop is scheduled.

### Auto Roll
Unknown Final6/filter evidence remains `FILTER_RECHECK_SAME_ITEM`. The exact current item is held untouched and re-read with zero Roll/material/popup/queue-advance input until ACCEPT/REJECT or user Stop. Only repeated physical item-owner loss may become `CURRENT_ITEM_LOST`.

### Auto Boss
Fair queue passes remain bounded so one difficult loot item cannot monopolize the queue. Any item still unresolved after the passes is left untouched in Player Bag, registered `DEFERRED_UNRESOLVED_SAFE_KEEP`, included in the next bag baseline, and the boss session continues. Unknown is never converted to REJECT.

### Safety boundary
This change does **not** make destructive uncertainty non-fatal. User Stop, client/input failures, physical item loss, unresolved Drop/Store transaction ownership, or capacity/inventory safety failures retain their existing safety behavior. The rootfix is specifically: **reader uncertainty is non-fatal; physical/transaction uncertainty remains protected.**

### QA
- Python compile: 23/23 PASS
- JSON parse: PASS
- Inline JavaScript syntax: PASS
- Per-Auto source contracts: PASS
- Live Windows/JX1 confirmation: REQUIRED before lock
