# Auto Pro By Eric — AutoRoll V1.6.4

## Evidence from V1.6.3 runtime log

The V1.6.3 ledger rootfix is working: two separate reacquire transactions completed in the same Roll attempt without `DUPLICATE_DOMAIN_EVENT`.

The new stop is not Fatal. It is:

`FINAL6_UNRESOLVED`

The nested reader reason is:

`TOOLTIP_NOT_FOUND_ON_ITEM`

The log shows AutoRoll repeatedly treated the Player Bag location around `[619,162]` / anchor `[2,0]` as the current item, but all hover samples reported `NOT_FOUND`.

## Root cause

After `ITEM_SOURCE -> ROLL_ITEM_SLOT -> Roll -> popup`, V1.6.3 assumed the rolled item must be reacquired in Player Bag.

That assumption is too strong.

A visual patch/signature can still look close enough at the old Bag cell to pass the MAE identity threshold even when the actual rolled item remains in the Roll item slot. Final6 then hovers the wrong physical owner and sees no tooltip.

## V1.6.4 fix

Post-Roll owner is now evidence-driven:

1. Probe `ROLL_ITEM_SLOT` first.
2. Reuse the canonical shared Final6 Reader/Filter through a temporary synthetic hover lattice centered exactly on the configured Roll item slot.
3. If a tooltip is present there, owner becomes `ROLL_ITEM_SLOT`.
4. If no tooltip is present there, fall back to Player Bag reacquisition and canonical read.
5. `FILTER_REJECT` with owner `ROLL_ITEM_SLOT` rerolls the same item in place; no redundant Bag pick/place.
6. `FILTER_ACCEPT` with owner `ROLL_ITEM_SLOT` returns the accepted item to its original Bag cell before moving to the next queue item.

## Scope control

Unchanged from V1.6.3:
- AutoBoss
- InventorySensor
- Stage16 Final6 Reader
- Filter Engine
- Option Registry
- Stage17 Backend
- Storage core

V1.6.2 inventory toggle owner rootfix and V1.6.3 reacquire transaction ledger rootfix are preserved.

## QA

- Python compile-all: PASS
- Synthetic Roll-slot hover grid centers exactly on configured Roll slot: PASS
- Protected shared hashes unchanged: PASS
- Live JX1: required
