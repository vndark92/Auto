# Auto Pro By Eric — AutoRoll V1.6.5

## Root cause from attached runtime proof

The dominant read instability is in **Final6 physical-row segmentation before OCR**.

Representative frame:
`20261007_131000_Q01_hover1_frame1.png`

V1.6.4 boxes:
`[(157, 159), (200, 207), (213, 222), (226, 235), (239, 261), (265, 274)]`

The old geometry can select a very thin stray band and merge two adjacent real option rows into one over-tall band. OCR then receives the wrong six physical rows and becomes UNCERTAIN/UNRESOLVED even though the tooltip is visibly present.

## V1.6.5 rootfix

Stage16 now performs a geometry-only normalization step before Final6 selection:

- estimate normal row height from the live tooltip;
- discard only strong ultra-thin outliers;
- detect an over-tall fused band;
- split it only at a strong projection valley;
- require both halves to have plausible row height, glyph count and horizontal span;
- leave all OCR text, option/value parsing, registry and Filter truth unchanged.

V1.6.5 boxes on the same frame:
`[(201, 209), (214, 223), (227, 236), (240, 252), (253, 262), (266, 275)]`

## Replay across the attached log

Frames replayed: **256**

- V1.6.4 structural truth pass: **51/256 (19.92%)**
- V1.6.5 structural truth pass: **256/256 (100.0%)**
- Previously failing frames repaired to pass: **205**

This is a structural replay; live JX1 OCR/Filter confirmation is still required.

## Roll timing

Changed from:

`Roll mouse-up -> wait 3.0s -> popup`

to:

`Roll mouse-up -> wait 4.0s -> popup`

The UI status and runtime state were updated to `WAIT_RESULT_4S`.

## Scope control

Preserved:
- V1.6.2 inventory Q/F4 single-owner rootfix
- V1.6.3 reacquire retry ledger rootfix
- V1.6.4 post-Roll item owner rootfix

Unchanged:
- AutoBoss
- InventorySensor
- ItemFilterEngine
- OptionRegistry
- Stage17 Backend
- Storage core

Compile-all: **PASS**
Protected shared hashes: **PASS**
