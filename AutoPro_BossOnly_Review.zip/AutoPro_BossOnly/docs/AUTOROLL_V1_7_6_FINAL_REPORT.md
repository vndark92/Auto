# Auto Pro By Eric V12.11 — AutoRoll V1.7.6E
## Paddle oneDNN Runtime Rootfix

### Live log basis
Input: `logs(20261013-233814).rar` from V1.7.5E READER_TEST.

- Queue reads: 382
- Time span in filenames: 20261014_001457 → 20261014_014701
- Execution mode: READER_TEST 382/382
- Live actions enabled: false 382/382
- Active registry: WEAPON_CLOSED_9 382/382
- Pipeline: PROFILE_SLOT_AWARE_TWO_STAGE_V1_7_5 382/382
- Filter outcome: REJECT 378/382; UNRESOLVED 4/382
- Fail-safe disposition: DROP (test-only, no live action) 378; BLOCK 4
- Final6 segmentation: OK 386/386 frames
- Paddle runtime used: 0/382 queue reads
- Paddle bridge failures: PADDLEOCR_RUNTIME_FAILED 386/386 frame attempts
- Dominant Paddle error: `ConvertPirAttribute2RuntimeAttribute ... onednn_instruction.cc:118`
- Final6 row identity: 745 AUTHORITATIVE / 1571 UNKNOWN = 32.17% authoritative row identity
- Four unresolved cases correctly used Frame-2 and remained BLOCK; no uncertainty was converted to reject-by-guess.

### Root cause
PaddlePaddle 3.3.1 + PaddleOCR 3.7.0 initializes successfully, but CPU inference enters the oneDNN/PIR runtime path and throws the `ConvertPirAttribute2RuntimeAttribute` NotImplementedError. Import/warmup-only checks therefore produce a false READY state.

### V1.7.6E fix
1. PaddleOCR v3 CPU initialization now prefers `enable_mkldnn=False`, `enable_hpi=False`, `device="cpu"`.
2. Exact oneDNN/PIR runtime failure gets one bounded fresh-engine retry with MKL-DNN disabled.
3. Paddle remains text evidence only; it never becomes numeric or Filter decision authority.
4. Failure remains fail-closed and falls back to existing Tesseract/visual path.
5. `PADDLEOCR_SETUP.py` now performs a real synthetic inference smoke test, not initialization-only warmup.
6. One-folder Python 3.12 installer and all V1.7.5 slot-aware registries are preserved.

### Scope note
The supplied live log used `scope_value=vukhi` for all 382 reads. Therefore the new V1.7.5 Áo/Bao tay/Dây chuyền slot extensions were loaded in runtime provenance but were not exercised by this test run.

### QA
- Python compile: PASS (23 Python files)
- Mock init policy: PASS (`enable_mkldnn=False` first choice)
- Mock exact oneDNN runtime recovery: PASS (one bounded retry)
- Mock unrelated runtime error: PASS (fail-closed, no retry loop)
- Protected core hash: PASS for AutoRoll transaction, AutoBoss, InventorySensor, Stage16, ItemFilterEngine, OptionRegistry, Stage17 Backend, StorageTruthHarness
- Changed files only: Paddle hybrid, Paddle setup smoke test, BUILD_VERSION, environment requirements comment
- Live JX1/Paddle inference after rootfix: REQUIRED
