# Auto Pro By Eric — AutoRoll V1.7.1 PaddleOCR Runtime Bridge Rootfix

## Root cause confirmed from logs(20261007-154210).rar

The package path is V1.7.0, but the live queue-reader path did not use the Paddle hybrid reader.

Observed across all 31 Q01 queue-read artifacts:

- reader.status = FAST_SCAN: 31/31
- performance_path = MULTI_PROFILE_SHARED_EVIDENCE_V1: 31/31
- fast_filter pipeline = MULTI_PROFILE_OBSERVED_OPTION_FILTER_V12_0: 31/31
- reader_selection fields: 0
- Paddle runtime evidence keys: 0
- PADDLE_HYBRID_READY: 0

Runtime provenance explicitly names:

`Api._read_queue_item_internal/_fast_scan_one_crop`

V1.7.0 had integrated PaddleOCR in `Stage16.read_single_tooltip()`, but active configured filters normally finish earlier in the Stage17 FAST_SCAN path. Therefore PaddleOCR could be installed correctly and still never participate in the actual read.

## V1.7.1 rootfix

PaddleOCR is now bridged directly into `_fast_scan_one_crop()`.

The direct runtime pipeline is:

FULL TOOLTIP
→ existing Final6 physical-row geometry
→ Tesseract foreground OCR
+ PaddleOCR Vietnamese full-tooltip OCR
→ align Paddle detections to each of the six physical rows
→ choose semantically strongest NAME/FAMILY text evidence
→ existing visual row authority
→ existing VALUE-ROI numeric authority
→ existing OptionRegistry / Filter

Paddle does not donate numeric truth and does not directly decide PASS/FAIL.

## Diagnostics

Every fast queue read now contains:

- `reader.paddle_runtime_used`
- `reader.paddle_runtime_bridge`
- `fast_filter.paddle_runtime_bridge`
- per-frame `paddle_runtime_bridge`
- per-row Paddle text/confidence

So the next log can prove whether Paddle is actually active.

## Preserved

- V1.7.0 Stage16 hybrid reader
- V1.6.7 gentle pacing
- exact 4-second Roll wait
- No World Drop Guard
- AutoBoss
- InventorySensor
- ItemFilterEngine
- OptionRegistry
- Storage core

Live Windows/JX1 confirmation is required.
