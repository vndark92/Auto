# Auto Pro By Eric — AutoRoll V1.7.2 Pacing 20% Slower

AutoRoll action cadence is slowed by exactly **20%** at runtime.

Formula:

`effective_ms = ceil(configured_ms × 1.20)`

Because the multiplier is applied in `AutoRollInputPacing.ms()`, it also affects pacing values already saved in an existing user config. There is no destructive config reset.

## Effective default timing

{
  "move_duration_ms": 12,
  "pre_click_settle_ms": 30,
  "post_click_settle_ms": 36,
  "focus_settle_ms": 66,
  "focus_activation_settle_ms": 42,
  "pick_confirm_timeout_ms": 1320,
  "slot_confirm_timeout_ms": 1320,
  "retry_delay_ms": 84,
  "verify_poll_ms": 42,
  "tooltip_hover_settle_ms": 72,
  "reader_reread_delay_ms": 72,
  "mouse_down_dwell_ms": 78,
  "focus_click_settle_ms": 42
}

## Roll wait

The previously locked Roll-result wait remains exactly **4.0 seconds** and is not multiplied to 4.8 seconds.

## Not scaled

Counts, image thresholds and safety geometry are unchanged:
- stable frame count
- perception/reacquire counts
- identity MAE thresholds
- safe-radius pixels
- slot evidence radius

## Preserved

- PaddleOCR V1.7.1 Runtime Bridge
- Stage16 hybrid/fallback
- No World Drop Guard
- AutoBoss
- InventorySensor
- Filter / OptionRegistry
- Storage core

Compile: **PASS**
Protected shared hashes: **PASS**

Live JX1 confirmation is required.
