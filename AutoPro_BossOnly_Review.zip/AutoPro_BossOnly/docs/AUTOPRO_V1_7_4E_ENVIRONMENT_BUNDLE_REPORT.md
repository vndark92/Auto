# Auto Pro By Eric — V1.7.4E One-Folder Environment Bundle

## Scope
Environment/setup rootfix only. AutoRoll/AutoBoss/OCR recognition logic is not modified.

## Root causes addressed
- `RUN_AUTOPRO.bat` previously called the machine-default `python`, which selected Python 3.15 after Windows reinstall.
- PaddlePaddle 3.3.1 / PaddleOCR 3.7.0 are installed under Python 3.12, so the old launcher could not see `webview`, `pytesseract`, `mss`, or Paddle.
- Paddle install/check BAT files also used default `python`.
- Fresh Windows required manual recreation of Python, VC++ runtime, Tesseract and Python packages.

## New one-folder setup
`SETUP_AUTOPRO/`
- `INSTALL_ALL.bat` → one entry point for environment repair.
- `Install-AutoPro.ps1` → Python 3.12, VC++ x64, Tesseract, pip packages, model-cache restore, environment check, Paddle warmup.
- `CHECK_ENV.bat` / `CHECK_ENV.py` → writes `ENV_STATUS.json`.
- `PREPARE_OFFLINE_BUNDLE.bat` → caches Windows installers, Python wheels, and existing Paddle model caches for a future Windows reinstall.
- `requirements-py312.txt` → pinned top-level OCR/UI runtime.

## Launcher rootfix
`RUN_AUTOPRO.bat` now:
- requires `py -3.12`;
- checks required imports before launch;
- never follows the machine default Python;
- pauses and shows an actionable error instead of closing immediately.

## OCR runtime pins
- Python 3.12
- PaddlePaddle 3.3.1
- PaddleOCR 3.7.0
- pywebview 6.2.1
- pytesseract 0.3.13
- Tesseract 5.5.x
- mss / Pillow / OpenCV / NumPy via requirements file

## QA
- Core `.py` runtime files are byte-identical to V1.7.4.
- Only setup/launcher/requirements/readme/build metadata were changed.
- Python helper `SETUP_AUTOPRO/CHECK_ENV.py` compiles.
- Live Windows install and Paddle model warmup still require user-side execution.

Generated: 2026-10-13T15:16:22
