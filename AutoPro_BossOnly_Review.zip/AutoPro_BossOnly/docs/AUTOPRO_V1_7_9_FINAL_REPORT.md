# Auto Pro By Eric V12.11 — V1.7.9E
## Per-Auto Startup Contract + Filter Registry Rootfix

### Root cause
The Auto Mở Rương startup guard was still enforcing an obsolete registry snapshot: 32 total options, 26 filterable and 6 known-ignore. The canonical V1.7.5+ OptionRegistry is valid at 34 total entries: 7 blue + 19 gray + 3 slot-only filterable + 5 known-ignore. GLOBAL is intentionally a closed 20-option active union. Therefore the old guard rejected a valid registry before any chest loop/input began. This is not a Paddle, OCR, InventorySensor or Q/F4 failure.

### Rootfix architecture
- Removed the historical fixed-count startup gate and the generic `FILTER_REGISTRY_STARTUP_FAIL` path.
- Added one canonical `filter_runtime_guard()` which derives truth from `validate_registry()`, actual registry entries, current equipment scope, rule ownership, enabled rules and selected profile IDs.
- Auto Mở Rương calls the guard as `AUTO_CHEST`.
- Auto Roll calls it as `AUTO_ROLL` with AutoRoll's selected profile IDs.
- Auto Boss calls it as `AUTO_BOSS` with AutoBoss's selected profile IDs.
- Added backend-authoritative `automation_mode_guard()` so CHEST / ROLL / BOSS cannot own pointer/input concurrently. UI checks are only mirrors.
- Startup errors are now mode-specific instead of one generic registry error.

### Explicit function ownership
**Auto Mở Rương** owns source inventory Q/F4, chest opening queue, Final6/filter and KEEP/DROP/STORE lifecycle.

**Auto Roll** owns Roll UI verification, recorded item/material coordinates, Roll transaction, 4-second result wait, same-item reacquire and Final6/filter. It does not own the Chest lifecycle.

**Auto Boss** owns A/B navigation, Ctrl+F once per session, Key1 once per Boss cycle, Boss loot detection and KEEP/STORE/DROP disposition. STORE retains its own container setup/pair-test requirements.

### QA
- Python compile: 22/22 PASS.
- JSON parse: PASS.
- Inline UI JavaScript `node --check`: PASS.
- Current real filter configuration preflight: AUTO_CHEST READY / AUTO_ROLL READY / AUTO_BOSS READY.
- Empty filter configuration produces three separate `*_FILTER_NOT_CONFIGURED` reasons.
- Selected-disabled profile produces mode-specific `*_FILTER_SELECTED_PROFILES_INACTIVE`.
- Scope mismatch produces `*_FILTER_SCOPE_INVALID`.
- Mutual exclusion simulation: Chest blocked by Roll, Roll blocked by Boss, Boss blocked by Chest; self-owner does not block itself.
- Legacy `FILTER_REGISTRY_STARTUP_FAIL` string and old 32/26/6 startup checks are absent from runtime/UI.
- OptionRegistry, ItemFilterEngine, InventorySensor, Stage16, Paddle runtime, V1.7.8 vision/crop files and StorageTruth core are hash-identical to V1.7.8E.

### Live acceptance gate
Windows/JX1 must still verify the three real Start paths. V1.7.9E is a QA candidate until that run confirms Auto Mở Rương starts past filter preflight and each Auto remains mutually exclusive without cross-module regressions.
