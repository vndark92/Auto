# Auto Pro By Eric — V1.7.0 PaddleOCR Hybrid Final6

New pipeline:

FULL TOOLTIP
→ PaddleOCR Vietnamese detection + recognition
→ option-like text boxes sorted by Y
→ physical Final6
→ existing Tesseract Stage16 verifier
→ existing Stage16 truth gates
→ existing OptionRegistry
→ existing Stage17 Filter

PaddleOCR never directly decides ACCEPT/REJECT.

If PaddleOCR is missing, fails to initialize, or produces a weaker result, Auto Pro automatically falls back to the existing Stage16 reader.

## One-click setup

Run `INSTALL_PADDLEOCR_ENGINE.bat` once.

It installs PaddlePaddle CPU + PaddleOCR and runs `PADDLEOCR_SETUP.py` to initialize the Vietnamese OCR model. The first run may download model files.

## Preserved from V1.6.7

No World Drop Guard, exact 4-second Roll wait, gentle pacing, post-Roll owner, reacquire ledger, AutoBoss, InventorySensor, Stage17 Filter, OptionRegistry and Storage core are preserved.

Static compile: PASS
Protected shared hashes: PASS
Paddle present in build environment: False

Live PaddleOCR/JX1 runtime confirmation is required after installation.
