# AutoRoll V1.7.4 — Profile-Aware Two-Stage Registry

Parent: `AutoProByEric_V12.11_AutoRoll_V1.7.3_Final6OverlapFusedRowRootfix_QA_CANDIDATE.zip`

## Implemented

- Stage 1 selects a closed registry before option matching.
- Weapon = Closed-9.
- Common Gear = Closed-10 for Nón / Áo / Bao tay / Đai / Giày / Nhẫn.
- Dây chuyền / Ngọc bội = Closed-2.
- Canonical 32-option registry remains intact for audit/exclusion compatibility.
- Outside-profile strict family/canonical evidence returns `OUT_OF_PROFILE`; it cannot be promoted to a wanted option by fuzzy score.
- `Tốc độ đánh – ngoại công` and `Tốc độ đánh – nội công` remain separate mandatory qualifier identities.
- Fixed the visual secondary normalizer for Vietnamese `đ/Đ`, so `đánh` and `độ` retain their `d` token before ASCII folding.

## QA

- Python compile: PASS.
- UI JavaScript syntax: PASS.
- Canonical registry 32/32 validation: PASS.
- Profile membership: Weapon 9 / Common 10 / Accessory 2: PASS.
- 12 globally excluded canonical option texts: 12/12 gated OUT_OF_PROFILE in each of the three closed profiles.
- False exclusion on active canonical profile texts: 0/9 Weapon, 0/10 Common, 0/2 Accessory.
- V1.7.3 current-log Final6 replay: 36/36 segmentation truth PASS, 0 overlap.
- V1.6.5 historical regression set: 256/256 segmentation truth PASS, 0 overlap.
- Protected AutoBoss / InventorySensor / Stage16 / ItemFilterEngine / StorageTruthHarness hashes: unchanged.

## Safety

`UNRESOLVED` remains non-destructive. The new profile gate narrows candidate identity; it does not relax numeric authority, Filter authority, No World Drop Guard, 4-second Roll wait, or V1.7.2 pacing.

## Live status

Static/synthetic/historical replay QA passed. Live JX1 confirmation is still required; this report does not claim live recognition accuracy.
