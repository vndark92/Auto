# Auto Pro By Eric V12.11 — AutoRoll V1.7.8E
## Multimodal Final6 Evidence Rootfix

Status: **OFFLINE QA PASS — LIVE JX1 REQUIRED BEFORE LOCK**

### Evidence basis

Analyzed the supplied live archive `logs(20261014-070501).rar`:

- Queue reads: **246**
- Final6 complete: **245/246 = 99.59%**
- Paddle runtime used: **245/246 = 99.59%**
- Paddle successful frame calls: **245**
- Paddle CPU latency: median **9275.2 ms**, p95 **9696.0 ms**
- Old bridge frames with at least one duplicated Paddle box across adjacent rows: **154/245 = 62.86%**
- Extra duplicate row assignments in those frames: **332**
- Final6 unresolved: **1** (`20261014_071914_Q01_queue_read.json`)
- Old false-absence certificates blocked by the exact new high-confidence target-text gate: **11** reads. These are **not converted to PASS**; the conflicting row becomes UNKNOWN until visual/numeric authority resolves it.

The new log proves the V1.7.6 oneDNN rootfix is working: Paddle now executes on 245/246 queue reads. The remaining correctness failures therefore occur after OCR runtime startup, inside row alignment / evidence fusion / tooltip crop ownership.

### Root causes fixed

1. **Paddle detection reuse across physical rows**

   The V1.7.1 bridge independently searched a tolerance window for each Final6 row. One Paddle detection could therefore be appended to two adjacent rows. The supplied log shows this on 154/245 successful Paddle frames (62.86%).

   **V1.7.8 fix:** every Paddle detection is assigned once to the nearest valid physical Final6 row. A detection can never be reused by a second row.

2. **False `ABSENT_CONFIRMED` from visual-only exclusion while Paddle reads the target**

   V12 target compatibility consumed Tesseract text only. High-confidence Paddle text such as `Ky nng Võ cng vn có +1 cáp` could identify the skill family while the old visual gate still emitted `TARGET_EXCLUDED`. Six exclusions then became `FAIL_ABSENT_CONFIRMED`.

   **V1.7.8 fix:** target-specific Paddle NAME/FAMILY evidence participates as a secondary safety vote. If high-confidence Paddle text is semantically compatible with the wanted target but the only negative evidence is `TARGET_VISUAL_EXCLUDED`, the row is downgraded to `ROW_UNKNOWN`. This blocks a false absence certificate but does not create canonical identity, numeric value, PASS, or FAIL.

3. **Sixth option line clipped before Final6**

   The one unresolved two-frame case has only five clusters because the tooltip image ends through the sixth line. The green background projection was being treated as the exact text boundary.

   **V1.7.8 fix:** green projection remains only the panel locator. A bounded cadence-derived glyph guard is retained around the vertical panel edge before handing pixels to unchanged strict Final6 segmentation. No Final6 threshold was lowered and no synthetic row is inferred.

4. **Skill family OCR resilience was alias-driven/too exact**

   Common OCR forms drop one glyph (`nang -> nng`, `cong -> cng`, `von -> vn`).

   **V1.7.8 fix:** the skill family now requires a conservative four-token conjunction (`nang`, exact `vo`, `cong`, `von`) with edit-distance <= 1 only on the long high-specificity tokens. This avoids adding ad-hoc typo aliases.

### Multimodal authority contract

- Closed-world visual thresholds are unchanged: confirm **0.66**, exclude **0.43**, margin **0.075**.
- Paddle remains **NAME/FAMILY secondary evidence only**.
- Paddle never supplies numeric truth.
- Paddle never directly decides Filter PASS/FAIL.
- A Tesseract/Paddle discriminative-family disagreement becomes `OCR_FAMILY_CONFLICT`/UNKNOWN; neither engine silently wins.
- Filter still consumes canonical ObservedOption evidence.

### Files changed

- `AutoProByEric_Stage17_Backend_v1_8.py`
- `AutoProByEric_ClosedWorldOptionVision_v1.py`
- `AutoProByEric_TooltipDetector_v1_7.py`
- `BUILD_VERSION.json`
- package metadata/docs only

Protected AutoRoll transaction, AutoBoss, InventorySensor, ItemFilterEngine, OptionRegistry, Stage16 Reader, StorageTruthHarness, Paddle runtime/setup, launcher and locked UI hashes remain unchanged.

### Offline QA

- Python compile: **22/22 PASS**
- JSON parse: **PASS**
- JavaScript syntax: **2/2 PASS**
- Unique Paddle assignment synthetic contract: **PASS**
- High-confidence Paddle anti-exclusion -> UNKNOWN, never PASS: **PASS**
- Low-confidence Paddle cannot veto exclusion: **PASS**
- Paddle result contains no numeric authority fields: **PASS**
- Skill near-token family tests: **PASS**
- Multimodal family conflict -> UNKNOWN: **PASS**
- Tooltip guard retains a synthetic sixth row below the green panel edge: **PASS**
- Protected runtime hash set: **PASS**

### Remaining live gate

V1.7.8E must still be run on the real JX1 client. Do not lock/promote it until new logs prove unique Paddle row assignment, six-row recovery for the clipped-tooltip shape, and no regression in V1.7.7E inventory/Q-F4 behavior.

The supplied log also shows Paddle CPU inference around 9.3 s median. This build intentionally does **not** modify the stable V1.7.6 Paddle engine path while fixing correctness; performance optimization should be benchmarked separately after this evidence rootfix is live-verified.
