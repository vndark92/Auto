/* AUTO PRO BY ERIC — Frozen Wuxia V2 shell sharpness / fill owner V1.
   Surgical shell-only patch. Page content geometry is untouched.
   VisualCropRect = x:0, y:22, w:1387, h:780.
   One crop + one uniform scale + one offset for artwork, UI and hitboxes.
*/
(function(){
  'use strict';
  const DESIGN_WIDTH=1387, DESIGN_HEIGHT=850;
  const CROP={x:0,y:22,w:1387,h:780};
  const REGIONS={
    artwork:{x:0,y:0,w:DESIGN_WIDTH,h:DESIGN_HEIGHT}, crop:Object.assign({},CROP),
    nav:{x:221,y:147,w:170,h:540}, main:{x:410,y:122,w:946,h:680},
    center:{x:410,y:122,w:729,h:680}, right:{x:1139,y:122,w:217,h:680},
    chrome:{x:1138,y:30,w:210,h:59}
  };
  let last={scale:1,offsetX:0,offsetY:-CROP.y,width:CROP.w,height:CROP.h,fillMode:'CROP_COVER',crop:Object.assign({},CROP),dpr:1};
  let raf=0;
  function snapCss(v,dpr){return Math.round(v*dpr)/dpr}
  function applyMasterGeometry(){
    raf=0;
    const s=document.getElementById('frozenDesignSurface'); if(!s)return;
    const vw=Math.max(1,window.innerWidth||CROP.w), vh=Math.max(1,window.innerHeight||CROP.h);
    const dpr=Math.max(1,Number(window.devicePixelRatio)||1);
    // Fill the native client with the approved crop without stretching.
    // Common Windows 16:9 sizes match this crop almost exactly; max() also prevents sub-pixel bars.
    const scale=Math.max(vw/CROP.w,vh/CROP.h);
    const cropRenderedW=CROP.w*scale, cropRenderedH=CROP.h*scale;
    let viewX=(vw-cropRenderedW)/2;
    let viewY=(vh-cropRenderedH)/2;
    viewX=snapCss(viewX,dpr); viewY=snapCss(viewY,dpr);
    const surfaceOffsetX=viewX-CROP.x*scale;
    const surfaceOffsetY=viewY-CROP.y*scale;
    // CSS zoom lets Chromium rerasterize text/UI at the target scale instead of
    // scaling a pre-rasterized compositor layer. Position through layout, not transform.
    s.style.transform='none';
    s.style.zoom=String(scale);
    s.style.left=(surfaceOffsetX/scale).toFixed(6)+'px';
    s.style.top=(surfaceOffsetY/scale).toFixed(6)+'px';
    last={scale,offsetX:surfaceOffsetX,offsetY:surfaceOffsetY,width:vw,height:vh,fillMode:'CROP_COVER',crop:Object.assign({},CROP),dpr,cropRenderedW,cropRenderedH};
    document.body.dataset.masterScale=scale.toFixed(8);
    document.body.dataset.masterOffsetX=surfaceOffsetX.toFixed(3);
    document.body.dataset.masterOffsetY=surfaceOffsetY.toFixed(3);
    document.body.dataset.masterViewport=vw+'x'+vh;
    document.body.dataset.masterFillMode='CROP_COVER';
    const dbg=document.getElementById('uiDebugMetrics');
    if(dbg)dbg.textContent=`viewport ${vw}×${vh} · crop 0,22,1387×780 · zoom ${scale.toFixed(5)} · offset ${surfaceOffsetX.toFixed(1)},${surfaceOffsetY.toFixed(1)} · DPR ${dpr}`;
  }
  function queueGeometry(){if(raf)return;raf=requestAnimationFrame(applyMasterGeometry)}
  function isDebug(){return new URLSearchParams(location.search).get('uiDebug')==='1'}
  function addAnchor(name,x,y,color){
    const s=document.getElementById('frozenDesignSurface');if(!s)return;
    const d=document.createElement('div');d.className='ui-debug-anchor';d.dataset.anchor=name;
    Object.assign(d.style,{position:'absolute',left:(x-4)+'px',top:(y-4)+'px',width:'8px',height:'8px',borderRadius:'50%',background:color,zIndex:'270',pointerEvents:'none',boxShadow:'0 0 0 1px #001'});d.title=name;s.appendChild(d)
  }
  function initDebug(){
    if(!isDebug())return;document.body.classList.add('ui-debug');
    const slider=document.getElementById('uiReferenceOpacity'),overlay=document.getElementById('uiReferenceOverlay');
    if(slider&&overlay)slider.addEventListener('input',()=>overlay.style.opacity=(Number(slider.value)/100).toFixed(2));
    addAnchor('A',REGIONS.main.x,REGIONS.main.y,'#ff3333');addAnchor('B',REGIONS.main.x+REGIONS.main.w,REGIONS.main.y,'#ff3333');
    addAnchor('C',REGIONS.main.x,REGIONS.main.y+REGIONS.main.h,'#ff3333');addAnchor('D',REGIONS.main.x+REGIONS.main.w,REGIONS.main.y+REGIONS.main.h,'#ff3333');
    addAnchor('N',REGIONS.nav.x,REGIONS.nav.y,'#3498ff');addAnchor('W',REGIONS.chrome.x,REGIONS.chrome.y,'#ff35d3')
  }
  window.beginNativeDrag=function(ev){
    if(ev&&ev.button!==0)return;if(ev&&ev.detail>=2)return;
    const api=window.pywebview&&window.pywebview.api;if(api&&typeof api.begin_window_drag==='function'){try{api.begin_window_drag()}catch(_e){}}
  };
  window.addEventListener('resize',queueGeometry,{passive:true});
  if(window.visualViewport)window.visualViewport.addEventListener('resize',queueGeometry,{passive:true});
  window.addEventListener('DOMContentLoaded',()=>{applyMasterGeometry();initDebug()});
  window.addEventListener('pywebviewready',applyMasterGeometry,{once:false});
  window.__getMasterGeometry=()=>Object.assign({},last);
  window.__getMasterRegions=()=>JSON.parse(JSON.stringify(REGIONS));
  window.__debugHitRects=()=>Array.from(document.querySelectorAll('button,.navbtn,select,input')).filter(e=>e.offsetParent!==null).map(e=>({id:e.id||'',cls:e.className||'',rect:e.getBoundingClientRect().toJSON?e.getBoundingClientRect().toJSON():{x:e.getBoundingClientRect().x,y:e.getBoundingClientRect().y,width:e.getBoundingClientRect().width,height:e.getBoundingClientRect().height}}));
  applyMasterGeometry();
})();
