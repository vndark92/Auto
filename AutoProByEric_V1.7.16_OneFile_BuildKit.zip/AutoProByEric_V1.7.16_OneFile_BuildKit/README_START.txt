Auto Pro By Eric V1.7.16 — ONEFILE BUILD KIT
Để tạo 1 EXE trên Windows x64: chạy TAO_1_FILE_EXE.bat.
File sau build: dist\AutoProByEric_V1.7.16.exe.
Đây là bộ nguồn, chưa phải EXE đã biên dịch. Xem README_ONEFILE.md.
