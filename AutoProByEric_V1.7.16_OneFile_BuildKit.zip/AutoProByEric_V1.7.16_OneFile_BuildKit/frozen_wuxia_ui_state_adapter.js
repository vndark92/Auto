/* AUTO PRO BY ERIC — UI STATE ADAPTER + INCREMENTAL PRESENTATION REFRESH
   Reads existing runtime state. Never owns scheduler/automation. */
(function(){
  'use strict';
  const POLL_MS=750;
  const metrics={polls:0,renders:0,skipped:0,mismatches:0,lastRenderMs:0,maxRenderMs:0,lastSnapshot:null};
  let lastSig=''; let rafPending=false; let mismatchSince=0; let mismatchLastLogged=0;
  const now=()=>performance.now();
  const safe=(fn,fallback=null)=>{try{return fn()}catch(_e){return fallback}};
  function runtimeSnapshot(){
    const cc=safe(()=>chestControl,{} )||{};
    const ar=safe(()=>autoResume,{} )||{};
    const cs=safe(()=>chestLoopStats,{} )||{};
    const selected=document.getElementById('windowSelect');
    const pause=document.getElementById('chestPauseState');
    return {
      running:!!cc.running, cycleInFlight:!!cc.cycleInFlight, stopReason:cc.stopReason||'', generation:Number(cc.generation||0),
      loopOwner:cc.loopOwnerToken||'', paused:!!ar.pending, resumeEnabled:!!ar.enabled, resumePending:!!ar.pending,
      resumeRemain:ar.dueRemainingSec==null?null:Number(ar.dueRemainingSec), pauseCategory:ar.pauseCategory||'', pauseReason:ar.pauseReason||'',
      opened:Number(cs.opened||0), scanned:Number(cs.scanned||0), keep:Number(cs.keep||0), dropped:Number(cs.dropped||0),
      hwnd:selected?.value||'', clientStatus:document.getElementById('clientStatus')?.textContent||'', pauseText:pause?.textContent||'',
      online:navigator.onLine, activePage:safe(()=>activeUiPage,'overview')
    };
  }
  function signature(s){return JSON.stringify(s)}
  function renderIfChanged(force=false){
    metrics.polls++;
    const s=runtimeSnapshot(), sig=signature(s);
    metrics.lastSnapshot=s;
    if(!force && sig===lastSig){metrics.skipped++; checkMismatch(s); return;}
    lastSig=sig;
    if(rafPending)return;
    rafPending=true;
    requestAnimationFrame(()=>{
      rafPending=false;
      const t=now();
      safe(()=>refreshProductionPageMirrors());
      metrics.lastRenderMs=now()-t; metrics.maxRenderMs=Math.max(metrics.maxRenderMs,metrics.lastRenderMs); metrics.renders++;
      installLongTextTooltips(); checkMismatch(s);
    });
  }
  function checkMismatch(s){
    const el=document.getElementById('globalAutoState'); if(!el)return;
    const ui=String(el.textContent||'').trim().toUpperCase();
    const expected=s.running?'RUNNING':(s.resumePending?'PAUSED':'STOPPED');
    const bad=ui && ui!==expected;
    if(!bad){mismatchSince=0;return;}
    if(!mismatchSince)mismatchSince=now();
    if(now()-mismatchSince<900)return;
    metrics.mismatches++;
    if(now()-mismatchLastLogged>5000){
      mismatchLastLogged=now();
      const detail={expected,ui,runtime:s};
      console.warn('UI_RUNTIME_STATE_MISMATCH',detail);
      safe(()=>log('UI_RUNTIME_STATE_MISMATCH',detail));
    }
  }
  const tooltipSelectors=[
    '.ProdInfoRow b','.ProdCurrentDestination b','.ProdModuleTile small','.ProdModuleTile b','.ProdSettingRow b',
    '.ProdCompactState b','.ProdLargeStatus b','.ProdPauseBox b','.ProdResumeBox b','.ProdLogEvent .msg','.ProdPanelFooter',
    '.ProdQueueRow span','.ProdQueueRow b','.ProdBossQueue>div>*','.top-card strong','.top-card .tinyline','.ProdMainState','.IceBadge','#overviewAlertText'
  ];
  function installLongTextTooltips(root=document){
    root.querySelectorAll(tooltipSelectors.join(',')).forEach(el=>{
      const full=String(el.textContent||'').trim(); if(!full)return;
      if(!el.title || el.dataset.autoTitle==='1'){el.title=full;el.dataset.autoTitle='1'}
      const clipped=el.scrollWidth>el.clientWidth+1 || el.scrollHeight>el.clientHeight+1;
      el.dataset.uiTruncated=clipped?'true':'false';
    });
  }
  function installMutationObserver(){
    const main=document.querySelector('.main'); if(!main)return;
    const mo=new MutationObserver(records=>{
      let textChanged=false;
      for(const r of records){if(r.type==='characterData'||r.type==='childList'){textChanged=true;break}}
      if(textChanged){installLongTextTooltips(main);renderIfChanged(false)}
    });
    mo.observe(main,{subtree:true,childList:true,characterData:true});
  }
  function glyphProbe(){
    let p=document.getElementById('uiGlyphProbe');
    if(!p){p=document.createElement('div');p.id='uiGlyphProbe';p.textContent='ă â ê ô ơ ư đ Á À Ả Ã Ạ Ắ Ằ Ẳ Ẵ Ặ Ế Ề Ể Ễ Ệ Ứ Ừ Ử Ữ Ự';document.getElementById('frozenDesignSurface')?.appendChild(p)}
    const r=p.getBoundingClientRect(); const cs=getComputedStyle(p);
    return {text:p.textContent,width:r.width,height:r.height,fontFamily:cs.fontFamily,lineHeight:cs.lineHeight,replacementGlyph:p.textContent.includes('\uFFFD')};
  }
  function qaOverflowAudit(){
    const active=document.querySelector('.ice-page.active'); if(!active)return {page:null,cases:[]};
    const nodes=[...active.querySelectorAll('button,label,span,b,em,small,th,td,input,select,.title,.ProdHelper,.ProdPanelFooter')];
    const cases=[];
    nodes.forEach((el,i)=>{
      const cs=getComputedStyle(el); if(cs.display==='none'||cs.visibility==='hidden'||Number(cs.opacity)===0)return;
      const r=el.getBoundingClientRect(); if(r.width<1||r.height<1)return;
      const horizontal=el.scrollWidth>el.clientWidth+1, vertical=el.scrollHeight>el.clientHeight+1;
      const ellipsis=cs.textOverflow==='ellipsis'&&cs.whiteSpace==='nowrap';
      const allowed=(horizontal&&ellipsis&&!!el.title&&!vertical);
      if((horizontal||vertical)&&!allowed){cases.push({i,tag:el.tagName,id:el.id||'',className:String(el.className||''),text:String(el.textContent||el.value||'').trim().slice(0,120),horizontal,vertical,scroll:[el.scrollWidth,el.scrollHeight],client:[el.clientWidth,el.clientHeight],ellipsis,title:el.title||''})}
    });
    return {page:safe(()=>activeUiPage,null),cases};
  }
  function installQARouter(){
    const q=new URLSearchParams(location.search); const page=q.get('qaPage');
    if(page && safe(()=>ICE_PAGE_LABELS[page],null))setTimeout(()=>safe(()=>showModule(page)),100);
  }
  window.UIStateAdapter={runtimeSnapshot,renderIfChanged,metrics,qaOverflowAudit,glyphProbe,installLongTextTooltips};
  window.addEventListener('online',()=>renderIfChanged(true));
  window.addEventListener('offline',()=>renderIfChanged(true));
  document.addEventListener('DOMContentLoaded',()=>{installLongTextTooltips();installMutationObserver();glyphProbe();installQARouter();renderIfChanged(true);setInterval(()=>renderIfChanged(false),POLL_MS);},{once:true});
})();
