from pathlib import Path
import ctypes, sys, subprocess, time, os, json, threading

ROOT = Path(__file__).resolve().parent


def _enable_crisp_dpi():
    """Use native per-monitor DPI rendering on 4K/HiDPI displays."""
    try:
        # PER_MONITOR_AWARE_V2 = -4. Chromium/WebView text then renders at the
        # monitor's native DPI instead of being bitmap-stretched by Windows.
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        return
    except Exception:
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        return
    except Exception:
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

_enable_crisp_dpi()

import webview

# Frozen Wuxia master chrome: explicit drag selector instead of implicit renderer defaults.
try:
    if hasattr(webview, 'settings'):
        webview.settings['DRAG_REGION_SELECTOR'] = '.pywebview-drag-region'
        if 'DRAG_REGION_DIRECT_TARGET_ONLY' in webview.settings:
            webview.settings['DRAG_REGION_DIRECT_TARGET_ONLY'] = True
except Exception:
    pass
from AutoProByEric_LicenseGuard_v1 import LICENSE_GUARD
from AutoProByEric_InputTool_v1 import InputToolController
from AutoProByEric_MultiAccountLog_v1715 import MultiAccountLog
from AutoProByEric_InputPolicy_v1715 import reserve_inventory_hotkey
from AutoProByEric_ClientOwnership_v1716 import ClientOwnership
from AutoProByEric_RunSafety_v1716 import background_start_gate
import AutoProByEric_Stage17_Backend_v1_8 as backend_core
from AutoProByEric_Stage17_Backend_v1_8 import Api
from AutoProByEric_AutoRollRecordCoord_v1 import AutoRollRecordCoordCoordinator
from AutoProByEric_AutoBoss_v1 import AutoBossSessionController

def _is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False

def _elevate_once():
    if _is_admin():
        return True
    # A frozen EXE is its own entry point; do not pass the bundled .py as an argument.
    params = "" if getattr(sys, "frozen", False) else subprocess.list2cmdline([str(Path(__file__).resolve())])
    rc = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, params, str(ROOT), 1
    )
    if int(rc) > 32:
        raise SystemExit(0)
    return False

_elevate_once()

_license_startup = LICENSE_GUARD.startup_validate_with_setup()
if not _license_startup.get('active'):
    _reason = str(_license_startup.get('reason') or 'LICENSE_NOT_ACTIVE')
    try:
        ctypes.windll.user32.MessageBoxW(None, 'License validation failed:\n' + _reason + '\n\nChạy lại Auto hoặc CONFIGURE_LICENSE.bat để mở License Setup.', 'Auto Pro By Eric - License', 0x10)
    except Exception:
        print('[AutoPro License] ' + _reason)
    raise SystemExit(3)

class UIAdapterApi(Api):
    """UI-only adapter. Core automation methods remain inherited unchanged."""
    def __init__(self):
        super().__init__()
        self._ui_maximized = False
        self._account_log = MultiAccountLog(backend_core.LOGDIR, shared=True)
        self._owner = ClientOwnership(backend_core.LOGDIR, shared=True)
        self._claimed_client = None
        self._start_dispatch_lock = threading.RLock()
        self._auto_roll_record = AutoRollRecordCoordCoordinator(self, backend_core, ROOT)
        self._auto_boss = AutoBossSessionController(self, backend_core, ROOT)
        self._input_tool = InputToolController(
            send_key_once=self._input_tool_send_key_once,
            target_provider=lambda: int(self._cfg.get('locked_client') or 0),
            license_checker=lambda: bool(LICENSE_GUARD.status().get('active')),
            start_guard=self._cast_start_gate,
        )
        self._presence_stop = threading.Event()
        threading.Thread(target=self._presence_loop, name='AutoProAccountPresence', daemon=True).start()

    # Cooperative single-owner protocol: one live game HWND per app instance.
    # Never change the target while an Auto mode is active.
    def _claim_target(self, hwnd, *, physical=False):
        try:
            hwnd = int(hwnd or 0)
            if not hwnd or not backend_core.window_exists(hwnd):
                return {'ok': False, 'reason': 'NO_VALID_CLIENT'}
            pid = int(backend_core._window_pid(hwnd) or 0)
            if pid <= 0:
                return {'ok': False, 'reason': 'CLIENT_PID_UNAVAILABLE'}
            if self._claimed_client and self._claimed_client != (hwnd, pid):
                return {'ok': False, 'reason': 'APP_ALREADY_OWNS_OTHER_CLIENT', 'owned_hwnd': self._claimed_client[0]}
            claim = self._owner.claim_client(hwnd, pid)
            if not claim.get('ok'):
                return claim
            self._claimed_client = (hwnd, pid)
            if physical:
                claim = self._owner.claim_physical_input()
                if not claim.get('ok'):
                    return {'ok': False, 'reason': 'PHYSICAL_INPUT_BUSY_OTHER_INSTANCE',
                            'note': 'Chỉ một AutoPro được quyền điều khiển chuột/phím vật lý ở cùng thời điểm.'}
            return {'ok': True, 'hwnd': hwnd, 'game_pid': pid,
                    'physical_input_exclusive': bool(physical)}
        except Exception as exc:
            return {'ok': False, 'reason': 'CLIENT_OWNER_CHECK_FAILED', 'error': str(exc)}

    def _presence_loop(self):
        # Never perform input or screenshot here. Presence is a lightweight
        # window/process + in-memory state observation only.
        while not self._presence_stop.is_set():
            try:
                bound = self._claimed_client
                if bound:
                    hwnd, pid = bound
                    alive = bool(backend_core.window_exists(hwnd) and
                                 int(backend_core._window_pid(hwnd) or 0) == pid)
                    modes = self.automation_mode_guard('INPUT_TOOL').get('active_modes') or []
                    self._account_log.publish_presence(
                        hwnd, pid,
                        backend_core._window_title(hwnd) if alive else 'Cửa sổ game đã đóng',
                        modes, bool(self._input_tool.status().get('running')), alive)
            except Exception:
                pass  # Observability must never interrupt automation.
            self._presence_stop.wait(12.0)

    def ownership_status(self):
        result = self._owner.status()
        result['claimed_client'] = list(self._claimed_client) if self._claimed_client else None
        return result

    def _cast_start_gate(self, hwnd):
        # Single owner for UI START and F10 global-hotkey START.
        with self._start_dispatch_lock:
            modes = self.automation_mode_guard('INPUT_TOOL')
            if modes.get('active_modes'):
                return {'ok': False, 'reason': 'AUTOMATION_ACTIVE_STOP_FIRST',
                        'active_modes': modes['active_modes'], 'safe_pause': True}
            return self._claim_target(hwnd, physical=(str(self._cfg.get('input_mode', 'Auto')) != 'Background'))

    def _start_guard(self, hwnd, module):
        # Never overlap a free-running Cast Bua key loop with Chest/Roll/Boss.
        # This is a conservative mode barrier, NOT per-input ACK/transaction locking.
        if self._input_tool.status().get('running'):
            gate = {'ok': False, 'reason': 'INPUT_TOOL_ACTIVE_STOP_FIRST', 'safe_pause': True}
            self._log_action(hwnd, module + '_START_BLOCKED', gate)
            return gate
        modes = self.automation_mode_guard(module)
        if not modes.get('ok'):
            gate = {'ok': False, 'reason': modes.get('reason','AUTOMATION_MODE_CONFLICT'),
                    'active_modes': modes.get('active_modes') or [], 'safe_pause': True}
            self._log_action(hwnd, module + '_START_BLOCKED', gate)
            return gate
        gate = background_start_gate(module, self._cfg.get('input_mode', 'Auto'))
        if not gate.get('ok'):
            self._log_action(hwnd, module + '_START_BLOCKED', gate)
            return gate
        # All legacy AUTO paths can use SendInput/SetCursorPos: reserve a global
        # physical-input lease even when the app UI says 'Auto'.
        gate = self._claim_target(hwnd, physical=True)
        if not gate.get('ok'):
            self._log_action(hwnd, module + '_START_BLOCKED', gate)
        return gate

    def set_selection(self, hwnd, group_id):
        with self._start_dispatch_lock:
            return self._set_selection_locked(hwnd, group_id)

    def _set_selection_locked(self, hwnd, group_id):
        try:
            target = int(hwnd or 0)
        except (ValueError, TypeError):
            return {'ok': False, 'reason': 'INVALID_HWND'}
        if not target:
            active = list(self.automation_mode_guard('INPUT_TOOL').get('active_modes') or [])
            if active or self._input_tool.status().get('running'):
                return {'ok': False, 'reason': 'CANNOT_CLEAR_CLIENT_WHILE_RUNNING', 'active_modes': active}
        if target and (not self._claimed_client or self._claimed_client[0] != target):
            active = list(self.automation_mode_guard('INPUT_TOOL').get('active_modes') or [])
            if active or self._input_tool.status().get('running'):
                return {'ok': False, 'reason': 'CANNOT_SWITCH_CLIENT_WHILE_RUNNING', 'active_modes': active}
            # Obtain a new lease before releasing the former one. On conflict,
            # keep the former selection intact, no fallback to a shared client.
            pid = int(backend_core._window_pid(target) or 0) if backend_core.window_exists(target) else 0
            if not pid:
                return {'ok': False, 'reason': 'NO_VALID_CLIENT'}
            lease = self._owner.claim_client(target, pid)
            if not lease.get('ok'):
                return lease
            old = self._claimed_client
            result = super().set_selection(target, group_id)
            if result.get('ok'):
                self._claimed_client = (target, pid)
                if old and old != (target, pid):
                    self._owner.release_client(*old)
                # Old foreground exclusivity stays process-scoped to avoid
                # releasing it during an unobserved in-flight legacy action.
            else:
                self._owner.release_client(target, pid)
            return result
        return super().set_selection(target, group_id)

    def chest_prepare_loop(self, hwnd, *args, **kwargs):
        with self._start_dispatch_lock:
            gate = self._start_guard(hwnd, 'CHEST')
            if not gate.get('ok'):
                return gate
            result = super().chest_prepare_loop(hwnd, *args, **kwargs)
            self._log_action(hwnd, 'CHEST_PREPARE', result)
            return result

    def chest_process_one_live(self, hwnd):
        # A process cannot process a second HWND by direct API calls.
        gate = self._claim_target(hwnd)
        if not gate.get('ok'):
            return gate
        result = super().chest_process_one_live(hwnd)
        self._log_action(hwnd, 'CHEST_CYCLE', result)
        return result

    def client_log_batch(self, events=None):
        """Write UI/action telemetry into independent per-HWND session streams.

        UI strings are untrusted; never interpret them as paths or commands.
        """
        count = 0
        try:
            for item in list(events or [])[:80]:
                if not isinstance(item, dict):
                    continue
                hwnd = int(item.get('hwnd') or 0)
                pid = backend_core._window_pid(hwnd) if hwnd and backend_core.window_exists(hwnd) else 0
                title = backend_core._window_title(hwnd) if pid else 'Đã đóng / chưa chọn cửa sổ'
                self._account_log.append(hwnd, pid, title, item.get('category','INFO'),
                                         item.get('message',''), item.get('details'))
                count += 1
            return {'ok': True, 'count':count}
        except Exception as exc:
            return {'ok':False,'reason':'ACCOUNT_LOG_BATCH_FAILED','error':str(exc)}

    def open_multi_account_logs(self):
        try:
            path=self._account_log.root
            path.mkdir(parents=True,exist_ok=True)
            if sys.platform.startswith('win'):
                os.startfile(str(path))
            return {'ok':True,'path':str(path)}
        except Exception as exc:
            return {'ok':False,'reason':'MULTI_ACCOUNT_FOLDER_OPEN_FAILED','error':str(exc)}

    def client_log_alias_set(self, hwnd, alias):
        """Set a local display label for a live game window; never read log paths from JS."""
        try:
            hwnd = int(hwnd or 0)
            if not hwnd or not backend_core.window_exists(hwnd):
                return {'ok': False, 'reason': 'NO_VALID_CLIENT'}
            pid = int(backend_core._window_pid(hwnd) or 0)
            if not pid:
                return {'ok': False, 'reason': 'CLIENT_PID_UNAVAILABLE'}
            # This label is for presentation only; client ownership is still
            # determined strictly from PID/HWND by the OS-backed lease.
            result = self._account_log.set_alias(f'{pid}:{hwnd}', alias)
            self._log_action(hwnd, 'ACCOUNT_ALIAS_UPDATED', {'ok': True})
            return result
        except Exception as exc:
            return {'ok': False, 'reason': 'ACCOUNT_ALIAS_SAVE_FAILED', 'error': str(exc)}

    def client_log_recent(self, selected_account='ALL', limit=200):
        try:
            return self._account_log.recent(selected_account=str(selected_account or 'ALL'),limit=limit)
        except Exception as exc:
            return {'ok':False,'reason':'ACCOUNT_LOG_READ_FAILED','error':str(exc)}

    def _log_action(self, hwnd, code, result):
        try:
            hwnd = int(hwnd or self._cfg.get('locked_client') or 0)
            pid = backend_core._window_pid(hwnd) if hwnd and backend_core.window_exists(hwnd) else 0
            title = backend_core._window_title(hwnd) if pid else 'Đã đóng / chưa chọn cửa sổ'
            safe = {key: result.get(key) for key in ('ok','reason','state','running','used_mode','skipped') if key in result} if isinstance(result,dict) else {'result_type':type(result).__name__}
            self._account_log.append(hwnd, pid, title, 'ACTION', code, safe)
        except Exception:
            pass  # Telemetry must never block an automation safety path.

    def background_input_capability(self, hwnd=0):
        """Non-mutating check. A passing probe does not prove game acceptance."""
        hwnd=int(hwnd or self._cfg.get('locked_client') or 0)
        if not hwnd or not backend_core.window_exists(hwnd):
            return {'ok':False,'reason':'NO_VALID_CLIENT','supported':False}
        pid=backend_core._window_pid(hwnd)
        mismatch=backend_core._process_elevated(pid) is True and not backend_core._is_current_process_elevated()
        return {'ok':not mismatch,'supported':False, 'hwnd':hwnd,
                'backend':'PostMessage', 'needs_live_game_test':True,
                'no_foreground_fallback':True, 'no_cursor_reposition_in_key_path':True,
                'reason':'ADMIN_MISMATCH' if mismatch else 'NOT_VERIFIED_BY_GAME',
                'note':'PostMessage không chiếm chuột; game có thể không chấp nhận. Các tác vụ Auto khác cần test riêng.'}

    def _native_top_level_hwnd(self):
        """Resolve the real top-level pywebview window HWND, not the inner WebView control."""
        if not sys.platform.startswith('win'):
            return 0
        # Fast path: native wrapper handle when pywebview exposes a true top-level form.
        try:
            win = webview.active_window()
            native = getattr(win, 'native', None) if win else None
            handle = getattr(native, 'Handle', None)
            if handle is not None:
                try: hwnd = int(handle.ToInt64())
                except Exception:
                    try: hwnd = int(handle.ToInt32())
                    except Exception: hwnd = int(handle)
                if hwnd and ctypes.windll.user32.IsWindow(hwnd):
                    root = ctypes.windll.user32.GetAncestor(hwnd, 2)  # GA_ROOT
                    return int(root or hwnd)
        except Exception:
            pass
        # Robust fallback: enumerate visible top-level windows owned by this Python process.
        try:
            user32=ctypes.windll.user32; pid=os.getpid(); candidates=[]
            WNDENUMPROC=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
            @WNDENUMPROC
            def _cb(hwnd,lparam):
                proc=ctypes.c_ulong()
                user32.GetWindowThreadProcessId(hwnd,ctypes.byref(proc))
                if int(proc.value)!=pid or not user32.IsWindowVisible(hwnd):
                    return True
                n=user32.GetWindowTextLengthW(hwnd)
                buf=ctypes.create_unicode_buffer(max(1,n+1)); user32.GetWindowTextW(hwnd,buf,len(buf))
                title=buf.value or ''
                rect=(ctypes.c_long*4)()
                try: user32.GetWindowRect(hwnd,ctypes.byref(rect))
                except Exception: pass
                area=max(0,int(rect[2]-rect[0]))*max(0,int(rect[3]-rect[1]))
                candidates.append((1 if title.startswith('Auto Pro By Eric') else 0,area,int(hwnd),title))
                return True
            user32.EnumWindows(_cb,0)
            if candidates:
                candidates.sort(reverse=True)
                return candidates[0][2]
        except Exception:
            pass
        return 0

    def toggle_maximize(self):
        try:
            hwnd=self._native_top_level_hwnd()
            if hwnd:
                user32=ctypes.windll.user32
                maximized=bool(user32.IsZoomed(hwnd))
                user32.ShowWindow(hwnd, 9 if maximized else 3)  # SW_RESTORE / SW_MAXIMIZE
                self._ui_maximized=not maximized
                return {"ok": True, "maximized": self._ui_maximized, "method": "WIN32_SHOWWINDOW"}
            win=webview.active_window()
            if not win:
                return {"ok": False, "reason": "NO_ACTIVE_WINDOW"}
            if self._ui_maximized:
                win.restore(); self._ui_maximized=False
            else:
                win.maximize(); self._ui_maximized=True
            return {"ok": True, "maximized": self._ui_maximized, "method": "PYWEBVIEW_FALLBACK"}
        except Exception as e:
            return {"ok": False, "reason": "WINDOW_TOGGLE_FAILED", "error": str(e)}

    def minimize(self):
        try:
            hwnd=self._native_top_level_hwnd()
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
                return True
        except Exception:
            pass
        return super().minimize()

    def begin_window_drag(self):
        """Start a real Windows non-client move loop on the top-level app window."""
        try:
            if not sys.platform.startswith('win'):
                return {"ok": False, "reason": "WINDOWS_ONLY_NATIVE_DRAG"}
            hwnd=self._native_top_level_hwnd()
            if not hwnd:
                return {"ok": False, "reason": "TOP_LEVEL_HWND_NOT_FOUND"}
            user32=ctypes.windll.user32
            if user32.IsZoomed(hwnd):
                user32.ShowWindow(hwnd, 9)  # SW_RESTORE
                self._ui_maximized=False
                time.sleep(0.03)
            user32.ReleaseCapture()
            user32.SendMessageW(hwnd, 0x00A1, 2, 0)  # WM_NCLBUTTONDOWN / HTCAPTION
            return {"ok": True, "method": "WIN32_TOPLEVEL_HTCAPTION", "hwnd": int(hwnd)}
        except Exception as e:
            return {"ok": False, "reason": "NATIVE_DRAG_FAILED", "error": str(e)}

    def get_ui_settings(self):
        """Presentation/settings adapter over existing persisted config only."""
        try:
            hwnd=int(self._cfg.get('locked_client') or 0)
            title=backend_core._window_title(hwnd) if hwnd and backend_core.window_exists(hwnd) else ''
            pid=backend_core._window_pid(hwnd) if hwnd and backend_core.window_exists(hwnd) else 0
            game_elevated=backend_core._process_elevated(pid) if pid else None
            chest=self._cfg.setdefault('modules',{}).setdefault('chest',{})
            ar=self.get_auto_resume_after_lag(hwnd)
            return {
                'ok':True,'input_mode':str(self._cfg.get('input_mode','Auto')),
                'non_intrusive_requested':str(self._cfg.get('input_mode','Auto')) == 'Background',
                'shortcut_mode':self.get_shortcut_mode(),'inventory_hotkey':self.get_inventory_hotkey(),
                'auto_resume_after_lag_enabled':bool(ar.get('auto_resume_enabled')),
                'auto_detect_on_startup':bool(self._cfg.get('auto_detect_on_startup',False)),
                'locked_client':hwnd or None,'selected_client_title':title,
                'auto_elevated':bool(_is_admin()),'game_elevated':game_elevated,
                'ui_scale':'AUTO_MASTER','start_with_windows_supported':False,'minimize_to_tray_supported':False,
            }
        except Exception as e:
            return {'ok':False,'reason':'UI_SETTINGS_READ_FAILED','error':str(e)}

    def save_ui_settings(self, payload):
        with self._start_dispatch_lock:
            return self._save_ui_settings_locked(payload)

    def _save_ui_settings_locked(self, payload):
        """Save only settings that already exist in the runtime/config model."""
        try:
            payload=dict(payload or {})
            mode=str(payload.get('input_mode',self._cfg.get('input_mode','Auto')))
            if mode not in ('Auto','Background','Foreground'):
                return {'ok':False,'reason':'INVALID_INPUT_MODE'}
            if mode != str(self._cfg.get('input_mode','Auto')):
                live = list(self.automation_mode_guard('INPUT_TOOL').get('active_modes') or [])
                if live or self._input_tool.status().get('running'):
                    return {'ok':False,'reason':'STOP_AUTOMATION_BEFORE_INPUT_MODE_CHANGE','active_modes':live}
            shortcut=str(payload.get('shortcut_mode',self.get_shortcut_mode()))
            if shortcut not in ('Mặc định','Kết hợp'):
                return {'ok':False,'reason':'INVALID_SHORTCUT_MODE'}
            self._cfg['input_mode']=mode
            self._cfg['shortcut_mode']=shortcut
            self._cfg['auto_detect_on_startup']=bool(payload.get('auto_detect_on_startup',self._cfg.get('auto_detect_on_startup',False)))
            backend_core._save_app_config(self._cfg)
            ar=self.set_auto_resume_after_lag(bool(payload.get('auto_resume_after_lag_enabled',False)))
            return {'ok':True,'input_mode':mode,'shortcut_mode':shortcut,'inventory_hotkey':self.get_inventory_hotkey(),
                    'auto_detect_on_startup':bool(self._cfg.get('auto_detect_on_startup',False)),
                    'auto_resume_after_lag_enabled':bool(ar.get('auto_resume_enabled'))}
        except Exception as e:
            return {'ok':False,'reason':'UI_SETTINGS_SAVE_FAILED','error':str(e)}

    def _input_tool_send_key_once(self, hwnd, key):
        """Lean foreground SendInput path for the independent F3-F9 helper."""
        try:
            hwnd = int(hwnd or 0)
            if not hwnd or not backend_core.window_exists(hwnd):
                return {'ok': False, 'reason': 'INPUT_TOOL_CLIENT_NOT_FOUND'}
            key = str(key or '').upper().strip()
            vk_map = {f'F{i}': 0x70 + (i - 1) for i in range(3, 10)}
            vk = vk_map.get(key)
            if vk is None:
                return {'ok': False, 'reason': 'INPUT_TOOL_KEY_INVALID', 'key': key}
            pid = backend_core._window_pid(hwnd)
            auto_elevated = backend_core._is_current_process_elevated()
            game_elevated = backend_core._process_elevated(pid) if pid else None
            if game_elevated is True and not auto_elevated:
                return {
                    'ok': False,
                    'reason': 'INPUT_TOOL_ADMIN_MISMATCH',
                    'error': 'Game đang chạy Admin nhưng Auto chưa chạy Admin.',
                }
            # V1.7.15: never let the independent Cast Bùa F4 race with
            # Inventory F4 while any automation owns the game client.
            active = list(self.automation_mode_guard('INPUT_TOOL').get('active_modes') or [])
            if reserve_inventory_hotkey(key, self.get_inventory_hotkey(), active):
                return {'ok':True,'skipped':True,'reason':'HOTKEY_RESERVED_BY_AUTOMATION',
                        'active_modes':active,'key':key,'hwnd':hwnd}
            # Strict background key path: no activation, no SendInput,
            # no mouse movement and NO foreground fallback on failure.
            if str(self._cfg.get('input_mode','Auto')) == 'Background':
                sent, target = backend_core._post_key(hwnd, vk)
                return {'ok':bool(sent),'reason':'BACKGROUND_SENT_UNVERIFIED' if sent else 'BACKGROUND_POSTMESSAGE_FAILED',
                        'hwnd':hwnd,'key':key,'target_hwnd':int(target),
                        'used_mode':'Background/PostMessage','acceptance_verified':False}
            activation = backend_core._activate_window(hwnd)
            if not activation.get('ok'):
                return {'ok': False, 'reason': 'INPUT_TOOL_FOREGROUND_FAILED', 'activation': activation}
            sent, scan = backend_core._sendinput_scancode(vk)
            return {
                'ok': bool(sent),
                'reason': 'OK' if sent else 'INPUT_TOOL_SENDINPUT_FAILED',
                'key': key,
                'scan_code': int(scan),
                'hwnd': hwnd,
                'used_mode': 'Foreground/SendInputScanCode',
                'auto_elevated': bool(auto_elevated),
                'game_elevated': game_elevated,
            }
        except Exception as e:
            return {'ok': False, 'reason': 'INPUT_TOOL_SEND_EXCEPTION', 'error': str(e)}

    def input_tool_get(self):
        try:
            return {'ok': True, **self._input_tool.status()}
        except Exception as e:
            return {'ok': False, 'reason': 'INPUT_TOOL_STATUS_FAILED', 'error': str(e)}

    def input_tool_save(self, payload):
        try:
            return self._input_tool.save_config(payload or {})
        except Exception as e:
            return {'ok': False, 'reason': 'INPUT_TOOL_SAVE_FAILED', 'error': str(e)}

    def input_tool_start(self, hwnd=0, payload=None):
        """Start Cast Bùa with an optional UI config snapshot.

        Passing the current checkbox state here makes START atomic: F3/F4 (or any
        other selected set) is persisted and used by the same start request.  The
        global F10 path still uses the most recently auto-saved configuration.
        """
        try:
            if not LICENSE_GUARD.status().get('active'):
                return {'ok': False, 'reason': 'LICENSE_NOT_ACTIVE'}
            if isinstance(payload, dict):
                saved = self._input_tool.save_config(payload)
                if not saved.get('ok'):
                    return saved
            with self._start_dispatch_lock:
                modes = self.automation_mode_guard('INPUT_TOOL')
                if modes.get('active_modes'):
                    return {'ok': False, 'reason': 'AUTOMATION_ACTIVE_STOP_FIRST',
                            'active_modes': modes['active_modes'], 'safe_pause': True}
                target = int(hwnd or self._cfg.get('locked_client') or 0)
                gate = self._claim_target(target, physical=(str(self._cfg.get('input_mode','Auto')) != 'Background'))
                if not gate.get('ok'): return gate
                r = self._input_tool.start(target)
                self._log_action(target, 'INPUT_TOOL_START', r)
                return r
        except Exception as e:
            return {'ok': False, 'reason': 'INPUT_TOOL_START_FAILED', 'error': str(e)}

    def input_tool_stop(self, reason='MANUAL_STOP'):
        try:
            r = self._input_tool.stop(str(reason or 'MANUAL_STOP'))
            self._log_action(self._cfg.get('locked_client'), 'INPUT_TOOL_STOP', r)
            return r
        except Exception as e:
            return {'ok': False, 'reason': 'INPUT_TOOL_STOP_FAILED', 'error': str(e)}

    def storage_status_snapshot(self, hwnd):
        """Fresh, read-only storage scan for the Storage page; planner/core remain untouched."""
        try:
            hwnd=int(hwnd or 0)
            if not hwnd or not backend_core.window_exists(hwnd):
                return {'ok':False,'reason':'NO_VALID_CLIENT'}
            image=backend_core.capture_client(hwnd)
            if image is None:return {'ok':False,'reason':'CAPTURE_FAILED'}
            opened=backend_core._try_personal_bag_open_once(hwnd,image,input_mode=self._cfg.get('input_mode','Auto'))
            if not opened.get('ok'):
                return {'ok':False,'reason':opened.get('reason','STORAGE_OPEN_FAILED')}
            frame=backend_core.capture_client(hwnd)
            if frame is None:return {'ok':False,'reason':'CAPTURE_FAILED_AFTER_STORAGE_OPEN'}
            grid=backend_core.detect_personal_storage_grid(frame)
            if not grid.get('ok'):
                return {'ok':False,'reason':grid.get('reason','STORAGE_LAYOUT_ERROR'),'planner_status':'SENSOR ERROR','planner_code':'STORAGE_LAYOUT_ERROR'}
            snap=backend_core.snapshot_inventory(frame,grid)
            if not snap.get('ok'):
                return {'ok':False,'reason':'STORAGE_SENSOR_ERROR','planner_status':'SENSOR ERROR','planner_code':'STORAGE_SENSOR_ERROR'}
            reserved=set(getattr(self,'_personal_bag_reserved_cells',set()) or set())
            occupied=sorted(backend_core._personal_snapshot_blocked_cells(snap,set()))
            free=[]
            rows=int(grid.get('rows') or 10); cols=int(grid.get('cols') or 6)
            occset=set(occupied)
            for rr in range(rows):
                for cc in range(cols):
                    if (rr,cc) not in occset:free.append((rr,cc))
            diag=backend_core._write_personal_bag_occupancy_diag(frame,grid,snap,reserved,target=None,note='UI_STORAGE_PAGE_SCAN')
            return {'ok':True,'status_code':'STORAGE_SCAN_OK','rows':rows,'columns':cols,'total_cells':rows*cols,
                    'used_count':len(occupied),'free_count':len(free),'reserved_count':len(reserved),
                    'occupied_cells':[list(x) for x in occupied],'reserved_cells':[list(x) for x in sorted(reserved)],
                    'destination_cells':[],'planner_status':'SẴN SÀNG','planner_code':'PLANNER_IDLE','debug_file':str(diag or '')}
        except Exception as e:
            return {'ok':False,'reason':'STORAGE_SCAN_EXCEPTION','error':str(e)}

    def open_storage_grid_debug(self, hwnd):
        r=self.storage_status_snapshot(hwnd)
        try:
            p=Path(str(r.get('debug_file') or ''))
            if r.get('ok') and p.exists():os.startfile(p)
        except Exception:pass
        return r

    def storage_test_one_matched_item(self, hwnd):
        """UI test adapter: call the existing StoreController only for an already-MATCHed queue item."""
        try:
            hwnd=int(hwnd or 0)
            if not hwnd:return {'ok':False,'reason':'NO_CLIENT'}
            item=self._queue_item_by_index(0)
            if not item:return {'ok':False,'reason':'NO_QUEUE_ITEM'}
            if str(item.get('decision') or '').upper()!='KEEP':
                return {'ok':False,'reason':'NO_MATCHED_QUEUE_ITEM','queue_item':backend_core.public_queue_item(item)}
            gate=self._chest_begin_atomic_action('STORE_PERSONAL_BAG')
            if not gate.get('started'):
                return {'ok':False,'reason':gate.get('reason','STORE_ACTION_GATE_FAILED')}
            try:
                r=self.chest_store_queue_item(hwnd,0)
            finally:
                self._chest_end_atomic_action()
            return {**r,'queue_item':backend_core.public_queue_item(item)}
        except Exception as e:
            return {'ok':False,'reason':'STORE_TEST_ADAPTER_EXCEPTION','error':str(e)}

    # AUTO ROLL RECORDED CLIENT COORDINATES MASTER V1 -------------------
    # Independent mode. Locked AutoChest runtime remains inherited/read-only.
    def autoroll_status(self):
        return self._auto_roll_record.status()

    def autoroll_record_point(self, hwnd, kind, delay_ms=1200):
        return self._auto_roll_record.record_point(int(hwnd or 0), str(kind or ''), int(delay_ms or 0))

    def autoroll_set_filter_profiles(self, profile_ids):
        return self._auto_roll_record.set_filter_profiles(profile_ids)

    def autoroll_clear_points(self):
        return self._auto_roll_record.clear_points()

    def autoroll_start(self, hwnd, test_one=False):
        with self._start_dispatch_lock:
            gate=self._start_guard(hwnd, 'ROLL')
            if not gate.get('ok'): return gate
            r=self._auto_roll_record.start(int(hwnd or 0), bool(test_one))
            self._log_action(hwnd,'ROLL_START',r)
            return r

    def autoroll_stop(self, reason='USER_UI_STOP'):
        r=self._auto_roll_record.stop(str(reason or 'USER_UI_STOP'))
        self._log_action(self._cfg.get('locked_client'),'ROLL_STOP',r)
        return r

    # AUTO BOSS V1.0 ---------------------------------------------------
    # New subsystem. AutoRoll/AutoChest remain separate owners.
    def autoboss_status(self):
        return self._auto_boss.status()

    def autoboss_update_config(self, payload):
        return self._auto_boss.update_config(payload or {})

    def autoboss_record_point(self, hwnd, which, delay_ms=1200):
        return self._auto_boss.record_point(int(hwnd or 0), str(which or ''), int(delay_ms or 0))

    def autoboss_record_container_profile(self, hwnd, kind):
        return self._auto_boss.record_container_profile(int(hwnd or 0), str(kind or ''))

    def autoboss_learn_player_bag(self, hwnd):
        return self._auto_boss.learn_player_bag(int(hwnd or 0))

    def autoboss_learn_storage(self, hwnd):
        return self._auto_boss.learn_storage(int(hwnd or 0))

    def autoboss_test_container_pair(self, hwnd):
        return self._auto_boss.test_container_pair(int(hwnd or 0))

    def autoboss_reset_container_profiles(self, scope='ALL'):
        return self._auto_boss.reset_container_profiles(str(scope or 'ALL'))

    def autoboss_route_record_start(self, hwnd, route):
        return self._auto_boss.start_route_record(int(hwnd or 0), str(route or ''))

    def autoboss_route_record_stop(self, route=''):
        return self._auto_boss.stop_route_record(str(route or ''))

    def autoboss_route_test(self, hwnd, route):
        return self._auto_boss.test_route(int(hwnd or 0), str(route or ''))

    def autoboss_route_reset(self, route='ALL'):
        return self._auto_boss.reset_route(str(route or 'ALL'))

    def autoboss_start(self, hwnd, test_one_cycle=False):
        with self._start_dispatch_lock:
            gate=self._start_guard(hwnd, 'BOSS')
            if not gate.get('ok'): return gate
            r=self._auto_boss.start(int(hwnd or 0), bool(test_one_cycle))
            self._log_action(hwnd,'BOSS_START',r)
            return r

    def autoboss_stop(self, reason='USER_UI_STOP'):
        r=self._auto_boss.stop(str(reason or 'USER_UI_STOP'))
        self._log_action(self._cfg.get('locked_client'),'BOSS_STOP',r)
        return r

    def boss_test_move(self, which, _legacy_point_text='', hwnd=0):
        hwnd=int(hwnd or self._cfg.get('locked_client') or self._active_hwnd or 0)
        return self._auto_boss.test_move(hwnd, str(which or ''))

    def boss_test_one_cycle(self, hwnd=0):
        hwnd=int(hwnd or self._cfg.get('locked_client') or self._active_hwnd or 0)
        return self.autoboss_start(hwnd, True)

    def export_ui_log(self, text):
        try:
            stamp=time.strftime('%Y%m%d_%H%M%S')
            p=backend_core.LOGDIR/f'{stamp}_ui_view_export.log'
            p.write_text(str(text or ''),encoding='utf-8')
            return {'ok':True,'filename':p.name,'path':str(p)}
        except Exception as e:
            return {'ok':False,'reason':'UI_LOG_EXPORT_FAILED','error':str(e)}

    def open_personal_storage(self, hwnd):
        """Bind the visible quick-action button to the existing proven storage opener."""
        try:
            hwnd = int(hwnd or 0)
            if not hwnd:
                return {"ok": False, "reason": "NO_CLIENT"}
            if str(self._cfg.get('input_mode','Auto')) == 'Background':
                return {'ok': False, 'reason': 'BACKGROUND_STORAGE_OPEN_UNVERIFIED', 'safe_pause': True}
            gate = self._claim_target(hwnd, physical=True)
            if not gate.get('ok'):
                return gate
            image = backend_core.capture_client(hwnd)
            if image is None:
                return {"ok": False, "reason": "CAPTURE_FAILED"}
            result = backend_core._try_personal_bag_open_once(hwnd, image, input_mode=self._cfg.get('input_mode','Auto'))
            # Do not return PIL image through JS API. Preserve only JSON-safe presentation data.
            return {
                "ok": bool(result.get("ok")),
                "reason": result.get("reason"),
                "opened": bool(result.get("opened")),
                "already_open": bool(result.get("already_open")),
                "open_method": result.get("open_method"),
                "open_polls": result.get("open_polls"),
                "open_wait_ms": result.get("open_wait_ms"),
            }
        except Exception as e:
            return {"ok": False, "reason": "OPEN_PERSONAL_STORAGE_FAILED", "error": str(e)}

api = UIAdapterApi()

_AUTOPRO_ICON_HANDLES = []
def _apply_autopro_window_icon():
    """Cosmetic-only: apply the approved AP ice emblem to the native app window/taskbar."""
    if not sys.platform.startswith('win'):
        return
    icon_path = str(ROOT / 'AutoProByEric.ico')
    if not os.path.exists(icon_path):
        return
    try:
        user32 = ctypes.windll.user32
        IMAGE_ICON = 1
        LR_LOADFROMFILE = 0x0010
        WM_SETICON = 0x0080
        ICON_SMALL = 0
        ICON_BIG = 1
        for _ in range(160):
            hwnd = api._native_top_level_hwnd()
            if hwnd:
                hbig = user32.LoadImageW(None, icon_path, IMAGE_ICON, 256, 256, LR_LOADFROMFILE)
                hsmall = user32.LoadImageW(None, icon_path, IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
                if hbig:
                    user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, hbig)
                    _AUTOPRO_ICON_HANDLES.append(hbig)
                if hsmall:
                    user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, hsmall)
                    _AUTOPRO_ICON_HANDLES.append(hsmall)
                return
            time.sleep(0.05)
    except Exception:
        pass

def _license_invalid_runtime(reason):
    stop_reason = 'LICENSE_' + str(reason or 'INVALID')
    try:
        api.autoroll_stop(stop_reason)
    except Exception:
        pass
    try:
        api.autoboss_stop(stop_reason)
    except Exception:
        pass
    try:
        api.chest_request_stop(0, stop_reason)
    except Exception:
        pass
    try:
        api.input_tool_stop(stop_reason)
    except Exception:
        pass
    try:
        ctypes.windll.user32.MessageBoxW(None, 'License is no longer valid:\n' + str(reason), 'Auto Pro By Eric - License', 0x30)
    except Exception:
        pass

LICENSE_GUARD.start_monitor(on_invalid=_license_invalid_runtime)

try:
    if hasattr(webview, 'settings') and 'JS_API_MAX_DEPTH' in webview.settings:
        webview.settings['JS_API_MAX_DEPTH'] = 2
except Exception:
    pass

window = webview.create_window(
    'Auto Pro By Eric · V1.7.16 Dev · Minimal',
    url=str(ROOT / 'ui_locked.html'),
    js_api=api,
    width=1387,
    height=780,
    min_size=(1040, 585),
    resizable=True,
    frameless=True,
    easy_drag=False,
    background_color='#111827',
)

threading.Thread(target=_apply_autopro_window_icon, name='AutoProWindowIcon', daemon=True).start()
webview.start(debug=False)
