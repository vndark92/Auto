"""Generate ONE standalone AutoProByEric_V1.7.16.exe on Windows 64-bit.

No feature changes. PyInstaller extraction to _MEIPASS is transient, persistent
settings/logs are staged per EXE installation under %LOCALAPPDATA%.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import shutil

ROOT = Path(__file__).resolve().parent.parent
NAME = "AutoProByEric_V1.7.16"
VERSION = "1.7.16"
MUTABLE_NAMES = {
    "AutoProByEric_UserOptionFilter.json", "AutoProByEric_AutoRollRecordCoord_v1.json",
    "AutoProByEric_AutoBoss_v1.json", "input_tool.json", "license_client.json",
    "AutoProByEric_Stage16_FilterSample_v1.6.json",
    "autopro_runtime_config.json", "ocr_path.json", "shop_open_guard_v8_8.json",
    "shop_open_reference_v8_8.png",
}
INCLUDE_SUFFIX = {".py", ".html", ".css", ".js", ".json", ".png", ".ico"}


def payload_files():
    files = [p for p in ROOT.iterdir() if p.is_file() and p.suffix.lower() in INCLUDE_SUFFIX
             and p.name != "onefile_payload_manifest.json"]
    for folder_name in ("Data", "assets", "runtime"):
        folder = ROOT / folder_name
        if folder.is_dir():
            files += [p for p in folder.rglob("*") if p.is_file()]
    return sorted(files)


def make_manifest(paths):
    records = []
    for file in paths:
        rel = file.relative_to(ROOT).as_posix()
        records.append({
            "path": rel,
            "sha256": hashlib.sha256(file.read_bytes()).hexdigest(),
            # Never overwrite user configs or the taught data registry on update.
            "mutable": file.name in MUTABLE_NAMES or rel.startswith("Data/"),
        })
    manifest = {"version": VERSION, "files": records}
    target = ROOT / "onefile_payload_manifest.json"
    target.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return target


def build():
    if os.name != "nt" or platform.machine().lower() not in ("amd64", "x86_64"):
        raise SystemExit("ERROR: Build requires Windows x64. This machine cannot cross-compile PyInstaller Windows packages.")
    # Vendor an existing local Windows Tesseract distribution before writing
    # the manifest. This is required because _MEIPASS is temporary and the
    # application needs a stable executable in its profile after extraction.
    bundled_tesseract = ROOT / "runtime" / "tesseract"
    machine_tesseract = Path(os.environ.get("PROGRAMFILES", "C:/Program Files")) / "Tesseract-OCR"
    vendor_tesseract = ROOT / "vendor" / "Tesseract-OCR"
    if not (bundled_tesseract / "tesseract.exe").is_file():
        for source in (vendor_tesseract, machine_tesseract):
            if (source / "tesseract.exe").is_file():
                shutil.copytree(source, bundled_tesseract, dirs_exist_ok=True)
                print("Bundled Windows Tesseract from", source, flush=True)
                break
    if not (bundled_tesseract / "tesseract.exe").is_file():
        raise SystemExit("BUILD BLOCKED: Tesseract.exe not found. Install Tesseract-OCR x64 on this Windows builder or copy its complete directory into vendor\\Tesseract-OCR. This prevents distributing a one-file build with broken Tesseract OCR.")
    paths = payload_files()
    if not (ROOT / "AutoProByEric_Stage17_LockedUI_v1_8.py") in paths:
        raise SystemExit("Missing application source")
    manifest = make_manifest(paths)
    cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean",
           "--onefile", "--windowed", "--noupx", "--name", NAME,
           "--distpath", str(ROOT / "dist"), "--workpath", str(ROOT / "build"),
           "--specpath", str(ROOT),
           "--collect-all", "webview", "--collect-all", "paddleocr",
           "--collect-all", "paddle", "--collect-all", "cv2",
           "--collect-all", "pythonnet", "--collect-all", "win32com",
           "--hidden-import", "pytesseract", "--hidden-import", "mss",
           "--hidden-import", "PIL", "--hidden-import", "clr",
           "--hidden-import", "win32api", "--hidden-import", "win32con",
           "--hidden-import", "win32gui", "--hidden-import", "win32process",
           "--icon", str(ROOT / "AutoProByEric.ico")]
    for file in [*paths, manifest]:
        rel = file.relative_to(ROOT).as_posix()
        dest = str(Path(rel).parent) if "/" in rel else "."
        cmd += ["--add-data", str(file) + os.pathsep + dest]
    cmd += [str(ROOT / "tools" / "onefile_launcher.py")]
    print("Building one-file Windows EXE (this can be large)...", flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)
    out = ROOT / "dist" / f"{NAME}.exe"
    if not out.is_file() or out.open("rb").read(2) != b"MZ":
        raise SystemExit("EXE was not generated or is not PE executable")
    print("BUILD OK:", out, "bytes:", out.stat().st_size, flush=True)
    print("One EXE is the only required distribution artifact (Windows runtimes such as WebView2 may still be required).")


if __name__ == "__main__":
    build()
