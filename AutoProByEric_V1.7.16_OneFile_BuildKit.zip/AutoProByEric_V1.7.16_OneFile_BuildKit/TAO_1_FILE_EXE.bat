@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHONUTF8=1"
title Auto Pro By Eric - Build OneFile V1.7.16
where py >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python launcher not found. Install Python 3.12 64-bit on the build machine.
  pause
  exit /b 2
)
py -3.12 -c "import sys; assert sys.maxsize > 2**32; assert sys.version_info[:2] == (3,12)"
if errorlevel 1 (
  echo [ERROR] Python 3.12 x64 is required for build.
  pause
  exit /b 2
)
if not exist ".venv-onefile\Scripts\python.exe" py -3.12 -m venv .venv-onefile
if not exist ".venv-onefile\Scripts\python.exe" (echo [ERROR] Cannot create venv. & pause & exit /b 3)
".venv-onefile\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 (echo [ERROR] pip install failed. & pause & exit /b 4)
".venv-onefile\Scripts\python.exe" -m pip install -r requirements.txt "pyinstaller==6.16.0" "pywin32>=306" "pythonnet>=3.0"
if errorlevel 1 (echo [ERROR] Package installation failed. & pause & exit /b 5)
".venv-onefile\Scripts\python.exe" tools\build_windows_onefile.py
if errorlevel 1 (echo [ERROR] One-file EXE build failed. & pause & exit /b 6)
echo.
echo ===================== SUCCESS =====================
echo Single EXE: dist\AutoProByEric_V1.7.16.exe
echo No separate Data/UI/README files are needed next to the EXE.
echo ===================================================
pause
