/* V1.7.15: additive per-HWND telemetry; no automation path depends on logging. */
(() => {
  const $id = id => document.getElementById(id);
  const queued = [];
  let syncing = false;
  let reading = false;
  const originalLog = window.log;
  if (typeof originalLog === 'function') {
    window.log = function(message, details) {
      originalLog.apply(this, arguments);
      const selector = $id('windowSelect');
      const hwnd = Number(selector?.value || 0);
      const category = typeof window.classifyUiLogCategory === 'function'
        ? window.classifyUiLogCategory(message) : 'INFO';
      queued.push({hwnd, message:String(message || ''), category,
        details:details && typeof details === 'object' ? details : {}});
      if (queued.length > 500) queued.splice(0, queued.length - 500);
    };
  }
  async function flush() {
    if (syncing || !queued.length || !window.pywebview?.api?.client_log_batch) return;
    syncing = true;
    const batch = queued.splice(0, 60);
    try {
      const result = await window.pywebview.api.client_log_batch(batch);
      if (!result?.ok) console.warn('Multi-account log write failed', result?.reason);
    } catch(e) {
      console.warn('Multi-account log writer unavailable', e);
    } finally { syncing = false; }
  }
  async function refresh() {
    if (reading || !window.pywebview?.api?.client_log_recent) return;
    // Avoid polling log files when the user is viewing other tabs.
    if (!$id('view-logs')?.classList.contains('active')) return;
    reading = true;
    try {
      const select = $id('logAccountFilter');
      const chosen = select?.value || 'ALL';
      const response = await window.pywebview.api.client_log_recent('ALL', 300);
      if (!response?.ok) return;
      const current = new Set(Array.from(select?.options || []).map(o=>o.value));
      const accounts = Array.isArray(response.accounts) ? response.accounts : [];
      for (const entry of accounts) {
        if (current.has(entry.id)) continue;
        const option = document.createElement('option');
        option.value = entry.id;
        option.textContent = (entry.title || 'Cửa sổ') + ' · ' + entry.id;
        select.appendChild(option);
      }
      // Show all observed accounts even if one account has no new events.
      const rows = (response.events || []).filter(e => chosen === 'ALL' || e.account_id === chosen);
      const host = $id('multiAccountLogPage');
      if (host) {
        const frag = document.createDocumentFragment();
        for (const entry of rows.slice(-100)) {
          const row = document.createElement('div'); row.className='MultiAccountRow';
          const time = document.createElement('time');
          const stamp = new Date(entry.timestamp);
          time.textContent = Number.isNaN(stamp.getTime()) ? '—' : stamp.toLocaleTimeString('vi-VN',{hour12:false});
          const title = document.createElement('span'); title.className='account';
          title.textContent = entry.title || ('HWND ' + entry.hwnd);
          title.title = 'Game PID ' + entry.game_pid + ' / HWND ' + entry.hwnd;
          const category = document.createElement('span'); category.className='kind'; category.textContent = entry.category || 'INFO';
          const message = document.createElement('span'); message.className='message'; message.textContent = entry.message || '';
          row.append(time, title, category, message); frag.appendChild(row);
        }
        host.replaceChildren(frag);
        if (!rows.length) host.textContent = 'Chưa có sự kiện cho cửa sổ đã chọn.';
        host.scrollTop = host.scrollHeight;
      }
      const count = $id('multiAccountLogCount');
      if (count) count.textContent = rows.length + ' sự kiện · ' + accounts.length + ' cửa sổ';
    } catch(e) { console.warn('Multi-account log read failed', e); }
    finally { reading = false; }
  }
  window.refreshMultiAccountLogs = refresh;
  window.openMultiAccountLogFolder = async () => {
    try { await window.pywebview.api.open_multi_account_logs(); }
    catch(e) { console.warn('Could not open account log folder', e); }
  };
  window.checkNonIntrusive = async () => {
    const label=$id('noMouseCheckState');
    const hwnd=Number($id('windowSelect')?.value || 0);
    try {
      const result=await window.pywebview.api.background_input_capability(hwnd);
      if (label) label.textContent = result.reason === 'NOT_VERIFIED_BY_GAME'
        ? 'PostMessage sẵn sàng; cần thử trực tiếp trong game'
        : ('Chưa hỗ trợ: ' + (result.reason || 'không rõ'));
      if (window.log) window.log('BACKGROUND_CAPABILITY_CHECK', result);
    } catch(e) { if(label)label.textContent='Không kiểm tra được'; }
  };
  setInterval(flush, 1200);
  setInterval(refresh, 3500);
  window.addEventListener('pywebviewready', () => {flush(); refresh();});
})();
