@echo off
setlocal
cd /d "%~dp0"
title Auto Pro By Eric

echo [AutoPro] Checking Python 3.12...
py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
if errorlevel 1 goto setup_required

echo [AutoPro] Checking required modules...
py -3.12 -c "import webview,pytesseract,mss,numpy,cv2; from PIL import Image" >nul 2>&1
if errorlevel 1 goto setup_required

echo [AutoPro] Starting...
rem V1.7.16-dev NoKey source build: no activation step.
py -3.12 AutoProByEric_Stage17_LockedUI_v1_8.py
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo Auto Pro exited with error code %RC%.
  echo Check the Python error and README_V1716.md.
  echo If this is an environment issue, run SETUP_AUTOPRO\CHECK_ENV.bat.
  pause
)
exit /b %RC%

:setup_required
echo.
echo Auto Pro environment is incomplete.
echo Run: SETUP_AUTOPRO\INSTALL_ALL.bat
echo.
pause
exit /b 2
